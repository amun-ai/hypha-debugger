// src/services/execute.ts
function isCspEvalError(e) {
  if (!e) return false;
  if (e instanceof EvalError) return true;
  const msg = String(e.message || e);
  return /unsafe-eval|Content Security Policy|call to .*Function/i.test(msg);
}
function autoReturn(code) {
  const trimmed = code.trim();
  if (/\breturn\b/.test(trimmed)) return trimmed;
  let lines = trimmed.split("\n").map((l) => l.trim()).filter(Boolean);
  if (lines.length === 1 && lines[0].includes(";")) {
    lines = lines[0].split(";").map((s) => s.trim()).filter(Boolean);
  }
  if (lines.length === 0) return trimmed;
  const lastLine = lines[lines.length - 1];
  if (/^(if|for|while|switch|try|class|function |const |let |var |import |export )/.test(lastLine)) {
    return trimmed;
  }
  lines[lines.length - 1] = "return (" + lastLine.replace(/;$/, "") + ");";
  return lines.join(";\n");
}
async function executeScript(code, timeout_ms) {
  const timeoutMs = timeout_ms ?? 1e4;
  try {
    let execCode = autoReturn(code);
    let fn;
    try {
      fn = new Function("return (async () => {" + execCode + "})()");
    } catch (e) {
      if (isCspEvalError(e)) {
        return {
          error: "execute_script is unavailable on this page: its Content Security Policy blocks dynamic code evaluation ('unsafe-eval' not allowed). Use the DOM/interaction services (get_browser_state, click_element_by_index, query_dom, etc.) instead \u2014 they do not need eval."
        };
      }
      fn = new Function("return (async () => {" + code + "})()");
    }
    const result = await Promise.race([
      fn(),
      new Promise(
        (_, reject) => setTimeout(() => reject(new Error("Execution timed out")), timeoutMs)
      )
    ]);
    let serialized;
    let type = typeof result;
    try {
      if (result === void 0) {
        serialized = null;
        type = "undefined";
      } else if (result instanceof HTMLElement) {
        serialized = {
          tag: result.tagName.toLowerCase(),
          id: result.id,
          className: result.className,
          text: (result.textContent ?? "").trim().slice(0, 500)
        };
        type = "HTMLElement";
      } else if (result instanceof NodeList || result instanceof HTMLCollection) {
        serialized = Array.from(result).map((el) => ({
          tag: el.tagName?.toLowerCase(),
          id: el.id,
          text: (el.textContent ?? "").trim().slice(0, 200)
        }));
        type = "NodeList";
      } else {
        serialized = JSON.parse(JSON.stringify(result));
      }
    } catch {
      serialized = String(result);
      type = "string (serialized)";
    }
    return { result: serialized, type };
  } catch (err) {
    return { error: `Execution error: ${err.message ?? err}` };
  }
}
executeScript.__schema__ = {
  name: "executeScript",
  description: `Execute arbitrary JavaScript code in the page context. Supports async/await. The last expression is auto-returned (no need for explicit "return"). Examples: "document.title", "document.querySelectorAll('a').length", "await fetch('/api/data').then(r => r.json())". Returns: { result, type } on success, or { error } on exception.`,
  parameters: {
    type: "object",
    properties: {
      code: {
        type: "string",
        description: `JavaScript code to execute. The last expression is automatically returned. Examples: "document.title", "document.querySelector('h1').textContent".`
      },
      timeout_ms: {
        type: "number",
        description: "Maximum execution time in milliseconds. Default: 10000."
      }
    },
    required: ["code"]
  }
};

// ../extension/src/browser-tools.ts
var attached = /* @__PURE__ */ new Set();
async function ensureAttached(tabId) {
  if (attached.has(tabId)) return;
  await chrome.debugger.attach({ tabId }, "1.3");
  attached.add(tabId);
  try {
    await chrome.debugger.sendCommand({ tabId }, "Page.enable");
    await chrome.debugger.sendCommand({ tabId }, "Page.setBypassCSP", { enabled: true });
    await chrome.debugger.sendCommand({ tabId }, "Runtime.enable");
  } catch {
  }
}
async function detachAll() {
  for (const id of [...attached]) {
    try {
      await chrome.debugger.detach({ tabId: id });
    } catch {
    }
  }
  attached.clear();
}
function forgetTab(tabId) {
  attached.delete(tabId);
}
async function cdpEval(tabId, code) {
  try {
    await ensureAttached(tabId);
  } catch (e) {
    return {
      error: "Could not attach the Chrome debugger to this tab: " + (e?.message ?? e) + " (restricted page like chrome:// or the Web Store, or another debugger is already attached)."
    };
  }
  const expression = `(async () => { ${autoReturn(code)} })()`;
  const res = await chrome.debugger.sendCommand({ tabId }, "Runtime.evaluate", {
    expression,
    returnByValue: true,
    awaitPromise: true,
    userGesture: true
  });
  if (res?.exceptionDetails) {
    const ex = res.exceptionDetails;
    return { error: ex.exception?.description || ex.exception?.value || ex.text || "Evaluation error" };
  }
  const r = res?.result || {};
  return { result: r.value !== void 0 ? r.value : r.description ?? null, type: r.type };
}
async function cdpScreenshot(tabId, opts) {
  try {
    await ensureAttached(tabId);
  } catch (e) {
    return { error: "Could not attach the Chrome debugger to this tab: " + (e?.message ?? e) };
  }
  const send = (m, p) => chrome.debugger.sendCommand({ tabId }, m, p || {});
  try {
    const fmt = opts.format === "png" ? "png" : "jpeg";
    const q = Math.max(0, Math.min(1, opts.quality ?? 0.6));
    const maxW = opts.max_width ?? 800;
    const maxH = opts.max_height ?? 800;
    const metrics = await send("Page.getLayoutMetrics");
    const css = metrics.cssContentSize || metrics.contentSize || { width: 1280, height: 800 };
    const vp = metrics.cssVisualViewport || {};
    let clip;
    if (opts.selector) {
      const r = await send("Runtime.evaluate", {
        expression: `(()=>{const e=document.querySelector(${JSON.stringify(
          opts.selector
        )});if(!e)return null;const b=e.getBoundingClientRect();return {x:b.left+scrollX,y:b.top+scrollY,width:b.width,height:b.height};})()`,
        returnByValue: true
      });
      const v = r?.result?.value;
      if (!v) return { error: `No element found for selector: ${opts.selector}` };
      clip = v;
    } else if (opts.full_page) {
      clip = { x: 0, y: 0, width: Math.ceil(css.width), height: Math.ceil(css.height) };
    } else {
      clip = {
        x: vp.pageX || 0,
        y: vp.pageY || 0,
        width: Math.ceil(vp.clientWidth || css.width),
        height: Math.ceil(vp.clientHeight || 800)
      };
    }
    if (!clip.width || !clip.height) return { error: "Could not determine screenshot area" };
    const scale = Math.min(1, maxW / clip.width, maxH / clip.height);
    const params = {
      format: fmt,
      captureBeyondViewport: true,
      clip: { ...clip, scale }
    };
    if (fmt === "jpeg") params.quality = Math.round(q * 100);
    const shot = await send("Page.captureScreenshot", params);
    const base64 = shot.data;
    const media_type = fmt === "png" ? "image/png" : "image/jpeg";
    return {
      base64,
      media_type,
      data_url: `data:${media_type};base64,${base64}`,
      format: fmt,
      width: Math.round(clip.width * scale),
      height: Math.round(clip.height * scale),
      size_kb: Math.round(base64.length * 0.75 / 1024)
    };
  } catch (e) {
    return { error: "Screenshot failed: " + (e?.message ?? e) };
  }
}
function originOf(url) {
  try {
    return new URL(url).origin;
  } catch {
    return "";
  }
}
function tabSummary(t) {
  return {
    id: t.id,
    title: t.title,
    url: t.url,
    origin: originOf(t.url),
    // pass this to the site-skill tools
    active: t.active,
    window_id: t.windowId,
    status: t.status
  };
}
async function resolveTarget(ctx2) {
  let id = ctx2.getTarget();
  if (id != null) {
    try {
      await chrome.tabs.get(id);
      return id;
    } catch {
    }
  }
  const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!active) throw new Error("No active tab");
  ctx2.setTarget(active.id);
  return active.id;
}
var SKILLS_KEY = "hyphaSiteSkills";
function normEntry(e) {
  if (e == null) return { description: "", content: "" };
  if (typeof e === "string") {
    const desc = e.split("\n").map((l) => l.trim()).find(Boolean)?.replace(/^#+\s*/, "").slice(0, 160) || "";
    return { description: desc, content: e };
  }
  return { description: e.description || "", content: e.content || "" };
}
function normName(s) {
  return String(s || "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/-+/g, "-").replace(/^-+|-+$/g, "").slice(0, 64).replace(/^-+|-+$/g, "");
}
function toSkillMd(name, e) {
  const desc = e.description.replace(/\r?\n/g, " ").trim();
  return `---
name: ${name}
description: ${desc}
---

${e.content}`;
}
async function loadAllSkills() {
  const r = await chrome.storage.local.get(SKILLS_KEY);
  return r[SKILLS_KEY] || {};
}
async function saveAllSkills(all) {
  await chrome.storage.local.set({ [SKILLS_KEY]: all });
}
var SYNC_META = "hyphaSkillsMeta";
var SYNC_PREFIX = "hyphaSkillsChunk";
var SYNC_CHUNK = 7e3;
async function writeSyncChunks(obj, partial) {
  const json = JSON.stringify(obj || {});
  const chunks = [];
  for (let i = 0; i < json.length; i += SYNC_CHUNK) chunks.push(json.slice(i, i + SYNC_CHUNK));
  const prev = (await chrome.storage.sync.get(SYNC_META))[SYNC_META];
  const prevN = prev?.chunks || 0;
  const set = { [SYNC_META]: { chunks: chunks.length, partial } };
  chunks.forEach((c, i) => set[SYNC_PREFIX + i] = c);
  await chrome.storage.sync.set(set);
  if (prevN > chunks.length) {
    const rm = [];
    for (let i = chunks.length; i < prevN; i++) rm.push(SYNC_PREFIX + i);
    await chrome.storage.sync.remove(rm);
  }
}
function catalogOnly(all) {
  const out = {};
  for (const [o, site] of Object.entries(all || {})) {
    out[o] = {};
    for (const [n, e] of Object.entries(site)) out[o][n] = { description: normEntry(e).description, content: "" };
  }
  return out;
}
async function mirrorSkillsToSync(all) {
  if (!chrome.storage?.sync) return;
  try {
    await writeSyncChunks(all || {}, false);
  } catch {
    try {
      await writeSyncChunks(catalogOnly(all || {}), true);
      console.warn(
        "[hypha] site skills exceed Chrome sync quota \u2014 backed up the catalog (names + descriptions) only. Use Export in the side panel for a full backup."
      );
    } catch (e2) {
      console.warn("[hypha] skill sync mirror failed:", e2);
    }
  }
}
async function readSkillsFromSync() {
  if (!chrome.storage?.sync) return null;
  try {
    const meta = (await chrome.storage.sync.get(SYNC_META))[SYNC_META];
    if (!meta?.chunks) return null;
    const keys = Array.from({ length: meta.chunks }, (_, i) => SYNC_PREFIX + i);
    const got = await chrome.storage.sync.get(keys);
    let json = "";
    for (let i = 0; i < meta.chunks; i++) json += got[SYNC_PREFIX + i] || "";
    return JSON.parse(json);
  } catch (e) {
    console.warn("[hypha] skill sync read failed:", e);
    return null;
  }
}
async function hydrateSkillsFromSync() {
  try {
    const local = await loadAllSkills();
    if (Object.keys(local).length) return;
    const synced = await readSkillsFromSync();
    if (synced && Object.keys(synced).length) {
      await chrome.storage.local.set({ [SKILLS_KEY]: synced });
      console.log("[hypha] restored site skills from sync backup");
    }
  } catch (e) {
    console.warn("[hypha] skill hydrate failed:", e);
  }
}
async function siteFor(ctx2, explicit) {
  if (explicit) return explicit;
  const t = await chrome.tabs.get(await resolveTarget(ctx2));
  return originOf(t.url) || t.url || "unknown";
}
async function skillIndexForOrigin(origin) {
  const site = (await loadAllSkills())[origin] || {};
  return Object.entries(site).map(([name, e]) => ({
    name,
    description: normEntry(e).description
  }));
}
var BROWSER_TOOLS = {
  list_tabs: {
    schema: {
      name: "list_tabs",
      description: "List all open browser tabs across windows. Returns id, title, url, active, window_id, status. Use the id with activate_tab / close_tab / navigate.",
      parameters: { type: "object", properties: {} }
    },
    run: async () => (await chrome.tabs.query({})).map(tabSummary)
  },
  get_active_tab: {
    schema: {
      name: "get_active_tab",
      description: "Get the currently targeted tab (the tab that page-level tools act on). Defaults to the browser's active tab.",
      parameters: { type: "object", properties: {} }
    },
    run: async (ctx2) => {
      const id = await resolveTarget(ctx2);
      return tabSummary(await chrome.tabs.get(id));
    }
  },
  open_tab: {
    schema: {
      name: "open_tab",
      description: "Open a new tab at a URL and make it the target for page-level tools. Returns the new tab.",
      parameters: {
        type: "object",
        properties: {
          url: { type: "string", description: "URL to open (include https://)" },
          focus: { type: "boolean", description: "Focus the new tab (default true)" }
        },
        required: ["url"]
      }
    },
    run: async (ctx2, [url, focus = true]) => {
      const active = ctx2.forceBackground?.() ? false : !!focus;
      const t = await chrome.tabs.create({ url, active });
      ctx2.setTarget(t.id);
      return tabSummary({ ...t, url: t.url || url });
    }
  },
  close_tab: {
    schema: {
      name: "close_tab",
      description: "Close a tab by id.",
      parameters: {
        type: "object",
        properties: { tab_id: { type: "number", description: "Tab id to close" } },
        required: ["tab_id"]
      }
    },
    run: async (_ctx, [tab_id]) => {
      await chrome.tabs.remove(tab_id);
      return { success: true };
    }
  },
  activate_tab: {
    schema: {
      name: "activate_tab",
      description: "Make a tab the target for page-level tools (get_browser_state, click_element_by_index, screenshot, \u2026). By default it also brings the tab to the front; in 'work in background' mode it just retargets without stealing focus.",
      parameters: {
        type: "object",
        properties: { tab_id: { type: "number", description: "Tab id to target" } },
        required: ["tab_id"]
      }
    },
    run: async (ctx2, [tab_id]) => {
      const bg = ctx2.forceBackground?.();
      if (!bg) {
        const t = await chrome.tabs.get(tab_id);
        await chrome.tabs.update(tab_id, { active: true });
        try {
          await chrome.windows.update(t.windowId, { focused: true });
        } catch {
        }
      }
      ctx2.setTarget(tab_id);
      return { success: true, background: !!bg, tab: tabSummary(await chrome.tabs.get(tab_id)) };
    }
  },
  navigate: {
    schema: {
      name: "navigate",
      description: "Navigate the target tab to a URL (full page load). Use open_tab to navigate in a new tab instead.",
      parameters: {
        type: "object",
        properties: { url: { type: "string", description: "URL to navigate to" } },
        required: ["url"]
      }
    },
    run: async (ctx2, [url]) => {
      const id = await resolveTarget(ctx2);
      await chrome.tabs.update(id, { url });
      return { success: true, url };
    }
  },
  reload_tab: {
    schema: {
      name: "reload_tab",
      description: "Reload the target tab.",
      parameters: {
        type: "object",
        properties: {
          bypass_cache: { type: "boolean", description: "Hard reload (default false)" }
        }
      }
    },
    run: async (ctx2, [bypass_cache = false]) => {
      const id = await resolveTarget(ctx2);
      await chrome.tabs.reload(id, { bypassCache: !!bypass_cache });
      return { success: true };
    }
  },
  go_back: {
    schema: {
      name: "go_back",
      description: "Go back in the target tab's history.",
      parameters: { type: "object", properties: {} }
    },
    run: async (ctx2) => {
      await chrome.tabs.goBack(await resolveTarget(ctx2));
      return { success: true };
    }
  },
  go_forward: {
    schema: {
      name: "go_forward",
      description: "Go forward in the target tab's history.",
      parameters: { type: "object", properties: {} }
    },
    run: async (ctx2) => {
      await chrome.tabs.goForward(await resolveTarget(ctx2));
      return { success: true };
    }
  },
  execute_script: {
    schema: {
      name: "execute_script",
      description: "Run arbitrary JavaScript in the target tab's page context and return the result. Uses the Chrome debugger (Page.setBypassCSP), so it works even on strict-CSP pages that block 'unsafe-eval'. The last expression is auto-returned; async code is awaited. Attaching shows Chrome's 'debugging this browser' banner.",
      parameters: {
        type: "object",
        properties: { code: { type: "string", description: "JavaScript to execute" } },
        required: ["code"]
      }
    },
    run: async (ctx2, [code]) => cdpEval(await resolveTarget(ctx2), String(code ?? ""))
  },
  take_screenshot: {
    schema: {
      name: "take_screenshot",
      description: "Capture a screenshot of the target tab via the Chrome debugger (Page.captureScreenshot) \u2014 works reliably even when the tab is NOT in the foreground (unlike DOM-rasterizing approaches that stall on background tabs). Capture the viewport, a specific element (selector), or the full page. Downscaled to fit max_width \xD7 max_height (default 800px) and JPEG-encoded at quality 0.6 by default. Returns { base64, media_type, data_url, format, width, height, size_kb }. Use `base64` (raw, no prefix) directly with Claude/GPT image content fields; `data_url` for HTML <img src=...> previews. On failure returns { error }.",
      parameters: {
        type: "object",
        properties: {
          selector: { type: "string", description: "CSS selector of the element to capture. Omit for the viewport (or full page if full_page=true)." },
          format: { type: "string", enum: ["png", "jpeg"], description: "Image format. Default: jpeg (smaller). Use png only when sharp text matters." },
          quality: { type: "number", description: "JPEG quality 0\u20131. Default 0.6. Ignored for PNG." },
          max_width: { type: "number", description: "Max output width in px. Default 800. Scaled down preserving aspect ratio." },
          max_height: { type: "number", description: "Max output height in px. Default 800. Scaled down preserving aspect ratio." },
          full_page: { type: "boolean", description: "If true, capture the entire scrollable page instead of just the viewport. Default false." }
        }
      }
    },
    run: async (ctx2, [selector, format, quality, max_width, max_height, full_page]) => cdpScreenshot(await resolveTarget(ctx2), { selector, format, quality, max_width, max_height, full_page })
  },
  // ---- skill memory (accumulate per-origin know-how across sessions) ------
  // Every skill is BOUND TO A SITE ORIGIN and identified by a NAME. Listing
  // returns name + description; the name is the key to read the full content.
  list_site_skills: {
    schema: {
      name: "list_site_skills",
      description: "List saved site skills grouped BY SITE ORIGIN. Each skill is a markdown note about one operation type (search, export, create, login, \u2026) learned in past sessions. Returns each skill's NAME and DESCRIPTION (not the full content) \u2014 read the full markdown with get_site_skill(origin, name). With no argument, returns every origin with its skills. Pass `origin` to list just that site's. Call this FIRST when you start on a site so you reuse skills instead of re-exploring.",
      parameters: {
        type: "object",
        properties: {
          origin: {
            type: "string",
            description: "Site origin, e.g. https://example.com (from tab/browser info). Omit to list all origins."
          }
        }
      }
    },
    run: async (_ctx, [origin]) => {
      const all = await loadAllSkills();
      const indexOf = (o) => Object.entries(all[o] || {}).map(([name, e]) => ({
        name,
        description: normEntry(e).description
      }));
      if (origin) {
        const skills = indexOf(String(origin));
        return { origin: String(origin), skills, count: skills.length };
      }
      const sites = {};
      for (const o of Object.keys(all)) sites[o] = indexOf(o);
      return { sites, site_count: Object.keys(sites).length };
    }
  },
  get_site_skill: {
    schema: {
      name: "get_site_skill",
      description: "Read one saved site skill \u2014 returns it as an agentskills.io SKILL.md (frontmatter + body) plus the separate description and content. Pass the site `origin` and the skill `name` (both from list_site_skills; the origin is also in tab/browser info). Read before updating so you extend rather than overwrite it.",
      parameters: {
        type: "object",
        properties: {
          origin: { type: "string", description: "Site origin, e.g. https://example.com" },
          name: { type: "string", description: "Skill name (the key from list_site_skills)" }
        },
        required: ["origin", "name"]
      }
    },
    run: async (ctx2, [origin, name]) => {
      const o = await siteFor(ctx2, origin);
      const site = (await loadAllSkills())[o] || {};
      const raw = site[String(name)];
      if (raw == null) {
        const available = Object.keys(site);
        return {
          origin: o,
          name,
          found: false,
          available,
          hint: available.length ? `No skill named '${name}' for ${o}. Available: ${available.join(", ")}. Use list_site_skills(origin) to see names + descriptions.` : `No skills saved for ${o} yet. Explore, then save one with set_site_skill(origin, name, description, content).`
        };
      }
      const e = normEntry(raw);
      return {
        origin: o,
        name,
        found: true,
        description: e.description,
        content: e.content,
        skill_md: toSkillMd(String(name), e)
      };
    }
  },
  set_site_skill: {
    schema: {
      name: "set_site_skill",
      description: "Save or update a site skill \u2014 an Agent Skill (agentskills.io) BOUND TO A SITE ORIGIN. It captures your experience doing ONE type of operation on this site (e.g. searching, exporting a report, creating an item, logging in). Provide: `name` \u2014 the skill name / key, 1-64 chars, lowercase letters/numbers/hyphens (e.g. 'search', 'export-report'); `description` \u2014 one line (\u22641024 chars) saying what it does and when to use it (shown in list_site_skills); `content` \u2014 the markdown SKILL.md body: what works, the execute_script JS snippet or discovered API endpoint+params, key selectors/element indices, the steps, and gotchas. Pass `origin` (from tab/browser info) so it's stored under the right site; defaults to the current target tab's origin. A site can have many skills. To update, read the entry, edit, and set it again under the same name.",
      parameters: {
        type: "object",
        properties: {
          origin: {
            type: "string",
            description: "Site origin to bind this skill to. Defaults to the current tab's origin."
          },
          name: { type: "string", description: "Skill name / key: 1-64 chars, lowercase a-z, 0-9, hyphens (e.g. 'export-report')" },
          description: { type: "string", description: "One line (\u22641024 chars): what the skill does and when to use it" },
          content: { type: "string", description: "SKILL.md markdown body: how to do this operation (recipe, JS/API, selectors, steps, gotchas)" }
        },
        required: ["name", "description", "content"]
      }
    },
    run: async (ctx2, [origin, name, description, content]) => {
      const o = await siteFor(ctx2, origin);
      const nm = normName(name);
      if (!nm) {
        return {
          success: false,
          error: "Invalid skill name. Use 1-64 chars: lowercase letters, numbers and single hyphens, e.g. 'export-report'."
        };
      }
      const desc = String(description ?? "").replace(/\r?\n/g, " ").trim().slice(0, 1024);
      if (!desc) {
        return { success: false, error: "A non-empty `description` is required (\u22641024 chars)." };
      }
      const all = await loadAllSkills();
      all[o] = all[o] || {};
      const renamed = nm !== String(name);
      all[o][nm] = { description: desc, content: String(content ?? "") };
      await saveAllSkills(all);
      return {
        success: true,
        origin: o,
        name: nm,
        ...renamed ? { note: `name normalized to '${nm}' (agentskills naming rules)` } : {},
        count: Object.keys(all[o]).length
      };
    }
  },
  remove_site_skill: {
    schema: {
      name: "remove_site_skill",
      description: "Delete an outdated skill entry. Pass the site `origin` (from tab/browser info) and the skill `name`.",
      parameters: {
        type: "object",
        properties: {
          origin: { type: "string", description: "Site origin the skill is bound to" },
          name: { type: "string", description: "Skill name to delete" }
        },
        required: ["origin", "name"]
      }
    },
    run: async (ctx2, [origin, name]) => {
      const o = await siteFor(ctx2, origin);
      const all = await loadAllSkills();
      const had = !!(all[o] && String(name) in all[o]);
      if (all[o]) delete all[o][String(name)];
      await saveAllSkills(all);
      return { success: true, origin: o, name, removed: had };
    }
  }
};
var BROWSER_TOOL_NAMES = new Set(Object.keys(BROWSER_TOOLS));

// ../extension/src/background.ts
var SKILL_MGMT = /* @__PURE__ */ new Set([
  "list_site_skills",
  "get_site_skill",
  "set_site_skill",
  "remove_site_skill"
]);
async function attachSiteSkills(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return;
  if (targetTabId == null) return;
  try {
    let origin = "";
    const cand = value.origin || value.url || value.tab?.url;
    try {
      if (cand) origin = new URL(cand).origin;
    } catch {
    }
    if (!origin) {
      const t = await chrome.tabs.get(targetTabId);
      origin = new URL(t.url).origin;
    }
    value.origin = origin;
    const index = await skillIndexForOrigin(origin);
    value.site_skills = index;
    if (index.length) {
      value.site_skills_hint = `${index.length} saved skill(s) for ${origin}: ${index.map((s) => s.name).join(", ")}. REUSE these before exploring \u2014 read a full entry with get_site_skill(origin, name); refine with set_site_skill(origin, name, description, content).`;
    } else {
      value.site_skills_hint = `No site skills saved for ${origin} yet. Explore once, then work efficiently (prefer execute_script with the site's own APIs, and batch operations), and capture what you learn with set_site_skill(origin, name, description, content) so next time on this site is faster and cheaper.`;
    }
  } catch {
  }
}
var targetTabId = null;
var forceBackground = false;
var ctx = {
  getTarget: () => targetTabId,
  setTarget: (id) => {
    targetTabId = id;
    try {
      chrome.storage.local.set({ hyphaTarget: id });
    } catch {
    }
    void emitTarget(id);
  },
  forceBackground: () => forceBackground
};
async function hydrateForceBackground() {
  try {
    forceBackground = !!(await chrome.storage.local.get("hyphaForceBackground")).hyphaForceBackground;
  } catch {
  }
}
async function hydrateTarget() {
  try {
    const r = await chrome.storage.local.get("hyphaTarget");
    const id = r.hyphaTarget;
    if (id != null) {
      try {
        await chrome.tabs.get(id);
        targetTabId = id;
        return;
      } catch {
        await chrome.storage.local.remove("hyphaTarget");
      }
    }
    targetTabId = null;
  } catch {
  }
}
async function emitTarget(id) {
  try {
    const t = await chrome.tabs.get(id);
    ui({ type: "target", tab: { id: t.id, title: t.title, url: t.url } });
  } catch {
  }
}
var creating = null;
async function ensureOffscreen() {
  const has = await hasOffscreen();
  if (has) return;
  if (!creating) {
    creating = chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["WORKERS", "DOM_SCRAPING"],
      justification: "Hold the persistent Hypha RPC WebSocket connection (needs a DOM and a stable lifetime)."
    }).catch((e) => {
      if (!String(e?.message || e).includes("single offscreen")) throw e;
    }).finally(() => {
      creating = null;
    });
  }
  await creating;
}
async function hasOffscreen() {
  try {
    const c = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
    return c.length > 0;
  } catch {
    return false;
  }
}
async function ensureContent(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["main-world.js"],
      world: "MAIN"
    });
  } catch (e) {
    throw new Error(
      "Cannot attach to this tab (a restricted page like chrome:// or the Web Store?): " + (e?.message ?? e)
    );
  }
}
async function handleCall(method, args) {
  ui({ type: "log", msg: `${method}(${summarize(args)})`, kind: "call" });
  await hydrateTarget();
  await hydrateForceBackground();
  try {
    let value;
    if (BROWSER_TOOL_NAMES.has(method)) {
      value = await BROWSER_TOOLS[method].run(ctx, args || []);
    } else {
      let tabId = targetTabId;
      if (tabId == null) {
        const [a] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
        if (a?.id != null) {
          ctx.setTarget(a.id);
          tabId = a.id;
        }
      }
      if (tabId == null) throw new Error("No target tab \u2014 open or activate a tab first");
      await ensureContent(tabId);
      const res = await chrome.tabs.sendMessage(tabId, { __hyphaPage: true, method, args });
      if (res && res.__error) throw new Error(res.__error);
      value = res ? res.value : void 0;
    }
    const isErr = value && typeof value === "object" && "error" in value;
    if (!isErr && !SKILL_MGMT.has(method)) await attachSiteSkills(value);
    ui({ type: "log", msg: isErr ? `${method}: ${value.error}` : `${method} -> ok`, kind: isErr ? "error" : "result" });
    return value;
  } catch (e) {
    ui({ type: "log", msg: `${method}: ${e?.message ?? e}`, kind: "error" });
    throw e;
  }
}
async function connectBrowser(config) {
  try {
    const [a] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (a?.id != null) ctx.setTarget(a.id);
    await chrome.storage.local.set({ hyphaConnected: true, hyphaConfig: config });
    await ensureOffscreen();
    chrome.runtime.sendMessage({ __off: "connect", config }).catch(() => {
    });
  } catch (e) {
    ui({ type: "status", status: "error", detail: "setup failed: " + (e?.message ?? e) });
  }
}
async function pinActiveTab() {
  const [a] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (a?.id != null) ctx.setTarget(a.id);
}
async function focusTarget() {
  await hydrateTarget();
  if (targetTabId == null) return;
  try {
    const t = await chrome.tabs.get(targetTabId);
    await chrome.tabs.update(targetTabId, { active: true });
    await chrome.windows.update(t.windowId, { focused: true });
  } catch {
  }
}
async function disconnectBrowser() {
  await chrome.storage.local.set({ hyphaConnected: false });
  chrome.runtime.sendMessage({ __off: "disconnect" }).catch(() => {
  });
  await detachAll();
}
async function reconcile() {
  const r = await chrome.storage.local.get(["hyphaConnected", "hyphaConfig"]);
  if (r.hyphaConnected && r.hyphaConfig) {
    await ensureOffscreen();
    chrome.runtime.sendMessage({ __off: "connect", config: r.hyphaConfig }).catch(() => {
    });
  }
}
async function persistUi(msg) {
  if (msg.type === "ready") {
    await chrome.storage.local.set({
      hyphaStatus: "connected",
      hyphaServiceUrl: msg.service_url || "",
      hyphaToken: msg.token || "",
      hyphaWorkspace: msg.workspace || ""
    });
  } else if (msg.type === "status") {
    if (msg.status === "disconnected" || msg.status === "error") {
      await chrome.storage.local.set({ hyphaStatus: msg.status, hyphaServiceUrl: "" });
    } else if (msg.status === "connecting" || msg.status === "connected") {
      await chrome.storage.local.set({ hyphaStatus: msg.status });
    }
  }
}
function ui(data) {
  chrome.runtime.sendMessage({ __ui: true, ...data }).catch(() => {
  });
}
function summarize(args) {
  if (!args || !args.length) return "";
  return args.map(
    (a) => typeof a === "string" ? a.length > 40 ? a.slice(0, 40) + "\u2026" : a : typeof a === "object" && a ? "{\u2026}" : String(a)
  ).join(", ");
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || typeof msg !== "object") return;
  if (msg.__hyphaCall) {
    handleCall(msg.method, msg.args).then((value) => sendResponse({ value })).catch((e) => sendResponse({ __error: e?.message ?? String(e) }));
    return true;
  }
  if (msg.__ui) {
    void persistUi(msg);
    return;
  }
  if (msg.__off === "offscreenReady") {
    void (async () => {
      const r = await chrome.storage.local.get(["hyphaConnected", "hyphaConfig"]);
      if (r.hyphaConnected && r.hyphaConfig)
        chrome.runtime.sendMessage({ __off: "connect", config: r.hyphaConfig }).catch(() => {
        });
    })();
    return;
  }
  if (msg.__ctl === "connect") {
    void connectBrowser(msg.config);
  } else if (msg.__ctl === "disconnect") {
    void disconnectBrowser();
  } else if (msg.__ctl === "pinActiveTab") {
    void pinActiveTab();
  } else if (msg.__ctl === "focusTarget") {
    void focusTarget();
  } else if (msg.__ctl === "getStatus") {
    void (async () => {
      const s = await chrome.storage.local.get([
        "hyphaStatus",
        "hyphaServiceUrl",
        "hyphaToken",
        "hyphaWorkspace"
      ]);
      if (s.hyphaServiceUrl) {
        ui({
          type: "ready",
          service_url: s.hyphaServiceUrl,
          token: s.hyphaToken || "",
          workspace: s.hyphaWorkspace || ""
        });
      } else if (s.hyphaStatus) {
        ui({ type: "status", status: s.hyphaStatus });
      }
      await hydrateTarget();
      if (targetTabId != null) await emitTarget(targetTabId);
    })();
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === targetTabId) targetTabId = null;
  forgetTab(tabId);
});
chrome.debugger?.onDetach?.addListener((source) => {
  if (source?.tabId != null) forgetTab(source.tabId);
});
chrome.storage?.onChanged?.addListener((changes, area) => {
  if (area === "local" && changes.hyphaSiteSkills) {
    void mirrorSkillsToSync(changes.hyphaSiteSkills.newValue || {});
  }
  if (area === "local" && changes.hyphaForceBackground) {
    forceBackground = !!changes.hyphaForceBackground.newValue;
  }
});
chrome.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: true }).catch(() => {
});
chrome.alarms?.create?.("hypha-keepalive", { periodInMinutes: 0.5 });
chrome.alarms?.onAlarm?.addListener((a) => {
  if (a.name === "hypha-keepalive") void reconcile();
});
chrome.runtime.onStartup?.addListener(() => {
  void reconcile();
  void hydrateSkillsFromSync();
});
chrome.runtime.onInstalled?.addListener(() => {
  void reconcile();
  void hydrateSkillsFromSync();
});
void reconcile();
void hydrateSkillsFromSync();
