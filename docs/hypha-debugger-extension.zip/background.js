// src/services/execute.ts
function isCspEvalError(e) {
  if (!e) return false;
  if (e instanceof EvalError) return true;
  const msg = String(e.message || e);
  return /unsafe-eval|Content Security Policy|call to .*Function/i.test(msg);
}
function autoReturn(code) {
  const trimmed = code.trim();
  if (/\breturn\b/.test(trimmed)) return trimmed;
  let lines = trimmed.split("\n").map((l) => l.trim()).filter(Boolean);
  if (lines.length === 1 && lines[0].includes(";")) {
    lines = lines[0].split(";").map((s) => s.trim()).filter(Boolean);
  }
  if (lines.length === 0) return trimmed;
  const lastLine = lines[lines.length - 1];
  if (/^(if|for|while|switch|try|class|function |const |let |var |import |export )/.test(lastLine)) {
    return trimmed;
  }
  lines[lines.length - 1] = "return (" + lastLine.replace(/;$/, "") + ");";
  return lines.join(";\n");
}
async function executeScript(code, timeout_ms) {
  const timeoutMs = timeout_ms ?? 1e4;
  try {
    let execCode = autoReturn(code);
    let fn;
    try {
      fn = new Function("return (async () => {" + execCode + "})()");
    } catch (e) {
      if (isCspEvalError(e)) {
        return {
          error: "execute_script is unavailable on this page: its Content Security Policy blocks dynamic code evaluation ('unsafe-eval' not allowed). Use the DOM/interaction services (get_browser_state, click_element_by_index, query_dom, etc.) instead \u2014 they do not need eval."
        };
      }
      fn = new Function("return (async () => {" + code + "})()");
    }
    const result = await Promise.race([
      fn(),
      new Promise(
        (_, reject) => setTimeout(() => reject(new Error("Execution timed out")), timeoutMs)
      )
    ]);
    let serialized;
    let type = typeof result;
    try {
      if (result === void 0) {
        serialized = null;
        type = "undefined";
      } else if (result instanceof HTMLElement) {
        serialized = {
          tag: result.tagName.toLowerCase(),
          id: result.id,
          className: result.className,
          text: (result.textContent ?? "").trim().slice(0, 500)
        };
        type = "HTMLElement";
      } else if (result instanceof NodeList || result instanceof HTMLCollection) {
        serialized = Array.from(result).map((el) => ({
          tag: el.tagName?.toLowerCase(),
          id: el.id,
          text: (el.textContent ?? "").trim().slice(0, 200)
        }));
        type = "NodeList";
      } else {
        serialized = JSON.parse(JSON.stringify(result));
      }
    } catch {
      serialized = String(result);
      type = "string (serialized)";
    }
    return { result: serialized, type };
  } catch (err) {
    return { error: `Execution error: ${err.message ?? err}` };
  }
}
executeScript.__schema__ = {
  name: "executeScript",
  description: `Execute arbitrary JavaScript code in the page context. Supports async/await. The last expression is auto-returned (no need for explicit "return"). Examples: "document.title", "document.querySelectorAll('a').length", "await fetch('/api/data').then(r => r.json())". Returns: { result, type } on success, or { error } on exception.`,
  parameters: {
    type: "object",
    properties: {
      code: {
        type: "string",
        description: `JavaScript code to execute. The last expression is automatically returned. Examples: "document.title", "document.querySelector('h1').textContent".`
      },
      timeout_ms: {
        type: "number",
        description: "Maximum execution time in milliseconds. Default: 10000."
      }
    },
    required: ["code"]
  }
};

// ../extension/src/browser-tools.ts
var attached = /* @__PURE__ */ new Set();
async function ensureAttached(tabId) {
  if (attached.has(tabId)) return;
  await chrome.debugger.attach({ tabId }, "1.3");
  attached.add(tabId);
  try {
    await chrome.debugger.sendCommand({ tabId }, "Page.enable");
    await chrome.debugger.sendCommand({ tabId }, "Page.setBypassCSP", { enabled: true });
    await chrome.debugger.sendCommand({ tabId }, "Runtime.enable");
  } catch {
  }
}
async function detachAll() {
  for (const id of [...attached]) {
    try {
      await chrome.debugger.detach({ tabId: id });
    } catch {
    }
  }
  attached.clear();
}
function forgetTab(tabId) {
  attached.delete(tabId);
}
async function cdpEval(tabId, code) {
  await ensureAttached(tabId);
  const expression = `(async () => { ${autoReturn(code)} })()`;
  const res = await chrome.debugger.sendCommand({ tabId }, "Runtime.evaluate", {
    expression,
    returnByValue: true,
    awaitPromise: true,
    userGesture: true,
    replMode: true
  });
  if (res?.exceptionDetails) {
    const ex = res.exceptionDetails;
    return { error: ex.exception?.description || ex.exception?.value || ex.text || "Evaluation error" };
  }
  const r = res?.result || {};
  return { result: r.value !== void 0 ? r.value : r.description ?? null, type: r.type };
}
function tabSummary(t) {
  return {
    id: t.id,
    title: t.title,
    url: t.url,
    active: t.active,
    window_id: t.windowId,
    status: t.status
  };
}
async function resolveTarget(ctx2) {
  let id = ctx2.getTarget();
  if (id != null) {
    try {
      await chrome.tabs.get(id);
      return id;
    } catch {
    }
  }
  const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!active) throw new Error("No active tab");
  ctx2.setTarget(active.id);
  return active.id;
}
var BROWSER_TOOLS = {
  list_tabs: {
    schema: {
      name: "list_tabs",
      description: "List all open browser tabs across windows. Returns id, title, url, active, window_id, status. Use the id with activate_tab / close_tab / navigate.",
      parameters: { type: "object", properties: {} }
    },
    run: async () => (await chrome.tabs.query({})).map(tabSummary)
  },
  get_active_tab: {
    schema: {
      name: "get_active_tab",
      description: "Get the currently targeted tab (the tab that page-level tools act on). Defaults to the browser's active tab.",
      parameters: { type: "object", properties: {} }
    },
    run: async (ctx2) => {
      const id = await resolveTarget(ctx2);
      return tabSummary(await chrome.tabs.get(id));
    }
  },
  open_tab: {
    schema: {
      name: "open_tab",
      description: "Open a new tab at a URL and make it the target for page-level tools. Returns the new tab.",
      parameters: {
        type: "object",
        properties: {
          url: { type: "string", description: "URL to open (include https://)" },
          focus: { type: "boolean", description: "Focus the new tab (default true)" }
        },
        required: ["url"]
      }
    },
    run: async (ctx2, [url, focus = true]) => {
      const t = await chrome.tabs.create({ url, active: !!focus });
      ctx2.setTarget(t.id);
      return tabSummary(t);
    }
  },
  close_tab: {
    schema: {
      name: "close_tab",
      description: "Close a tab by id.",
      parameters: {
        type: "object",
        properties: { tab_id: { type: "number", description: "Tab id to close" } },
        required: ["tab_id"]
      }
    },
    run: async (_ctx, [tab_id]) => {
      await chrome.tabs.remove(tab_id);
      return { success: true };
    }
  },
  activate_tab: {
    schema: {
      name: "activate_tab",
      description: "Focus a tab by id and make it the target for page-level tools (get_browser_state, click_element_by_index, screenshot, \u2026).",
      parameters: {
        type: "object",
        properties: { tab_id: { type: "number", description: "Tab id to target" } },
        required: ["tab_id"]
      }
    },
    run: async (ctx2, [tab_id]) => {
      const t = await chrome.tabs.get(tab_id);
      await chrome.tabs.update(tab_id, { active: true });
      try {
        await chrome.windows.update(t.windowId, { focused: true });
      } catch {
      }
      ctx2.setTarget(tab_id);
      return { success: true, tab: tabSummary(await chrome.tabs.get(tab_id)) };
    }
  },
  navigate: {
    schema: {
      name: "navigate",
      description: "Navigate the target tab to a URL (full page load). Use open_tab to navigate in a new tab instead.",
      parameters: {
        type: "object",
        properties: { url: { type: "string", description: "URL to navigate to" } },
        required: ["url"]
      }
    },
    run: async (ctx2, [url]) => {
      const id = await resolveTarget(ctx2);
      await chrome.tabs.update(id, { url });
      return { success: true, url };
    }
  },
  reload_tab: {
    schema: {
      name: "reload_tab",
      description: "Reload the target tab.",
      parameters: {
        type: "object",
        properties: {
          bypass_cache: { type: "boolean", description: "Hard reload (default false)" }
        }
      }
    },
    run: async (ctx2, [bypass_cache = false]) => {
      const id = await resolveTarget(ctx2);
      await chrome.tabs.reload(id, { bypassCache: !!bypass_cache });
      return { success: true };
    }
  },
  go_back: {
    schema: {
      name: "go_back",
      description: "Go back in the target tab's history.",
      parameters: { type: "object", properties: {} }
    },
    run: async (ctx2) => {
      await chrome.tabs.goBack(await resolveTarget(ctx2));
      return { success: true };
    }
  },
  go_forward: {
    schema: {
      name: "go_forward",
      description: "Go forward in the target tab's history.",
      parameters: { type: "object", properties: {} }
    },
    run: async (ctx2) => {
      await chrome.tabs.goForward(await resolveTarget(ctx2));
      return { success: true };
    }
  },
  execute_script: {
    schema: {
      name: "execute_script",
      description: "Run arbitrary JavaScript in the target tab's page context and return the result. Uses the Chrome debugger (Page.setBypassCSP), so it works even on strict-CSP pages that block 'unsafe-eval'. The last expression is auto-returned; async code is awaited. Attaching shows Chrome's 'debugging this browser' banner.",
      parameters: {
        type: "object",
        properties: { code: { type: "string", description: "JavaScript to execute" } },
        required: ["code"]
      }
    },
    run: async (ctx2, [code]) => cdpEval(await resolveTarget(ctx2), String(code ?? ""))
  }
};
var BROWSER_TOOL_NAMES = new Set(Object.keys(BROWSER_TOOLS));

// ../extension/src/background.ts
var targetTabId = null;
var ctx = {
  getTarget: () => targetTabId,
  setTarget: (id) => {
    targetTabId = id;
    try {
      chrome.storage.local.set({ hyphaTarget: id });
    } catch {
    }
    void emitTarget(id);
  }
};
async function hydrateTarget() {
  try {
    const r = await chrome.storage.local.get("hyphaTarget");
    const id = r.hyphaTarget;
    if (id != null) {
      try {
        await chrome.tabs.get(id);
        targetTabId = id;
        return;
      } catch {
        await chrome.storage.local.remove("hyphaTarget");
      }
    }
    targetTabId = null;
  } catch {
  }
}
async function emitTarget(id) {
  try {
    const t = await chrome.tabs.get(id);
    ui({ type: "target", tab: { id: t.id, title: t.title, url: t.url } });
  } catch {
  }
}
var creating = null;
async function ensureOffscreen() {
  const has = await hasOffscreen();
  if (has) return;
  if (!creating) {
    creating = chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["WORKERS", "DOM_SCRAPING"],
      justification: "Hold the persistent Hypha RPC WebSocket connection (needs a DOM and a stable lifetime)."
    }).catch((e) => {
      if (!String(e?.message || e).includes("single offscreen")) throw e;
    }).finally(() => {
      creating = null;
    });
  }
  await creating;
}
async function hasOffscreen() {
  try {
    const c = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
    return c.length > 0;
  } catch {
    return false;
  }
}
async function ensureContent(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["main-world.js"],
      world: "MAIN"
    });
  } catch (e) {
    throw new Error(
      "Cannot attach to this tab (a restricted page like chrome:// or the Web Store?): " + (e?.message ?? e)
    );
  }
}
async function handleCall(method, args) {
  ui({ type: "log", msg: `${method}(${summarize(args)})`, kind: "call" });
  await hydrateTarget();
  try {
    let value;
    if (BROWSER_TOOL_NAMES.has(method)) {
      value = await BROWSER_TOOLS[method].run(ctx, args || []);
    } else {
      let tabId = targetTabId;
      if (tabId == null) {
        const [a] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
        if (a?.id != null) {
          ctx.setTarget(a.id);
          tabId = a.id;
        }
      }
      if (tabId == null) throw new Error("No target tab \u2014 open or activate a tab first");
      await ensureContent(tabId);
      const res = await chrome.tabs.sendMessage(tabId, { __hyphaPage: true, method, args });
      if (res && res.__error) throw new Error(res.__error);
      value = res ? res.value : void 0;
    }
    const isErr = value && typeof value === "object" && "error" in value;
    ui({ type: "log", msg: isErr ? `${method}: ${value.error}` : `${method} -> ok`, kind: isErr ? "error" : "result" });
    return value;
  } catch (e) {
    ui({ type: "log", msg: `${method}: ${e?.message ?? e}`, kind: "error" });
    throw e;
  }
}
async function connectBrowser(config) {
  const [a] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (a?.id != null) ctx.setTarget(a.id);
  await chrome.storage.local.set({ hyphaConnected: true, hyphaConfig: config });
  await ensureOffscreen();
  chrome.runtime.sendMessage({ __off: "connect", config }).catch(() => {
  });
}
async function pinActiveTab() {
  const [a] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (a?.id != null) ctx.setTarget(a.id);
}
async function disconnectBrowser() {
  await chrome.storage.local.set({ hyphaConnected: false });
  chrome.runtime.sendMessage({ __off: "disconnect" }).catch(() => {
  });
  await detachAll();
}
async function reconcile() {
  const r = await chrome.storage.local.get(["hyphaConnected", "hyphaConfig"]);
  if (r.hyphaConnected && r.hyphaConfig) {
    await ensureOffscreen();
  }
}
function ui(data) {
  chrome.runtime.sendMessage({ __ui: true, ...data }).catch(() => {
  });
}
function summarize(args) {
  if (!args || !args.length) return "";
  return args.map(
    (a) => typeof a === "string" ? a.length > 40 ? a.slice(0, 40) + "\u2026" : a : typeof a === "object" && a ? "{\u2026}" : String(a)
  ).join(", ");
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || typeof msg !== "object") return;
  if (msg.__hyphaCall) {
    handleCall(msg.method, msg.args).then((value) => sendResponse({ value })).catch((e) => sendResponse({ __error: e?.message ?? String(e) }));
    return true;
  }
  if (msg.__ctl === "connect") {
    void connectBrowser(msg.config);
  } else if (msg.__ctl === "disconnect") {
    void disconnectBrowser();
  } else if (msg.__ctl === "pinActiveTab") {
    void pinActiveTab();
  } else if (msg.__ctl === "getStatus") {
    void (async () => {
      const s = await chrome.storage.local.get([
        "hyphaStatus",
        "hyphaServiceUrl",
        "hyphaToken",
        "hyphaWorkspace"
      ]);
      if (s.hyphaServiceUrl) {
        ui({
          type: "ready",
          service_url: s.hyphaServiceUrl,
          token: s.hyphaToken || "",
          workspace: s.hyphaWorkspace || ""
        });
      } else if (s.hyphaStatus) {
        ui({ type: "status", status: s.hyphaStatus });
      }
      await hydrateTarget();
      if (targetTabId != null) await emitTarget(targetTabId);
    })();
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === targetTabId) targetTabId = null;
  forgetTab(tabId);
});
chrome.debugger?.onDetach?.addListener((source) => {
  if (source?.tabId != null) forgetTab(source.tabId);
});
chrome.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: true }).catch(() => {
});
chrome.alarms?.create?.("hypha-keepalive", { periodInMinutes: 0.5 });
chrome.alarms?.onAlarm?.addListener((a) => {
  if (a.name === "hypha-keepalive") void reconcile();
});
chrome.runtime.onStartup?.addListener(() => void reconcile());
chrome.runtime.onInstalled?.addListener(() => void reconcile());
void reconcile();
