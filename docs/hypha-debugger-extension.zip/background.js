// ../extension/src/runtime-channel.ts
var RELAY_ENVELOPE = "__hyphaRelayEnvelope";

// ../extension/src/background.ts
var OFFSCREEN_PATH = "offscreen.html";
var STORE_KEY = "hyphaActiveConnections";
var creatingOffscreen = null;
async function ensureOffscreen() {
  const has = await (chrome.offscreen?.hasDocument?.() ?? hasOffscreenFallback());
  if (has) return;
  if (!creatingOffscreen) {
    creatingOffscreen = chrome.offscreen.createDocument({
      url: OFFSCREEN_PATH,
      reasons: ["WORKERS", "DOM_SCRAPING"],
      justification: "Hold the Hypha RPC WebSocket connection (needs a DOM and a stable lifetime)."
    }).catch((e) => {
      if (!String(e?.message || e).includes("single offscreen")) throw e;
    }).finally(() => {
      creatingOffscreen = null;
    });
  }
  await creatingOffscreen;
}
async function hasOffscreenFallback() {
  try {
    const ctxs = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
    return ctxs.length > 0;
  } catch {
    return false;
  }
}
async function getActive() {
  const r = await chrome.storage.local.get(STORE_KEY);
  return r[STORE_KEY] || {};
}
async function setActive(map) {
  await chrome.storage.local.set({ [STORE_KEY]: map });
}
async function connectTab(tabId, config) {
  await ensureOffscreen();
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["main-world.js"],
      world: "MAIN"
    });
  } catch (e) {
    console.warn("[hypha-bg] inject failed", e);
  }
  const active = await getActive();
  active[tabId] = config;
  await setActive(active);
  chrome.runtime.sendMessage({ __hyphaCtl: "createConnector", tabId, config }).catch(() => {
  });
}
async function disconnectTab(tabId) {
  const active = await getActive();
  delete active[tabId];
  await setActive(active);
  chrome.runtime.sendMessage({ __hyphaCtl: "destroyConnector", tabId }).catch(() => {
  });
  stampUi({ type: "status", status: "disconnected" }, tabId);
}
async function reconcile() {
  const active = await getActive();
  const tabIds = Object.keys(active);
  if (tabIds.length === 0) return;
  await ensureOffscreen();
  for (const idStr of tabIds) {
    const tabId = Number(idStr);
    try {
      await chrome.tabs.get(tabId);
      await connectTab(tabId, active[idStr]);
    } catch {
      delete active[idStr];
    }
  }
  await setActive(active);
}
function stampUi(data, tabId) {
  chrome.runtime.sendMessage({ __hyphaUi: true, __stamped: true, tabId, ...data }).catch(() => {
  });
}
chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!msg || typeof msg !== "object") return;
  if (msg[RELAY_ENVELOPE]) {
    if (msg.dir === "toConnector" && sender?.tab?.id != null) {
      chrome.runtime.sendMessage({ ...msg, tabId: sender.tab.id }).catch(() => {
      });
    } else if (msg.dir === "toAgent" && msg.tabId != null && !sender?.tab) {
      chrome.tabs.sendMessage(msg.tabId, msg).catch(() => {
      });
    }
    return;
  }
  if (msg.__hyphaUi && !msg.__stamped) {
    const tabId = sender?.tab?.id ?? msg.tabId;
    if (tabId != null) {
      const { __hyphaUi, tabId: _t, ...rest } = msg;
      stampUi(rest, tabId);
    }
    return;
  }
  if (msg.__hyphaCtl === "connect") {
    void connectTab(msg.tabId, msg.config);
    return;
  }
  if (msg.__hyphaCtl === "disconnect") {
    void disconnectTab(msg.tabId);
    return;
  }
  if (msg.__hyphaCtl === "getActive") {
    getActive().then((a) => chrome.runtime.sendMessage({ __hyphaUi: true, __stamped: true, type: "active", active: a }).catch(() => {
    }));
    return;
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  void disconnectTab(tabId);
});
chrome.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: true }).catch(() => {
});
chrome.runtime.onStartup?.addListener(() => void reconcile());
chrome.runtime.onInstalled?.addListener(() => void reconcile());
void reconcile();
