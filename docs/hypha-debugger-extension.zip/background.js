// ../extension/src/browser-tools.ts
function tabSummary(t) {
  return {
    id: t.id,
    title: t.title,
    url: t.url,
    active: t.active,
    window_id: t.windowId,
    status: t.status
  };
}
async function resolveTarget(ctx2) {
  let id = ctx2.getTarget();
  if (id != null) {
    try {
      await chrome.tabs.get(id);
      return id;
    } catch {
    }
  }
  const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!active) throw new Error("No active tab");
  ctx2.setTarget(active.id);
  return active.id;
}
var BROWSER_TOOLS = {
  list_tabs: {
    schema: {
      name: "list_tabs",
      description: "List all open browser tabs across windows. Returns id, title, url, active, window_id, status. Use the id with activate_tab / close_tab / navigate.",
      parameters: { type: "object", properties: {} }
    },
    run: async () => (await chrome.tabs.query({})).map(tabSummary)
  },
  get_active_tab: {
    schema: {
      name: "get_active_tab",
      description: "Get the currently targeted tab (the tab that page-level tools act on). Defaults to the browser's active tab.",
      parameters: { type: "object", properties: {} }
    },
    run: async (ctx2) => {
      const id = await resolveTarget(ctx2);
      return tabSummary(await chrome.tabs.get(id));
    }
  },
  open_tab: {
    schema: {
      name: "open_tab",
      description: "Open a new tab at a URL and make it the target for page-level tools. Returns the new tab.",
      parameters: {
        type: "object",
        properties: {
          url: { type: "string", description: "URL to open (include https://)" },
          focus: { type: "boolean", description: "Focus the new tab (default true)" }
        },
        required: ["url"]
      }
    },
    run: async (ctx2, [url, focus = true]) => {
      const t = await chrome.tabs.create({ url, active: !!focus });
      ctx2.setTarget(t.id);
      return tabSummary(t);
    }
  },
  close_tab: {
    schema: {
      name: "close_tab",
      description: "Close a tab by id.",
      parameters: {
        type: "object",
        properties: { tab_id: { type: "number", description: "Tab id to close" } },
        required: ["tab_id"]
      }
    },
    run: async (_ctx, [tab_id]) => {
      await chrome.tabs.remove(tab_id);
      return { success: true };
    }
  },
  activate_tab: {
    schema: {
      name: "activate_tab",
      description: "Focus a tab by id and make it the target for page-level tools (get_browser_state, click_element_by_index, screenshot, \u2026).",
      parameters: {
        type: "object",
        properties: { tab_id: { type: "number", description: "Tab id to target" } },
        required: ["tab_id"]
      }
    },
    run: async (ctx2, [tab_id]) => {
      const t = await chrome.tabs.get(tab_id);
      await chrome.tabs.update(tab_id, { active: true });
      try {
        await chrome.windows.update(t.windowId, { focused: true });
      } catch {
      }
      ctx2.setTarget(tab_id);
      return { success: true, tab: tabSummary(await chrome.tabs.get(tab_id)) };
    }
  },
  navigate: {
    schema: {
      name: "navigate",
      description: "Navigate the target tab to a URL (full page load). Use open_tab to navigate in a new tab instead.",
      parameters: {
        type: "object",
        properties: { url: { type: "string", description: "URL to navigate to" } },
        required: ["url"]
      }
    },
    run: async (ctx2, [url]) => {
      const id = await resolveTarget(ctx2);
      await chrome.tabs.update(id, { url });
      return { success: true, url };
    }
  },
  reload_tab: {
    schema: {
      name: "reload_tab",
      description: "Reload the target tab.",
      parameters: {
        type: "object",
        properties: {
          bypass_cache: { type: "boolean", description: "Hard reload (default false)" }
        }
      }
    },
    run: async (ctx2, [bypass_cache = false]) => {
      const id = await resolveTarget(ctx2);
      await chrome.tabs.reload(id, { bypassCache: !!bypass_cache });
      return { success: true };
    }
  },
  go_back: {
    schema: {
      name: "go_back",
      description: "Go back in the target tab's history.",
      parameters: { type: "object", properties: {} }
    },
    run: async (ctx2) => {
      await chrome.tabs.goBack(await resolveTarget(ctx2));
      return { success: true };
    }
  },
  go_forward: {
    schema: {
      name: "go_forward",
      description: "Go forward in the target tab's history.",
      parameters: { type: "object", properties: {} }
    },
    run: async (ctx2) => {
      await chrome.tabs.goForward(await resolveTarget(ctx2));
      return { success: true };
    }
  }
};
var BROWSER_TOOL_NAMES = new Set(Object.keys(BROWSER_TOOLS));

// ../extension/src/background.ts
var targetTabId = null;
var ctx = {
  getTarget: () => targetTabId,
  setTarget: (id) => {
    targetTabId = id;
  }
};
var creating = null;
async function ensureOffscreen() {
  const has = await hasOffscreen();
  if (has) return;
  if (!creating) {
    creating = chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["WORKERS", "DOM_SCRAPING"],
      justification: "Hold the persistent Hypha RPC WebSocket connection (needs a DOM and a stable lifetime)."
    }).catch((e) => {
      if (!String(e?.message || e).includes("single offscreen")) throw e;
    }).finally(() => {
      creating = null;
    });
  }
  await creating;
}
async function hasOffscreen() {
  try {
    const c = await chrome.runtime.getContexts({ contextTypes: ["OFFSCREEN_DOCUMENT"] });
    return c.length > 0;
  } catch {
    return false;
  }
}
async function ensureContent(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["main-world.js"],
      world: "MAIN"
    });
  } catch (e) {
    throw new Error(
      "Cannot attach to this tab (a restricted page like chrome:// or the Web Store?): " + (e?.message ?? e)
    );
  }
}
async function handleCall(method, args) {
  ui({ type: "log", msg: `${method}(${summarize(args)})`, kind: "call" });
  try {
    let value;
    if (BROWSER_TOOL_NAMES.has(method)) {
      value = await BROWSER_TOOLS[method].run(ctx, args || []);
    } else {
      let tabId = targetTabId;
      if (tabId == null) {
        const [a] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
        tabId = a?.id ?? null;
        if (tabId != null) targetTabId = tabId;
      }
      if (tabId == null) throw new Error("No target tab \u2014 open or activate a tab first");
      await ensureContent(tabId);
      const res = await chrome.tabs.sendMessage(tabId, { __hyphaPage: true, method, args });
      if (res && res.__error) throw new Error(res.__error);
      value = res ? res.value : void 0;
    }
    const isErr = value && typeof value === "object" && "error" in value;
    ui({ type: "log", msg: isErr ? `${method}: ${value.error}` : `${method} -> ok`, kind: isErr ? "error" : "result" });
    return value;
  } catch (e) {
    ui({ type: "log", msg: `${method}: ${e?.message ?? e}`, kind: "error" });
    throw e;
  }
}
async function connectBrowser(config) {
  const [a] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (a?.id != null) targetTabId = a.id;
  await chrome.storage.local.set({ hyphaConnected: true, hyphaConfig: config });
  await ensureOffscreen();
  chrome.runtime.sendMessage({ __off: "connect", config }).catch(() => {
  });
}
async function disconnectBrowser() {
  await chrome.storage.local.set({ hyphaConnected: false });
  chrome.runtime.sendMessage({ __off: "disconnect" }).catch(() => {
  });
}
async function reconcile() {
  const r = await chrome.storage.local.get(["hyphaConnected", "hyphaConfig"]);
  if (r.hyphaConnected && r.hyphaConfig) {
    await ensureOffscreen();
  }
}
function ui(data) {
  chrome.runtime.sendMessage({ __ui: true, ...data }).catch(() => {
  });
}
function summarize(args) {
  if (!args || !args.length) return "";
  return args.map(
    (a) => typeof a === "string" ? a.length > 40 ? a.slice(0, 40) + "\u2026" : a : typeof a === "object" && a ? "{\u2026}" : String(a)
  ).join(", ");
}
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || typeof msg !== "object") return;
  if (msg.__hyphaCall) {
    handleCall(msg.method, msg.args).then((value) => sendResponse({ value })).catch((e) => sendResponse({ __error: e?.message ?? String(e) }));
    return true;
  }
  if (msg.__ctl === "connect") {
    void connectBrowser(msg.config);
  } else if (msg.__ctl === "disconnect") {
    void disconnectBrowser();
  }
});
chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === targetTabId) targetTabId = null;
});
chrome.sidePanel?.setPanelBehavior?.({ openPanelOnActionClick: true }).catch(() => {
});
chrome.alarms?.create?.("hypha-keepalive", { periodInMinutes: 0.5 });
chrome.alarms?.onAlarm?.addListener((a) => {
  if (a.name === "hypha-keepalive") void reconcile();
});
chrome.runtime.onStartup?.addListener(() => void reconcile());
chrome.runtime.onInstalled?.addListener(() => void reconcile());
void reconcile();
