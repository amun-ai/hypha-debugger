"use strict";
(() => {
  // src/utils/env.ts
  function detectFrameworks() {
    const frameworks = [];
    const w = window;
    if (w.__REACT_DEVTOOLS_GLOBAL_HOOK__?.renderers?.size > 0) {
      frameworks.push("react");
    } else {
      const root = document.querySelector("#root, #app, [data-reactroot]");
      if (root) {
        const hasReactFiber = Object.keys(root).some(
          (k) => k.startsWith("__reactFiber$") || k.startsWith("__reactInternalInstance$")
        );
        if (hasReactFiber) frameworks.push("react");
      }
    }
    if (w.__VUE__ || w.__VUE_DEVTOOLS_GLOBAL_HOOK__) {
      frameworks.push("vue");
    } else {
      const el = document.querySelector("[data-v-app], #app");
      if (el && el.__vue_app__) frameworks.push("vue");
    }
    if (w.ng || document.querySelector("[ng-version]")) {
      frameworks.push("angular");
    }
    if (document.querySelector("[class*='svelte-']")) {
      frameworks.push("svelte");
    }
    if (w.__NEXT_DATA__) {
      frameworks.push("nextjs");
    }
    return frameworks;
  }
  function collectPageInfo() {
    const perf = performance.getEntriesByType(
      "navigation"
    )[0];
    return {
      url: window.location.href,
      title: document.title,
      viewport: {
        width: window.innerWidth,
        height: window.innerHeight
      },
      document_size: {
        width: document.documentElement.scrollWidth,
        height: document.documentElement.scrollHeight
      },
      user_agent: navigator.userAgent,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      cookies_enabled: navigator.cookieEnabled,
      language: navigator.language,
      platform: navigator.platform,
      online: navigator.onLine,
      performance: {
        load_time_ms: perf ? Math.round(perf.loadEventEnd - perf.startTime) : null,
        dom_content_loaded_ms: perf ? Math.round(perf.domContentLoadedEventEnd - perf.startTime) : null
      },
      frameworks: detectFrameworks()
    };
  }

  // src/services/info.ts
  function getPageInfo(include_logs, log_limit, log_level) {
    const info = collectPageInfo();
    if (include_logs) {
      const logs = window.__HYPHA_DEBUGGER__?.consoleLogs ?? [];
      const limit = log_limit ?? 50;
      let filtered = log_level ? logs.filter((l) => l.level === log_level) : logs;
      info.console_logs = filtered.slice(-limit);
    }
    return info;
  }
  getPageInfo.__schema__ = {
    name: "getPageInfo",
    description: "Get information about the current web page including URL, title, viewport size, detected frameworks, and performance timing. Optionally include recent console logs.",
    parameters: {
      type: "object",
      properties: {
        include_logs: {
          type: "boolean",
          description: "If true, include recent console output in the response. Default: false."
        },
        log_limit: {
          type: "number",
          description: "Maximum number of console log entries to include (most recent). Default: 50."
        },
        log_level: {
          type: "string",
          description: 'Filter console logs by level: "log", "warn", "error", "info". Omit for all levels.',
          enum: ["log", "warn", "error", "info"]
        }
      }
    }
  };
  function getConsoleLogs(options) {
    const logs = window.__HYPHA_DEBUGGER__?.consoleLogs ?? [];
    const level = options?.level;
    const limit = options?.limit ?? 100;
    let filtered = level ? logs.filter((l) => l.level === level) : logs;
    return filtered.slice(-limit);
  }
  getConsoleLogs.__schema__ = {
    name: "getConsoleLogs",
    description: "Retrieve captured console output (log, warn, error, info).",
    parameters: {
      type: "object",
      properties: {
        level: {
          type: "string",
          description: 'Filter by log level: "log", "warn", "error", "info". Omit for all levels.',
          enum: ["log", "warn", "error", "info"]
        },
        limit: {
          type: "number",
          description: "Maximum number of log entries to return (most recent). Default: 100."
        }
      }
    }
  };

  // src/services/dom.ts
  function elementToInfo(el) {
    const rect = el.getBoundingClientRect();
    const attrs = {};
    for (const attr of Array.from(el.attributes)) {
      attrs[attr.name] = attr.value;
    }
    return {
      tag: el.tagName.toLowerCase(),
      id: el.id,
      classes: Array.from(el.classList),
      text: (el.textContent ?? "").trim().slice(0, 500),
      attributes: attrs,
      bounds: {
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        width: Math.round(rect.width),
        height: Math.round(rect.height)
      },
      visible: rect.width > 0 && rect.height > 0 && getComputedStyle(el).visibility !== "hidden" && getComputedStyle(el).display !== "none",
      children_count: el.children.length
    };
  }
  function queryDom(selector, limit) {
    limit = limit ?? 20;
    const elements = document.querySelectorAll(selector);
    const results = [];
    for (let i = 0; i < Math.min(elements.length, limit); i++) {
      results.push(elementToInfo(elements[i]));
    }
    return results;
  }
  queryDom.__schema__ = {
    name: "queryDom",
    description: "Query DOM elements by CSS selector. Returns tag, id, classes, text content, attributes, bounding rect, and visibility for each matching element.",
    parameters: {
      type: "object",
      properties: {
        selector: {
          type: "string",
          description: 'CSS selector to query, e.g. "button.primary", "#app > div".'
        },
        limit: {
          type: "number",
          description: "Maximum number of elements to return. Default: 20."
        }
      },
      required: ["selector"]
    }
  };
  function clickElement(selector) {
    const el = document.querySelector(selector);
    if (!el) {
      return { success: false, message: `No element found for selector: ${selector}` };
    }
    const rect = el.getBoundingClientRect();
    el.dispatchEvent(
      new MouseEvent("click", {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX: rect.left + rect.width / 2,
        clientY: rect.top + rect.height / 2
      })
    );
    return { success: true, message: `Clicked element: ${selector}` };
  }
  clickElement.__schema__ = {
    name: "clickElement",
    description: "Click a DOM element matching the CSS selector.",
    parameters: {
      type: "object",
      properties: {
        selector: {
          type: "string",
          description: "CSS selector of the element to click."
        }
      },
      required: ["selector"]
    }
  };
  function fillInput(selector, value) {
    const el = document.querySelector(selector);
    if (!el) {
      return { success: false, message: `No element found for selector: ${selector}` };
    }
    const tag = el.tagName.toLowerCase();
    if (tag === "input" || tag === "textarea") {
      const inputEl = el;
      const proto = tag === "textarea" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
      if (nativeSetter) {
        nativeSetter.call(inputEl, value);
      } else {
        inputEl.value = value;
      }
      inputEl.dispatchEvent(new Event("input", { bubbles: true }));
      inputEl.dispatchEvent(new Event("change", { bubbles: true }));
      return { success: true, message: `Filled ${selector} with value` };
    }
    if (tag === "select") {
      const selectEl = el;
      const nativeSetter = Object.getOwnPropertyDescriptor(
        HTMLSelectElement.prototype,
        "value"
      )?.set;
      if (nativeSetter) {
        nativeSetter.call(selectEl, value);
      } else {
        selectEl.value = value;
      }
      selectEl.dispatchEvent(new Event("change", { bubbles: true }));
      return { success: true, message: `Set ${selector} to ${value}` };
    }
    return { success: false, message: `Element ${selector} is not an input/textarea/select` };
  }
  fillInput.__schema__ = {
    name: "fillInput",
    description: "Set the value of an input, textarea, or select element. Works with React controlled components.",
    parameters: {
      type: "object",
      properties: {
        selector: {
          type: "string",
          description: "CSS selector of the input element."
        },
        value: {
          type: "string",
          description: "The value to set."
        }
      },
      required: ["selector", "value"]
    }
  };
  function scrollTo(target) {
    if (typeof target === "string") {
      const el = document.querySelector(target);
      if (!el) {
        return { success: false, message: `No element found for selector: ${target}` };
      }
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      return { success: true, message: `Scrolled to ${target}` };
    }
    window.scrollTo({ left: target.x, top: target.y, behavior: "smooth" });
    return { success: true, message: `Scrolled to (${target.x}, ${target.y})` };
  }
  scrollTo.__schema__ = {
    name: "scrollTo",
    description: "Scroll to a DOM element (by CSS selector) or to an absolute position {x, y}.",
    parameters: {
      type: "object",
      properties: {
        target: {
          description: "CSS selector string to scroll to an element, or an object {x, y} for absolute scroll position."
        }
      },
      required: ["target"]
    }
  };
  function getComputedStyles(selector, properties) {
    const el = document.querySelector(selector);
    if (!el) {
      return { error: `No element found for selector: ${selector}` };
    }
    const computed = getComputedStyle(el);
    const result = {};
    const props = properties ?? [
      "display",
      "position",
      "width",
      "height",
      "color",
      "background-color",
      "font-size",
      "font-family",
      "margin",
      "padding",
      "border",
      "opacity",
      "visibility",
      "overflow",
      "z-index"
    ];
    for (const prop of props) {
      result[prop] = computed.getPropertyValue(prop);
    }
    return result;
  }
  getComputedStyles.__schema__ = {
    name: "getComputedStyles",
    description: "Get computed CSS styles for an element.",
    parameters: {
      type: "object",
      properties: {
        selector: {
          type: "string",
          description: "CSS selector of the element."
        },
        properties: {
          type: "array",
          items: { type: "string" },
          description: 'CSS property names to retrieve, e.g. ["color", "font-size"]. Omit for common defaults.'
        }
      },
      required: ["selector"]
    }
  };
  function getElementBounds(selector) {
    const el = document.querySelector(selector);
    if (!el) {
      return { error: `No element found for selector: ${selector}` };
    }
    const rect = el.getBoundingClientRect();
    return {
      bounds: {
        x: Math.round(rect.x),
        y: Math.round(rect.y),
        width: Math.round(rect.width),
        height: Math.round(rect.height)
      },
      visible: rect.width > 0 && rect.height > 0 && getComputedStyle(el).visibility !== "hidden" && getComputedStyle(el).display !== "none"
    };
  }
  getElementBounds.__schema__ = {
    name: "getElementBounds",
    description: "Get the bounding rectangle and visibility of a DOM element.",
    parameters: {
      type: "object",
      properties: {
        selector: {
          type: "string",
          description: "CSS selector of the element."
        }
      },
      required: ["selector"]
    }
  };
  function getHtml(selector, outer, max_length) {
    const useOuter = outer ?? true;
    const maxLen = max_length ?? 5e4;
    const el = selector ? document.querySelector(selector) : document.documentElement;
    if (!el) {
      return { error: `No element found for selector: ${selector}` };
    }
    const raw = useOuter ? el.outerHTML : el.innerHTML;
    const truncated = raw.length > maxLen;
    return {
      html: truncated ? raw.slice(0, maxLen) : raw,
      length: raw.length,
      truncated
    };
  }
  getHtml.__schema__ = {
    name: "getHtml",
    description: "Get the HTML content of the page or a specific element. Returns outerHTML by default. Useful for understanding page structure.",
    parameters: {
      type: "object",
      properties: {
        selector: {
          type: "string",
          description: "CSS selector of the element. Omit to get the full page HTML."
        },
        outer: {
          type: "boolean",
          description: "If true (default), return outerHTML (includes the element itself). If false, return innerHTML (children only)."
        },
        max_length: {
          type: "number",
          description: "Maximum character length of the returned HTML. Default: 50000. Result will be truncated if longer."
        }
      }
    }
  };

  // node_modules/html-to-image/es/util.js
  function resolveUrl(url, baseUrl) {
    if (url.match(/^[a-z]+:\/\//i)) {
      return url;
    }
    if (url.match(/^\/\//)) {
      return window.location.protocol + url;
    }
    if (url.match(/^[a-z]+:/i)) {
      return url;
    }
    const doc = document.implementation.createHTMLDocument();
    const base = doc.createElement("base");
    const a = doc.createElement("a");
    doc.head.appendChild(base);
    doc.body.appendChild(a);
    if (baseUrl) {
      base.href = baseUrl;
    }
    a.href = url;
    return a.href;
  }
  var uuid = /* @__PURE__ */ (() => {
    let counter = 0;
    const random = () => (
      // eslint-disable-next-line no-bitwise
      `0000${(Math.random() * 36 ** 4 << 0).toString(36)}`.slice(-4)
    );
    return () => {
      counter += 1;
      return `u${random()}${counter}`;
    };
  })();
  function toArray(arrayLike) {
    const arr = [];
    for (let i = 0, l = arrayLike.length; i < l; i++) {
      arr.push(arrayLike[i]);
    }
    return arr;
  }
  var styleProps = null;
  function getStyleProperties(options = {}) {
    if (styleProps) {
      return styleProps;
    }
    if (options.includeStyleProperties) {
      styleProps = options.includeStyleProperties;
      return styleProps;
    }
    styleProps = toArray(window.getComputedStyle(document.documentElement));
    return styleProps;
  }
  function px(node, styleProperty) {
    const win = node.ownerDocument.defaultView || window;
    const val = win.getComputedStyle(node).getPropertyValue(styleProperty);
    return val ? parseFloat(val.replace("px", "")) : 0;
  }
  function getNodeWidth(node) {
    const leftBorder = px(node, "border-left-width");
    const rightBorder = px(node, "border-right-width");
    return node.clientWidth + leftBorder + rightBorder;
  }
  function getNodeHeight(node) {
    const topBorder = px(node, "border-top-width");
    const bottomBorder = px(node, "border-bottom-width");
    return node.clientHeight + topBorder + bottomBorder;
  }
  function getImageSize(targetNode, options = {}) {
    const width = options.width || getNodeWidth(targetNode);
    const height = options.height || getNodeHeight(targetNode);
    return { width, height };
  }
  function getPixelRatio() {
    let ratio;
    let FINAL_PROCESS;
    try {
      FINAL_PROCESS = process;
    } catch (e) {
    }
    const val = FINAL_PROCESS && FINAL_PROCESS.env ? FINAL_PROCESS.env.devicePixelRatio : null;
    if (val) {
      ratio = parseInt(val, 10);
      if (Number.isNaN(ratio)) {
        ratio = 1;
      }
    }
    return ratio || window.devicePixelRatio || 1;
  }
  var canvasDimensionLimit = 16384;
  function checkCanvasDimensions(canvas) {
    if (canvas.width > canvasDimensionLimit || canvas.height > canvasDimensionLimit) {
      if (canvas.width > canvasDimensionLimit && canvas.height > canvasDimensionLimit) {
        if (canvas.width > canvas.height) {
          canvas.height *= canvasDimensionLimit / canvas.width;
          canvas.width = canvasDimensionLimit;
        } else {
          canvas.width *= canvasDimensionLimit / canvas.height;
          canvas.height = canvasDimensionLimit;
        }
      } else if (canvas.width > canvasDimensionLimit) {
        canvas.height *= canvasDimensionLimit / canvas.width;
        canvas.width = canvasDimensionLimit;
      } else {
        canvas.width *= canvasDimensionLimit / canvas.height;
        canvas.height = canvasDimensionLimit;
      }
    }
  }
  function createImage(url) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        img.decode().then(() => {
          requestAnimationFrame(() => resolve(img));
        });
      };
      img.onerror = reject;
      img.crossOrigin = "anonymous";
      img.decoding = "async";
      img.src = url;
    });
  }
  async function svgToDataURL(svg) {
    return Promise.resolve().then(() => new XMLSerializer().serializeToString(svg)).then(encodeURIComponent).then((html) => `data:image/svg+xml;charset=utf-8,${html}`);
  }
  async function nodeToDataURL(node, width, height) {
    const xmlns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(xmlns, "svg");
    const foreignObject = document.createElementNS(xmlns, "foreignObject");
    svg.setAttribute("width", `${width}`);
    svg.setAttribute("height", `${height}`);
    svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    foreignObject.setAttribute("width", "100%");
    foreignObject.setAttribute("height", "100%");
    foreignObject.setAttribute("x", "0");
    foreignObject.setAttribute("y", "0");
    foreignObject.setAttribute("externalResourcesRequired", "true");
    svg.appendChild(foreignObject);
    foreignObject.appendChild(node);
    return svgToDataURL(svg);
  }
  var isInstanceOfElement = (node, instance) => {
    if (node instanceof instance)
      return true;
    const nodePrototype = Object.getPrototypeOf(node);
    if (nodePrototype === null)
      return false;
    return nodePrototype.constructor.name === instance.name || isInstanceOfElement(nodePrototype, instance);
  };

  // node_modules/html-to-image/es/clone-pseudos.js
  function formatCSSText(style) {
    const content = style.getPropertyValue("content");
    return `${style.cssText} content: '${content.replace(/'|"/g, "")}';`;
  }
  function formatCSSProperties(style, options) {
    return getStyleProperties(options).map((name) => {
      const value = style.getPropertyValue(name);
      const priority = style.getPropertyPriority(name);
      return `${name}: ${value}${priority ? " !important" : ""};`;
    }).join(" ");
  }
  function getPseudoElementStyle(className, pseudo, style, options) {
    const selector = `.${className}:${pseudo}`;
    const cssText = style.cssText ? formatCSSText(style) : formatCSSProperties(style, options);
    return document.createTextNode(`${selector}{${cssText}}`);
  }
  function clonePseudoElement(nativeNode, clonedNode, pseudo, options) {
    const style = window.getComputedStyle(nativeNode, pseudo);
    const content = style.getPropertyValue("content");
    if (content === "" || content === "none") {
      return;
    }
    const className = uuid();
    try {
      clonedNode.className = `${clonedNode.className} ${className}`;
    } catch (err) {
      return;
    }
    const styleElement = document.createElement("style");
    styleElement.appendChild(getPseudoElementStyle(className, pseudo, style, options));
    clonedNode.appendChild(styleElement);
  }
  function clonePseudoElements(nativeNode, clonedNode, options) {
    clonePseudoElement(nativeNode, clonedNode, ":before", options);
    clonePseudoElement(nativeNode, clonedNode, ":after", options);
  }

  // node_modules/html-to-image/es/mimes.js
  var WOFF = "application/font-woff";
  var JPEG = "image/jpeg";
  var mimes = {
    woff: WOFF,
    woff2: WOFF,
    ttf: "application/font-truetype",
    eot: "application/vnd.ms-fontobject",
    png: "image/png",
    jpg: JPEG,
    jpeg: JPEG,
    gif: "image/gif",
    tiff: "image/tiff",
    svg: "image/svg+xml",
    webp: "image/webp"
  };
  function getExtension(url) {
    const match = /\.([^./]*?)$/g.exec(url);
    return match ? match[1] : "";
  }
  function getMimeType(url) {
    const extension = getExtension(url).toLowerCase();
    return mimes[extension] || "";
  }

  // node_modules/html-to-image/es/dataurl.js
  function getContentFromDataUrl(dataURL) {
    return dataURL.split(/,/)[1];
  }
  function isDataUrl(url) {
    return url.search(/^(data:)/) !== -1;
  }
  function makeDataUrl(content, mimeType) {
    return `data:${mimeType};base64,${content}`;
  }
  async function fetchAsDataURL(url, init, process2) {
    const res = await fetch(url, init);
    if (res.status === 404) {
      throw new Error(`Resource "${res.url}" not found`);
    }
    const blob = await res.blob();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = reject;
      reader.onloadend = () => {
        try {
          resolve(process2({ res, result: reader.result }));
        } catch (error) {
          reject(error);
        }
      };
      reader.readAsDataURL(blob);
    });
  }
  var cache = {};
  function getCacheKey(url, contentType, includeQueryParams) {
    let key = url.replace(/\?.*/, "");
    if (includeQueryParams) {
      key = url;
    }
    if (/ttf|otf|eot|woff2?/i.test(key)) {
      key = key.replace(/.*\//, "");
    }
    return contentType ? `[${contentType}]${key}` : key;
  }
  async function resourceToDataURL(resourceUrl, contentType, options) {
    const cacheKey = getCacheKey(resourceUrl, contentType, options.includeQueryParams);
    if (cache[cacheKey] != null) {
      return cache[cacheKey];
    }
    if (options.cacheBust) {
      resourceUrl += (/\?/.test(resourceUrl) ? "&" : "?") + (/* @__PURE__ */ new Date()).getTime();
    }
    let dataURL;
    try {
      const content = await fetchAsDataURL(resourceUrl, options.fetchRequestInit, ({ res, result }) => {
        if (!contentType) {
          contentType = res.headers.get("Content-Type") || "";
        }
        return getContentFromDataUrl(result);
      });
      dataURL = makeDataUrl(content, contentType);
    } catch (error) {
      dataURL = options.imagePlaceholder || "";
      let msg = `Failed to fetch resource: ${resourceUrl}`;
      if (error) {
        msg = typeof error === "string" ? error : error.message;
      }
      if (msg) {
        console.warn(msg);
      }
    }
    cache[cacheKey] = dataURL;
    return dataURL;
  }

  // node_modules/html-to-image/es/clone-node.js
  async function cloneCanvasElement(canvas) {
    const dataURL = canvas.toDataURL();
    if (dataURL === "data:,") {
      return canvas.cloneNode(false);
    }
    return createImage(dataURL);
  }
  async function cloneVideoElement(video, options) {
    if (video.currentSrc) {
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      canvas.width = video.clientWidth;
      canvas.height = video.clientHeight;
      ctx === null || ctx === void 0 ? void 0 : ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataURL2 = canvas.toDataURL();
      return createImage(dataURL2);
    }
    const poster = video.poster;
    const contentType = getMimeType(poster);
    const dataURL = await resourceToDataURL(poster, contentType, options);
    return createImage(dataURL);
  }
  async function cloneIFrameElement(iframe, options) {
    var _a;
    try {
      if ((_a = iframe === null || iframe === void 0 ? void 0 : iframe.contentDocument) === null || _a === void 0 ? void 0 : _a.body) {
        return await cloneNode(iframe.contentDocument.body, options, true);
      }
    } catch (_b) {
    }
    return iframe.cloneNode(false);
  }
  async function cloneSingleNode(node, options) {
    if (isInstanceOfElement(node, HTMLCanvasElement)) {
      return cloneCanvasElement(node);
    }
    if (isInstanceOfElement(node, HTMLVideoElement)) {
      return cloneVideoElement(node, options);
    }
    if (isInstanceOfElement(node, HTMLIFrameElement)) {
      return cloneIFrameElement(node, options);
    }
    return node.cloneNode(isSVGElement(node));
  }
  var isSlotElement = (node) => node.tagName != null && node.tagName.toUpperCase() === "SLOT";
  var isSVGElement = (node) => node.tagName != null && node.tagName.toUpperCase() === "SVG";
  async function cloneChildren(nativeNode, clonedNode, options) {
    var _a, _b;
    if (isSVGElement(clonedNode)) {
      return clonedNode;
    }
    let children = [];
    if (isSlotElement(nativeNode) && nativeNode.assignedNodes) {
      children = toArray(nativeNode.assignedNodes());
    } else if (isInstanceOfElement(nativeNode, HTMLIFrameElement) && ((_a = nativeNode.contentDocument) === null || _a === void 0 ? void 0 : _a.body)) {
      children = toArray(nativeNode.contentDocument.body.childNodes);
    } else {
      children = toArray(((_b = nativeNode.shadowRoot) !== null && _b !== void 0 ? _b : nativeNode).childNodes);
    }
    if (children.length === 0 || isInstanceOfElement(nativeNode, HTMLVideoElement)) {
      return clonedNode;
    }
    await children.reduce((deferred, child) => deferred.then(() => cloneNode(child, options)).then((clonedChild) => {
      if (clonedChild) {
        clonedNode.appendChild(clonedChild);
      }
    }), Promise.resolve());
    return clonedNode;
  }
  function cloneCSSStyle(nativeNode, clonedNode, options) {
    const targetStyle = clonedNode.style;
    if (!targetStyle) {
      return;
    }
    const sourceStyle = window.getComputedStyle(nativeNode);
    if (sourceStyle.cssText) {
      targetStyle.cssText = sourceStyle.cssText;
      targetStyle.transformOrigin = sourceStyle.transformOrigin;
    } else {
      getStyleProperties(options).forEach((name) => {
        let value = sourceStyle.getPropertyValue(name);
        if (name === "font-size" && value.endsWith("px")) {
          const reducedFont = Math.floor(parseFloat(value.substring(0, value.length - 2))) - 0.1;
          value = `${reducedFont}px`;
        }
        if (isInstanceOfElement(nativeNode, HTMLIFrameElement) && name === "display" && value === "inline") {
          value = "block";
        }
        if (name === "d" && clonedNode.getAttribute("d")) {
          value = `path(${clonedNode.getAttribute("d")})`;
        }
        targetStyle.setProperty(name, value, sourceStyle.getPropertyPriority(name));
      });
    }
  }
  function cloneInputValue(nativeNode, clonedNode) {
    if (isInstanceOfElement(nativeNode, HTMLTextAreaElement)) {
      clonedNode.innerHTML = nativeNode.value;
    }
    if (isInstanceOfElement(nativeNode, HTMLInputElement)) {
      clonedNode.setAttribute("value", nativeNode.value);
    }
  }
  function cloneSelectValue(nativeNode, clonedNode) {
    if (isInstanceOfElement(nativeNode, HTMLSelectElement)) {
      const clonedSelect = clonedNode;
      const selectedOption = Array.from(clonedSelect.children).find((child) => nativeNode.value === child.getAttribute("value"));
      if (selectedOption) {
        selectedOption.setAttribute("selected", "");
      }
    }
  }
  function decorate(nativeNode, clonedNode, options) {
    if (isInstanceOfElement(clonedNode, Element)) {
      cloneCSSStyle(nativeNode, clonedNode, options);
      clonePseudoElements(nativeNode, clonedNode, options);
      cloneInputValue(nativeNode, clonedNode);
      cloneSelectValue(nativeNode, clonedNode);
    }
    return clonedNode;
  }
  async function ensureSVGSymbols(clone, options) {
    const uses = clone.querySelectorAll ? clone.querySelectorAll("use") : [];
    if (uses.length === 0) {
      return clone;
    }
    const processedDefs = {};
    for (let i = 0; i < uses.length; i++) {
      const use = uses[i];
      const id = use.getAttribute("xlink:href");
      if (id) {
        const exist = clone.querySelector(id);
        const definition = document.querySelector(id);
        if (!exist && definition && !processedDefs[id]) {
          processedDefs[id] = await cloneNode(definition, options, true);
        }
      }
    }
    const nodes = Object.values(processedDefs);
    if (nodes.length) {
      const ns = "http://www.w3.org/1999/xhtml";
      const svg = document.createElementNS(ns, "svg");
      svg.setAttribute("xmlns", ns);
      svg.style.position = "absolute";
      svg.style.width = "0";
      svg.style.height = "0";
      svg.style.overflow = "hidden";
      svg.style.display = "none";
      const defs = document.createElementNS(ns, "defs");
      svg.appendChild(defs);
      for (let i = 0; i < nodes.length; i++) {
        defs.appendChild(nodes[i]);
      }
      clone.appendChild(svg);
    }
    return clone;
  }
  async function cloneNode(node, options, isRoot) {
    if (!isRoot && options.filter && !options.filter(node)) {
      return null;
    }
    return Promise.resolve(node).then((clonedNode) => cloneSingleNode(clonedNode, options)).then((clonedNode) => cloneChildren(node, clonedNode, options)).then((clonedNode) => decorate(node, clonedNode, options)).then((clonedNode) => ensureSVGSymbols(clonedNode, options));
  }

  // node_modules/html-to-image/es/embed-resources.js
  var URL_REGEX = /url\((['"]?)([^'"]+?)\1\)/g;
  var URL_WITH_FORMAT_REGEX = /url\([^)]+\)\s*format\((["']?)([^"']+)\1\)/g;
  var FONT_SRC_REGEX = /src:\s*(?:url\([^)]+\)\s*format\([^)]+\)[,;]\s*)+/g;
  function toRegex(url) {
    const escaped = url.replace(/([.*+?^${}()|\[\]\/\\])/g, "\\$1");
    return new RegExp(`(url\\(['"]?)(${escaped})(['"]?\\))`, "g");
  }
  function parseURLs(cssText) {
    const urls = [];
    cssText.replace(URL_REGEX, (raw, quotation, url) => {
      urls.push(url);
      return raw;
    });
    return urls.filter((url) => !isDataUrl(url));
  }
  async function embed(cssText, resourceURL, baseURL, options, getContentFromUrl) {
    try {
      const resolvedURL = baseURL ? resolveUrl(resourceURL, baseURL) : resourceURL;
      const contentType = getMimeType(resourceURL);
      let dataURL;
      if (getContentFromUrl) {
        const content = await getContentFromUrl(resolvedURL);
        dataURL = makeDataUrl(content, contentType);
      } else {
        dataURL = await resourceToDataURL(resolvedURL, contentType, options);
      }
      return cssText.replace(toRegex(resourceURL), `$1${dataURL}$3`);
    } catch (error) {
    }
    return cssText;
  }
  function filterPreferredFontFormat(str, { preferredFontFormat }) {
    return !preferredFontFormat ? str : str.replace(FONT_SRC_REGEX, (match) => {
      while (true) {
        const [src, , format] = URL_WITH_FORMAT_REGEX.exec(match) || [];
        if (!format) {
          return "";
        }
        if (format === preferredFontFormat) {
          return `src: ${src};`;
        }
      }
    });
  }
  function shouldEmbed(url) {
    return url.search(URL_REGEX) !== -1;
  }
  async function embedResources(cssText, baseUrl, options) {
    if (!shouldEmbed(cssText)) {
      return cssText;
    }
    const filteredCSSText = filterPreferredFontFormat(cssText, options);
    const urls = parseURLs(filteredCSSText);
    return urls.reduce((deferred, url) => deferred.then((css) => embed(css, url, baseUrl, options)), Promise.resolve(filteredCSSText));
  }

  // node_modules/html-to-image/es/embed-images.js
  async function embedProp(propName, node, options) {
    var _a;
    const propValue = (_a = node.style) === null || _a === void 0 ? void 0 : _a.getPropertyValue(propName);
    if (propValue) {
      const cssString = await embedResources(propValue, null, options);
      node.style.setProperty(propName, cssString, node.style.getPropertyPriority(propName));
      return true;
    }
    return false;
  }
  async function embedBackground(clonedNode, options) {
    ;
    await embedProp("background", clonedNode, options) || await embedProp("background-image", clonedNode, options);
    await embedProp("mask", clonedNode, options) || await embedProp("-webkit-mask", clonedNode, options) || await embedProp("mask-image", clonedNode, options) || await embedProp("-webkit-mask-image", clonedNode, options);
  }
  async function embedImageNode(clonedNode, options) {
    const isImageElement = isInstanceOfElement(clonedNode, HTMLImageElement);
    if (!(isImageElement && !isDataUrl(clonedNode.src)) && !(isInstanceOfElement(clonedNode, SVGImageElement) && !isDataUrl(clonedNode.href.baseVal))) {
      return;
    }
    const url = isImageElement ? clonedNode.src : clonedNode.href.baseVal;
    const dataURL = await resourceToDataURL(url, getMimeType(url), options);
    await new Promise((resolve, reject) => {
      clonedNode.onload = resolve;
      clonedNode.onerror = options.onImageErrorHandler ? (...attributes) => {
        try {
          resolve(options.onImageErrorHandler(...attributes));
        } catch (error) {
          reject(error);
        }
      } : reject;
      const image = clonedNode;
      if (image.decode) {
        image.decode = resolve;
      }
      if (image.loading === "lazy") {
        image.loading = "eager";
      }
      if (isImageElement) {
        clonedNode.srcset = "";
        clonedNode.src = dataURL;
      } else {
        clonedNode.href.baseVal = dataURL;
      }
    });
  }
  async function embedChildren(clonedNode, options) {
    const children = toArray(clonedNode.childNodes);
    const deferreds = children.map((child) => embedImages(child, options));
    await Promise.all(deferreds).then(() => clonedNode);
  }
  async function embedImages(clonedNode, options) {
    if (isInstanceOfElement(clonedNode, Element)) {
      await embedBackground(clonedNode, options);
      await embedImageNode(clonedNode, options);
      await embedChildren(clonedNode, options);
    }
  }

  // node_modules/html-to-image/es/apply-style.js
  function applyStyle(node, options) {
    const { style } = node;
    if (options.backgroundColor) {
      style.backgroundColor = options.backgroundColor;
    }
    if (options.width) {
      style.width = `${options.width}px`;
    }
    if (options.height) {
      style.height = `${options.height}px`;
    }
    const manual = options.style;
    if (manual != null) {
      Object.keys(manual).forEach((key) => {
        style[key] = manual[key];
      });
    }
    return node;
  }

  // node_modules/html-to-image/es/embed-webfonts.js
  var cssFetchCache = {};
  async function fetchCSS(url) {
    let cache2 = cssFetchCache[url];
    if (cache2 != null) {
      return cache2;
    }
    const res = await fetch(url);
    const cssText = await res.text();
    cache2 = { url, cssText };
    cssFetchCache[url] = cache2;
    return cache2;
  }
  async function embedFonts(data, options) {
    let cssText = data.cssText;
    const regexUrl = /url\(["']?([^"')]+)["']?\)/g;
    const fontLocs = cssText.match(/url\([^)]+\)/g) || [];
    const loadFonts = fontLocs.map(async (loc) => {
      let url = loc.replace(regexUrl, "$1");
      if (!url.startsWith("https://")) {
        url = new URL(url, data.url).href;
      }
      return fetchAsDataURL(url, options.fetchRequestInit, ({ result }) => {
        cssText = cssText.replace(loc, `url(${result})`);
        return [loc, result];
      });
    });
    return Promise.all(loadFonts).then(() => cssText);
  }
  function parseCSS(source) {
    if (source == null) {
      return [];
    }
    const result = [];
    const commentsRegex = /(\/\*[\s\S]*?\*\/)/gi;
    let cssText = source.replace(commentsRegex, "");
    const keyframesRegex = new RegExp("((@.*?keyframes [\\s\\S]*?){([\\s\\S]*?}\\s*?)})", "gi");
    while (true) {
      const matches = keyframesRegex.exec(cssText);
      if (matches === null) {
        break;
      }
      result.push(matches[0]);
    }
    cssText = cssText.replace(keyframesRegex, "");
    const importRegex = /@import[\s\S]*?url\([^)]*\)[\s\S]*?;/gi;
    const combinedCSSRegex = "((\\s*?(?:\\/\\*[\\s\\S]*?\\*\\/)?\\s*?@media[\\s\\S]*?){([\\s\\S]*?)}\\s*?})|(([\\s\\S]*?){([\\s\\S]*?)})";
    const unifiedRegex = new RegExp(combinedCSSRegex, "gi");
    while (true) {
      let matches = importRegex.exec(cssText);
      if (matches === null) {
        matches = unifiedRegex.exec(cssText);
        if (matches === null) {
          break;
        } else {
          importRegex.lastIndex = unifiedRegex.lastIndex;
        }
      } else {
        unifiedRegex.lastIndex = importRegex.lastIndex;
      }
      result.push(matches[0]);
    }
    return result;
  }
  async function getCSSRules(styleSheets, options) {
    const ret = [];
    const deferreds = [];
    styleSheets.forEach((sheet) => {
      if ("cssRules" in sheet) {
        try {
          toArray(sheet.cssRules || []).forEach((item, index) => {
            if (item.type === CSSRule.IMPORT_RULE) {
              let importIndex = index + 1;
              const url = item.href;
              const deferred = fetchCSS(url).then((metadata) => embedFonts(metadata, options)).then((cssText) => parseCSS(cssText).forEach((rule) => {
                try {
                  sheet.insertRule(rule, rule.startsWith("@import") ? importIndex += 1 : sheet.cssRules.length);
                } catch (error) {
                  console.error("Error inserting rule from remote css", {
                    rule,
                    error
                  });
                }
              })).catch((e) => {
                console.error("Error loading remote css", e.toString());
              });
              deferreds.push(deferred);
            }
          });
        } catch (e) {
          const inline = styleSheets.find((a) => a.href == null) || document.styleSheets[0];
          if (sheet.href != null) {
            deferreds.push(fetchCSS(sheet.href).then((metadata) => embedFonts(metadata, options)).then((cssText) => parseCSS(cssText).forEach((rule) => {
              inline.insertRule(rule, inline.cssRules.length);
            })).catch((err) => {
              console.error("Error loading remote stylesheet", err);
            }));
          }
          console.error("Error inlining remote css file", e);
        }
      }
    });
    return Promise.all(deferreds).then(() => {
      styleSheets.forEach((sheet) => {
        if ("cssRules" in sheet) {
          try {
            toArray(sheet.cssRules || []).forEach((item) => {
              ret.push(item);
            });
          } catch (e) {
            console.error(`Error while reading CSS rules from ${sheet.href}`, e);
          }
        }
      });
      return ret;
    });
  }
  function getWebFontRules(cssRules) {
    return cssRules.filter((rule) => rule.type === CSSRule.FONT_FACE_RULE).filter((rule) => shouldEmbed(rule.style.getPropertyValue("src")));
  }
  async function parseWebFontRules(node, options) {
    if (node.ownerDocument == null) {
      throw new Error("Provided element is not within a Document");
    }
    const styleSheets = toArray(node.ownerDocument.styleSheets);
    const cssRules = await getCSSRules(styleSheets, options);
    return getWebFontRules(cssRules);
  }
  function normalizeFontFamily(font) {
    return font.trim().replace(/["']/g, "");
  }
  function getUsedFonts(node) {
    const fonts = /* @__PURE__ */ new Set();
    function traverse(node2) {
      const fontFamily = node2.style.fontFamily || getComputedStyle(node2).fontFamily;
      fontFamily.split(",").forEach((font) => {
        fonts.add(normalizeFontFamily(font));
      });
      Array.from(node2.children).forEach((child) => {
        if (child instanceof HTMLElement) {
          traverse(child);
        }
      });
    }
    traverse(node);
    return fonts;
  }
  async function getWebFontCSS(node, options) {
    const rules = await parseWebFontRules(node, options);
    const usedFonts = getUsedFonts(node);
    const cssTexts = await Promise.all(rules.filter((rule) => usedFonts.has(normalizeFontFamily(rule.style.fontFamily))).map((rule) => {
      const baseUrl = rule.parentStyleSheet ? rule.parentStyleSheet.href : null;
      return embedResources(rule.cssText, baseUrl, options);
    }));
    return cssTexts.join("\n");
  }
  async function embedWebFonts(clonedNode, options) {
    const cssText = options.fontEmbedCSS != null ? options.fontEmbedCSS : options.skipFonts ? null : await getWebFontCSS(clonedNode, options);
    if (cssText) {
      const styleNode = document.createElement("style");
      const sytleContent = document.createTextNode(cssText);
      styleNode.appendChild(sytleContent);
      if (clonedNode.firstChild) {
        clonedNode.insertBefore(styleNode, clonedNode.firstChild);
      } else {
        clonedNode.appendChild(styleNode);
      }
    }
  }

  // node_modules/html-to-image/es/index.js
  async function toSvg(node, options = {}) {
    const { width, height } = getImageSize(node, options);
    const clonedNode = await cloneNode(node, options, true);
    await embedWebFonts(clonedNode, options);
    await embedImages(clonedNode, options);
    applyStyle(clonedNode, options);
    const datauri = await nodeToDataURL(clonedNode, width, height);
    return datauri;
  }
  async function toCanvas(node, options = {}) {
    const { width, height } = getImageSize(node, options);
    const svg = await toSvg(node, options);
    const img = await createImage(svg);
    const canvas = document.createElement("canvas");
    const context = canvas.getContext("2d");
    const ratio = options.pixelRatio || getPixelRatio();
    const canvasWidth = options.canvasWidth || width;
    const canvasHeight = options.canvasHeight || height;
    canvas.width = canvasWidth * ratio;
    canvas.height = canvasHeight * ratio;
    if (!options.skipAutoScale) {
      checkCanvasDimensions(canvas);
    }
    canvas.style.width = `${canvasWidth}`;
    canvas.style.height = `${canvasHeight}`;
    if (options.backgroundColor) {
      context.fillStyle = options.backgroundColor;
      context.fillRect(0, 0, canvas.width, canvas.height);
    }
    context.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas;
  }
  async function toPng(node, options = {}) {
    const canvas = await toCanvas(node, options);
    return canvas.toDataURL();
  }
  async function toJpeg(node, options = {}) {
    const canvas = await toCanvas(node, options);
    return canvas.toDataURL("image/jpeg", options.quality || 1);
  }

  // src/services/screenshot.ts
  function errorMessage(err) {
    if (!err) return "Unknown error";
    if (typeof err === "string") return err;
    if (err.message) return err.message;
    if (err instanceof Event) return `Event: ${err.type}`;
    try {
      return JSON.stringify(err);
    } catch {
      return String(err);
    }
  }
  function splitDataUrl(dataUrl) {
    const m = /^data:([^;,]+)(?:;[^,]*)?,(.*)$/.exec(dataUrl);
    if (!m) throw new Error("Output is not a valid data: URL");
    const mediaType = m[1];
    let payload = m[2];
    if (!/;base64/i.test(dataUrl)) {
      throw new Error(
        `Output is not base64-encoded (got ${mediaType}). Capture probably failed silently.`
      );
    }
    return { mediaType, base64: payload };
  }
  async function resizeDataUrl(dataUrl, maxWidth, maxHeight, format, quality) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        try {
          const srcW = img.naturalWidth;
          const srcH = img.naturalHeight;
          if (!srcW || !srcH) {
            reject(new Error("Captured image has zero dimensions"));
            return;
          }
          const scale = Math.min(maxWidth / srcW, maxHeight / srcH, 1);
          const dstW = Math.max(1, Math.round(srcW * scale));
          const dstH = Math.max(1, Math.round(srcH * scale));
          const canvas = document.createElement("canvas");
          canvas.width = dstW;
          canvas.height = dstH;
          const ctx = canvas.getContext("2d");
          if (!ctx) {
            reject(new Error("Could not get 2D canvas context"));
            return;
          }
          if (format === "jpeg") {
            ctx.fillStyle = "#ffffff";
            ctx.fillRect(0, 0, dstW, dstH);
          }
          ctx.drawImage(img, 0, 0, dstW, dstH);
          const mime = format === "jpeg" ? "image/jpeg" : "image/png";
          const out = canvas.toDataURL(mime, quality);
          resolve({ dataUrl: out, width: dstW, height: dstH });
        } catch (drawErr) {
          reject(new Error(`Canvas resize failed: ${errorMessage(drawErr)}`));
        }
      };
      img.onerror = (ev) => reject(
        new Error(
          `Failed to load captured image for resizing${ev instanceof Event ? ` (${ev.type})` : ""}`
        )
      );
      img.src = dataUrl;
    });
  }
  async function takeScreenshot(selector, format, quality, max_width, max_height, full_page) {
    const fmt = format ?? "jpeg";
    const qual = quality ?? 0.6;
    const maxW = max_width ?? 800;
    const maxH = max_height ?? 800;
    const capturePage = full_page ?? false;
    let target;
    if (selector) {
      target = document.querySelector(selector);
      if (!target) {
        return { error: `No element found for selector: ${selector}` };
      }
    } else if (capturePage) {
      target = document.documentElement;
    } else {
      target = document.body;
    }
    try {
      const node = target;
      const viewportW = window.innerWidth;
      const viewportH = window.innerHeight;
      const TRANSPARENT_PIXEL = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkAAIAAAoAAv/lxKUAAAAASUVORK5CYII=";
      const captureOptions = {
        quality: qual,
        pixelRatio: 1,
        cacheBust: true,
        skipAutoScale: true,
        skipFonts: true,
        imagePlaceholder: TRANSPARENT_PIXEL,
        filter: (el) => {
          return el.id !== "hypha-debugger-host" && el.id !== "hypha-debugger-cursor" && el.id !== "playwright-highlight-container";
        }
      };
      if (!selector && !capturePage) {
        captureOptions.width = viewportW;
        captureOptions.height = viewportH;
      }
      const runCapture = async (opts, timeoutMs = 15e3) => {
        const capturePromise = fmt === "jpeg" ? toJpeg(node, opts) : toPng(node, opts);
        return Promise.race([
          capturePromise,
          new Promise(
            (_, reject) => setTimeout(
              () => reject(
                new Error(`Screenshot capture timed out after ${timeoutMs}ms`)
              ),
              timeoutMs
            )
          )
        ]);
      };
      let dataUrl;
      try {
        dataUrl = await runCapture(captureOptions);
      } catch (captureErr) {
        try {
          const noImagesOpts = {
            ...captureOptions,
            filter: (el) => {
              if (!captureOptions.filter(el)) return false;
              const tag = el.tagName?.toLowerCase();
              return tag !== "img" && tag !== "picture" && tag !== "video";
            }
          };
          dataUrl = await runCapture(noImagesOpts, 1e4);
        } catch (retryErr) {
          return {
            error: `Capture failed: ${errorMessage(captureErr)} (retry without images also failed: ${errorMessage(retryErr)})`
          };
        }
      }
      let resized;
      try {
        resized = await resizeDataUrl(dataUrl, maxW, maxH, fmt, qual);
      } catch (resizeErr) {
        return {
          error: `Resize failed: ${errorMessage(resizeErr)} (this usually means the captured image was malformed; try lowering max_width or use full_page:false)`
        };
      }
      let parts;
      try {
        parts = splitDataUrl(resized.dataUrl);
      } catch (validateErr) {
        return { error: `Output validation failed: ${errorMessage(validateErr)}` };
      }
      if (parts.base64.length < 200) {
        return {
          error: `Output too small (${parts.base64.length} chars base64) \u2014 capture likely failed`
        };
      }
      const sizeKb = Math.round(parts.base64.length * 0.75 / 1024);
      return {
        base64: parts.base64,
        media_type: parts.mediaType,
        data_url: resized.dataUrl,
        format: fmt,
        width: resized.width,
        height: resized.height,
        size_kb: sizeKb
      };
    } catch (err) {
      return { error: `Screenshot failed: ${errorMessage(err)}` };
    }
  }
  takeScreenshot.__schema__ = {
    name: "takeScreenshot",
    description: "Capture a screenshot of the current viewport, a specific element, or the full page. Downscaled to fit within max_width \xD7 max_height (default 800px) and JPEG-encoded at quality 0.6 by default for agent-friendly payload sizes. Returns: { base64, media_type, data_url, format, width, height, size_kb }. Use `base64` (raw base64, no prefix) directly with Claude/GPT image content fields. Use `data_url` for HTML <img src=...> previews. On failure returns { error }.",
    parameters: {
      type: "object",
      properties: {
        selector: {
          type: "string",
          description: "CSS selector of the element to capture. Omit to capture the viewport (or full page if full_page=true)."
        },
        format: {
          type: "string",
          enum: ["png", "jpeg"],
          description: 'Image format. Default: "jpeg" (much smaller than PNG). Use "png" only when sharp text really matters.'
        },
        quality: {
          type: "number",
          description: "JPEG quality (0\u20131). Default: 0.6. Ignored for PNG. Lower = smaller payload."
        },
        max_width: {
          type: "number",
          description: "Maximum output width in pixels. Default: 800. Image scaled down preserving aspect ratio."
        },
        max_height: {
          type: "number",
          description: "Maximum output height in pixels. Default: 800. Image scaled down preserving aspect ratio."
        },
        full_page: {
          type: "boolean",
          description: "If true, capture the entire scrollable page instead of just the viewport. Default: false."
        }
      }
    }
  };

  // src/services/execute.ts
  function isCspEvalError(e) {
    if (!e) return false;
    if (e instanceof EvalError) return true;
    const msg = String(e.message || e);
    return /unsafe-eval|Content Security Policy|call to .*Function/i.test(msg);
  }
  function autoReturn(code) {
    const trimmed = code.trim();
    if (/\breturn\b/.test(trimmed)) return trimmed;
    let lines = trimmed.split("\n").map((l) => l.trim()).filter(Boolean);
    if (lines.length === 1 && lines[0].includes(";")) {
      lines = lines[0].split(";").map((s) => s.trim()).filter(Boolean);
    }
    if (lines.length === 0) return trimmed;
    const lastLine = lines[lines.length - 1];
    if (/^(if|for|while|switch|try|class|function |const |let |var |import |export )/.test(lastLine)) {
      return trimmed;
    }
    lines[lines.length - 1] = "return (" + lastLine.replace(/;$/, "") + ");";
    return lines.join(";\n");
  }
  async function executeScript(code, timeout_ms) {
    const timeoutMs = timeout_ms ?? 1e4;
    try {
      let execCode = autoReturn(code);
      let fn;
      try {
        fn = new Function("return (async () => {" + execCode + "})()");
      } catch (e) {
        if (isCspEvalError(e)) {
          return {
            error: "execute_script is unavailable on this page: its Content Security Policy blocks dynamic code evaluation ('unsafe-eval' not allowed). Use the DOM/interaction services (get_browser_state, click_element_by_index, query_dom, etc.) instead \u2014 they do not need eval."
          };
        }
        fn = new Function("return (async () => {" + code + "})()");
      }
      const result = await Promise.race([
        fn(),
        new Promise(
          (_, reject) => setTimeout(() => reject(new Error("Execution timed out")), timeoutMs)
        )
      ]);
      let serialized;
      let type = typeof result;
      try {
        if (result === void 0) {
          serialized = null;
          type = "undefined";
        } else if (result instanceof HTMLElement) {
          serialized = {
            tag: result.tagName.toLowerCase(),
            id: result.id,
            className: result.className,
            text: (result.textContent ?? "").trim().slice(0, 500)
          };
          type = "HTMLElement";
        } else if (result instanceof NodeList || result instanceof HTMLCollection) {
          serialized = Array.from(result).map((el) => ({
            tag: el.tagName?.toLowerCase(),
            id: el.id,
            text: (el.textContent ?? "").trim().slice(0, 200)
          }));
          type = "NodeList";
        } else {
          serialized = JSON.parse(JSON.stringify(result));
        }
      } catch {
        serialized = String(result);
        type = "string (serialized)";
      }
      return { result: serialized, type };
    } catch (err) {
      return { error: `Execution error: ${err.message ?? err}` };
    }
  }
  executeScript.__schema__ = {
    name: "executeScript",
    description: `Execute arbitrary JavaScript code in the page context. Supports async/await. The last expression is auto-returned (no need for explicit "return"). Examples: "document.title", "document.querySelectorAll('a').length", "await fetch('/api/data').then(r => r.json())". Returns: { result, type } on success, or { error } on exception.`,
    parameters: {
      type: "object",
      properties: {
        code: {
          type: "string",
          description: `JavaScript code to execute. The last expression is automatically returned. Examples: "document.title", "document.querySelector('h1').textContent".`
        },
        timeout_ms: {
          type: "number",
          description: "Maximum execution time in milliseconds. Default: 10000."
        }
      },
      required: ["code"]
    }
  };

  // src/services/navigate.ts
  var STORAGE_KEY = "__hypha_debugger_config__";
  function getScriptUrl() {
    try {
      const raw = sessionStorage.getItem(STORAGE_KEY);
      if (raw) {
        const config = JSON.parse(raw);
        if (config.script_url) return config.script_url;
      }
    } catch {
    }
    return "https://cdn.jsdelivr.net/npm/hypha-debugger/dist/hypha-debugger.min.js";
  }
  function injectLoader(html, scriptUrl) {
    const loader = `<script src="${scriptUrl}"><\/script>`;
    if (html.includes("</body>")) {
      return html.replace("</body>", loader + "\n</body>");
    }
    if (html.includes("</html>")) {
      return html.replace("</html>", loader + "\n</html>");
    }
    return html + "\n" + loader;
  }
  function softReplace(url, pushState) {
    const scriptUrl = getScriptUrl();
    fetch(url, { credentials: "same-origin", cache: "reload" }).then((response) => {
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const contentType = response.headers.get("content-type") ?? "";
      if (!contentType.includes("text/html")) {
        throw new Error("Not HTML");
      }
      return response.text();
    }).then((html) => {
      const modified = injectLoader(html, scriptUrl);
      document.open();
      document.write(modified);
      document.close();
      if (pushState) {
        try {
          history.pushState({}, "", pushState);
        } catch {
        }
      }
    }).catch(() => {
      if (pushState) {
        window.location.href = pushState;
      } else {
        window.location.reload();
      }
    });
  }
  function navigate(url) {
    try {
      const targetUrl = new URL(url, location.href);
      const sameOrigin = targetUrl.origin === location.origin;
      if (sameOrigin) {
        setTimeout(() => softReplace(targetUrl.href, targetUrl.href), 150);
        return {
          success: true,
          message: `Navigating to ${url} (debugger will auto-reconnect)`
        };
      } else {
        window.location.href = url;
        return {
          success: true,
          message: `Navigating to ${url} (cross-origin, debugger will disconnect)`
        };
      }
    } catch (err) {
      return {
        success: false,
        message: `Navigation failed: ${err.message ?? err}`
      };
    }
  }
  navigate.__schema__ = {
    name: "navigate",
    description: "Navigate the browser to a new URL. For same-origin URLs, the debugger auto-reconnects. Cross-origin navigation will disconnect the debugger.",
    parameters: {
      type: "object",
      properties: {
        url: {
          type: "string",
          description: "The URL to navigate to."
        }
      },
      required: ["url"]
    }
  };
  function goBack() {
    try {
      window.history.back();
      return {
        success: true,
        message: "Navigated back (debugger will auto-reconnect via popstate)"
      };
    } catch (err) {
      return {
        success: false,
        message: `Back navigation failed: ${err.message ?? err}`
      };
    }
  }
  goBack.__schema__ = {
    name: "goBack",
    description: "Navigate back in browser history. The debugger auto-reconnects for same-origin pages.",
    parameters: {
      type: "object",
      properties: {}
    }
  };
  function goForward() {
    try {
      window.history.forward();
      return {
        success: true,
        message: "Navigated forward (debugger will auto-reconnect via popstate)"
      };
    } catch (err) {
      return {
        success: false,
        message: `Forward navigation failed: ${err.message ?? err}`
      };
    }
  }
  goForward.__schema__ = {
    name: "goForward",
    description: "Navigate forward in browser history. The debugger auto-reconnects for same-origin pages.",
    parameters: {
      type: "object",
      properties: {}
    }
  };
  function reload() {
    try {
      setTimeout(() => softReplace(location.href), 150);
      return {
        success: true,
        message: "Reloading page (debugger will auto-reconnect)"
      };
    } catch (err) {
      return { success: false, message: `Reload failed: ${err.message ?? err}` };
    }
  }
  reload.__schema__ = {
    name: "reload",
    description: "Reload the current page. The debugger auto-reconnects after reload using soft page replacement.",
    parameters: {
      type: "object",
      properties: {}
    }
  };

  // src/services/react.ts
  function getFiberFromDOM(node) {
    const keys = Object.keys(node);
    const fiberKey = keys.find(
      (k) => k.startsWith("__reactFiber$") || k.startsWith("__reactInternalInstance$")
    );
    return fiberKey ? node[fiberKey] : null;
  }
  function findReactRoot() {
    const common = ["#root", "#app", "#__next", "[data-reactroot]", "main", "body"];
    for (const sel of common) {
      const el = document.querySelector(sel);
      if (el && getFiberFromDOM(el)) return el;
    }
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_ELEMENT,
      null
    );
    let node = walker.currentNode;
    while (node) {
      if (node instanceof Element && getFiberFromDOM(node)) return node;
      node = walker.nextNode();
    }
    return null;
  }
  function getComponentName(fiber) {
    const { type } = fiber;
    if (!type) return "(unknown)";
    if (typeof type === "string") return type;
    if (typeof type === "function") {
      return type.displayName || type.name || "Anonymous";
    }
    if (typeof type === "object") {
      if (type.displayName) return type.displayName;
      if (type.render)
        return type.render.displayName || type.render.name || "ForwardRef";
      if (type.type) return getComponentName({ type: type.type });
      if (type.$$typeof?.toString() === "Symbol(react.memo)") {
        return `Memo(${getComponentName({ type: type.type })})`;
      }
    }
    return "(unknown)";
  }
  function getFiberType(fiber) {
    if (fiber.tag === 0 || fiber.tag === 11 || fiber.tag === 14 || fiber.tag === 15)
      return "function";
    if (fiber.tag === 1) return "class";
    if (fiber.tag === 5 || fiber.tag === 6) return "host";
    return "other";
  }
  function safeSerialize(obj, depth = 0, maxDepth = 2) {
    if (depth > maxDepth) return "[max depth]";
    if (obj === null || obj === void 0) return obj;
    if (typeof obj === "function") return `[Function: ${obj.name || "anonymous"}]`;
    if (typeof obj !== "object") return obj;
    if (obj instanceof HTMLElement) return `[${obj.tagName.toLowerCase()}#${obj.id}]`;
    if (Array.isArray(obj)) {
      return obj.slice(0, 10).map((v) => safeSerialize(v, depth + 1, maxDepth));
    }
    const result = {};
    const keys = Object.keys(obj).slice(0, 20);
    for (const key of keys) {
      if (key.startsWith("_") || key.startsWith("$$")) continue;
      try {
        result[key] = safeSerialize(obj[key], depth + 1, maxDepth);
      } catch {
        result[key] = "[unserializable]";
      }
    }
    return result;
  }
  function extractState(fiber) {
    if (fiber.tag === 1 && fiber.stateNode) {
      return safeSerialize(fiber.stateNode.state);
    }
    if (fiber.tag === 0 || fiber.tag === 11 || fiber.tag === 15) {
      const states = [];
      let hook = fiber.memoizedState;
      let i = 0;
      while (hook && i < 20) {
        if (hook.queue !== null && hook.queue !== void 0) {
          states.push(safeSerialize(hook.memoizedState));
        }
        hook = hook.next;
        i++;
      }
      return states.length > 0 ? states : null;
    }
    return null;
  }
  function fiberToInfo(fiber, depth, maxDepth) {
    const fiberType = getFiberType(fiber);
    const isComponent = fiberType === "function" || fiberType === "class";
    const info = {
      name: getComponentName(fiber),
      type: fiberType,
      props: isComponent ? safeSerialize(fiber.memoizedProps) : {},
      state: isComponent ? extractState(fiber) : null,
      key: fiber.key,
      children: []
    };
    if (depth < maxDepth) {
      let child = fiber.child;
      while (child) {
        const childInfo = fiberToInfo(child, depth + 1, maxDepth);
        if (childInfo) {
          if (childInfo.type !== "host" || childInfo.children.length > 0) {
            info.children.push(childInfo);
          }
        }
        child = child.sibling;
      }
    }
    return info;
  }
  function getReactTree(selector, max_depth) {
    const maxDepth = max_depth ?? 5;
    let rootEl;
    let usedSelector;
    if (selector) {
      rootEl = document.querySelector(selector);
      usedSelector = selector;
      if (!rootEl) {
        return { error: `No element found for selector: ${selector}` };
      }
    } else {
      rootEl = findReactRoot();
      usedSelector = rootEl?.tagName.toLowerCase() + (rootEl?.id ? "#" + rootEl.id : "") || "(auto)";
      if (!rootEl) {
        return {
          error: "No React root found on this page. Tried #root, #app, #__next, [data-reactroot], main, body \u2014 none had React fibers. This page may not be a React app, or React may not have rendered yet. Pass an explicit `selector` if you know the mount point."
        };
      }
    }
    const fiber = getFiberFromDOM(rootEl);
    if (!fiber) {
      return {
        error: `No React fiber found on element "${usedSelector}". Is this a React app?`
      };
    }
    let current = fiber;
    while (current && current.tag === 3) {
      current = current.child;
    }
    if (!current) {
      return { error: "Could not find root React component fiber." };
    }
    const tree = fiberToInfo(current, 0, maxDepth);
    if (!tree) {
      return { error: "Could not build React component tree." };
    }
    return tree;
  }
  getReactTree.__schema__ = {
    name: "getReactTree",
    description: "Inspect the React component tree. Returns component names, props, state (including hooks), and children hierarchy. When no selector is provided, auto-detects the React root by scanning common mount points (#root, #app, #__next, [data-reactroot], main, body) and then walking the DOM for any element with a React fiber attached.",
    parameters: {
      type: "object",
      properties: {
        selector: {
          type: "string",
          description: "CSS selector of the React root element. Omit for auto-detection."
        },
        max_depth: {
          type: "number",
          description: "Maximum depth to traverse the component tree. Default: 5."
        }
      }
    }
  };

  // src/services/skill.ts
  function generateSkillMd(serviceFunctions, serviceUrl, pageContext, guidance) {
    const frontmatter = [
      "---",
      "name: web-debugger",
      "description: A Hypha debugger injected into a LIVE web page in a real browser. Remotely inspect the DOM, take screenshots, run JavaScript, fill forms, click/type by index, inspect React, and navigate \u2014 all via HTTP API calls.",
      "compatibility: Requires network access to the Hypha server. Works with any HTTP client (curl, fetch, Python requests).",
      "metadata:",
      '  version: "0.1"',
      '  author: "hypha-debugger"',
      "---"
    ].join("\n");
    const attached = pageContext?.title || pageContext?.url ? `**Currently attached to:** ${pageContext.title ? `"${pageContext.title}"` : ""}${pageContext.url ? ` \u2014 ${pageContext.url}` : ""} (call \`get_page_info\` for live details).` : "Call `get_page_info` to see the page you are attached to.";
    const intro = [
      "",
      "# Web Debugger \u2014 control a live web page",
      "",
      "**What this is:** a Hypha debugger has been injected into a LIVE web page running in a real browser, and this document is its HTTP API. You (an AI agent) can remotely inspect and control that exact page \u2014 read and modify the DOM, click and type, take screenshots, run JavaScript, and inspect React components. Changes you make are applied to the real page immediately.",
      "",
      attached,
      "",
      "Every function below is an HTTP endpoint under the service URL. Pick the approach that fits your task \u2014 they combine freely.",
      ...guidance ? ["", guidance] : [],
      "",
      "## Approaches",
      "",
      "### execute_script \u2014 Run Arbitrary JavaScript",
      "",
      "The most versatile function. Use it to read/modify page state, call APIs, query the DOM,",
      "or do anything JavaScript can do. The last expression is auto-returned (no need for `return`).",
      "",
      "```bash",
      `# Read page state`,
      `curl -X POST '{SERVICE_URL}/execute_script' \\`,
      `  -H 'Content-Type: application/json' -d '{"code": "document.title"}'`,
      "",
      `# Query DOM`,
      `curl -X POST '{SERVICE_URL}/execute_script' \\`,
      `  -H 'Content-Type: application/json' -d '{"code": "document.querySelector(\\"h1\\").textContent"}'`,
      "",
      `# Call an API`,
      `curl -X POST '{SERVICE_URL}/execute_script' \\`,
      `  -H 'Content-Type: application/json' -d '{"code": "await fetch(\\"/api/data\\").then(r => r.json())"}'`,
      "",
      `# Modify the page`,
      `curl -X POST '{SERVICE_URL}/execute_script' \\`,
      `  -H 'Content-Type: application/json' -d '{"code": "document.getElementById(\\"name\\").value = \\"Alice\\""}'`,
      "```",
      "",
      "### get_browser_state + Index-Based Interaction",
      "",
      "Best for UI interaction as a user would \u2014 clicking buttons, filling forms, selecting options.",
      "All interactive elements are detected and indexed as `[0]`, `[1]`, `[2]`, etc.",
      "",
      "```bash",
      `# Step 1: See all interactive elements`,
      `curl '{SERVICE_URL}/get_browser_state'`,
      "",
      `# Step 2: Act by index`,
      `curl -X POST '{SERVICE_URL}/click_element_by_index' \\`,
      `  -H 'Content-Type: application/json' -d '{"index": 2}'`,
      "",
      `curl -X POST '{SERVICE_URL}/input_text' \\`,
      `  -H 'Content-Type: application/json' -d '{"index": 1, "text": "hello world"}'`,
      "",
      `curl -X POST '{SERVICE_URL}/select_option' \\`,
      `  -H 'Content-Type: application/json' -d '{"index": 3, "option_text": "French"}'`,
      "",
      `curl -X POST '{SERVICE_URL}/scroll' \\`,
      `  -H 'Content-Type: application/json' -d '{"direction": "down"}'`,
      "",
      `# Step 3: Verify visually`,
      `curl '{SERVICE_URL}/take_screenshot'`,
      "```",
      "",
      "### get_react_tree \u2014 Inspect React Components",
      "",
      "If the page uses React, inspect component names, props, state, and hooks:",
      "```bash",
      `curl '{SERVICE_URL}/get_react_tree'`,
      "```",
      "",
      "### CSS Selector-Based Functions",
      "",
      "Use CSS selectors directly when you know the element:",
      "```bash",
      `curl -X POST '{SERVICE_URL}/click_element' \\`,
      `  -H 'Content-Type: application/json' -d '{"selector": "button.submit"}'`,
      "",
      `curl -X POST '{SERVICE_URL}/fill_input' \\`,
      `  -H 'Content-Type: application/json' -d '{"selector": "#email", "value": "user@example.com"}'`,
      "",
      `curl -X POST '{SERVICE_URL}/query_dom' \\`,
      `  -H 'Content-Type: application/json' -d '{"selector": ".product-card"}'`,
      "```",
      "",
      "## How to call functions",
      "",
      "All functions are available as HTTP endpoints. Replace `{SERVICE_URL}` with the actual service URL.",
      "",
      "- **GET** for functions with no required parameters",
      "- **POST** with JSON body for functions with parameters",
      "- Append `?_mode=last` to resolve the most recent instance (recommended after page reloads where the clientId changes)",
      "",
      "## Response format",
      "",
      "All functions return JSON. There are three patterns:",
      "",
      "**1. Data-returning functions** (e.g. `take_screenshot`, `get_page_info`, `execute_script`, `get_browser_state`, `get_html`, `get_react_tree`) return function-specific keys:",
      "",
      "- `take_screenshot` \u2192 `{base64, media_type, data_url, format, width, height, size_kb}`. Use `base64` (raw, no prefix) for Claude/GPT image content fields. Use `data_url` for HTML `<img src=...>` previews.",
      "- `execute_script` \u2192 `{result, type}` (or `{error}` on exception)",
      "- `get_browser_state` \u2192 `{url, title, header, content, footer, element_count}`",
      "- `get_page_info` \u2192 `{url, title, viewport_width, viewport_height, ...}`",
      "- `get_html` \u2192 `{html, length, truncated}`",
      "",
      "**2. Action functions** (e.g. `click_*`, `input_text`, `select_option`, `scroll`, `navigate`) return:",
      "",
      '- `{success: true, message: "..."}` \u2014 action succeeded',
      '- `{success: false, message: "..."}` \u2014 action failed (element not found, etc.)',
      "",
      "**3. Errors from the Hypha gateway** (NOT from the service itself) return:",
      "",
      '- `{success: false, detail: "..."}` \u2014 e.g. service not found, call timed out, disconnected. If you see this, the browser tab is probably closed or the debugger crashed.',
      ""
    ].join("\n");
    const functionDocs = ["## Available Functions", ""];
    const entries = Object.entries(serviceFunctions).filter(
      ([name, fn]) => fn?.__schema__ && name !== "get_skill_md"
    );
    for (const [name, fn] of entries) {
      const schema = fn.__schema__;
      functionDocs.push(`### \`${name}\``);
      functionDocs.push("");
      functionDocs.push(schema.description);
      functionDocs.push("");
      const props = schema.parameters?.properties;
      const required = schema.parameters?.required ?? [];
      if (props && Object.keys(props).length > 0) {
        functionDocs.push("**Parameters:**");
        functionDocs.push("");
        functionDocs.push("| Parameter | Type | Required | Description |");
        functionDocs.push("|-----------|------|----------|-------------|");
        for (const [param, info] of Object.entries(props)) {
          const isRequired = required.includes(param);
          let typeStr = info.type ?? "any";
          if (info.enum) {
            typeStr = info.enum.map((e) => `"${e}"`).join(" / ");
          }
          if (info.items) typeStr = `${info.items.type}[]`;
          const desc = (info.description ?? "").replace(/\|/g, "\\|");
          functionDocs.push(
            `| \`${param}\` | ${typeStr} | ${isRequired ? "Yes" : "No"} | ${desc} |`
          );
        }
        functionDocs.push("");
        if (required.length > 0) {
          const exampleParams = {};
          for (const p of required) {
            const info = props[p];
            if (info?.type === "string") exampleParams[p] = `<${p}>`;
            else if (info?.type === "number") exampleParams[p] = "0";
            else exampleParams[p] = `<${p}>`;
          }
          functionDocs.push("**Example:**");
          functionDocs.push("```bash");
          functionDocs.push(
            `curl -X POST '{SERVICE_URL}/${name}' \\`
          );
          functionDocs.push(`  -H 'Content-Type: application/json' \\`);
          functionDocs.push(`  -d '${JSON.stringify(exampleParams)}'`);
          functionDocs.push("```");
        } else {
          functionDocs.push("**Example:**");
          functionDocs.push("```bash");
          functionDocs.push(
            `curl '{SERVICE_URL}/${name}'`
          );
          functionDocs.push("```");
        }
      } else {
        functionDocs.push("**Parameters:** None");
        functionDocs.push("");
        functionDocs.push("**Example:**");
        functionDocs.push("```bash");
        functionDocs.push(
          `curl '{SERVICE_URL}/${name}'`
        );
        functionDocs.push("```");
      }
      functionDocs.push("");
    }
    const tips = [
      "## Tips",
      "",
      "- **`execute_script` is the most versatile** \u2014 use it for reading state, calling APIs, DOM queries, or anything not covered by other functions. The last expression is auto-returned. Returns `{result, type}`.",
      "- **`get_browser_state` is the best way to see what's on the page** \u2014 it detects all interactive elements and shows them as indexed items.",
      "- **After each action, call `get_browser_state` again** \u2014 element indices change when the DOM updates.",
      "- **Use `take_screenshot`** to visually verify the page state. The response includes `base64` (raw, ready for Claude/GPT image fields) and `data_url` (for HTML previews). Default size is 800px JPEG q=0.6 \u2014 bump `max_width` if you need more detail.",
      "- **Use `remove_highlights`** before a screenshot for a clean view.",
      "- **Use `scroll`** with an element index to scroll inside a specific container (e.g. a chat window, sidebar).",
      "- **Use `get_page_info` with `include_logs=true`** to check for JavaScript errors or debug output.",
      "- **Use `get_react_tree`** if the page uses React \u2014 it gives you component names, props, and state without needing DevTools.",
      "- **Use `navigate`** to go to other pages \u2014 same-origin navigation auto-reconnects the debugger.",
      '- **If you get `{success: false, detail: "Service not found"}`** \u2014 the browser tab was closed or the debugger disconnected. The user needs to re-click the bookmarklet.',
      "- **Append `?_mode=last`** to the URL if the service clientId changed (e.g. after page reload) \u2014 resolves to the most recent instance.",
      "- All POST endpoints accept JSON body with the parameter names as keys.",
      ""
    ].join("\n");
    return [frontmatter, intro, functionDocs.join("\n"), tips].join("\n");
  }

  // src/page-controller/dom-tree.js
  var dom_tree_default = (args = {
    doHighlightElements: true,
    focusHighlightIndex: -1,
    viewportExpansion: 0,
    debugMode: false,
    /**
     * @edit
     */
    /** @type {Element[]} */
    interactiveBlacklist: [],
    /** @type {Element[]} */
    interactiveWhitelist: [],
    highlightOpacity: 0.1,
    highlightLabelOpacity: 0.5
  }) => {
    const { interactiveBlacklist, interactiveWhitelist, highlightOpacity, highlightLabelOpacity } = args;
    const { doHighlightElements, focusHighlightIndex, viewportExpansion, debugMode } = args;
    let highlightIndex = 0;
    const extraData = /* @__PURE__ */ new WeakMap();
    function addExtraData(element, data) {
      if (!element || element.nodeType !== Node.ELEMENT_NODE) return;
      extraData.set(element, { ...extraData.get(element), ...data });
    }
    const DOM_CACHE = {
      boundingRects: /* @__PURE__ */ new WeakMap(),
      clientRects: /* @__PURE__ */ new WeakMap(),
      computedStyles: /* @__PURE__ */ new WeakMap(),
      clearCache: () => {
        DOM_CACHE.boundingRects = /* @__PURE__ */ new WeakMap();
        DOM_CACHE.clientRects = /* @__PURE__ */ new WeakMap();
        DOM_CACHE.computedStyles = /* @__PURE__ */ new WeakMap();
      }
    };
    function getCachedBoundingRect(element) {
      if (!element) return null;
      if (DOM_CACHE.boundingRects.has(element)) {
        return DOM_CACHE.boundingRects.get(element);
      }
      const rect = element.getBoundingClientRect();
      if (rect) {
        DOM_CACHE.boundingRects.set(element, rect);
      }
      return rect;
    }
    function getCachedComputedStyle(element) {
      if (!element) return null;
      if (DOM_CACHE.computedStyles.has(element)) {
        return DOM_CACHE.computedStyles.get(element);
      }
      const style = window.getComputedStyle(element);
      if (style) {
        DOM_CACHE.computedStyles.set(element, style);
      }
      return style;
    }
    function getCachedClientRects(element) {
      if (!element) return null;
      if (DOM_CACHE.clientRects.has(element)) {
        return DOM_CACHE.clientRects.get(element);
      }
      const rects = element.getClientRects();
      if (rects) {
        DOM_CACHE.clientRects.set(element, rects);
      }
      return rects;
    }
    const DOM_HASH_MAP = {};
    const ID = { current: 0 };
    const HIGHLIGHT_CONTAINER_ID = "playwright-highlight-container";
    const xpathCache = /* @__PURE__ */ new WeakMap();
    function highlightElement(element, index, parentIframe = null) {
      if (!element) return index;
      const overlays = [];
      let label = null;
      let labelWidth = 20;
      let labelHeight = 16;
      let cleanupFn = null;
      try {
        let container = document.getElementById(HIGHLIGHT_CONTAINER_ID);
        if (!container) {
          container = document.createElement("div");
          container.id = HIGHLIGHT_CONTAINER_ID;
          container.style.position = "fixed";
          container.style.pointerEvents = "none";
          container.style.top = "0";
          container.style.left = "0";
          container.style.width = "100%";
          container.style.height = "100%";
          container.style.zIndex = "2147483640";
          container.style.backgroundColor = "transparent";
          document.body.appendChild(container);
        }
        const rects = element.getClientRects();
        if (!rects || rects.length === 0) return index;
        const colors = [
          "#FF0000",
          "#00FF00",
          "#0000FF",
          "#FFA500",
          "#800080",
          "#008080",
          "#FF69B4",
          "#4B0082",
          "#FF4500",
          "#2E8B57",
          "#DC143C",
          "#4682B4"
        ];
        const colorIndex = index % colors.length;
        let baseColor = colors[colorIndex];
        const backgroundColor = baseColor + Math.floor(highlightOpacity * 255).toString(16).padStart(2, "0");
        baseColor = baseColor + Math.floor(highlightLabelOpacity * 255).toString(16).padStart(2, "0");
        let iframeOffset = { x: 0, y: 0 };
        if (parentIframe) {
          const iframeRect = parentIframe.getBoundingClientRect();
          iframeOffset.x = iframeRect.left;
          iframeOffset.y = iframeRect.top;
        }
        const fragment = document.createDocumentFragment();
        for (const rect of rects) {
          if (rect.width === 0 || rect.height === 0) continue;
          const overlay = document.createElement("div");
          overlay.style.position = "fixed";
          overlay.style.border = `2px solid ${baseColor}`;
          overlay.style.backgroundColor = backgroundColor;
          overlay.style.pointerEvents = "none";
          overlay.style.boxSizing = "border-box";
          const top = rect.top + iframeOffset.y;
          const left = rect.left + iframeOffset.x;
          overlay.style.top = `${top}px`;
          overlay.style.left = `${left}px`;
          overlay.style.width = `${rect.width}px`;
          overlay.style.height = `${rect.height}px`;
          fragment.appendChild(overlay);
          overlays.push({ element: overlay, initialRect: rect });
        }
        const firstRect = rects[0];
        label = document.createElement("div");
        label.className = "playwright-highlight-label";
        label.style.position = "fixed";
        label.style.background = baseColor;
        label.style.color = "white";
        label.style.padding = "1px 4px";
        label.style.borderRadius = "4px";
        label.style.fontSize = `${Math.min(12, Math.max(8, firstRect.height / 2))}px`;
        label.textContent = index.toString();
        labelWidth = label.offsetWidth > 0 ? label.offsetWidth : labelWidth;
        labelHeight = label.offsetHeight > 0 ? label.offsetHeight : labelHeight;
        const firstRectTop = firstRect.top + iframeOffset.y;
        const firstRectLeft = firstRect.left + iframeOffset.x;
        let labelTop = firstRectTop + 2;
        let labelLeft = firstRectLeft + firstRect.width - labelWidth - 2;
        if (firstRect.width < labelWidth + 4 || firstRect.height < labelHeight + 4) {
          labelTop = firstRectTop - labelHeight - 2;
          labelLeft = firstRectLeft + firstRect.width - labelWidth;
          if (labelLeft < iframeOffset.x) labelLeft = firstRectLeft;
        }
        labelTop = Math.max(0, Math.min(labelTop, window.innerHeight - labelHeight));
        labelLeft = Math.max(0, Math.min(labelLeft, window.innerWidth - labelWidth));
        label.style.top = `${labelTop}px`;
        label.style.left = `${labelLeft}px`;
        fragment.appendChild(label);
        const updatePositions = () => {
          const newRects = element.getClientRects();
          let newIframeOffset = { x: 0, y: 0 };
          if (parentIframe) {
            const iframeRect = parentIframe.getBoundingClientRect();
            newIframeOffset.x = iframeRect.left;
            newIframeOffset.y = iframeRect.top;
          }
          overlays.forEach((overlayData, i) => {
            if (i < newRects.length) {
              const newRect = newRects[i];
              const newTop = newRect.top + newIframeOffset.y;
              const newLeft = newRect.left + newIframeOffset.x;
              overlayData.element.style.top = `${newTop}px`;
              overlayData.element.style.left = `${newLeft}px`;
              overlayData.element.style.width = `${newRect.width}px`;
              overlayData.element.style.height = `${newRect.height}px`;
              overlayData.element.style.display = newRect.width === 0 || newRect.height === 0 ? "none" : "block";
            } else {
              overlayData.element.style.display = "none";
            }
          });
          if (newRects.length < overlays.length) {
            for (let i = newRects.length; i < overlays.length; i++) {
              overlays[i].element.style.display = "none";
            }
          }
          if (label && newRects.length > 0) {
            const firstNewRect = newRects[0];
            const firstNewRectTop = firstNewRect.top + newIframeOffset.y;
            const firstNewRectLeft = firstNewRect.left + newIframeOffset.x;
            let newLabelTop = firstNewRectTop + 2;
            let newLabelLeft = firstNewRectLeft + firstNewRect.width - labelWidth - 2;
            if (firstNewRect.width < labelWidth + 4 || firstNewRect.height < labelHeight + 4) {
              newLabelTop = firstNewRectTop - labelHeight - 2;
              newLabelLeft = firstNewRectLeft + firstNewRect.width - labelWidth;
              if (newLabelLeft < newIframeOffset.x) newLabelLeft = firstNewRectLeft;
            }
            newLabelTop = Math.max(0, Math.min(newLabelTop, window.innerHeight - labelHeight));
            newLabelLeft = Math.max(0, Math.min(newLabelLeft, window.innerWidth - labelWidth));
            label.style.top = `${newLabelTop}px`;
            label.style.left = `${newLabelLeft}px`;
            label.style.display = "block";
          } else if (label) {
            label.style.display = "none";
          }
        };
        const throttleFunction = (func, delay) => {
          let lastCall = 0;
          return (...args2) => {
            const now = performance.now();
            if (now - lastCall < delay) return;
            lastCall = now;
            return func(...args2);
          };
        };
        const throttledUpdatePositions = throttleFunction(updatePositions, 16);
        window.addEventListener("scroll", throttledUpdatePositions, true);
        window.addEventListener("resize", throttledUpdatePositions);
        cleanupFn = () => {
          window.removeEventListener("scroll", throttledUpdatePositions, true);
          window.removeEventListener("resize", throttledUpdatePositions);
          overlays.forEach((overlay) => overlay.element.remove());
          if (label) label.remove();
        };
        container.appendChild(fragment);
        return index + 1;
      } finally {
        if (cleanupFn) {
          ;
          (window._highlightCleanupFunctions = window._highlightCleanupFunctions || []).push(
            cleanupFn
          );
        }
      }
    }
    function getElementPosition(currentElement) {
      if (!currentElement.parentElement) {
        return 0;
      }
      const tagName = currentElement.nodeName.toLowerCase();
      const siblings = Array.from(currentElement.parentElement.children).filter(
        (sib) => sib.nodeName.toLowerCase() === tagName
      );
      if (siblings.length === 1) {
        return 0;
      }
      const index = siblings.indexOf(currentElement) + 1;
      return index;
    }
    function getXPathTree(element, stopAtBoundary = true) {
      if (xpathCache.has(element)) return xpathCache.get(element);
      const segments = [];
      let currentElement = element;
      while (currentElement && currentElement.nodeType === Node.ELEMENT_NODE) {
        if (stopAtBoundary && (currentElement.parentNode instanceof ShadowRoot || currentElement.parentNode instanceof HTMLIFrameElement)) {
          break;
        }
        const position = getElementPosition(currentElement);
        const tagName = currentElement.nodeName.toLowerCase();
        const xpathIndex = position > 0 ? `[${position}]` : "";
        segments.unshift(`${tagName}${xpathIndex}`);
        currentElement = currentElement.parentNode;
      }
      const result = segments.join("/");
      xpathCache.set(element, result);
      return result;
    }
    function isScrollableElement(element) {
      if (!element || element.nodeType !== Node.ELEMENT_NODE) {
        return null;
      }
      const style = getCachedComputedStyle(element);
      if (!style) return null;
      const display = style.display;
      if (display === "inline" || display === "inline-block") {
        return null;
      }
      const overflowX = style.overflowX;
      const overflowY = style.overflowY;
      const scrollableX = overflowX === "auto" || overflowX === "scroll";
      const scrollableY = overflowY === "auto" || overflowY === "scroll";
      if (!scrollableX && !scrollableY) {
        return null;
      }
      const scrollWidth = element.scrollWidth - element.clientWidth;
      const scrollHeight = element.scrollHeight - element.clientHeight;
      const threshold = 4;
      if (scrollWidth < threshold && scrollHeight < threshold) {
        return null;
      }
      if (!scrollableY && scrollWidth < threshold) {
        return null;
      }
      if (!scrollableX && scrollHeight < threshold) {
        return null;
      }
      const distanceToTop = element.scrollTop;
      const distanceToLeft = element.scrollLeft;
      const distanceToRight = element.scrollWidth - element.clientWidth - element.scrollLeft;
      const distanceToBottom = element.scrollHeight - element.clientHeight - element.scrollTop;
      const scrollData = {
        top: distanceToTop,
        right: distanceToRight,
        bottom: distanceToBottom,
        left: distanceToLeft
      };
      addExtraData(element, {
        scrollable: true,
        scrollData
      });
      return scrollData;
    }
    function isTextNodeVisible(textNode) {
      try {
        if (viewportExpansion === -1) {
          const parentElement2 = textNode.parentElement;
          if (!parentElement2) return false;
          try {
            return parentElement2.checkVisibility({
              checkOpacity: true,
              checkVisibilityCSS: true
            });
          } catch (e) {
            const style = window.getComputedStyle(parentElement2);
            return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
          }
        }
        const range = document.createRange();
        range.selectNodeContents(textNode);
        const rects = range.getClientRects();
        if (!rects || rects.length === 0) {
          return false;
        }
        let isAnyRectVisible = false;
        let isAnyRectInViewport = false;
        for (const rect of rects) {
          if (rect.width > 0 && rect.height > 0) {
            isAnyRectVisible = true;
            if (!(rect.bottom < -viewportExpansion || rect.top > window.innerHeight + viewportExpansion || rect.right < -viewportExpansion || rect.left > window.innerWidth + viewportExpansion)) {
              isAnyRectInViewport = true;
              break;
            }
          }
        }
        if (!isAnyRectVisible || !isAnyRectInViewport) {
          return false;
        }
        const parentElement = textNode.parentElement;
        if (!parentElement) return false;
        try {
          return parentElement.checkVisibility({
            checkOpacity: true,
            checkVisibilityCSS: true
          });
        } catch (e) {
          const style = window.getComputedStyle(parentElement);
          return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
        }
      } catch (e) {
        console.warn("Error checking text node visibility:", e);
        return false;
      }
    }
    function isElementAccepted(element) {
      if (!element || !element.tagName) return false;
      const alwaysAccept = /* @__PURE__ */ new Set([
        "body",
        "div",
        "main",
        "article",
        "section",
        "nav",
        "header",
        "footer"
      ]);
      const tagName = element.tagName.toLowerCase();
      if (alwaysAccept.has(tagName)) return true;
      const leafElementDenyList = /* @__PURE__ */ new Set([
        "svg",
        "script",
        "style",
        "link",
        "meta",
        "noscript",
        "template"
      ]);
      return !leafElementDenyList.has(tagName);
    }
    function isElementVisible(element) {
      const style = getCachedComputedStyle(element);
      return element.offsetWidth > 0 && element.offsetHeight > 0 && style?.visibility !== "hidden" && style?.display !== "none";
    }
    function isInteractiveElement(element) {
      if (!element || element.nodeType !== Node.ELEMENT_NODE) {
        return false;
      }
      if (interactiveBlacklist.includes(element)) {
        return false;
      }
      if (interactiveWhitelist.includes(element)) {
        return true;
      }
      const tagName = element.tagName.toLowerCase();
      const style = getCachedComputedStyle(element);
      const interactiveCursors = /* @__PURE__ */ new Set([
        "pointer",
        // Link/clickable elements
        "move",
        // Movable elements
        "text",
        // Text selection
        "grab",
        // Grabbable elements
        "grabbing",
        // Currently grabbing
        "cell",
        // Table cell selection
        "copy",
        // Copy operation
        "alias",
        // Alias creation
        "all-scroll",
        // Scrollable content
        "col-resize",
        // Column resize
        "context-menu",
        // Context menu available
        "crosshair",
        // Precise selection
        "e-resize",
        // East resize
        "ew-resize",
        // East-west resize
        "help",
        // Help available
        "n-resize",
        // North resize
        "ne-resize",
        // Northeast resize
        "nesw-resize",
        // Northeast-southwest resize
        "ns-resize",
        // North-south resize
        "nw-resize",
        // Northwest resize
        "nwse-resize",
        // Northwest-southeast resize
        "row-resize",
        // Row resize
        "s-resize",
        // South resize
        "se-resize",
        // Southeast resize
        "sw-resize",
        // Southwest resize
        "vertical-text",
        // Vertical text selection
        "w-resize",
        // West resize
        "zoom-in",
        // Zoom in
        "zoom-out"
        // Zoom out
      ]);
      const nonInteractiveCursors = /* @__PURE__ */ new Set([
        "not-allowed",
        // Action not allowed
        "no-drop",
        // Drop not allowed
        "wait",
        // Processing
        "progress",
        // In progress
        "initial",
        // Initial value
        "inherit"
        // Inherited value
        //? Let's just include all potentially clickable elements that are not specifically blocked
        // 'none',        // No cursor
        // 'default',     // Default cursor
        // 'auto',        // Browser default
      ]);
      function doesElementHaveInteractivePointer(element2) {
        if (element2.tagName.toLowerCase() === "html") return false;
        if (style?.cursor && interactiveCursors.has(style.cursor)) return true;
        return false;
      }
      let isInteractiveCursor = doesElementHaveInteractivePointer(element);
      if (isInteractiveCursor) {
        return true;
      }
      const interactiveElements = /* @__PURE__ */ new Set([
        "a",
        // Links
        "button",
        // Buttons
        "input",
        // All input types (text, checkbox, radio, etc.)
        "select",
        // Dropdown menus
        "textarea",
        // Text areas
        "details",
        // Expandable details
        "summary",
        // Summary element (clickable part of details)
        "label",
        // Form labels (often clickable)
        "option",
        // Select options
        "optgroup",
        // Option groups
        "fieldset",
        // Form fieldsets (can be interactive with legend)
        "legend"
        // Fieldset legends
      ]);
      const explicitDisableTags = /* @__PURE__ */ new Set([
        "disabled",
        // Standard disabled attribute
        // 'aria-disabled',      // ARIA disabled state
        "readonly"
        // Read-only state
        // 'aria-readonly',     // ARIA read-only state
        // 'aria-hidden',       // Hidden from accessibility
        // 'hidden',            // Hidden attribute
        // 'inert',             // Inert attribute
        // 'aria-inert',        // ARIA inert state
        // 'tabindex="-1"',     // Removed from tab order
        // 'aria-hidden="true"' // Hidden from screen readers
      ]);
      if (interactiveElements.has(tagName)) {
        if (style?.cursor && nonInteractiveCursors.has(style.cursor)) {
          return false;
        }
        for (const disableTag of explicitDisableTags) {
          if (element.hasAttribute(disableTag) || element.getAttribute(disableTag) === "true" || element.getAttribute(disableTag) === "") {
            return false;
          }
        }
        if (element.disabled) {
          return false;
        }
        if (element.readOnly) {
          return false;
        }
        if (element.inert) {
          return false;
        }
        return true;
      }
      const role = element.getAttribute("role");
      const ariaRole = element.getAttribute("aria-role");
      if (element.getAttribute("contenteditable") === "true" || element.isContentEditable) {
        return true;
      }
      if (element.classList && (element.classList.contains("button") || element.classList.contains("dropdown-toggle") || element.getAttribute("data-index") || element.getAttribute("data-toggle") === "dropdown" || element.getAttribute("aria-haspopup") === "true")) {
        return true;
      }
      const interactiveRoles = /* @__PURE__ */ new Set([
        "button",
        // Directly clickable element
        // 'link',            // Clickable link
        "menu",
        // Menu container (ARIA menus)
        "menubar",
        // Menu bar container
        "menuitem",
        // Clickable menu item
        "menuitemradio",
        // Radio-style menu item (selectable)
        "menuitemcheckbox",
        // Checkbox-style menu item (toggleable)
        "radio",
        // Radio button (selectable)
        "checkbox",
        // Checkbox (toggleable)
        "tab",
        // Tab (clickable to switch content)
        "switch",
        // Toggle switch (clickable to change state)
        "slider",
        // Slider control (draggable)
        "spinbutton",
        // Number input with up/down controls
        "combobox",
        // Dropdown with text input
        "searchbox",
        // Search input field
        "textbox",
        // Text input field
        "listbox",
        // Selectable list
        "option",
        // Selectable option in a list
        "scrollbar"
        // Scrollable control
      ]);
      const hasInteractiveRole = interactiveElements.has(tagName) || role && interactiveRoles.has(role) || ariaRole && interactiveRoles.has(ariaRole);
      if (hasInteractiveRole) return true;
      try {
        if (typeof getEventListeners === "function") {
          const listeners = getEventListeners(element);
          const mouseEvents = ["click", "mousedown", "mouseup", "dblclick"];
          for (const eventType of mouseEvents) {
            if (listeners[eventType] && listeners[eventType].length > 0) {
              return true;
            }
          }
        }
        const getEventListenersForNode = element?.ownerDocument?.defaultView?.getEventListenersForNode || window.getEventListenersForNode;
        if (typeof getEventListenersForNode === "function") {
          const listeners = getEventListenersForNode(element);
          const interactionEvents = [
            "click",
            "mousedown",
            "mouseup",
            "keydown",
            "keyup",
            "submit",
            "change",
            "input",
            "focus",
            "blur"
          ];
          for (const eventType of interactionEvents) {
            for (const listener of listeners) {
              if (listener.type === eventType) {
                return true;
              }
            }
          }
        }
        const commonMouseAttrs = ["onclick", "onmousedown", "onmouseup", "ondblclick"];
        for (const attr of commonMouseAttrs) {
          if (element.hasAttribute(attr) || typeof element[attr] === "function") {
            return true;
          }
        }
      } catch (e) {
      }
      if (isScrollableElement(element)) {
        return true;
      }
      return false;
    }
    function isTopElement(element) {
      if (viewportExpansion === -1) {
        return true;
      }
      const rects = getCachedClientRects(element);
      if (!rects || rects.length === 0) {
        return false;
      }
      let isAnyRectInViewport = false;
      for (const rect2 of rects) {
        if (rect2.width > 0 && rect2.height > 0 && !// Only check non-empty rects
        (rect2.bottom < -viewportExpansion || rect2.top > window.innerHeight + viewportExpansion || rect2.right < -viewportExpansion || rect2.left > window.innerWidth + viewportExpansion)) {
          isAnyRectInViewport = true;
          break;
        }
      }
      if (!isAnyRectInViewport) {
        return false;
      }
      let doc = element.ownerDocument;
      if (doc !== window.document) {
        return true;
      }
      let rect = Array.from(rects).find((r) => r.width > 0 && r.height > 0);
      if (!rect) {
        return false;
      }
      const shadowRoot = element.getRootNode();
      if (shadowRoot instanceof ShadowRoot) {
        const centerX = rect.left + rect.width / 2;
        const centerY = rect.top + rect.height / 2;
        try {
          const topEl = shadowRoot.elementFromPoint(centerX, centerY);
          if (!topEl) return false;
          let current = topEl;
          while (current && current !== shadowRoot) {
            if (current === element) return true;
            current = current.parentElement;
          }
          return false;
        } catch (e) {
          return true;
        }
      }
      const margin = 5;
      const checkPoints = [
        // Initially only this was used, but it was not enough
        { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 },
        { x: rect.left + margin, y: rect.top + margin },
        // top left
        // { x: rect.right - margin, y: rect.top + margin },    // top right
        // { x: rect.left + margin, y: rect.bottom - margin },  // bottom left
        { x: rect.right - margin, y: rect.bottom - margin }
        // bottom right
      ];
      return checkPoints.some(({ x, y }) => {
        try {
          const topEl = document.elementFromPoint(x, y);
          if (!topEl) return false;
          let current = topEl;
          while (current && current !== document.documentElement) {
            if (current === element) return true;
            current = current.parentElement;
          }
          return false;
        } catch (e) {
          return true;
        }
      });
    }
    function isInExpandedViewport(element, viewportExpansion2) {
      if (viewportExpansion2 === -1) {
        return true;
      }
      const rects = element.getClientRects();
      if (!rects || rects.length === 0) {
        const boundingRect = getCachedBoundingRect(element);
        if (!boundingRect || boundingRect.width === 0 || boundingRect.height === 0) {
          return false;
        }
        return !(boundingRect.bottom < -viewportExpansion2 || boundingRect.top > window.innerHeight + viewportExpansion2 || boundingRect.right < -viewportExpansion2 || boundingRect.left > window.innerWidth + viewportExpansion2);
      }
      for (const rect of rects) {
        if (rect.width === 0 || rect.height === 0) continue;
        if (!(rect.bottom < -viewportExpansion2 || rect.top > window.innerHeight + viewportExpansion2 || rect.right < -viewportExpansion2 || rect.left > window.innerWidth + viewportExpansion2)) {
          return true;
        }
      }
      return false;
    }
    function isInteractiveCandidate(element) {
      if (!element || element.nodeType !== Node.ELEMENT_NODE) return false;
      const tagName = element.tagName.toLowerCase();
      const interactiveElements = /* @__PURE__ */ new Set([
        "a",
        "button",
        "input",
        "select",
        "textarea",
        "details",
        "summary",
        "label"
      ]);
      if (interactiveElements.has(tagName)) return true;
      const hasQuickInteractiveAttr = element.hasAttribute("onclick") || element.hasAttribute("role") || element.hasAttribute("tabindex") || element.hasAttribute("aria-") || element.hasAttribute("data-action") || element.getAttribute("contenteditable") === "true";
      return hasQuickInteractiveAttr;
    }
    const DISTINCT_INTERACTIVE_TAGS = /* @__PURE__ */ new Set([
      "a",
      "button",
      "input",
      "select",
      "textarea",
      "summary",
      "details",
      "label",
      "option"
    ]);
    const INTERACTIVE_ROLES = /* @__PURE__ */ new Set([
      "button",
      "link",
      "menuitem",
      "menuitemradio",
      "menuitemcheckbox",
      "radio",
      "checkbox",
      "tab",
      "switch",
      "slider",
      "spinbutton",
      "combobox",
      "searchbox",
      "textbox",
      "listbox",
      "option",
      "scrollbar"
    ]);
    function isHeuristicallyInteractive(element) {
      if (!element || element.nodeType !== Node.ELEMENT_NODE) return false;
      if (!isElementVisible(element)) return false;
      const hasInteractiveAttributes = element.hasAttribute("role") || element.hasAttribute("tabindex") || element.hasAttribute("onclick") || typeof element.onclick === "function";
      const hasInteractiveClass = /\b(btn|clickable|menu|item|entry|link)\b/i.test(
        element.className || ""
      );
      const isInKnownContainer = Boolean(
        element.closest('button,a,[role="button"],.menu,.dropdown,.list,.toolbar')
      );
      const hasVisibleChildren = [...element.children].some(isElementVisible);
      const isParentBody = element.parentElement && element.parentElement.isSameNode(document.body);
      return (isInteractiveElement(element) || hasInteractiveAttributes || hasInteractiveClass) && hasVisibleChildren && isInKnownContainer && !isParentBody;
    }
    function isElementDistinctInteraction(element) {
      if (!element || element.nodeType !== Node.ELEMENT_NODE) {
        return false;
      }
      const tagName = element.tagName.toLowerCase();
      const role = element.getAttribute("role");
      if (tagName === "iframe") {
        return true;
      }
      if (DISTINCT_INTERACTIVE_TAGS.has(tagName)) {
        return true;
      }
      if (role && INTERACTIVE_ROLES.has(role)) {
        return true;
      }
      if (element.isContentEditable || element.getAttribute("contenteditable") === "true") {
        return true;
      }
      if (element.hasAttribute("data-testid") || element.hasAttribute("data-cy") || element.hasAttribute("data-test")) {
        return true;
      }
      if (element.hasAttribute("onclick") || typeof element.onclick === "function") {
        return true;
      }
      try {
        const getEventListenersForNode = element?.ownerDocument?.defaultView?.getEventListenersForNode || window.getEventListenersForNode;
        if (typeof getEventListenersForNode === "function") {
          const listeners = getEventListenersForNode(element);
          const interactionEvents = [
            "click",
            "mousedown",
            "mouseup",
            "keydown",
            "keyup",
            "submit",
            "change",
            "input",
            "focus",
            "blur"
          ];
          for (const eventType of interactionEvents) {
            for (const listener of listeners) {
              if (listener.type === eventType) {
                return true;
              }
            }
          }
        }
        const commonEventAttrs = [
          "onmousedown",
          "onmouseup",
          "onkeydown",
          "onkeyup",
          "onsubmit",
          "onchange",
          "oninput",
          "onfocus",
          "onblur"
        ];
        if (commonEventAttrs.some((attr) => element.hasAttribute(attr))) {
          return true;
        }
      } catch (e) {
      }
      if (isHeuristicallyInteractive(element)) {
        return true;
      }
      return false;
    }
    function handleHighlighting(nodeData, node, parentIframe, isParentHighlighted) {
      if (!nodeData.isInteractive) return false;
      let shouldHighlight = false;
      if (!isParentHighlighted) {
        shouldHighlight = true;
      } else {
        if (isElementDistinctInteraction(node)) {
          shouldHighlight = true;
        } else {
          shouldHighlight = false;
        }
      }
      if (shouldHighlight) {
        nodeData.isInViewport = isInExpandedViewport(node, viewportExpansion);
        if (nodeData.isInViewport || viewportExpansion === -1) {
          nodeData.highlightIndex = highlightIndex++;
          if (doHighlightElements) {
            if (focusHighlightIndex >= 0) {
              if (focusHighlightIndex === nodeData.highlightIndex) {
                highlightElement(node, nodeData.highlightIndex, parentIframe);
              }
            } else {
              highlightElement(node, nodeData.highlightIndex, parentIframe);
            }
            return true;
          }
        } else {
        }
      }
      return false;
    }
    function buildDomTree(node, parentIframe = null, isParentHighlighted = false) {
      if (!node || node.id === HIGHLIGHT_CONTAINER_ID || node.nodeType !== Node.ELEMENT_NODE && node.nodeType !== Node.TEXT_NODE) {
        return null;
      }
      if (!node || node.id === HIGHLIGHT_CONTAINER_ID) {
        return null;
      }
      if (node.dataset?.browserUseIgnore === "true" || node.dataset?.pageAgentIgnore === "true") {
        return null;
      }
      if (node.getAttribute && node.getAttribute("aria-hidden") === "true") {
        return null;
      }
      if (node === document.body) {
        const nodeData2 = {
          tagName: "body",
          attributes: {},
          xpath: "/body",
          children: []
        };
        for (const child of node.childNodes) {
          const domElement = buildDomTree(child, parentIframe, false);
          if (domElement) nodeData2.children.push(domElement);
        }
        const id2 = `${ID.current++}`;
        DOM_HASH_MAP[id2] = nodeData2;
        return id2;
      }
      if (node.nodeType !== Node.ELEMENT_NODE && node.nodeType !== Node.TEXT_NODE) {
        return null;
      }
      if (node.nodeType === Node.TEXT_NODE) {
        const textContent = node.textContent?.trim();
        if (!textContent) {
          return null;
        }
        const parentElement = node.parentElement;
        if (!parentElement || parentElement.tagName.toLowerCase() === "script") {
          return null;
        }
        const id2 = `${ID.current++}`;
        DOM_HASH_MAP[id2] = {
          type: "TEXT_NODE",
          text: textContent,
          isVisible: isTextNodeVisible(node)
        };
        return id2;
      }
      if (node.nodeType === Node.ELEMENT_NODE && !isElementAccepted(node)) {
        return null;
      }
      if (viewportExpansion !== -1 && !node.shadowRoot) {
        const rect = getCachedBoundingRect(node);
        const style = getCachedComputedStyle(node);
        const isFixedOrSticky = style && (style.position === "fixed" || style.position === "sticky");
        const hasSize = node.offsetWidth > 0 || node.offsetHeight > 0;
        if (!rect || !isFixedOrSticky && !hasSize && (rect.bottom < -viewportExpansion || rect.top > window.innerHeight + viewportExpansion || rect.right < -viewportExpansion || rect.left > window.innerWidth + viewportExpansion)) {
          return null;
        }
      }
      const nodeData = {
        tagName: node.tagName.toLowerCase(),
        attributes: {},
        /**
         * @edit no need for xpath
         */
        // xpath: getXPathTree(node, true),
        children: []
      };
      if (isInteractiveCandidate(node) || node.tagName.toLowerCase() === "iframe" || node.tagName.toLowerCase() === "body") {
        const attributeNames = node.getAttributeNames?.() || [];
        for (const name of attributeNames) {
          const value = node.getAttribute(name);
          nodeData.attributes[name] = value;
        }
        if (node.tagName.toLowerCase() === "input" && (node.type === "checkbox" || node.type === "radio")) {
          nodeData.attributes.checked = node.checked ? "true" : "false";
        }
      }
      let nodeWasHighlighted = false;
      if (node.nodeType === Node.ELEMENT_NODE) {
        nodeData.isVisible = isElementVisible(node);
        if (nodeData.isVisible) {
          nodeData.isTopElement = isTopElement(node);
          const role = node.getAttribute("role");
          const isMenuContainer = role === "menu" || role === "menubar" || role === "listbox";
          if (nodeData.isTopElement || isMenuContainer) {
            nodeData.isInteractive = isInteractiveElement(node);
            nodeWasHighlighted = handleHighlighting(nodeData, node, parentIframe, isParentHighlighted);
            nodeData.ref = node;
            if (nodeData.isInteractive && Object.keys(nodeData.attributes).length === 0) {
              const attributeNames = node.getAttributeNames?.() || [];
              for (const name of attributeNames) {
                const value = node.getAttribute(name);
                nodeData.attributes[name] = value;
              }
            }
          }
        }
      }
      if (node.tagName) {
        const tagName = node.tagName.toLowerCase();
        if (tagName === "iframe") {
          try {
            const iframeDoc = node.contentDocument || node.contentWindow?.document;
            if (iframeDoc) {
              for (const child of iframeDoc.childNodes) {
                const domElement = buildDomTree(child, node, false);
                if (domElement) nodeData.children.push(domElement);
              }
            }
          } catch (e) {
            console.warn("Unable to access iframe:", e);
          }
        } else if (node.isContentEditable || node.getAttribute("contenteditable") === "true" || node.id === "tinymce" || node.classList.contains("mce-content-body") || tagName === "body" && node.getAttribute("data-id")?.startsWith("mce_")) {
          for (const child of node.childNodes) {
            const domElement = buildDomTree(child, parentIframe, nodeWasHighlighted);
            if (domElement) nodeData.children.push(domElement);
          }
        } else {
          if (node.shadowRoot) {
            nodeData.shadowRoot = true;
            for (const child of node.shadowRoot.childNodes) {
              const domElement = buildDomTree(child, parentIframe, nodeWasHighlighted);
              if (domElement) nodeData.children.push(domElement);
            }
          }
          for (const child of node.childNodes) {
            const passHighlightStatusToChild = nodeWasHighlighted || isParentHighlighted;
            const domElement = buildDomTree(child, parentIframe, passHighlightStatusToChild);
            if (domElement) nodeData.children.push(domElement);
          }
        }
      }
      if (nodeData.tagName === "a" && nodeData.children.length === 0 && !nodeData.attributes.href) {
        const rect = getCachedBoundingRect(node);
        const hasSize = rect && rect.width > 0 && rect.height > 0 || node.offsetWidth > 0 || node.offsetHeight > 0;
        if (!hasSize) {
          return null;
        }
      }
      nodeData.extra = extraData.get(node) || null;
      const id = `${ID.current++}`;
      DOM_HASH_MAP[id] = nodeData;
      return id;
    }
    const rootId = buildDomTree(document.body);
    DOM_CACHE.clearCache();
    return { rootId, map: DOM_HASH_MAP };
  };

  // src/page-controller/dom.ts
  var DEFAULT_VIEWPORT_EXPANSION = -1;
  function resolveViewportExpansion(viewportExpansion) {
    return viewportExpansion ?? DEFAULT_VIEWPORT_EXPANSION;
  }
  var newElementsCache = /* @__PURE__ */ new WeakMap();
  function getFlatTree(config) {
    const viewportExpansion = resolveViewportExpansion(config.viewportExpansion);
    const interactiveBlacklist = [];
    for (const item of config.interactiveBlacklist || []) {
      if (typeof item === "function") {
        interactiveBlacklist.push(item());
      } else {
        interactiveBlacklist.push(item);
      }
    }
    const interactiveWhitelist = [];
    for (const item of config.interactiveWhitelist || []) {
      if (typeof item === "function") {
        interactiveWhitelist.push(item());
      } else {
        interactiveWhitelist.push(item);
      }
    }
    const elements = dom_tree_default({
      doHighlightElements: true,
      debugMode: true,
      focusHighlightIndex: -1,
      viewportExpansion,
      interactiveBlacklist,
      interactiveWhitelist,
      highlightOpacity: config.highlightOpacity ?? 0,
      highlightLabelOpacity: config.highlightLabelOpacity ?? 0.1
    });
    for (const nodeId in elements.map) {
      const node = elements.map[nodeId];
      if (node.isInteractive && node.ref) {
        const ref = node.ref;
        if (!newElementsCache.has(ref)) {
          newElementsCache.set(ref, window.location.href);
          node.isNew = true;
        }
      }
    }
    return elements;
  }
  var globRegexCache = /* @__PURE__ */ new Map();
  function globToRegex(pattern) {
    let regex = globRegexCache.get(pattern);
    if (!regex) {
      const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, "\\$&");
      regex = new RegExp(`^${escaped.replace(/\*/g, ".*")}$`);
      globRegexCache.set(pattern, regex);
    }
    return regex;
  }
  function matchAttributes(attrs, patterns) {
    const result = {};
    for (const pattern of patterns) {
      if (pattern.includes("*")) {
        const regex = globToRegex(pattern);
        for (const key of Object.keys(attrs)) {
          if (regex.test(key) && attrs[key].trim()) {
            result[key] = attrs[key].trim();
          }
        }
      } else {
        const value = attrs[pattern];
        if (value && value.trim()) {
          result[pattern] = value.trim();
        }
      }
    }
    return result;
  }
  function flatTreeToString(flatTree, includeAttributes) {
    const DEFAULT_INCLUDE_ATTRIBUTES = [
      "title",
      "type",
      "checked",
      "name",
      "role",
      "value",
      "placeholder",
      "data-date-format",
      "alt",
      "aria-label",
      "aria-expanded",
      "data-state",
      "aria-checked",
      "id",
      "for",
      "target",
      "aria-haspopup",
      "aria-controls",
      "aria-owns",
      "contenteditable"
    ];
    const includeAttrs = [
      ...includeAttributes || [],
      ...DEFAULT_INCLUDE_ATTRIBUTES
    ];
    const capTextLength = (text, maxLength) => {
      if (text.length > maxLength) {
        return text.substring(0, maxLength) + "...";
      }
      return text;
    };
    const buildTreeNode = (nodeId) => {
      const node = flatTree.map[nodeId];
      if (!node) return null;
      if (node.type === "TEXT_NODE") {
        const textNode = node;
        return {
          type: "text",
          text: textNode.text,
          isVisible: textNode.isVisible,
          parent: null,
          children: []
        };
      } else {
        const elementNode = node;
        const children = [];
        if (elementNode.children) {
          for (const childId of elementNode.children) {
            const child = buildTreeNode(childId);
            if (child) {
              children.push(child);
            }
          }
        }
        return {
          type: "element",
          tagName: elementNode.tagName,
          attributes: elementNode.attributes ?? {},
          isVisible: elementNode.isVisible ?? false,
          isInteractive: elementNode.isInteractive ?? false,
          isTopElement: elementNode.isTopElement ?? false,
          isNew: elementNode.isNew ?? false,
          highlightIndex: elementNode.highlightIndex,
          parent: null,
          children,
          extra: elementNode.extra ?? {}
        };
      }
    };
    const setParentReferences = (node, parent = null) => {
      node.parent = parent;
      for (const child of node.children) {
        setParentReferences(child, node);
      }
    };
    const rootNode = buildTreeNode(flatTree.rootId);
    if (!rootNode) return "";
    setParentReferences(rootNode);
    const hasParentWithHighlightIndex = (node) => {
      let current = node.parent;
      while (current) {
        if (current.type === "element" && current.highlightIndex !== void 0) {
          return true;
        }
        current = current.parent;
      }
      return false;
    };
    const processNode = (node, depth, result2) => {
      let nextDepth = depth;
      const depthStr = "	".repeat(depth);
      if (node.type === "element") {
        if (node.highlightIndex !== void 0) {
          nextDepth += 1;
          const text = getAllTextTillNextClickableElement(node);
          let attributesHtmlStr = "";
          if (includeAttrs.length > 0 && node.attributes) {
            const attributesToInclude = matchAttributes(
              node.attributes,
              includeAttrs
            );
            const keys = Object.keys(attributesToInclude);
            if (keys.length > 1) {
              const keysToRemove = /* @__PURE__ */ new Set();
              const seenValues = {};
              for (const key of keys) {
                const value = attributesToInclude[key];
                if (value.length > 5) {
                  if (value in seenValues) {
                    keysToRemove.add(key);
                  } else {
                    seenValues[value] = key;
                  }
                }
              }
              for (const key of keysToRemove) {
                delete attributesToInclude[key];
              }
            }
            if (attributesToInclude.role === node.tagName) {
              delete attributesToInclude.role;
            }
            const attrsToRemoveIfTextMatches = [
              "aria-label",
              "placeholder",
              "title"
            ];
            for (const attr of attrsToRemoveIfTextMatches) {
              if (attributesToInclude[attr] && attributesToInclude[attr].toLowerCase().trim() === text.toLowerCase().trim()) {
                delete attributesToInclude[attr];
              }
            }
            if (Object.keys(attributesToInclude).length > 0) {
              attributesHtmlStr = Object.entries(attributesToInclude).map(([key, value]) => `${key}=${capTextLength(value, 20)}`).join(" ");
            }
          }
          const highlightIndicator = node.isNew ? `*[${node.highlightIndex}]` : `[${node.highlightIndex}]`;
          let line = `${depthStr}${highlightIndicator}<${node.tagName ?? ""}`;
          if (attributesHtmlStr) {
            line += ` ${attributesHtmlStr}`;
          }
          if (node.extra) {
            if (node.extra.scrollable) {
              let scrollDataText = "";
              if (node.extra.scrollData?.left)
                scrollDataText += `left=${node.extra.scrollData.left}, `;
              if (node.extra.scrollData?.top)
                scrollDataText += `top=${node.extra.scrollData.top}, `;
              if (node.extra.scrollData?.right)
                scrollDataText += `right=${node.extra.scrollData.right}, `;
              if (node.extra.scrollData?.bottom)
                scrollDataText += `bottom=${node.extra.scrollData.bottom}`;
              line += ` data-scrollable="${scrollDataText}"`;
            }
          }
          if (text) {
            const trimmedText = text.trim();
            if (!attributesHtmlStr) {
              line += " ";
            }
            line += `>${trimmedText}`;
          } else if (!attributesHtmlStr) {
            line += " ";
          }
          line += " />";
          result2.push(line);
        }
        for (const child of node.children) {
          processNode(child, nextDepth, result2);
        }
      } else if (node.type === "text") {
        if (hasParentWithHighlightIndex(node)) {
          return;
        }
        if (node.parent && node.parent.type === "element" && node.parent.isVisible && node.parent.isTopElement) {
          result2.push(`${depthStr}${node.text ?? ""}`);
        }
      }
    };
    const result = [];
    processNode(rootNode, 0, result);
    return result.join("\n");
  }
  var getAllTextTillNextClickableElement = (node, maxDepth = -1) => {
    const textParts = [];
    const collectText = (currentNode, currentDepth) => {
      if (maxDepth !== -1 && currentDepth > maxDepth) {
        return;
      }
      if (currentNode.type === "element" && currentNode !== node && currentNode.highlightIndex !== void 0) {
        return;
      }
      if (currentNode.type === "text" && currentNode.text) {
        textParts.push(currentNode.text);
      } else if (currentNode.type === "element") {
        for (const child of currentNode.children) {
          collectText(child, currentDepth + 1);
        }
      }
    };
    collectText(node, 0);
    return textParts.join("\n").trim();
  };
  function getSelectorMap(flatTree) {
    const selectorMap = /* @__PURE__ */ new Map();
    const keys = Object.keys(flatTree.map);
    for (const key of keys) {
      const node = flatTree.map[key];
      if (node.isInteractive && typeof node.highlightIndex === "number") {
        selectorMap.set(
          node.highlightIndex,
          node
        );
      }
    }
    return selectorMap;
  }
  function getElementTextMap(simplifiedHTML) {
    const lines = simplifiedHTML.split("\n").map((line) => line.trim()).filter((line) => line.length > 0);
    const elementTextMap = /* @__PURE__ */ new Map();
    for (const line of lines) {
      const regex = /^\[(\d+)\]<[^>]+>([^<]*)/;
      const match = regex.exec(line);
      if (match) {
        const index = parseInt(match[1], 10);
        elementTextMap.set(index, line);
      }
    }
    return elementTextMap;
  }
  function cleanUpHighlights() {
    const cleanupFunctions = window._highlightCleanupFunctions || [];
    for (const cleanup of cleanupFunctions) {
      if (typeof cleanup === "function") {
        cleanup();
      }
    }
    window._highlightCleanupFunctions = [];
  }

  // src/page-controller/actions.ts
  async function waitFor(seconds) {
    await new Promise((resolve) => setTimeout(resolve, seconds * 1e3));
  }
  function getElementByIndex(selectorMap, index) {
    const interactiveNode = selectorMap.get(index);
    if (!interactiveNode) {
      throw new Error(`No interactive element found at index ${index}`);
    }
    const element = interactiveNode.ref;
    if (!element) {
      throw new Error(`Element at index ${index} does not have a reference`);
    }
    if (!(element instanceof HTMLElement)) {
      throw new Error(`Element at index ${index} is not an HTMLElement`);
    }
    return element;
  }
  var lastClickedElement = null;
  function blurLastClickedElement() {
    if (lastClickedElement) {
      lastClickedElement.blur();
      lastClickedElement.dispatchEvent(
        new MouseEvent("mouseout", { bubbles: true, cancelable: true })
      );
      lastClickedElement = null;
    }
  }
  async function scrollIntoViewIfNeeded(element) {
    const rect = element.getBoundingClientRect();
    const inViewport = rect.top >= 0 && rect.bottom <= window.innerHeight && rect.left >= 0 && rect.right <= window.innerWidth;
    if (!inViewport) {
      element.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
      await waitFor(0.4);
    }
  }
  async function movePointerToElement(element) {
    const rect = element.getBoundingClientRect();
    const x = rect.left + rect.width / 2;
    const y = rect.top + rect.height / 2;
    window.dispatchEvent(
      new CustomEvent("HyphaDebugger::MovePointerTo", { detail: { x, y } })
    );
    await waitFor(0.3);
  }
  async function clickElement2(element) {
    blurLastClickedElement();
    lastClickedElement = element;
    await scrollIntoViewIfNeeded(element);
    await movePointerToElement(element);
    window.dispatchEvent(new CustomEvent("HyphaDebugger::ClickPointer"));
    await waitFor(0.05);
    element.dispatchEvent(
      new MouseEvent("mouseenter", { bubbles: true, cancelable: true })
    );
    element.dispatchEvent(
      new MouseEvent("mouseover", { bubbles: true, cancelable: true })
    );
    element.dispatchEvent(
      new MouseEvent("mousedown", { bubbles: true, cancelable: true })
    );
    element.focus();
    element.dispatchEvent(
      new MouseEvent("mouseup", { bubbles: true, cancelable: true })
    );
    element.dispatchEvent(
      new MouseEvent("click", { bubbles: true, cancelable: true })
    );
    await waitFor(0.2);
  }
  var _nativeInputValueSetter = null;
  var _nativeTextAreaValueSetter = null;
  function getNativeInputValueSetter() {
    if (!_nativeInputValueSetter) {
      _nativeInputValueSetter = Object.getOwnPropertyDescriptor(
        window.HTMLInputElement.prototype,
        "value"
      ).set;
    }
    return _nativeInputValueSetter;
  }
  function getNativeTextAreaValueSetter() {
    if (!_nativeTextAreaValueSetter) {
      _nativeTextAreaValueSetter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype,
        "value"
      ).set;
    }
    return _nativeTextAreaValueSetter;
  }
  async function inputTextElement(element, text) {
    const isContentEditable = element.isContentEditable;
    if (!(element instanceof HTMLInputElement) && !(element instanceof HTMLTextAreaElement) && !isContentEditable) {
      throw new Error("Element is not an input, textarea, or contenteditable");
    }
    await clickElement2(element);
    if (isContentEditable) {
      if (element.dispatchEvent(
        new InputEvent("beforeinput", {
          bubbles: true,
          cancelable: true,
          inputType: "deleteContent"
        })
      )) {
        element.innerText = "";
        element.dispatchEvent(
          new InputEvent("input", {
            bubbles: true,
            inputType: "deleteContent"
          })
        );
      }
      if (element.dispatchEvent(
        new InputEvent("beforeinput", {
          bubbles: true,
          cancelable: true,
          inputType: "insertText",
          data: text
        })
      )) {
        element.innerText = text;
        element.dispatchEvent(
          new InputEvent("input", {
            bubbles: true,
            inputType: "insertText",
            data: text
          })
        );
      }
      element.dispatchEvent(new Event("change", { bubbles: true }));
      element.blur();
    } else if (element instanceof HTMLTextAreaElement) {
      getNativeTextAreaValueSetter().call(element, text);
    } else {
      getNativeInputValueSetter().call(element, text);
    }
    if (!isContentEditable) {
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
    await waitFor(0.1);
    blurLastClickedElement();
  }
  async function selectOptionElement(selectElement, optionText) {
    if (!(selectElement instanceof HTMLSelectElement)) {
      throw new Error("Element is not a select element");
    }
    await scrollIntoViewIfNeeded(selectElement);
    const rect = selectElement.getBoundingClientRect();
    window.dispatchEvent(
      new CustomEvent("HyphaDebugger::MovePointerTo", {
        detail: { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 }
      })
    );
    await waitFor(0.3);
    window.dispatchEvent(new CustomEvent("HyphaDebugger::ClickPointer"));
    const options = Array.from(selectElement.options);
    const option = options.find(
      (opt) => opt.textContent?.trim() === optionText.trim()
    );
    if (!option) {
      throw new Error(
        `Option with text "${optionText}" not found in select element`
      );
    }
    selectElement.value = option.value;
    selectElement.dispatchEvent(new Event("change", { bubbles: true }));
    await waitFor(0.1);
  }
  async function scrollVertically(down, scroll_amount, element) {
    if (element) {
      let currentElement = element;
      let scrollSuccess = false;
      let scrolledElement = null;
      let scrollDelta = 0;
      let attempts = 0;
      const dy2 = scroll_amount;
      while (currentElement && attempts < 10) {
        const computedStyle = window.getComputedStyle(currentElement);
        const hasScrollableY = /(auto|scroll|overlay)/.test(
          computedStyle.overflowY
        );
        const canScrollVertically = currentElement.scrollHeight > currentElement.clientHeight;
        if (hasScrollableY && canScrollVertically) {
          const beforeScroll = currentElement.scrollTop;
          const maxScroll = currentElement.scrollHeight - currentElement.clientHeight;
          let scrollAmount = dy2 / 3;
          if (scrollAmount > 0) {
            scrollAmount = Math.min(scrollAmount, maxScroll - beforeScroll);
          } else {
            scrollAmount = Math.max(scrollAmount, -beforeScroll);
          }
          currentElement.scrollTop = beforeScroll + scrollAmount;
          const afterScroll = currentElement.scrollTop;
          const actualScrollDelta = afterScroll - beforeScroll;
          if (Math.abs(actualScrollDelta) > 0.5) {
            scrollSuccess = true;
            scrolledElement = currentElement;
            scrollDelta = actualScrollDelta;
            break;
          }
        }
        if (currentElement === document.body || currentElement === document.documentElement) {
          break;
        }
        currentElement = currentElement.parentElement;
        attempts++;
      }
      if (scrollSuccess) {
        return `Scrolled container (${scrolledElement?.tagName}) by ${scrollDelta}px`;
      } else {
        return `No scrollable container found for element (${element.tagName})`;
      }
    }
    const dy = scroll_amount;
    const bigEnough = (el2) => el2.clientHeight >= window.innerHeight * 0.5;
    const canScroll = (el2) => el2 && /(auto|scroll|overlay)/.test(getComputedStyle(el2).overflowY) && el2.scrollHeight > el2.clientHeight && bigEnough(el2);
    let el = document.activeElement;
    while (el && !canScroll(el) && el !== document.body) el = el.parentElement;
    el = canScroll(el) ? el : Array.from(document.querySelectorAll("*")).find(canScroll) || document.scrollingElement || document.documentElement;
    if (el === document.scrollingElement || el === document.documentElement || el === document.body) {
      const scrollBefore = window.scrollY;
      window.scrollBy(0, dy);
      const scrollAfter = window.scrollY;
      const scrolled = scrollAfter - scrollBefore;
      if (Math.abs(scrolled) < 1) {
        return dy > 0 ? "Already at the bottom of the page." : "Already at the top of the page.";
      }
      const scrollMax = document.documentElement.scrollHeight - window.innerHeight;
      const reachedBottom = dy > 0 && scrollAfter >= scrollMax - 1;
      const reachedTop = dy < 0 && scrollAfter <= 1;
      if (reachedBottom)
        return `Scrolled page by ${scrolled}px. Reached the bottom.`;
      if (reachedTop) return `Scrolled page by ${scrolled}px. Reached the top.`;
      return `Scrolled page by ${scrolled}px.`;
    } else {
      const scrollBefore = el.scrollTop;
      const scrollMax = el.scrollHeight - el.clientHeight;
      el.scrollBy({ top: dy, behavior: "smooth" });
      await waitFor(0.1);
      const scrollAfter = el.scrollTop;
      const scrolled = scrollAfter - scrollBefore;
      if (Math.abs(scrolled) < 1) {
        return dy > 0 ? `Already at the bottom of container (${el.tagName}).` : `Already at the top of container (${el.tagName}).`;
      }
      const reachedBottom = dy > 0 && scrollAfter >= scrollMax - 1;
      const reachedTop = dy < 0 && scrollAfter <= 1;
      if (reachedBottom)
        return `Scrolled container (${el.tagName}) by ${scrolled}px. Reached the bottom.`;
      if (reachedTop)
        return `Scrolled container (${el.tagName}) by ${scrolled}px. Reached the top.`;
      return `Scrolled container (${el.tagName}) by ${scrolled}px.`;
    }
  }
  async function scrollHorizontally(right, scroll_amount, element) {
    if (element) {
      let currentElement = element;
      let scrollSuccess = false;
      let scrolledElement = null;
      let scrollDelta = 0;
      let attempts = 0;
      const dx2 = right ? scroll_amount : -scroll_amount;
      while (currentElement && attempts < 10) {
        const computedStyle = window.getComputedStyle(currentElement);
        const hasScrollableX = /(auto|scroll|overlay)/.test(
          computedStyle.overflowX
        );
        const canScrollHorizontally = currentElement.scrollWidth > currentElement.clientWidth;
        if (hasScrollableX && canScrollHorizontally) {
          const beforeScroll = currentElement.scrollLeft;
          const maxScroll = currentElement.scrollWidth - currentElement.clientWidth;
          let scrollAmount = dx2 / 3;
          if (scrollAmount > 0) {
            scrollAmount = Math.min(scrollAmount, maxScroll - beforeScroll);
          } else {
            scrollAmount = Math.max(scrollAmount, -beforeScroll);
          }
          currentElement.scrollLeft = beforeScroll + scrollAmount;
          const afterScroll = currentElement.scrollLeft;
          const actualScrollDelta = afterScroll - beforeScroll;
          if (Math.abs(actualScrollDelta) > 0.5) {
            scrollSuccess = true;
            scrolledElement = currentElement;
            scrollDelta = actualScrollDelta;
            break;
          }
        }
        if (currentElement === document.body || currentElement === document.documentElement) {
          break;
        }
        currentElement = currentElement.parentElement;
        attempts++;
      }
      if (scrollSuccess) {
        return `Scrolled container (${scrolledElement?.tagName}) horizontally by ${scrollDelta}px`;
      } else {
        return `No horizontally scrollable container found for element (${element.tagName})`;
      }
    }
    const dx = right ? scroll_amount : -scroll_amount;
    const bigEnough = (el2) => el2.clientWidth >= window.innerWidth * 0.5;
    const canScroll = (el2) => el2 && /(auto|scroll|overlay)/.test(getComputedStyle(el2).overflowX) && el2.scrollWidth > el2.clientWidth && bigEnough(el2);
    let el = document.activeElement;
    while (el && !canScroll(el) && el !== document.body) el = el.parentElement;
    el = canScroll(el) ? el : Array.from(document.querySelectorAll("*")).find(canScroll) || document.scrollingElement || document.documentElement;
    if (el === document.scrollingElement || el === document.documentElement || el === document.body) {
      const scrollBefore = window.scrollX;
      const scrollMax = document.documentElement.scrollWidth - window.innerWidth;
      window.scrollBy(dx, 0);
      const scrollAfter = window.scrollX;
      const scrolled = scrollAfter - scrollBefore;
      if (Math.abs(scrolled) < 1) {
        return dx > 0 ? "Already at the right edge of the page." : "Already at the left edge of the page.";
      }
      const reachedRight = dx > 0 && scrollAfter >= scrollMax - 1;
      const reachedLeft = dx < 0 && scrollAfter <= 1;
      if (reachedRight)
        return `Scrolled page by ${scrolled}px. Reached the right edge.`;
      if (reachedLeft)
        return `Scrolled page by ${scrolled}px. Reached the left edge.`;
      return `Scrolled page horizontally by ${scrolled}px.`;
    } else {
      const scrollBefore = el.scrollLeft;
      const scrollMax = el.scrollWidth - el.clientWidth;
      el.scrollBy({ left: dx, behavior: "smooth" });
      await waitFor(0.1);
      const scrollAfter = el.scrollLeft;
      const scrolled = scrollAfter - scrollBefore;
      if (Math.abs(scrolled) < 1) {
        return dx > 0 ? `Already at the right edge of container (${el.tagName}).` : `Already at the left edge of container (${el.tagName}).`;
      }
      const reachedRight = dx > 0 && scrollAfter >= scrollMax - 1;
      const reachedLeft = dx < 0 && scrollAfter <= 1;
      if (reachedRight)
        return `Scrolled container (${el.tagName}) by ${scrolled}px. Reached the right edge.`;
      if (reachedLeft)
        return `Scrolled container (${el.tagName}) by ${scrolled}px. Reached the left edge.`;
      return `Scrolled container (${el.tagName}) horizontally by ${scrolled}px.`;
    }
  }

  // src/page-controller/page-info.ts
  function getPageScrollInfo() {
    const viewport_width = window.innerWidth;
    const viewport_height = window.innerHeight;
    const page_width = Math.max(
      document.documentElement.scrollWidth,
      document.body.scrollWidth || 0
    );
    const page_height = Math.max(
      document.documentElement.scrollHeight,
      document.body.scrollHeight || 0
    );
    const scroll_x = window.scrollX || window.pageXOffset || document.documentElement.scrollLeft || 0;
    const scroll_y = window.scrollY || window.pageYOffset || document.documentElement.scrollTop || 0;
    const pixels_below = Math.max(
      0,
      page_height - (window.innerHeight + scroll_y)
    );
    const pixels_right = Math.max(
      0,
      page_width - (window.innerWidth + scroll_x)
    );
    return {
      viewport_width,
      viewport_height,
      page_width,
      page_height,
      scroll_x,
      scroll_y,
      pixels_above: scroll_y,
      pixels_below,
      pages_above: viewport_height > 0 ? scroll_y / viewport_height : 0,
      pages_below: viewport_height > 0 ? pixels_below / viewport_height : 0,
      total_pages: viewport_height > 0 ? page_height / viewport_height : 0,
      current_page_position: scroll_y / Math.max(1, page_height - viewport_height),
      pixels_left: scroll_x,
      pixels_right
    };
  }

  // src/page-controller/index.ts
  var PageController = class {
    config;
    flatTree = null;
    selectorMap = /* @__PURE__ */ new Map();
    elementTextMap = /* @__PURE__ */ new Map();
    simplifiedHTML = "";
    isIndexed = false;
    constructor(config = {}) {
      this.config = config;
    }
    /**
     * Get structured browser state for LLM consumption.
     * Builds the DOM tree, highlights interactive elements, and returns
     * a simplified text representation with numeric indices.
     */
    async getBrowserState() {
      const url = window.location.href;
      const title = document.title;
      const pi = getPageScrollInfo();
      const viewportExpansion = resolveViewportExpansion(
        this.config.viewportExpansion
      );
      await this.updateTree();
      const content = this.simplifiedHTML;
      const titleLine = `Current Page: [${title}](${url})`;
      const pageInfoLine = `Page info: ${pi.viewport_width}x${pi.viewport_height}px viewport, ${pi.page_width}x${pi.page_height}px total, ${pi.pages_above.toFixed(1)} pages above, ${pi.pages_below.toFixed(1)} pages below, at ${(pi.current_page_position * 100).toFixed(0)}%`;
      const elementsLabel = viewportExpansion === -1 ? "Interactive elements (full page):" : "Interactive elements (viewport):";
      const hasContentAbove = pi.pixels_above > 4;
      const scrollHintAbove = hasContentAbove && viewportExpansion !== -1 ? `... ${pi.pixels_above} pixels above - scroll to see more ...` : "[Start of page]";
      const header = `${titleLine}
${pageInfoLine}

${elementsLabel}

${scrollHintAbove}`;
      const hasContentBelow = pi.pixels_below > 4;
      const footer = hasContentBelow && viewportExpansion !== -1 ? `... ${pi.pixels_below} pixels below - scroll to see more ...` : "[End of page]";
      return {
        url,
        title,
        header,
        content,
        footer,
        element_count: this.selectorMap.size
      };
    }
    /**
     * Update DOM tree, returns simplified HTML for LLM.
     */
    async updateTree() {
      cleanUpHighlights();
      this.flatTree = getFlatTree(this.config);
      this.simplifiedHTML = flatTreeToString(
        this.flatTree,
        this.config.includeAttributes
      );
      this.selectorMap.clear();
      this.selectorMap = getSelectorMap(this.flatTree);
      this.elementTextMap.clear();
      this.elementTextMap = getElementTextMap(this.simplifiedHTML);
      this.isIndexed = true;
      return this.simplifiedHTML;
    }
    async cleanUpHighlights() {
      cleanUpHighlights();
    }
    assertIndexed() {
      if (!this.isIndexed) {
        throw new Error(
          "DOM tree not indexed yet. Call get_browser_state first."
        );
      }
    }
    /** Clean up highlights after performing an action. */
    cleanUpAfterAction() {
      cleanUpHighlights();
    }
    async clickElement(index) {
      try {
        this.assertIndexed();
        const element = getElementByIndex(this.selectorMap, index);
        const elemText = this.elementTextMap.get(index);
        this.cleanUpAfterAction();
        await clickElement2(element);
        if (element instanceof HTMLAnchorElement && element.target === "_blank") {
          return {
            success: true,
            message: `Clicked element (${elemText ?? index}). Link opened in a new tab.`
          };
        }
        return {
          success: true,
          message: `Clicked element (${elemText ?? index}).`
        };
      } catch (error) {
        return {
          success: false,
          message: `Failed to click element: ${error}`
        };
      }
    }
    async inputText(index, text) {
      try {
        this.assertIndexed();
        const element = getElementByIndex(this.selectorMap, index);
        const elemText = this.elementTextMap.get(index);
        this.cleanUpAfterAction();
        await inputTextElement(element, text);
        return {
          success: true,
          message: `Input text "${text}" into element (${elemText ?? index}).`
        };
      } catch (error) {
        return {
          success: false,
          message: `Failed to input text: ${error}`
        };
      }
    }
    async selectOption(index, optionText) {
      try {
        this.assertIndexed();
        const element = getElementByIndex(this.selectorMap, index);
        const elemText = this.elementTextMap.get(index);
        this.cleanUpAfterAction();
        await selectOptionElement(element, optionText);
        return {
          success: true,
          message: `Selected option "${optionText}" in element (${elemText ?? index}).`
        };
      } catch (error) {
        return {
          success: false,
          message: `Failed to select option: ${error}`
        };
      }
    }
    async scroll(options) {
      try {
        this.assertIndexed();
        this.cleanUpAfterAction();
        const { direction, amount, index } = options;
        const element = index !== void 0 ? getElementByIndex(this.selectorMap, index) : null;
        let message;
        if (direction === "left" || direction === "right") {
          const pixels = amount ?? window.innerWidth * 0.8;
          message = await scrollHorizontally(
            direction === "right",
            pixels,
            element
          );
        } else {
          const pixels = amount ?? window.innerHeight * 0.8;
          const scrollAmount = direction === "down" ? pixels : -pixels;
          message = await scrollVertically(
            direction === "down",
            scrollAmount,
            element
          );
        }
        return { success: true, message };
      } catch (error) {
        return {
          success: false,
          message: `Failed to scroll: ${error}`
        };
      }
    }
    dispose() {
      cleanUpHighlights();
      this.flatTree = null;
      this.selectorMap.clear();
      this.elementTextMap.clear();
      this.simplifiedHTML = "";
      this.isIndexed = false;
    }
  };

  // src/services/page-controller.ts
  var controller = null;
  function getController() {
    if (!controller) {
      controller = new PageController({
        viewportExpansion: -1,
        // full page by default
        highlightOpacity: 0.1,
        // 10% fill on element boxes
        highlightLabelOpacity: 0.5
        // 50% opacity on number labels + borders
      });
    }
    return controller;
  }
  async function getBrowserState(viewport_only) {
    const ctrl = getController();
    if (viewport_only !== void 0) {
      ctrl.config.viewportExpansion = viewport_only ? 0 : -1;
    }
    const timeoutMs = 15e3;
    return Promise.race([
      ctrl.getBrowserState(),
      new Promise(
        (_, reject) => setTimeout(
          () => reject(
            new Error(
              `get_browser_state timed out after ${timeoutMs}ms (complex DOM or cross-origin iframes)`
            )
          ),
          timeoutMs
        )
      )
    ]);
  }
  getBrowserState.__schema__ = {
    name: "getBrowserState",
    description: "Get the current page state with all interactive elements indexed as [0], [1], [2], etc. Returns a simplified HTML representation optimized for LLM consumption. Interactive elements (buttons, links, inputs, scrollable areas) are detected via smart heuristics (CSS cursor, ARIA roles, event listeners, tag names). Use the returned indices with click_element_by_index, input_text, select_option, or scroll. Call this first to understand the page before performing any actions.",
    parameters: {
      type: "object",
      properties: {
        viewport_only: {
          type: "boolean",
          description: "If true, only return elements visible in the current viewport. Default: false (full page)."
        }
      }
    }
  };
  async function clickElementByIndex(index) {
    return getController().clickElement(index);
  }
  clickElementByIndex.__schema__ = {
    name: "clickElementByIndex",
    description: "Click an interactive element by its numeric index from get_browser_state output. Simulates a full mouse event sequence (hover, mousedown, focus, mouseup, click) to trigger all event listeners including React/Vue handlers.",
    parameters: {
      type: "object",
      properties: {
        index: {
          type: "number",
          description: "The element index from get_browser_state (e.g. 0 for [0], 5 for [5])."
        }
      },
      required: ["index"]
    }
  };
  async function inputText(index, text) {
    return getController().inputText(index, text);
  }
  inputText.__schema__ = {
    name: "inputText",
    description: "Type text into an input, textarea, or contenteditable element by its index. Replaces existing content. Works with React controlled components, contenteditable editors (LinkedIn, Quill), and native inputs.",
    parameters: {
      type: "object",
      properties: {
        index: {
          type: "number",
          description: "The element index from get_browser_state."
        },
        text: {
          type: "string",
          description: "The text to type into the element."
        }
      },
      required: ["index", "text"]
    }
  };
  async function selectOption(index, option_text) {
    return getController().selectOption(index, option_text);
  }
  selectOption.__schema__ = {
    name: "selectOption",
    description: "Select a dropdown option in a <select> element by its index and the visible option text.",
    parameters: {
      type: "object",
      properties: {
        index: {
          type: "number",
          description: "The <select> element index from get_browser_state."
        },
        option_text: {
          type: "string",
          description: "The visible text of the option to select (case-sensitive, trimmed)."
        }
      },
      required: ["index", "option_text"]
    }
  };
  async function scroll(direction, amount, index) {
    return getController().scroll({ direction, amount, index });
  }
  scroll.__schema__ = {
    name: "scroll",
    description: "Scroll the page or a specific scrollable container. If index is provided, scrolls the nearest scrollable ancestor of that element. Otherwise scrolls the page or the largest scrollable container.",
    parameters: {
      type: "object",
      properties: {
        direction: {
          type: "string",
          enum: ["up", "down", "left", "right"],
          description: "Scroll direction."
        },
        amount: {
          type: "number",
          description: "Scroll amount in pixels. Default: ~80% of viewport height (vertical) or width (horizontal)."
        },
        index: {
          type: "number",
          description: "Optional element index. If provided, scrolls the nearest scrollable ancestor of this element."
        }
      },
      required: ["direction"]
    }
  };
  async function removeHighlights() {
    getController().cleanUpHighlights();
    return { success: true, message: "Highlights removed." };
  }
  removeHighlights.__schema__ = {
    name: "removeHighlights",
    description: "Remove all visual element index labels/highlights from the page. Useful after taking a screenshot if you want a clean view.",
    parameters: {
      type: "object",
      properties: {}
    }
  };

  // src/relay/service-map.ts
  function createServiceMap(ctx = {}) {
    const base = {
      get_page_info: getPageInfo,
      get_html: getHtml,
      query_dom: queryDom,
      click_element: clickElement,
      fill_input: fillInput,
      scroll_to: scrollTo,
      take_screenshot: takeScreenshot,
      execute_script: executeScript,
      navigate,
      get_react_tree: getReactTree,
      // Smart DOM analysis + index-based interaction (from page-controller)
      get_browser_state: getBrowserState,
      click_element_by_index: clickElementByIndex,
      input_text: inputText,
      select_option: selectOption,
      scroll,
      remove_highlights: removeHighlights
    };
    const getSkillMd = () => {
      const schemaFns = {};
      for (const [name, f] of Object.entries(base)) {
        if (f.__schema__) schemaFns[name] = f;
      }
      const url = ctx.getServiceUrl?.() ?? "{SERVICE_URL}";
      const pageContext = typeof document !== "undefined" ? { title: document.title, url: location?.href } : void 0;
      return generateSkillMd(schemaFns, url, pageContext);
    };
    getSkillMd.__schema__ = {
      name: "getSkillMd",
      description: "Get the SKILL.md document describing all available debugger functions, their parameters, and usage examples. Follows the agentskills.io specification.",
      parameters: { type: "object", properties: {} }
    };
    const entries = Object.entries(base).map(([name, fn]) => ({
      name,
      fn,
      schema: fn.__schema__
    }));
    entries.push({
      name: "get_skill_md",
      fn: getSkillMd,
      schema: getSkillMd.__schema__
    });
    return entries;
  }

  // ../extension/src/content.ts
  var FLAG = "__HYPHA_DEBUGGER_AGENT__";
  function callMainWorldReact(selector, depth) {
    return new Promise((resolve) => {
      const id = Math.random().toString(36).slice(2);
      const onResp = (e) => {
        const d = e.detail;
        if (!d || d.id !== id) return;
        window.removeEventListener("hypha-debugger:react-response", onResp);
        resolve(d.result);
      };
      window.addEventListener("hypha-debugger:react-response", onResp);
      window.dispatchEvent(
        new CustomEvent("hypha-debugger:react-request", { detail: { id, selector, depth } })
      );
      setTimeout(() => {
        window.removeEventListener("hypha-debugger:react-response", onResp);
        resolve({ error: "React bridge timed out (main-world helper not present?)" });
      }, 8e3);
    });
  }
  (function main() {
    const w = window;
    if (w[FLAG]) return;
    w[FLAG] = true;
    const map = new Map(createServiceMap().map((e) => [e.name, e.fn]));
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (!msg || !msg.__hyphaPage) return;
      (async () => {
        try {
          const args = msg.args || [];
          let value;
          if (msg.method === "get_react_tree") {
            value = await callMainWorldReact(args[0], args[1]);
          } else {
            const fn = map.get(msg.method);
            value = fn ? await fn(...args) : { error: `Unknown page method: ${msg.method}` };
          }
          sendResponse({ value });
        } catch (e) {
          sendResponse({ __error: e?.message ?? String(e) });
        }
      })();
      return true;
    });
  })();
})();
