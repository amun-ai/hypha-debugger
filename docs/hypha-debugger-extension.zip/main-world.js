"use strict";
(() => {
  // src/services/react.ts
  function getFiberFromDOM(node) {
    const keys = Object.keys(node);
    const fiberKey = keys.find(
      (k) => k.startsWith("__reactFiber$") || k.startsWith("__reactInternalInstance$")
    );
    return fiberKey ? node[fiberKey] : null;
  }
  function findReactRoot() {
    const common = ["#root", "#app", "#__next", "[data-reactroot]", "main", "body"];
    for (const sel of common) {
      const el = document.querySelector(sel);
      if (el && getFiberFromDOM(el)) return el;
    }
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_ELEMENT,
      null
    );
    let node = walker.currentNode;
    while (node) {
      if (node instanceof Element && getFiberFromDOM(node)) return node;
      node = walker.nextNode();
    }
    return null;
  }
  function getComponentName(fiber) {
    const { type } = fiber;
    if (!type) return "(unknown)";
    if (typeof type === "string") return type;
    if (typeof type === "function") {
      return type.displayName || type.name || "Anonymous";
    }
    if (typeof type === "object") {
      if (type.displayName) return type.displayName;
      if (type.render)
        return type.render.displayName || type.render.name || "ForwardRef";
      if (type.type) return getComponentName({ type: type.type });
      if (type.$$typeof?.toString() === "Symbol(react.memo)") {
        return `Memo(${getComponentName({ type: type.type })})`;
      }
    }
    return "(unknown)";
  }
  function getFiberType(fiber) {
    if (fiber.tag === 0 || fiber.tag === 11 || fiber.tag === 14 || fiber.tag === 15)
      return "function";
    if (fiber.tag === 1) return "class";
    if (fiber.tag === 5 || fiber.tag === 6) return "host";
    return "other";
  }
  function safeSerialize(obj, depth = 0, maxDepth = 2) {
    if (depth > maxDepth) return "[max depth]";
    if (obj === null || obj === void 0) return obj;
    if (typeof obj === "function") return `[Function: ${obj.name || "anonymous"}]`;
    if (typeof obj !== "object") return obj;
    if (obj instanceof HTMLElement) return `[${obj.tagName.toLowerCase()}#${obj.id}]`;
    if (Array.isArray(obj)) {
      return obj.slice(0, 10).map((v) => safeSerialize(v, depth + 1, maxDepth));
    }
    const result = {};
    const keys = Object.keys(obj).slice(0, 20);
    for (const key of keys) {
      if (key.startsWith("_") || key.startsWith("$$")) continue;
      try {
        result[key] = safeSerialize(obj[key], depth + 1, maxDepth);
      } catch {
        result[key] = "[unserializable]";
      }
    }
    return result;
  }
  function extractState(fiber) {
    if (fiber.tag === 1 && fiber.stateNode) {
      return safeSerialize(fiber.stateNode.state);
    }
    if (fiber.tag === 0 || fiber.tag === 11 || fiber.tag === 15) {
      const states = [];
      let hook = fiber.memoizedState;
      let i = 0;
      while (hook && i < 20) {
        if (hook.queue !== null && hook.queue !== void 0) {
          states.push(safeSerialize(hook.memoizedState));
        }
        hook = hook.next;
        i++;
      }
      return states.length > 0 ? states : null;
    }
    return null;
  }
  function fiberToInfo(fiber, depth, maxDepth) {
    const fiberType = getFiberType(fiber);
    const isComponent = fiberType === "function" || fiberType === "class";
    const info = {
      name: getComponentName(fiber),
      type: fiberType,
      props: isComponent ? safeSerialize(fiber.memoizedProps) : {},
      state: isComponent ? extractState(fiber) : null,
      key: fiber.key,
      children: []
    };
    if (depth < maxDepth) {
      let child = fiber.child;
      while (child) {
        const childInfo = fiberToInfo(child, depth + 1, maxDepth);
        if (childInfo) {
          if (childInfo.type !== "host" || childInfo.children.length > 0) {
            info.children.push(childInfo);
          }
        }
        child = child.sibling;
      }
    }
    return info;
  }
  function getReactTree(selector, max_depth) {
    const maxDepth = max_depth ?? 5;
    let rootEl;
    let usedSelector;
    if (selector) {
      rootEl = document.querySelector(selector);
      usedSelector = selector;
      if (!rootEl) {
        return { error: `No element found for selector: ${selector}` };
      }
    } else {
      rootEl = findReactRoot();
      usedSelector = rootEl?.tagName.toLowerCase() + (rootEl?.id ? "#" + rootEl.id : "") || "(auto)";
      if (!rootEl) {
        return {
          error: "No React root found on this page. Tried #root, #app, #__next, [data-reactroot], main, body \u2014 none had React fibers. This page may not be a React app, or React may not have rendered yet. Pass an explicit `selector` if you know the mount point."
        };
      }
    }
    const fiber = getFiberFromDOM(rootEl);
    if (!fiber) {
      return {
        error: `No React fiber found on element "${usedSelector}". Is this a React app?`
      };
    }
    let current = fiber;
    while (current && current.tag === 3) {
      current = current.child;
    }
    if (!current) {
      return { error: "Could not find root React component fiber." };
    }
    const tree = fiberToInfo(current, 0, maxDepth);
    if (!tree) {
      return { error: "Could not build React component tree." };
    }
    return tree;
  }
  getReactTree.__schema__ = {
    name: "getReactTree",
    description: "Inspect the React component tree. Returns component names, props, state (including hooks), and children hierarchy. When no selector is provided, auto-detects the React root by scanning common mount points (#root, #app, #__next, [data-reactroot], main, body) and then walking the DOM for any element with a React fiber attached.",
    parameters: {
      type: "object",
      properties: {
        selector: {
          type: "string",
          description: "CSS selector of the React root element. Omit for auto-detection."
        },
        max_depth: {
          type: "number",
          description: "Maximum depth to traverse the component tree. Default: 5."
        }
      }
    }
  };

  // ../extension/src/main-world.ts
  (function main() {
    const FLAG = "__HYPHA_DEBUGGER_MAIN__";
    const w = window;
    if (w[FLAG]) return;
    w[FLAG] = true;
    window.addEventListener("hypha-debugger:react-request", async (e) => {
      const detail = e.detail;
      if (!detail) return;
      let result;
      try {
        result = await getReactTree(detail.selector, detail.depth);
      } catch (err) {
        result = { error: err?.message ?? String(err) };
      }
      window.dispatchEvent(
        new CustomEvent("hypha-debugger:react-response", {
          detail: { id: detail.id, result }
        })
      );
    });
  })();
})();
