var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/hypha-rpc/dist/hypha-rpc-websocket.js
var require_hypha_rpc_websocket = __commonJS({
  "node_modules/hypha-rpc/dist/hypha-rpc-websocket.js"(exports, module) {
    (function webpackUniversalModuleDefinition(root, factory) {
      if (typeof exports === "object" && typeof module === "object")
        module.exports = factory();
      else if (typeof define === "function" && define.amd)
        define("hyphaWebsocketClient", [], factory);
      else if (typeof exports === "object")
        exports["hyphaWebsocketClient"] = factory();
      else
        root["hyphaWebsocketClient"] = factory();
    })(exports, () => {
      return (
        /******/
        (() => {
          "use strict";
          var __webpack_modules__ = {
            /***/
            "./src/http-client.js": (
              /*!****************************!*\
                !*** ./src/http-client.js ***!
                \****************************/
              /***/
              (__unused_webpack_module2, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  HTTPStreamingRPCConnection: () => (
                    /* binding */
                    HTTPStreamingRPCConnection
                  ),
                  /* harmony export */
                  _connectToServerHTTP: () => (
                    /* binding */
                    _connectToServerHTTP
                  ),
                  /* harmony export */
                  connectToServerHTTP: () => (
                    /* binding */
                    connectToServerHTTP
                  ),
                  /* harmony export */
                  getRemoteServiceHTTP: () => (
                    /* binding */
                    getRemoteServiceHTTP
                  ),
                  /* harmony export */
                  normalizeServerUrl: () => (
                    /* binding */
                    normalizeServerUrl2
                  )
                  /* harmony export */
                });
                var _rpc_js__WEBPACK_IMPORTED_MODULE_0__2 = __webpack_require__2(
                  /*! ./rpc.js */
                  "./src/rpc.js"
                );
                var _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2 = __webpack_require__2(
                  /*! ./utils/index.js */
                  "./src/utils/index.js"
                );
                var _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2 = __webpack_require__2(
                  /*! ./utils/schema.js */
                  "./src/utils/schema.js"
                );
                var _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__2(
                  /*! @msgpack/msgpack */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/decode.mjs"
                );
                const MAX_RETRY2 = 1e6;
                class HTTPStreamingRPCConnection {
                  /**
                   * Initialize HTTP streaming connection.
                   *
                   * @param {string} server_url - The server URL (http:// or https://)
                   * @param {string} client_id - Unique client identifier
                   * @param {string} workspace - Target workspace (optional)
                   * @param {string} token - Authentication token (optional)
                   * @param {string} reconnection_token - Token for reconnection (optional)
                   * @param {number} timeout - Request timeout in seconds (default: 60)
                   * @param {number} token_refresh_interval - Interval for token refresh (default: 2 hours)
                   */
                  constructor(server_url2, client_id2, workspace2 = null, token2 = null, reconnection_token = null, timeout = 60, token_refresh_interval = 2 * 60 * 60) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(server_url2 && client_id2, "server_url and client_id are required");
                    this._server_url = server_url2.replace(/\/$/, "");
                    this._client_id = client_id2;
                    this._workspace = workspace2;
                    this._token = token2;
                    this._reconnection_token = reconnection_token;
                    this._timeout = timeout;
                    this._token_refresh_interval = token_refresh_interval;
                    this._handle_message = null;
                    this._handle_disconnected = null;
                    this._handle_connected = null;
                    this._closed = false;
                    this._enable_reconnect = false;
                    this._is_reconnection = false;
                    this.connection_info = null;
                    this.manager_id = null;
                    this._abort_controller = null;
                    this._refresh_token_task = null;
                  }
                  /**
                   * Register message handler.
                   */
                  on_message(handler) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(handler, "handler is required");
                    this._handle_message = handler;
                  }
                  /**
                   * Register disconnection handler.
                   */
                  on_disconnected(handler) {
                    this._handle_disconnected = handler;
                  }
                  /**
                   * Register connection handler.
                   */
                  on_connected(handler) {
                    this._handle_connected = handler;
                  }
                  /**
                   * Get HTTP headers with authentication.
                   *
                   * @param {boolean} for_stream - If true, set Accept header for msgpack stream
                   * @returns {Object} Headers object
                   */
                  _get_headers(for_stream = false) {
                    const headers = {
                      "Content-Type": "application/msgpack"
                    };
                    if (for_stream) {
                      headers["Accept"] = "application/x-msgpack-stream";
                    }
                    if (this._token) {
                      headers["Authorization"] = `Bearer ${this._token}`;
                    }
                    return headers;
                  }
                  /**
                   * Open the streaming connection.
                   */
                  async open() {
                    console.info(`Opening HTTP streaming connection to ${this._server_url}`);
                    const ws = this._workspace || "public";
                    const stream_url = `${this._server_url}/${ws}/rpc?client_id=${this._client_id}`;
                    this._startStreamLoop(stream_url);
                    const start = Date.now();
                    while (this.connection_info === null) {
                      await new Promise((resolve2) => setTimeout(resolve2, 100));
                      if (Date.now() - start > this._timeout * 1e3) {
                        throw new Error("Timeout waiting for connection info");
                      }
                      if (this._closed) {
                        throw new Error("Connection closed during setup");
                      }
                    }
                    this.manager_id = this.connection_info.manager_id;
                    if (this._workspace) {
                      const actual_ws = this.connection_info.workspace;
                      if (actual_ws !== this._workspace) {
                        throw new Error(
                          `Connected to wrong workspace: ${actual_ws}, expected: ${this._workspace}`
                        );
                      }
                    }
                    this._workspace = this.connection_info.workspace;
                    if (this.connection_info.reconnection_token) {
                      this._reconnection_token = this.connection_info.reconnection_token;
                    }
                    if (this.connection_info.reconnection_token_life_time) {
                      const token_life_time = this.connection_info.reconnection_token_life_time;
                      if (this._token_refresh_interval > token_life_time / 1.5) {
                        console.warn(
                          `Token refresh interval (${this._token_refresh_interval}s) is too long, adjusting to ${(token_life_time / 1.5).toFixed(0)}s based on token lifetime`
                        );
                        this._token_refresh_interval = token_life_time / 1.5;
                      }
                    }
                    console.info(
                      `HTTP streaming connected to workspace: ${this._workspace}, manager_id: ${this.manager_id}`
                    );
                    if (this._token_refresh_interval > 0) {
                      this._startTokenRefresh();
                    }
                    if (this._handle_connected) {
                      await this._handle_connected(this.connection_info);
                    }
                    return this.connection_info;
                  }
                  /**
                   * Start periodic token refresh via POST.
                   */
                  _startTokenRefresh() {
                    if (this._refresh_token_task) {
                      clearInterval(this._refresh_token_task);
                    }
                    setTimeout(() => {
                      this._sendRefreshToken();
                      this._refresh_token_task = setInterval(() => {
                        this._sendRefreshToken();
                      }, this._token_refresh_interval * 1e3);
                    }, 2e3);
                  }
                  /**
                   * Send a token refresh request via POST.
                   */
                  async _sendRefreshToken() {
                    if (this._closed) return;
                    try {
                      const ws = this._workspace || "public";
                      const url = `${this._server_url}/${ws}/rpc?client_id=${this._client_id}`;
                      const { encode } = await __webpack_require__2.e(
                        /*! import() */
                        "vendors-node_modules_msgpack_msgpack_dist_es5_esm_index_mjs"
                      ).then(__webpack_require__2.bind(
                        __webpack_require__2,
                        /*! @msgpack/msgpack */
                        "./node_modules/@msgpack/msgpack/dist.es5+esm/index.mjs"
                      ));
                      const body = encode({ type: "refresh_token" });
                      const response = await fetch(url, {
                        method: "POST",
                        headers: this._get_headers(false),
                        body
                      });
                      if (response.ok) {
                        console.debug("Token refresh requested successfully");
                      } else {
                        console.warn(`Token refresh request failed: ${response.status}`);
                      }
                    } catch (e) {
                      console.warn(`Failed to send refresh token request: ${e.message}`);
                    }
                  }
                  /**
                   * Start the streaming loop.
                   *
                   * OPTIMIZATION: Modern browsers automatically:
                   * - Negotiate HTTP/2 when server supports it
                   * - Use connection pooling for multiple requests to same origin
                   * - Handle keep-alive for persistent connections
                   * - Stream responses efficiently with backpressure handling
                   */
                  async _startStreamLoop(url) {
                    this._enable_reconnect = true;
                    this._closed = false;
                    let retry = 0;
                    this._is_reconnection = false;
                    while (!this._closed && retry < MAX_RETRY2) {
                      try {
                        const ws = this._workspace || "public";
                        let stream_url = `${this._server_url}/${ws}/rpc?client_id=${this._client_id}`;
                        if (this._reconnection_token) {
                          stream_url += `&reconnection_token=${encodeURIComponent(this._reconnection_token)}`;
                        }
                        this._abort_controller = new AbortController();
                        const response = await fetch(stream_url, {
                          method: "GET",
                          headers: this._get_headers(true),
                          signal: this._abort_controller.signal
                        });
                        if (!response.ok) {
                          const error_text = await response.text();
                          throw new Error(
                            `Stream failed with status ${response.status}: ${error_text}`
                          );
                        }
                        retry = 0;
                        await this._processMsgpackStream(response);
                      } catch (error) {
                        if (this._closed) break;
                        console.error(`Connection error: ${error.message}`);
                        if (!this._enable_reconnect) {
                          break;
                        }
                      }
                      this._is_reconnection = true;
                      if (!this._closed && this._enable_reconnect) {
                        retry += 1;
                        const delay = Math.min(Math.pow(2, Math.min(retry, 6)), 60);
                        console.warn(
                          `Stream disconnected, reconnecting in ${delay.toFixed(1)}s (attempt ${retry})`
                        );
                        await new Promise((resolve2) => setTimeout(resolve2, delay * 1e3));
                      } else {
                        break;
                      }
                    }
                    if (!this._closed && this._handle_disconnected) {
                      this._handle_disconnected("Stream ended");
                    }
                  }
                  /**
                   * Check if frame data is a control message and decode it.
                   *
                   * Control messages vs RPC messages:
                   * - Control messages: Single msgpack object with "type" field (connection_info, ping, etc.)
                   * - RPC messages: May contain multiple concatenated msgpack objects (main message + extra data)
                   *
                   * We only need to decode the first object to check if it's a control message.
                   * RPC messages are passed as raw bytes to the handler.
                   *
                   * @param {Uint8Array} frame_data - The msgpack frame data
                   * @returns {Object|null} Decoded control message or null
                   */
                  _tryDecodeControlMessage(frame_data) {
                    try {
                      const decoded = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__.decode)(frame_data);
                      if (typeof decoded === "object" && decoded !== null && decoded.type) {
                        const controlTypes = [
                          "connection_info",
                          "ping",
                          "pong",
                          "reconnection_token",
                          "error"
                        ];
                        if (controlTypes.includes(decoded.type)) {
                          return decoded;
                        }
                      }
                      return null;
                    } catch {
                      return null;
                    }
                  }
                  /**
                   * Process msgpack stream with 4-byte length prefix.
                   */
                  async _processMsgpackStream(response) {
                    const reader = response.body.getReader();
                    let buffer = new Uint8Array(4096);
                    let bufferLen = 0;
                    while (!this._closed) {
                      const { done, value } = await reader.read();
                      if (done) break;
                      const needed = bufferLen + value.length;
                      if (needed > buffer.length) {
                        let newSize = buffer.length;
                        while (newSize < needed) newSize *= 2;
                        const grown = new Uint8Array(newSize);
                        grown.set(buffer.subarray(0, bufferLen));
                        buffer = grown;
                      }
                      buffer.set(value, bufferLen);
                      bufferLen += value.length;
                      let offset = 0;
                      while (bufferLen - offset >= 4) {
                        const length = buffer[offset] << 24 | buffer[offset + 1] << 16 | buffer[offset + 2] << 8 | buffer[offset + 3];
                        if (bufferLen - offset < 4 + length) {
                          break;
                        }
                        const frame_data = buffer.slice(offset + 4, offset + 4 + length);
                        offset += 4 + length;
                        const controlMsg = this._tryDecodeControlMessage(frame_data);
                        if (controlMsg) {
                          const msg_type = controlMsg.type;
                          if (msg_type === "connection_info") {
                            this.connection_info = controlMsg;
                            if (this._is_reconnection) {
                              this._handleReconnection(controlMsg).catch((err) => {
                                console.error(`Reconnection handling failed: ${err.message}`);
                              });
                            }
                            continue;
                          } else if (msg_type === "ping" || msg_type === "pong") {
                            continue;
                          } else if (msg_type === "reconnection_token") {
                            this._reconnection_token = controlMsg.reconnection_token;
                            continue;
                          } else if (msg_type === "error") {
                            console.error(`Server error: ${controlMsg.message}`);
                            continue;
                          }
                        }
                        if (this._handle_message) {
                          try {
                            await this._handle_message(frame_data);
                          } catch (error) {
                            console.error(`Error in message handler: ${error.message}`);
                          }
                        }
                      }
                      if (offset > 0) {
                        const remaining = bufferLen - offset;
                        if (remaining > 0) {
                          buffer.copyWithin(0, offset, bufferLen);
                        }
                        bufferLen = remaining;
                      }
                    }
                  }
                  /**
                   * Handle reconnection: update state and notify RPC layer.
                   */
                  async _handleReconnection(connection_info) {
                    this.manager_id = connection_info.manager_id;
                    this._workspace = connection_info.workspace;
                    if (connection_info.reconnection_token) {
                      this._reconnection_token = connection_info.reconnection_token;
                    }
                    if (connection_info.reconnection_token_life_time) {
                      const token_life_time = connection_info.reconnection_token_life_time;
                      if (this._token_refresh_interval > token_life_time / 1.5) {
                        this._token_refresh_interval = token_life_time / 1.5;
                      }
                    }
                    console.warn(
                      `Stream reconnected to workspace: ${this._workspace}, manager_id: ${this.manager_id}`
                    );
                    if (this._handle_connected) {
                      await this._handle_connected(this.connection_info);
                    }
                    await new Promise((resolve2) => setTimeout(resolve2, 500));
                  }
                  /**
                   * Send a message to the server via HTTP POST.
                   *
                   * OPTIMIZATION: Uses keepalive flag for connection reuse.
                   * Modern browsers automatically:
                   * - Use HTTP/2 when available (multiplexing, header compression)
                   * - Manage connection pooling with HTTP/1.1 keep-alive
                   * - Reuse connections for same-origin requests
                   */
                  async emit_message(data) {
                    if (this._closed) {
                      throw new Error("Connection is closed");
                    }
                    const ws = this._workspace || "public";
                    let post_url = `${this._server_url}/${ws}/rpc?client_id=${this._client_id}`;
                    const body = data instanceof Uint8Array ? data : new Uint8Array(data);
                    const maxRetries = 3;
                    for (let attempt = 0; attempt < maxRetries; attempt++) {
                      try {
                        const useKeepalive = body.length < 6e4;
                        const response = await fetch(post_url, {
                          method: "POST",
                          headers: this._get_headers(false),
                          body,
                          ...useKeepalive && { keepalive: true }
                        });
                        if (!response.ok) {
                          const error_text = await response.text();
                          if (response.status === 400 && attempt < maxRetries - 1) {
                            console.warn(
                              `POST failed (attempt ${attempt + 1}/${maxRetries}): ${error_text}, retrying...`
                            );
                            await new Promise(
                              (r) => setTimeout(r, 500 * (attempt + 1))
                            );
                            continue;
                          }
                          throw new Error(
                            `POST failed with status ${response.status}: ${error_text}`
                          );
                        }
                        return true;
                      } catch (error) {
                        if (attempt < maxRetries - 1 && !this._closed) {
                          console.warn(
                            `Failed to send message (attempt ${attempt + 1}/${maxRetries}): ${error.message}, retrying...`
                          );
                          await new Promise(
                            (r) => setTimeout(r, 500 * (attempt + 1))
                          );
                        } else {
                          console.error(`Failed to send message: ${error.message}`);
                          throw error;
                        }
                      }
                    }
                  }
                  /**
                   * Set reconnection flag.
                   */
                  set_reconnection(value) {
                    this._enable_reconnect = value;
                  }
                  /**
                   * Close the connection.
                   */
                  async disconnect(reason = "client disconnect") {
                    if (this._closed) return;
                    this._closed = true;
                    if (this._refresh_token_task) {
                      clearInterval(this._refresh_token_task);
                      this._refresh_token_task = null;
                    }
                    if (this._abort_controller) {
                      this._abort_controller.abort();
                      this._abort_controller = null;
                    }
                    if (this._handle_disconnected) {
                      this._handle_disconnected(reason);
                    }
                  }
                }
                function normalizeServerUrl2(server_url2) {
                  if (!server_url2) {
                    throw new Error("server_url is required");
                  }
                  if (server_url2.startsWith("ws://")) {
                    server_url2 = server_url2.replace("ws://", "http://");
                  } else if (server_url2.startsWith("wss://")) {
                    server_url2 = server_url2.replace("wss://", "https://");
                  }
                  if (server_url2.endsWith("/ws")) {
                    server_url2 = server_url2.slice(0, -3);
                  }
                  return server_url2.replace(/\/$/, "");
                }
                async function _connectToServerHTTP(config2) {
                  let clientId = config2.clientId || config2.client_id;
                  if (!clientId) {
                    clientId = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.randId)();
                  }
                  const server_url2 = normalizeServerUrl2(config2.serverUrl || config2.server_url);
                  const connection = new HTTPStreamingRPCConnection(
                    server_url2,
                    clientId,
                    config2.workspace,
                    config2.token,
                    config2.reconnection_token,
                    config2.method_timeout || 30,
                    config2.token_refresh_interval || 2 * 60 * 60
                  );
                  const connection_info = await connection.open();
                  (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(connection_info, "Failed to connect to server");
                  await new Promise((resolve2) => setTimeout(resolve2, 100));
                  const workspace2 = connection_info.workspace;
                  const rpc = new _rpc_js__WEBPACK_IMPORTED_MODULE_0__2.RPC(connection, {
                    client_id: clientId,
                    workspace: workspace2,
                    default_context: { connection_type: "http_streaming" },
                    name: config2.name,
                    method_timeout: config2.method_timeout,
                    app_id: config2.app_id,
                    server_base_url: connection_info.public_base_url
                  });
                  await rpc.waitFor("services_registered", config2.method_timeout || 120);
                  const wm = await rpc.get_manager_service({
                    timeout: config2.method_timeout || 30,
                    case_conversion: "camel"
                  });
                  wm.rpc = rpc;
                  wm.disconnect = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2.schemaFunction)(rpc.disconnect.bind(rpc), {
                    name: "disconnect",
                    description: "Disconnect from server",
                    parameters: { properties: {}, type: "object" }
                  });
                  wm.registerService = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2.schemaFunction)(rpc.register_service.bind(rpc), {
                    name: "registerService",
                    description: "Register a service",
                    parameters: {
                      properties: {
                        service: { description: "Service to register", type: "object" }
                      },
                      required: ["service"],
                      type: "object"
                    }
                  });
                  const _getService = wm.getService;
                  wm.getService = async (query, config3 = {}) => {
                    return await _getService(query, config3);
                  };
                  if (_getService.__schema__) {
                    wm.getService.__schema__ = _getService.__schema__;
                  }
                  async function serve() {
                    await new Promise(() => {
                    });
                  }
                  wm.serve = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2.schemaFunction)(serve, {
                    name: "serve",
                    description: "Run event loop forever",
                    parameters: { type: "object", properties: {} }
                  });
                  if (connection_info) {
                    wm.config = Object.assign(wm.config || {}, connection_info);
                  }
                  if (connection.manager_id) {
                    rpc.on("force-exit", async (message) => {
                      if (message.from === "*/" + connection.manager_id) {
                        console.info(`Disconnecting from server: ${message.reason}`);
                        await rpc.disconnect();
                      }
                    });
                  }
                  return wm;
                }
                async function connectToServerHTTP(config2 = {}) {
                  return await _connectToServerHTTP(config2);
                }
                async function getRemoteServiceHTTP(serviceUri, config2 = {}) {
                  const { serverUrl, workspace: workspace2, clientId, serviceId, appId } = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.parseServiceUrl)(serviceUri);
                  const fullServiceId = `${workspace2}/${clientId}:${serviceId}@${appId}`;
                  if (config2.serverUrl) {
                    if (config2.serverUrl !== serverUrl) {
                      throw new Error("server_url mismatch");
                    }
                  }
                  config2.serverUrl = serverUrl;
                  const server3 = await connectToServerHTTP(config2);
                  return await server3.getService(fullServiceId);
                }
              }
            ),
            /***/
            "./src/rpc.js": (
              /*!********************!*\
                !*** ./src/rpc.js ***!
                \********************/
              /***/
              (__unused_webpack_module2, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  API_VERSION: () => (
                    /* binding */
                    API_VERSION
                  ),
                  /* harmony export */
                  RPC: () => (
                    /* binding */
                    RPC
                  )
                  /* harmony export */
                });
                var _utils_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./utils/index.js */
                  "./src/utils/index.js"
                );
                var _utils_schema_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__2(
                  /*! ./utils/schema.js */
                  "./src/utils/schema.js"
                );
                var _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__2(
                  /*! @msgpack/msgpack */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/decode.mjs"
                );
                var _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__2(
                  /*! @msgpack/msgpack */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/encode.mjs"
                );
                const API_VERSION = 3;
                const CHUNK_SIZE = 1024 * 256;
                const CONCURRENCY_LIMIT = 30;
                const ArrayBufferView = Object.getPrototypeOf(
                  Object.getPrototypeOf(new Uint8Array())
                ).constructor;
                function _isPrimitive(v) {
                  if (v === null || v === void 0) return true;
                  const t = typeof v;
                  return t === "number" || t === "string" || t === "boolean";
                }
                function _allPrimitivesArray(arr) {
                  for (let i = 0; i < arr.length; i++) {
                    const v = arr[i];
                    if (_isPrimitive(v)) continue;
                    if (v instanceof Uint8Array) continue;
                    if (Array.isArray(v)) {
                      if (!_allPrimitivesArray(v)) return false;
                      continue;
                    }
                    if (v && v.constructor === Object) {
                      if ("_rtype" in v) return false;
                      if (!_allPrimitivesObject(v)) return false;
                      continue;
                    }
                    return false;
                  }
                  return true;
                }
                function _allPrimitivesObject(obj) {
                  const values = Object.values(obj);
                  for (let i = 0; i < values.length; i++) {
                    const v = values[i];
                    if (_isPrimitive(v)) continue;
                    if (v instanceof Uint8Array) continue;
                    if (Array.isArray(v)) {
                      if (!_allPrimitivesArray(v)) return false;
                      continue;
                    }
                    if (v && v.constructor === Object) {
                      if ("_rtype" in v) return false;
                      if (!_allPrimitivesObject(v)) return false;
                      continue;
                    }
                    return false;
                  }
                  return true;
                }
                function _appendBuffer(buffer1, buffer2) {
                  const tmp = new Uint8Array(buffer1.byteLength + buffer2.byteLength);
                  tmp.set(new Uint8Array(buffer1), 0);
                  tmp.set(new Uint8Array(buffer2), buffer1.byteLength);
                  return tmp.buffer;
                }
                function withTimeout2(promise, timeoutMs, message = "Operation timed out") {
                  return new Promise((resolve2, reject2) => {
                    const timeoutId = setTimeout(() => {
                      reject2(new Error(`TimeoutError: ${message}`));
                    }, timeoutMs);
                    promise.then((result) => {
                      clearTimeout(timeoutId);
                      resolve2(result);
                    }).catch((error) => {
                      clearTimeout(timeoutId);
                      reject2(error);
                    });
                  });
                }
                function indexObject(obj, is) {
                  if (!is) throw new Error("undefined index");
                  if (typeof is === "string") return indexObject(obj, is.split("."));
                  else if (is.length === 0) return obj;
                  else return indexObject(obj[is[0]], is.slice(1));
                }
                function _get_schema(obj, name2 = null, skipContext = false) {
                  if (Array.isArray(obj)) {
                    return obj.map((v, i) => _get_schema(v, null, skipContext));
                  } else if (typeof obj === "object" && obj !== null) {
                    let schema = {};
                    for (let k in obj) {
                      schema[k] = _get_schema(obj[k], k, skipContext);
                    }
                    return schema;
                  } else if (typeof obj === "function") {
                    if (obj.__schema__) {
                      const schema = JSON.parse(JSON.stringify(obj.__schema__));
                      if (name2) {
                        schema.name = name2;
                        obj.__schema__.name = name2;
                      }
                      if (skipContext) {
                        if (schema.parameters && schema.parameters.properties) {
                          delete schema.parameters.properties["context"];
                        }
                        if (schema.parameters && schema.parameters.required) {
                          const contextIndex = schema.parameters.required.indexOf("context");
                          if (contextIndex > -1) {
                            schema.parameters.required.splice(contextIndex, 1);
                          }
                        }
                      }
                      return { type: "function", function: schema };
                    } else {
                      const funcName = name2 || obj.name || "function";
                      return {
                        type: "function",
                        function: {
                          name: funcName
                        }
                      };
                    }
                  } else if (typeof obj === "number") {
                    return { type: "number" };
                  } else if (typeof obj === "string") {
                    return { type: "string" };
                  } else if (typeof obj === "boolean") {
                    return { type: "boolean" };
                  } else if (obj === null) {
                    return { type: "null" };
                  } else {
                    return {};
                  }
                }
                function _annotate_service(service, serviceTypeInfo) {
                  function validateKeys(serviceDict, schemaDict, path = "root") {
                    for (let key in schemaDict) {
                      if (!serviceDict.hasOwnProperty(key)) {
                        throw new Error(`Missing key '${key}' in service at path '${path}'`);
                      }
                    }
                    for (let key in serviceDict) {
                      if (key !== "type" && !schemaDict.hasOwnProperty(key)) {
                        throw new Error(`Unexpected key '${key}' in service at path '${path}'`);
                      }
                    }
                  }
                  function annotateRecursive(newService, schemaInfo, path = "root") {
                    if (typeof newService === "object" && !Array.isArray(newService)) {
                      validateKeys(newService, schemaInfo, path);
                      for (let k in newService) {
                        let v = newService[k];
                        let newPath = `${path}.${k}`;
                        if (typeof v === "object" && !Array.isArray(v)) {
                          annotateRecursive(v, schemaInfo[k], newPath);
                        } else if (typeof v === "function") {
                          if (schemaInfo.hasOwnProperty(k)) {
                            newService[k] = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_1__.schemaFunction)(v, {
                              name: schemaInfo[k]["name"],
                              description: schemaInfo[k].description || "",
                              parameters: schemaInfo[k]["parameters"]
                            });
                          } else {
                            throw new Error(
                              `Missing schema for function '${k}' at path '${newPath}'`
                            );
                          }
                        }
                      }
                    } else if (Array.isArray(newService)) {
                      if (newService.length !== schemaInfo.length) {
                        throw new Error(`Length mismatch at path '${path}'`);
                      }
                      newService.forEach((v, i) => {
                        let newPath = `${path}[${i}]`;
                        if (typeof v === "object" && !Array.isArray(v)) {
                          annotateRecursive(v, schemaInfo[i], newPath);
                        } else if (typeof v === "function") {
                          if (schemaInfo.hasOwnProperty(i)) {
                            newService[i] = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_1__.schemaFunction)(v, {
                              name: schemaInfo[i]["name"],
                              description: schemaInfo[i].description || "",
                              parameters: schemaInfo[i]["parameters"]
                            });
                          } else {
                            throw new Error(
                              `Missing schema for function at index ${i} in path '${newPath}'`
                            );
                          }
                        }
                      });
                    }
                  }
                  validateKeys(service, serviceTypeInfo["definition"]);
                  annotateRecursive(service, serviceTypeInfo["definition"]);
                  return service;
                }
                function getFunctionInfo(func) {
                  const funcString = func.toString();
                  const nameMatch = funcString.match(/function\s*(\w*)/);
                  const name2 = nameMatch && nameMatch[1] || "";
                  const paramsMatch = funcString.match(/\(([^)]*)\)/);
                  let params = "";
                  if (paramsMatch) {
                    params = paramsMatch[1].split(",").map(
                      (p) => p.replace(/\/\*.*?\*\//g, "").replace(/\/\/.*$/g, "")
                    ).filter((p) => p.trim().length > 0).map((p) => p.trim()).join(", ");
                  }
                  let docMatch = funcString.match(/\)\s*\{\s*\/\*([\s\S]*?)\*\//);
                  const docstringBlock = docMatch && docMatch[1].trim() || "";
                  docMatch = funcString.match(/\)\s*\{\s*(\/\/[\s\S]*?)\n\s*[^\s\/]/);
                  const docstringLine = docMatch && docMatch[1].split("\n").map((s) => s.replace(/^\/\/\s*/, "").trim()).join("\n") || "";
                  const docstring = docstringBlock || docstringLine;
                  return name2 && params.length > 0 && {
                    name: name2,
                    sig: params,
                    doc: docstring
                  };
                }
                function concatArrayBuffers(buffers) {
                  var buffersLengths = buffers.map(function(b) {
                    return b.byteLength;
                  }), totalBufferlength = buffersLengths.reduce(function(p, c) {
                    return p + c;
                  }, 0), unit8Arr = new Uint8Array(totalBufferlength);
                  buffersLengths.reduce(function(p, c, i) {
                    unit8Arr.set(new Uint8Array(buffers[i]), p);
                    return p + c;
                  }, 0);
                  return unit8Arr.buffer;
                }
                class Timer {
                  constructor(timeout, callback, args, label) {
                    this._timeout = timeout;
                    this._callback = callback;
                    this._args = args;
                    this._label = label || "timer";
                    this._task = null;
                    this.started = false;
                  }
                  start() {
                    if (this.started) {
                      this.reset();
                    } else {
                      this._task = setTimeout(() => {
                        this._callback.apply(this, this._args);
                      }, this._timeout * 1e3);
                      this.started = true;
                    }
                  }
                  clear() {
                    if (this._task && this.started) {
                      clearTimeout(this._task);
                      this._task = null;
                      this.started = false;
                    } else {
                      console.warn(`Clearing a timer (${this._label}) which is not started`);
                    }
                  }
                  reset() {
                    if (this._task) {
                      clearTimeout(this._task);
                    }
                    this._task = setTimeout(() => {
                      this._callback.apply(this, this._args);
                    }, this._timeout * 1e3);
                    this.started = true;
                  }
                }
                class RemoteService extends Object {
                }
                class RPC extends _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.MessageEmitter {
                  constructor(connection, {
                    client_id: client_id2 = null,
                    default_context = null,
                    name: name2 = null,
                    codecs = null,
                    method_timeout: method_timeout2 = null,
                    max_message_buffer_size = 0,
                    debug = false,
                    workspace: workspace2 = null,
                    silent = false,
                    app_id = null,
                    server_base_url = null,
                    long_message_chunk_size = null
                  }) {
                    super(debug);
                    this._codecs = codecs || {};
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(client_id2 && typeof client_id2 === "string");
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(client_id2, "client_id is required");
                    this._client_id = client_id2;
                    this._name = name2;
                    this._app_id = app_id || "*";
                    this._local_workspace = workspace2;
                    this._silent = silent;
                    this.default_context = default_context || {};
                    this._method_annotations = /* @__PURE__ */ new WeakMap();
                    this._max_message_buffer_size = max_message_buffer_size;
                    this._chunk_store = {};
                    this._method_timeout = method_timeout2 || 30;
                    this._server_base_url = server_base_url;
                    this._long_message_chunk_size = long_message_chunk_size || CHUNK_SIZE;
                    this._services = {};
                    this._object_store = {
                      services: this._services
                    };
                    this._targetIdIndex = {};
                    this._background_tasks = /* @__PURE__ */ new Set();
                    const handleUnhandledRejection = (event2) => {
                      const reason = event2.reason;
                      if (reason && typeof reason === "object") {
                        const reasonStr = reason.toString();
                        if (reasonStr.includes("Method not found") || reasonStr.includes("Session not found") || reasonStr.includes("Method expired") || reasonStr.includes("Session not found")) {
                          console.debug(
                            "Ignoring expected method/session not found error:",
                            reason
                          );
                          event2.preventDefault();
                          return;
                        }
                      }
                      console.warn("Unhandled RPC promise rejection:", reason);
                    };
                    if (typeof window !== "undefined" && !window._hypha_rejection_handler_set) {
                      window.addEventListener("unhandledrejection", handleUnhandledRejection);
                      window._hypha_rejection_handler_set = true;
                    } else if (typeof process !== "undefined" && !process._hypha_rejection_handler_set) {
                      process.on("unhandledRejection", (reason, promise) => {
                        handleUnhandledRejection({ reason, promise, preventDefault: () => {
                        } });
                      });
                      process._hypha_rejection_handler_set = true;
                    }
                    if (connection) {
                      this.add_service({
                        id: "built-in",
                        type: "built-in",
                        name: `Built-in services for ${this._local_workspace}/${this._client_id}`,
                        config: {
                          require_context: true,
                          visibility: "public",
                          api_version: API_VERSION
                        },
                        ping: this._ping.bind(this),
                        get_service: this.get_local_service.bind(this),
                        message_cache: {
                          create: this._create_message.bind(this),
                          append: this._append_message.bind(this),
                          set: this._set_message.bind(this),
                          process: this._process_message.bind(this),
                          remove: this._remove_message.bind(this)
                        }
                      });
                      this.on("method", this._handle_method.bind(this));
                      this.on("error", console.error);
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(connection.emit_message && connection.on_message);
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                        connection.manager_id !== void 0,
                        "Connection must have manager_id"
                      );
                      this._emit_message = connection.emit_message.bind(connection);
                      connection.on_message(this._on_message.bind(this));
                      this._connection = connection;
                      const onConnected = async (connectionInfo) => {
                        if (!this._silent && this._connection.manager_id) {
                          console.debug("Connection established, reporting services...");
                          try {
                            const manager = await this._get_manager_with_retry();
                            const services = Object.values(this._services);
                            const servicesCount = services.length;
                            let registeredCount = 0;
                            const failedServices = [];
                            const serviceRegistrationTimeout = this._method_timeout || 3e4;
                            for (let service of services) {
                              try {
                                const serviceInfo = this._extract_service_info(service);
                                await withTimeout2(
                                  manager.registerService(serviceInfo),
                                  serviceRegistrationTimeout,
                                  `Timeout registering service ${service.id || "unknown"}`
                                );
                                registeredCount++;
                                console.debug(
                                  `Successfully registered service: ${service.id || "unknown"}`
                                );
                              } catch (serviceError) {
                                failedServices.push(service.id || "unknown");
                                if (serviceError.message && serviceError.message.includes("TimeoutError")) {
                                  console.error(
                                    `Timeout registering service ${service.id || "unknown"}`
                                  );
                                } else {
                                  console.error(
                                    `Failed to register service ${service.id || "unknown"}: ${serviceError}`
                                  );
                                }
                              }
                            }
                            if (registeredCount === servicesCount) {
                              console.info(
                                `Successfully registered all ${registeredCount} services with the server`
                              );
                            } else {
                              console.warn(
                                `Only registered ${registeredCount} out of ${servicesCount} services with the server. Failed services: ${failedServices.join(", ")}`
                              );
                            }
                            this._fire("services_registered", {
                              total: servicesCount,
                              registered: registeredCount,
                              failed: failedServices
                            });
                            try {
                              if (manager.subscribe && typeof manager.subscribe === "function") {
                                console.debug("Subscribing to client_disconnected events");
                                const handleClientDisconnected = async (event2) => {
                                  const clientId = event2.data?.id || event2.client;
                                  const workspace3 = event2.data?.workspace;
                                  if (clientId && workspace3) {
                                    const fullClientId = `${workspace3}/${clientId}`;
                                    console.debug(
                                      `Client ${fullClientId} disconnected, cleaning up sessions`
                                    );
                                    await this._handleClientDisconnected(fullClientId);
                                  } else if (clientId) {
                                    console.debug(
                                      `Client ${clientId} disconnected, cleaning up sessions`
                                    );
                                    await this._handleClientDisconnected(clientId);
                                  }
                                };
                                this._clientDisconnectedSubscription = await withTimeout2(
                                  manager.subscribe(["client_disconnected"]),
                                  serviceRegistrationTimeout,
                                  "Timeout subscribing to client_disconnected events"
                                );
                                this.on("client_disconnected", handleClientDisconnected);
                                console.debug(
                                  "Successfully subscribed to client_disconnected events"
                                );
                              } else {
                                console.debug(
                                  "Manager does not support subscribe method, skipping client_disconnected handling"
                                );
                                this._clientDisconnectedSubscription = null;
                              }
                            } catch (subscribeError) {
                              console.warn(
                                `Failed to subscribe to client_disconnected events: ${subscribeError}`
                              );
                              this._clientDisconnectedSubscription = null;
                            }
                          } catch (managerError) {
                            console.error(
                              `Failed to get manager service for registering services: ${managerError}`
                            );
                            this._fire("services_registration_failed", {
                              error: managerError.toString(),
                              total_services: Object.keys(this._services).length
                            });
                          }
                        } else {
                        }
                        if (connectionInfo) {
                          if (connectionInfo.public_base_url) {
                            this._server_base_url = connectionInfo.public_base_url;
                          }
                          this._fire("connected", connectionInfo);
                        }
                      };
                      connection.on_connected(onConnected);
                      onConnected();
                    } else {
                      this._emit_message = function() {
                        console.log("No connection to emit message");
                      };
                    }
                  }
                  register_codec(config2) {
                    if (!config2["name"] || !config2["encoder"] && !config2["decoder"]) {
                      throw new Error(
                        "Invalid codec format, please make sure you provide a name, type, encoder and decoder."
                      );
                    } else {
                      if (config2.type) {
                        for (let k of Object.keys(this._codecs)) {
                          if (this._codecs[k].type === config2.type || k === config2.name) {
                            delete this._codecs[k];
                            console.warn("Remove duplicated codec: " + k);
                          }
                        }
                      }
                      this._codecs[config2["name"]] = config2;
                    }
                  }
                  async _ping(msg, context2) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(msg == "ping");
                    return "pong";
                  }
                  async ping(client_id2, timeout) {
                    let method = this._generate_remote_method({
                      _rserver: this._server_base_url,
                      _rtarget: client_id2,
                      _rmethod: "services.built-in.ping",
                      _rpromise: true,
                      _rdoc: "Ping a remote client"
                    });
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(await method("ping", timeout) == "pong");
                  }
                  _create_message(key, heartbeat, overwrite, context2) {
                    if (heartbeat) {
                      if (!this._object_store[key]) {
                        throw new Error(`session does not exist anymore: ${key}`);
                      }
                      this._object_store[key]["timer"].reset();
                    }
                    if (!this._object_store["message_cache"]) {
                      this._object_store["message_cache"] = {};
                    }
                    if (!overwrite && this._object_store["message_cache"][key]) {
                      throw new Error(
                        `Message with the same key (${key}) already exists in the cache store, please use overwrite=true or remove it first.`
                      );
                    }
                    this._object_store["message_cache"][key] = [];
                  }
                  _append_message(key, data, heartbeat, context2) {
                    if (heartbeat) {
                      if (!this._object_store[key]) {
                        throw new Error(`session does not exist anymore: ${key}`);
                      }
                      this._object_store[key]["timer"].reset();
                    }
                    const cache2 = this._object_store["message_cache"];
                    if (!cache2[key]) {
                      throw new Error(`Message with key ${key} does not exists.`);
                    }
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(data instanceof ArrayBufferView);
                    cache2[key].push(data);
                  }
                  _set_message(key, index, data, heartbeat, context2) {
                    if (heartbeat) {
                      if (!this._object_store[key]) {
                        throw new Error(`session does not exist anymore: ${key}`);
                      }
                      this._object_store[key]["timer"].reset();
                    }
                    const cache2 = this._object_store["message_cache"];
                    if (!cache2[key]) {
                      throw new Error(`Message with key ${key} does not exists.`);
                    }
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(data instanceof ArrayBufferView);
                    cache2[key][index] = data;
                  }
                  _remove_message(key, context2) {
                    const cache2 = this._object_store["message_cache"];
                    if (!cache2[key]) {
                      throw new Error(`Message with key ${key} does not exists.`);
                    }
                    delete cache2[key];
                  }
                  _process_message(key, heartbeat, context2) {
                    if (heartbeat) {
                      if (!this._object_store[key]) {
                        throw new Error(`session does not exist anymore: ${key}`);
                      }
                      this._object_store[key]["timer"].reset();
                    }
                    const cache2 = this._object_store["message_cache"];
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(!!context2, "Context is required");
                    if (!cache2[key]) {
                      throw new Error(`Message with key ${key} does not exists.`);
                    }
                    cache2[key] = concatArrayBuffers(cache2[key]);
                    let unpacker = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_2__.decodeMulti)(cache2[key]);
                    const { done, value } = unpacker.next();
                    const main = value;
                    Object.assign(main, {
                      from: context2.from,
                      to: context2.to,
                      ws: context2.ws,
                      user: context2.user
                    });
                    main["ctx"] = JSON.parse(JSON.stringify(main));
                    Object.assign(main["ctx"], this.default_context);
                    if (!done) {
                      let extra = unpacker.next();
                      Object.assign(main, extra.value);
                    }
                    this._fire(main["type"], main);
                    delete cache2[key];
                  }
                  _on_message(message) {
                    if (typeof message === "string") {
                      const main = JSON.parse(message);
                      main["ctx"] = Object.assign({}, main, this.default_context);
                      this._fire(main["type"], main);
                    } else if (message instanceof ArrayBuffer || ArrayBuffer.isView(message)) {
                      let unpacker = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_2__.decodeMulti)(message);
                      const { done, value } = unpacker.next();
                      const main = value;
                      main["ctx"] = Object.assign({}, main, this.default_context);
                      if (!done) {
                        let extra = unpacker.next();
                        Object.assign(main, extra.value);
                      }
                      this._fire(main["type"], main);
                    } else if (typeof message === "object") {
                      message["ctx"] = Object.assign({}, message, this.default_context);
                      this._fire(message["type"], message);
                    } else {
                      throw new Error("Invalid message format");
                    }
                  }
                  reset() {
                    this._event_handlers = {};
                    this._services = {};
                  }
                  close() {
                    this._cleanupOnDisconnect();
                    for (const session_id in this._object_store) {
                      if (this._object_store.hasOwnProperty(session_id)) {
                        const session = this._object_store[session_id];
                        if (session && session.heartbeat_task) {
                          clearInterval(session.heartbeat_task);
                        }
                        if (session && session.timer) {
                          session.timer.clear();
                        }
                      }
                    }
                    if (this._clientDisconnectedSubscription) {
                      this.off("client_disconnected");
                      this._clientDisconnectedSubscription = null;
                    }
                    try {
                      for (const task of this._background_tasks) {
                        if (task && typeof task.cancel === "function") {
                          try {
                            task.cancel();
                          } catch (e) {
                            console.debug(`Error canceling background task: ${e}`);
                          }
                        }
                      }
                      this._background_tasks.clear();
                    } catch (e) {
                      console.debug(`Error cleaning up background tasks: ${e}`);
                    }
                    try {
                      this._connection = null;
                      this._emit_message = function() {
                        console.debug("RPC connection closed, ignoring message");
                        return Promise.reject(new Error("Connection is closed"));
                      };
                    } catch (e) {
                      console.debug(`Error during connection cleanup: ${e}`);
                    }
                    this._fire("disconnected");
                  }
                  async _handleClientDisconnected(clientId) {
                    try {
                      console.debug(`Handling disconnection for client: ${clientId}`);
                      const sessionsCleaned = this._cleanupSessionsForClient(clientId);
                      if (sessionsCleaned > 0) {
                        console.debug(
                          `Cleaned up ${sessionsCleaned} sessions for disconnected client: ${clientId}`
                        );
                      }
                      this._fire("remote_client_disconnected", {
                        client_id: clientId,
                        sessions_cleaned: sessionsCleaned
                      });
                    } catch (e) {
                      console.error(
                        `Error handling client disconnection for ${clientId}: ${e}`
                      );
                    }
                  }
                  _removeFromTargetIdIndex(sessionId) {
                    const topKey = sessionId.split(".")[0];
                    const session = this._object_store[topKey];
                    if (session && typeof session === "object") {
                      const targetId = session.target_id;
                      if (targetId && targetId in this._targetIdIndex) {
                        this._targetIdIndex[targetId].delete(topKey);
                        if (this._targetIdIndex[targetId].size === 0) {
                          delete this._targetIdIndex[targetId];
                        }
                      }
                    }
                  }
                  _cleanupSessionsForClient(clientId) {
                    let sessionsCleaned = 0;
                    const sessionKeys = this._targetIdIndex[clientId];
                    if (!sessionKeys) return 0;
                    for (const sessionKey of sessionKeys) {
                      const session = this._object_store[sessionKey];
                      if (!session || typeof session !== "object") {
                        continue;
                      }
                      if (session.target_id !== clientId) {
                        continue;
                      }
                      if (session.reject && typeof session.reject === "function") {
                        console.debug(`Rejecting session ${sessionKey}`);
                        try {
                          session.reject(new Error(`Client disconnected: ${clientId}`));
                        } catch (e) {
                          console.warn(`Error rejecting session ${sessionKey}: ${e}`);
                        }
                      }
                      if (session.resolve && typeof session.resolve === "function") {
                        console.debug(`Resolving session ${sessionKey} with error`);
                        try {
                          session.resolve(new Error(`Client disconnected: ${clientId}`));
                        } catch (e) {
                          console.warn(`Error resolving session ${sessionKey}: ${e}`);
                        }
                      }
                      if (session.timer && typeof session.timer.clear === "function") {
                        try {
                          session.timer.clear();
                        } catch (e) {
                          console.warn(`Error clearing timer for ${sessionKey}: ${e}`);
                        }
                      }
                      if (session.heartbeat_task) {
                        try {
                          clearInterval(session.heartbeat_task);
                        } catch (e) {
                          console.warn(`Error clearing heartbeat for ${sessionKey}: ${e}`);
                        }
                      }
                      delete this._object_store[sessionKey];
                      sessionsCleaned++;
                      console.debug(`Cleaned up session: ${sessionKey}`);
                    }
                    delete this._targetIdIndex[clientId];
                    return sessionsCleaned;
                  }
                  _cleanupOnDisconnect() {
                    try {
                      console.debug("Cleaning up all sessions due to local RPC disconnection");
                      const keysToDelete = [];
                      for (const key of Object.keys(this._object_store)) {
                        if (key === "services") {
                          continue;
                        }
                        const value = this._object_store[key];
                        if (typeof value === "object" && value !== null) {
                          if (value.reject && typeof value.reject === "function") {
                            try {
                              value.reject(new Error("RPC connection closed"));
                            } catch (e) {
                              console.debug(`Error rejecting promise during cleanup: ${e}`);
                            }
                          }
                          if (value.heartbeat_task) {
                            clearInterval(value.heartbeat_task);
                          }
                          if (value.timer && typeof value.timer.clear === "function") {
                            try {
                              value.timer.clear();
                            } catch (e) {
                              console.debug(`Error clearing timer: ${e}`);
                            }
                          }
                        }
                        keysToDelete.push(key);
                      }
                      for (const key of keysToDelete) {
                        delete this._object_store[key];
                      }
                      this._targetIdIndex = {};
                    } catch (e) {
                      console.error(`Error during cleanup on disconnect: ${e}`);
                    }
                  }
                  async disconnect() {
                    const connection = this._connection;
                    this.close();
                    if (connection) {
                      try {
                        await connection.disconnect();
                      } catch (e) {
                        console.debug(`Error disconnecting underlying connection: ${e}`);
                      }
                    }
                  }
                  async _get_manager_with_retry(maxRetries = 20) {
                    const baseDelay = 500;
                    const maxDelay = 1e4;
                    let lastError = null;
                    for (let attempt = 0; attempt < maxRetries; attempt++) {
                      try {
                        const svc = await this.get_remote_service(
                          `*/${this._connection.manager_id}:default`,
                          { timeout: 20, case_conversion: "camel" }
                        );
                        return svc;
                      } catch (e) {
                        lastError = e;
                        console.warn(
                          `Failed to get manager service (attempt ${attempt + 1}/${maxRetries}): ${e.message}`
                        );
                        if (attempt < maxRetries - 1) {
                          const delay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
                          await new Promise((resolve2) => setTimeout(resolve2, delay));
                        }
                      }
                    }
                    throw lastError;
                  }
                  async get_manager_service(config2) {
                    config2 = config2 || {};
                    const maxRetries = 20;
                    for (let attempt = 0; attempt < maxRetries; attempt++) {
                      const retryDelay = Math.min(500 * Math.pow(2, attempt), 1e4);
                      if (!this._connection.manager_id) {
                        if (attempt < maxRetries - 1) {
                          console.warn(
                            `Manager ID not set, retrying in ${retryDelay}ms (attempt ${attempt + 1}/${maxRetries})`
                          );
                          await new Promise((resolve2) => setTimeout(resolve2, retryDelay));
                          continue;
                        } else {
                          throw new Error("Manager ID not set after maximum retries");
                        }
                      }
                      try {
                        const svc = await this.get_remote_service(
                          `*/${this._connection.manager_id}:default`,
                          config2
                        );
                        return svc;
                      } catch (e) {
                        if (attempt < maxRetries - 1) {
                          console.warn(
                            `Failed to get manager service, retrying in ${retryDelay}ms: ${e.message}`
                          );
                          await new Promise((resolve2) => setTimeout(resolve2, retryDelay));
                        } else {
                          throw e;
                        }
                      }
                    }
                  }
                  get_all_local_services() {
                    return this._services;
                  }
                  get_local_service(service_id, context2) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(service_id);
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(context2, "Context is required");
                    const [ws, client_id2] = context2["to"].split("/");
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                      client_id2 === this._client_id,
                      "Services can only be accessed locally"
                    );
                    const service = this._services[service_id];
                    if (!service) {
                      throw new Error("Service not found: " + service_id);
                    }
                    if (service.config.visibility == "public" || service.config.visibility == "unlisted") {
                      return service;
                    }
                    if (context2["ws"] === ws) {
                      return service;
                    }
                    const authorized_workspaces = service.config.authorized_workspaces;
                    if (authorized_workspaces && authorized_workspaces.includes(context2["ws"])) {
                      return service;
                    }
                    throw new Error(
                      `Permission denied for getting protected service: ${service_id}, workspace mismatch: ${ws} != ${context2["ws"]}`
                    );
                  }
                  async get_remote_service(service_uri, config2) {
                    let { timeout, case_conversion, kwargs_expansion } = config2 || {};
                    timeout = timeout === void 0 ? this._method_timeout : timeout;
                    if (!service_uri && this._connection.manager_id) {
                      service_uri = "*/" + this._connection.manager_id;
                    } else if (!service_uri.includes(":")) {
                      service_uri = this._client_id + ":" + service_uri;
                    }
                    const provider = service_uri.split(":")[0];
                    let service_id = service_uri.split(":")[1];
                    if (service_id.includes("@")) {
                      service_id = service_id.split("@")[0];
                      const app_id = service_uri.split("@")[1];
                      if (this._app_id && this._app_id !== "*")
                        (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                          app_id === this._app_id,
                          `Invalid app id: ${app_id} != ${this._app_id}`
                        );
                    }
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(provider, `Invalid service uri: ${service_uri}`);
                    try {
                      const method = this._generate_remote_method({
                        _rserver: this._server_base_url,
                        _rtarget: provider,
                        _rmethod: "services.built-in.get_service",
                        _rpromise: true,
                        _rdoc: "Get a remote service"
                      });
                      let svc = await (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.waitFor)(
                        method(service_id),
                        timeout,
                        "Timeout Error: Failed to get remote service: " + service_uri
                      );
                      svc.id = `${provider}:${service_id}`;
                      if (kwargs_expansion) {
                        svc = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.expandKwargs)(svc);
                      }
                      if (case_conversion)
                        return Object.assign(
                          new RemoteService(),
                          (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.convertCase)(svc, case_conversion)
                        );
                      else return Object.assign(new RemoteService(), svc);
                    } catch (e) {
                      console.warn("Failed to get remote service: " + service_uri, e);
                      throw e;
                    }
                  }
                  _annotate_service_methods(aObject, object_id, require_context, run_in_executor, visibility, authorized_workspaces) {
                    if (typeof aObject === "function") {
                      let method_name = object_id.split(".")[1];
                      this._method_annotations.set(aObject, {
                        require_context: Array.isArray(require_context) ? require_context.includes(method_name) : !!require_context,
                        run_in_executor,
                        method_id: "services." + object_id,
                        visibility,
                        authorized_workspaces
                      });
                    } else if (aObject instanceof Array || aObject instanceof Object) {
                      for (let key of Object.keys(aObject)) {
                        let val = aObject[key];
                        if (typeof val === "function" && val.__rpc_object__) {
                          let client_id2 = val.__rpc_object__._rtarget;
                          if (client_id2.includes("/")) {
                            client_id2 = client_id2.split("/")[1];
                          }
                          if (this._client_id === client_id2) {
                            if (aObject instanceof Array) {
                              aObject = aObject.slice();
                            }
                            aObject[key] = indexObject(
                              this._object_store,
                              val.__rpc_object__._rmethod
                            );
                            val = aObject[key];
                          } else {
                            throw new Error(
                              `Local method not found: ${val.__rpc_object__._rmethod}, client id mismatch ${this._client_id} != ${client_id2}`
                            );
                          }
                        }
                        this._annotate_service_methods(
                          val,
                          object_id + "." + key,
                          require_context,
                          run_in_executor,
                          visibility,
                          authorized_workspaces
                        );
                      }
                    }
                  }
                  add_service(api, overwrite) {
                    if (!api || Array.isArray(api)) throw new Error("Invalid service object");
                    if (api.constructor === Object) {
                      api = Object.assign({}, api);
                    } else {
                      const normApi = {};
                      const props = Object.getOwnPropertyNames(api).concat(
                        Object.getOwnPropertyNames(Object.getPrototypeOf(api))
                      );
                      for (let k of props) {
                        if (k !== "constructor") {
                          if (typeof api[k] === "function") normApi[k] = api[k].bind(api);
                          else normApi[k] = api[k];
                        }
                      }
                      api.id = api.id || "default";
                      api = normApi;
                    }
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                      api.id && typeof api.id === "string",
                      `Service id not found: ${api}`
                    );
                    if (!api.name) {
                      api.name = api.id;
                    }
                    if (!api.config) {
                      api.config = {};
                    }
                    if (!api.type) {
                      api.type = "generic";
                    }
                    let require_context = false, run_in_executor = false;
                    if (api.config.require_context)
                      require_context = api.config.require_context;
                    if (api.config.run_in_executor) run_in_executor = true;
                    const visibility = api.config.visibility || "protected";
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(["protected", "public", "unlisted"].includes(visibility));
                    const authorized_workspaces = api.config.authorized_workspaces;
                    if (authorized_workspaces !== void 0) {
                      if (visibility !== "protected") {
                        throw new Error(
                          `authorized_workspaces can only be set when visibility is 'protected', got visibility='${visibility}'`
                        );
                      }
                      if (!Array.isArray(authorized_workspaces)) {
                        throw new Error(
                          "authorized_workspaces must be an array of workspace ids"
                        );
                      }
                      for (const ws_id of authorized_workspaces) {
                        if (typeof ws_id !== "string") {
                          throw new Error(
                            `Each workspace id in authorized_workspaces must be a string, got ${typeof ws_id}`
                          );
                        }
                      }
                    }
                    this._annotate_service_methods(
                      api,
                      api["id"],
                      require_context,
                      run_in_executor,
                      visibility,
                      authorized_workspaces
                    );
                    if (this._services[api.id]) {
                      if (overwrite) {
                        delete this._services[api.id];
                      } else {
                        throw new Error(
                          `Service already exists: ${api.id}, please specify a different id (not ${api.id}) or overwrite=true`
                        );
                      }
                    }
                    this._services[api.id] = api;
                    return api;
                  }
                  _extract_service_info(service) {
                    const config2 = service.config || {};
                    config2.workspace = config2.workspace || this._local_workspace || this._connection.workspace;
                    if (!config2.workspace) {
                      throw new Error(
                        "Workspace is not set. Please ensure the connection has a workspace or set local_workspace."
                      );
                    }
                    const skipContext = config2.require_context;
                    const excludeKeys = [
                      "id",
                      "config",
                      "name",
                      "description",
                      "type",
                      "docs",
                      "app_id",
                      "service_schema"
                    ];
                    const filteredService = {};
                    for (const key of Object.keys(service)) {
                      if (!excludeKeys.includes(key)) {
                        filteredService[key] = service[key];
                      }
                    }
                    const serviceSchema = _get_schema(filteredService, null, skipContext);
                    const serviceInfo = {
                      config: config2,
                      id: `${config2.workspace}/${this._client_id}:${service["id"]}`,
                      name: service.name || service["id"],
                      description: service.description || "",
                      type: service.type || "generic",
                      docs: service.docs || null,
                      app_id: this._app_id,
                      service_schema: serviceSchema
                    };
                    return serviceInfo;
                  }
                  async get_service_schema(service) {
                    const skipContext = service.config.require_context;
                    return _get_schema(service, null, skipContext);
                  }
                  async register_service(api, config2) {
                    let { check_type, notify, overwrite } = config2 || {};
                    notify = notify === void 0 ? true : notify;
                    let manager;
                    if (check_type && api.type) {
                      try {
                        manager = await this.get_manager_service({
                          timeout: 10,
                          case_conversion: "camel"
                        });
                        const type_info = await manager.get_service_type(api.type);
                        api = _annotate_service(api, type_info);
                      } catch (e) {
                        throw new Error(`Failed to get service type ${api.type}, error: ${e}`);
                      }
                    }
                    const service = this.add_service(api, overwrite);
                    const serviceInfo = this._extract_service_info(service);
                    if (notify) {
                      try {
                        manager = manager || await this.get_manager_service({
                          timeout: 10,
                          case_conversion: "camel"
                        });
                        await manager.registerService(serviceInfo);
                      } catch (e) {
                        throw new Error(`Failed to notify workspace manager: ${e}`);
                      }
                    }
                    return serviceInfo;
                  }
                  async unregister_service(service, notify) {
                    notify = notify === void 0 ? true : notify;
                    let service_id;
                    if (typeof service === "string") {
                      service_id = service;
                    } else {
                      service_id = service.id;
                    }
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                      service_id && typeof service_id === "string",
                      `Invalid service id: ${service_id}`
                    );
                    if (service_id.includes(":")) {
                      service_id = service_id.split(":")[1];
                    }
                    if (service_id.includes("@")) {
                      service_id = service_id.split("@")[0];
                    }
                    if (!this._services[service_id]) {
                      throw new Error(`Service not found: ${service_id}`);
                    }
                    if (notify) {
                      const manager = await this.get_manager_service({
                        timeout: 10,
                        case_conversion: "camel"
                      });
                      await manager.unregisterService(service_id);
                    }
                    delete this._services[service_id];
                  }
                  _ndarray(typedArray, shape, dtype) {
                    const _dtype = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.typedArrayToDtype)(typedArray);
                    if (dtype && dtype !== _dtype) {
                      throw "dtype doesn't match the type of the array: " + _dtype + " != " + dtype;
                    }
                    shape = shape || [typedArray.length];
                    return {
                      _rtype: "ndarray",
                      _rvalue: typedArray.buffer,
                      _rshape: shape,
                      _rdtype: _dtype
                    };
                  }
                  _encode_callback(name2, callback, session_id, clear_after_called, timer, local_workspace, description) {
                    let method_id = `${session_id}.${name2}`;
                    let encoded = {
                      _rtype: "method",
                      _rtarget: local_workspace ? `${local_workspace}/${this._client_id}` : this._client_id,
                      _rmethod: method_id,
                      _rpromise: false
                    };
                    const self2 = this;
                    let wrapped_callback = function() {
                      try {
                        callback.apply(null, Array.prototype.slice.call(arguments));
                      } catch (error) {
                        console.error(
                          `Error in callback(${method_id}, ${description}): ${error}`
                        );
                      } finally {
                        if (timer && timer.started) {
                          timer.clear();
                        }
                        if (clear_after_called && self2._object_store[session_id]) {
                          if (name2 === "resolve" || name2 === "reject") {
                            self2._removeFromTargetIdIndex(session_id);
                            delete self2._object_store[session_id];
                          } else {
                            self2._cleanup_session_if_needed(session_id, name2);
                          }
                        }
                      }
                    };
                    wrapped_callback.__name__ = `callback(${method_id})`;
                    return [encoded, wrapped_callback];
                  }
                  _cleanup_session_if_needed(session_id, callback_name) {
                    if (!session_id) {
                      console.debug("Cannot cleanup session: session_id is empty");
                      return;
                    }
                    try {
                      const store = this._get_session_store(session_id, false);
                      if (!store) {
                        console.debug(`Session ${session_id} not found for cleanup`);
                        return;
                      }
                      let should_cleanup = false;
                      if (store._promise_manager) {
                        try {
                          const promise_manager = store._promise_manager;
                          if (promise_manager.should_cleanup_on_callback && promise_manager.should_cleanup_on_callback(callback_name)) {
                            if (promise_manager.settle) {
                              promise_manager.settle();
                            }
                            should_cleanup = true;
                            console.debug(
                              `Promise session ${session_id} settled and marked for cleanup`
                            );
                          }
                        } catch (e) {
                          console.warn(
                            `Error in promise manager cleanup for session ${session_id}:`,
                            e
                          );
                        }
                      } else {
                        if ((callback_name === "resolve" || callback_name === "reject") && store._callbacks && Object.keys(store._callbacks).includes(callback_name)) {
                          should_cleanup = true;
                          console.debug(
                            `Regular session ${session_id} marked for cleanup after ${callback_name}`
                          );
                        }
                      }
                      if (should_cleanup) {
                        this._cleanup_session_completely(session_id);
                      }
                    } catch (error) {
                      console.warn(`Error during session cleanup for ${session_id}:`, error);
                    }
                  }
                  _cleanup_session_completely(session_id) {
                    try {
                      this._removeFromTargetIdIndex(session_id);
                      const store = this._get_session_store(session_id, false);
                      if (!store) {
                        console.debug(`Session ${session_id} already cleaned up`);
                        return;
                      }
                      if (store.timer && typeof store.timer.clear === "function") {
                        try {
                          store.timer.clear();
                        } catch (error) {
                          console.warn(
                            `Error clearing timer for session ${session_id}:`,
                            error
                          );
                        }
                      }
                      if (store.heartbeat_task && typeof store.heartbeat_task.cancel === "function") {
                        try {
                          store.heartbeat_task.cancel();
                        } catch (error) {
                          console.warn(
                            `Error canceling heartbeat for session ${session_id}:`,
                            error
                          );
                        }
                      }
                      const levels = session_id.split(".");
                      let current_store = this._object_store;
                      for (let i = 0; i < levels.length - 1; i++) {
                        const level = levels[i];
                        if (!current_store[level]) {
                          console.debug(
                            `Session path ${session_id} not found at level ${level}`
                          );
                          return;
                        }
                        current_store = current_store[level];
                      }
                      const final_key = levels[levels.length - 1];
                      if (current_store[final_key]) {
                        delete current_store[final_key];
                        console.debug(`Cleaned up session ${session_id}`);
                        this._cleanup_empty_containers(levels.slice(0, -1));
                      }
                    } catch (error) {
                      console.warn(
                        `Error in complete session cleanup for ${session_id}:`,
                        error
                      );
                    }
                  }
                  _cleanup_empty_containers(path_levels) {
                    try {
                      for (let depth = path_levels.length - 1; depth >= 0; depth--) {
                        let current_store = this._object_store;
                        for (let i = 0; i < depth; i++) {
                          current_store = current_store[path_levels[i]];
                          if (!current_store) return;
                        }
                        const container_key = path_levels[depth];
                        const container = current_store[container_key];
                        if (container && typeof container === "object" && Object.keys(container).length === 0) {
                          delete current_store[container_key];
                          console.debug(
                            `Cleaned up empty container at depth ${depth}: ${path_levels.slice(0, depth + 1).join(".")}`
                          );
                        } else {
                          break;
                        }
                      }
                    } catch (error) {
                      console.warn("Error cleaning up empty containers:", error);
                    }
                  }
                  get_session_stats() {
                    const stats = {
                      total_sessions: 0,
                      promise_sessions: 0,
                      regular_sessions: 0,
                      sessions_with_timers: 0,
                      sessions_with_heartbeat: 0,
                      system_stores: {},
                      session_ids: [],
                      memory_usage: 0
                    };
                    if (!this._object_store) {
                      return stats;
                    }
                    for (const key in this._object_store) {
                      const value = this._object_store[key];
                      if (["services", "message_cache"].includes(key)) {
                        stats.system_stores[key] = {
                          size: typeof value === "object" && value ? Object.keys(value).length : 0
                        };
                        continue;
                      }
                      if (value && typeof value === "object") {
                        const sessionKeys = Object.keys(value);
                        if (sessionKeys.length > 0) {
                          stats.total_sessions++;
                          stats.session_ids.push(key);
                          if (value._promise_manager) {
                            stats.promise_sessions++;
                          } else {
                            stats.regular_sessions++;
                          }
                          if (value._timer || value.timer) stats.sessions_with_timers++;
                          if (value._heartbeat || value.heartbeat)
                            stats.sessions_with_heartbeat++;
                          stats.memory_usage += JSON.stringify(value).length;
                        }
                      }
                    }
                    return stats;
                  }
                  _force_cleanup_all_sessions() {
                    if (!this._object_store) {
                      console.debug("Force cleaning up 0 sessions");
                      return;
                    }
                    let cleaned_count = 0;
                    const keys_to_delete = [];
                    for (const key in this._object_store) {
                      if (!["services", "message_cache"].includes(key)) {
                        const value = this._object_store[key];
                        if (value && typeof value === "object" && Object.keys(value).length > 0) {
                          keys_to_delete.push(key);
                          cleaned_count++;
                        }
                      }
                    }
                    for (const key of keys_to_delete) {
                      delete this._object_store[key];
                    }
                    this._targetIdIndex = {};
                    console.debug(`Force cleaning up ${cleaned_count} sessions`);
                  }
                  // Clean helper to identify promise method calls by session type
                  _is_promise_method_call(method_path) {
                    const session_id = method_path.split(".")[0];
                    const session = this._get_session_store(session_id, false);
                    return session && session._promise_manager;
                  }
                  // Simplified Promise Manager - enhanced version
                  _create_promise_manager() {
                    return {
                      should_cleanup_on_callback: (callback_name) => {
                        return ["resolve", "reject"].includes(callback_name);
                      },
                      settle: () => {
                        console.debug("Promise settled");
                      }
                    };
                  }
                  async _encode_promise(resolve2, reject2, session_id, clear_after_called, timer, local_workspace, description) {
                    let store = this._get_session_store(session_id, true);
                    if (!store) {
                      console.warn(
                        `Failed to create session store ${session_id}, session management may be impaired`
                      );
                      store = {};
                    }
                    store._promise_manager = this._create_promise_manager();
                    let encoded = {};
                    if (timer && reject2 && this._method_timeout) {
                      [encoded.heartbeat, store.heartbeat] = this._encode_callback(
                        "heartbeat",
                        timer.reset.bind(timer),
                        session_id,
                        false,
                        null,
                        local_workspace
                      );
                      store.timer = timer;
                      encoded.interval = this._method_timeout / 2;
                    } else {
                      timer = null;
                    }
                    [encoded.resolve, store.resolve] = this._encode_callback(
                      "resolve",
                      resolve2,
                      session_id,
                      clear_after_called,
                      timer,
                      local_workspace,
                      `resolve (${description})`
                    );
                    [encoded.reject, store.reject] = this._encode_callback(
                      "reject",
                      reject2,
                      session_id,
                      clear_after_called,
                      timer,
                      local_workspace,
                      `reject (${description})`
                    );
                    return encoded;
                  }
                  async _send_chunks(data, target_id, session_id) {
                    const remote_services = await this.get_remote_service(
                      `${target_id}:built-in`
                    );
                    if (!remote_services.message_cache) {
                      throw new Error(
                        "Remote client does not support message caching for large messages."
                      );
                    }
                    const message_cache = remote_services.message_cache;
                    const message_id = session_id || (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.randId)();
                    const total_size = data.length;
                    const start_time = Date.now();
                    const chunk_num = Math.ceil(total_size / this._long_message_chunk_size);
                    if (remote_services.config.api_version >= 3) {
                      await message_cache.create(message_id, !!session_id);
                      const semaphore = new _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.Semaphore(CONCURRENCY_LIMIT);
                      const tasks = [];
                      for (let idx = 0; idx < chunk_num; idx++) {
                        const startByte = idx * this._long_message_chunk_size;
                        const chunk = data.slice(
                          startByte,
                          startByte + this._long_message_chunk_size
                        );
                        const taskFn = async () => {
                          await message_cache.set(message_id, idx, chunk, !!session_id);
                        };
                        tasks.push(semaphore.run(taskFn));
                      }
                      try {
                        await Promise.all(tasks);
                      } catch (error) {
                        try {
                          await message_cache.remove(message_id);
                        } catch (cleanupError) {
                          console.error(
                            `Failed to clean up message cache after error: ${cleanupError}`
                          );
                        }
                        throw error;
                      }
                    } else {
                      await message_cache.create(message_id, !!session_id);
                      for (let idx = 0; idx < chunk_num; idx++) {
                        const startByte = idx * this._long_message_chunk_size;
                        const chunk = data.slice(
                          startByte,
                          startByte + this._long_message_chunk_size
                        );
                        await message_cache.append(message_id, chunk, !!session_id);
                      }
                    }
                    await message_cache.process(message_id, !!session_id);
                    const durationSec = ((Date.now() - start_time) / 1e3).toFixed(2);
                  }
                  emit(main_message, extra_data) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                      typeof main_message === "object" && main_message.type,
                      "Invalid message, must be an object with a `type` fields."
                    );
                    if (!main_message.to) {
                      this._fire(main_message.type, main_message);
                      return;
                    }
                    let message_package = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__.encode)(main_message);
                    if (extra_data) {
                      const extra = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__.encode)(extra_data);
                      const combined = new Uint8Array(message_package.length + extra.length);
                      combined.set(message_package);
                      combined.set(extra, message_package.length);
                      message_package = combined;
                    }
                    const total_size = message_package.length;
                    if (total_size > this._long_message_chunk_size + 1024) {
                      console.warn(`Sending large message (size=${total_size})`);
                    }
                    return this._emit_message(message_package);
                  }
                  _generate_remote_method(encoded_method, remote_parent, local_parent, remote_workspace, local_workspace) {
                    let target_id = encoded_method._rtarget;
                    if (remote_workspace && !target_id.includes("/")) {
                      if (!target_id.startsWith("*/")) {
                        if (remote_workspace !== target_id) {
                          target_id = remote_workspace + "/" + target_id;
                        }
                        encoded_method._rtarget = target_id;
                      }
                    }
                    let method_id = encoded_method._rmethod;
                    let with_promise = encoded_method._rpromise || false;
                    const description = `method: ${method_id}, docs: ${encoded_method._rdoc}`;
                    const self2 = this;
                    function remote_method() {
                      return new Promise(async (resolve2, reject2) => {
                        try {
                          let local_session_id = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.randId)();
                          if (local_parent) {
                            local_session_id = local_parent + "." + local_session_id;
                          }
                          let store = self2._get_session_store(local_session_id, true);
                          if (!store) {
                            reject2(
                              new Error(
                                `Runtime Error: Failed to get session store ${local_session_id} (context: ${description})`
                              )
                            );
                            return;
                          }
                          store["target_id"] = target_id;
                          const topKey = local_session_id.split(".")[0];
                          if (!(target_id in self2._targetIdIndex)) {
                            self2._targetIdIndex[target_id] = /* @__PURE__ */ new Set();
                          }
                          self2._targetIdIndex[target_id].add(topKey);
                          const args = await self2._encode(
                            Array.prototype.slice.call(arguments),
                            local_session_id,
                            local_workspace
                          );
                          const argLength = args.length;
                          const withKwargs = argLength > 0 && typeof args[argLength - 1] === "object" && args[argLength - 1] !== null && args[argLength - 1]._rkwargs;
                          if (withKwargs) delete args[argLength - 1]._rkwargs;
                          let from_client;
                          if (!self2._local_workspace) {
                            from_client = self2._client_id;
                          } else {
                            from_client = self2._local_workspace + "/" + self2._client_id;
                          }
                          let main_message = {
                            type: "method",
                            from: from_client,
                            to: target_id,
                            method: method_id
                          };
                          let extra_data = {};
                          if (args) {
                            extra_data["args"] = args;
                          }
                          if (withKwargs) {
                            extra_data["with_kwargs"] = withKwargs;
                          }
                          if (remote_parent) {
                            main_message["parent"] = remote_parent;
                          }
                          let timer = null;
                          if (with_promise) {
                            let hasInterfaceObject = function(obj) {
                              if (!obj || typeof obj !== "object") return false;
                              if (obj._rintf === true) return true;
                              if (Array.isArray(obj)) {
                                return obj.some((item) => hasInterfaceObject(item));
                              }
                              if (obj.constructor === Object) {
                                return Object.values(obj).some(
                                  (value) => hasInterfaceObject(value)
                                );
                              }
                              return false;
                            };
                            main_message["session"] = local_session_id;
                            let method_name = `${target_id}:${method_id}`;
                            const timeoutCallback = function(error_msg) {
                              reject2(error_msg);
                              if (self2._object_store[local_session_id]) {
                                self2._removeFromTargetIdIndex(local_session_id);
                                delete self2._object_store[local_session_id];
                                console.debug(
                                  `Cleaned up session ${local_session_id} after timeout`
                                );
                              }
                            };
                            timer = new Timer(
                              self2._method_timeout,
                              timeoutCallback,
                              [`Method call timed out: ${method_name}, context: ${description}`],
                              method_name
                            );
                            let clear_after_called = !hasInterfaceObject(args);
                            const promiseData = await self2._encode_promise(
                              resolve2,
                              reject2,
                              local_session_id,
                              clear_after_called,
                              timer,
                              local_workspace,
                              description
                            );
                            if (with_promise === true) {
                              extra_data["promise"] = promiseData;
                            } else if (with_promise === "*") {
                              extra_data["promise"] = "*";
                              extra_data["t"] = self2._method_timeout / 2;
                            } else {
                              throw new Error(`Unsupported promise type: ${with_promise}`);
                            }
                          }
                          let message_package = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__.encode)(main_message);
                          if (extra_data) {
                            const extra = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__.encode)(extra_data);
                            const combined = new Uint8Array(message_package.length + extra.length);
                            combined.set(message_package);
                            combined.set(extra, message_package.length);
                            message_package = combined;
                          }
                          const total_size = message_package.length;
                          if (total_size <= self2._long_message_chunk_size + 1024 || remote_method.__no_chunk__) {
                            self2._emit_message(message_package).then(function() {
                              if (timer) {
                                timer.start();
                              }
                            }).catch(function(err) {
                              const error_msg = `Failed to send the request when calling method (${target_id}:${method_id}), error: ${err}`;
                              if (reject2) {
                                reject2(new Error(error_msg));
                              } else {
                                console.warn("Unhandled RPC method call error:", error_msg);
                              }
                              if (timer) {
                                timer.clear();
                              }
                            });
                          } else {
                            self2._send_chunks(message_package, target_id, remote_parent).then(function() {
                              if (timer) {
                                timer.start();
                              }
                            }).catch(function(err) {
                              const error_msg = `Failed to send the request when calling method (${target_id}:${method_id}), error: ${err}`;
                              if (reject2) {
                                reject2(new Error(error_msg));
                              } else {
                                console.warn("Unhandled RPC method call error:", error_msg);
                              }
                              if (timer) {
                                timer.clear();
                              }
                            });
                          }
                        } catch (err) {
                          reject2(err);
                        }
                      });
                    }
                    remote_method.__rpc_object__ = encoded_method;
                    const parts = method_id.split(".");
                    remote_method.__name__ = encoded_method._rname || parts[parts.length - 1];
                    if (remote_method.__name__.includes("#")) {
                      remote_method.__name__ = remote_method.__name__.split("#")[1];
                    }
                    remote_method.__doc__ = encoded_method._rdoc || `Remote method: ${method_id}`;
                    remote_method.__schema__ = encoded_method._rschema;
                    remote_method.__no_chunk__ = encoded_method._rmethod === "services.built-in.message_cache.append";
                    return remote_method;
                  }
                  get_client_info() {
                    const services = [];
                    for (let service of Object.values(this._services)) {
                      services.push(this._extract_service_info(service));
                    }
                    return {
                      id: this._client_id,
                      services
                    };
                  }
                  async _handle_method(data) {
                    let resolve2 = null;
                    let reject2 = null;
                    let heartbeat_task = null;
                    try {
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(data.method && data.ctx && data.from);
                      const method_name = data.from + ":" + data.method;
                      const remote_workspace = data.from.split("/")[0];
                      const remote_client_id = data.from.split("/")[1];
                      data["to"] = data["to"].includes("/") ? data["to"] : remote_workspace + "/" + data["to"];
                      data["ctx"]["to"] = data["to"];
                      let local_workspace;
                      if (!this._local_workspace) {
                        local_workspace = data["to"].split("/")[0];
                      } else {
                        if (this._local_workspace && this._local_workspace !== "*") {
                          (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                            data["to"].split("/")[0] === this._local_workspace,
                            "Workspace mismatch: " + data["to"].split("/")[0] + " != " + this._local_workspace
                          );
                        }
                        local_workspace = this._local_workspace;
                      }
                      const local_parent = data.parent;
                      if (data.promise) {
                        const promise = await this._decode(
                          data.promise === "*" ? this._expand_promise(data) : data.promise,
                          data.session,
                          local_parent,
                          remote_workspace,
                          local_workspace
                        );
                        resolve2 = promise.resolve;
                        reject2 = promise.reject;
                        if (promise.heartbeat && promise.interval) {
                          async function heartbeat() {
                            try {
                              await promise.heartbeat();
                            } catch (err) {
                              console.error(err);
                            }
                          }
                          heartbeat_task = setInterval(heartbeat, promise.interval * 1e3);
                          if (data.session) {
                            const session_store = this._get_session_store(data.session, false);
                            if (session_store) {
                              session_store.heartbeat_task = heartbeat_task;
                            }
                          }
                        }
                      }
                      let method;
                      try {
                        method = indexObject(this._object_store, data["method"]);
                      } catch (e) {
                        if (this._is_promise_method_call(data["method"])) {
                          console.debug(
                            `Promise method ${data["method"]} not available (detected by session type), ignoring: ${method_name}`
                          );
                          return;
                        }
                        const method_parts = data["method"].split(".");
                        if (method_parts.length > 1) {
                          const session_id = method_parts[0];
                          if (session_id in this._object_store) {
                            console.debug(
                              `Session ${session_id} exists but method ${data["method"]} not found, likely expired callback: ${method_name}`
                            );
                            if (typeof reject2 === "function") {
                              reject2(new Error(`Method expired or not found: ${method_name}`));
                            }
                            return;
                          } else {
                            console.debug(
                              `Session ${session_id} not found for method ${data["method"]}, likely cleaned up: ${method_name}`
                            );
                            if (typeof reject2 === "function") {
                              reject2(new Error(`Session not found: ${method_name}`));
                            }
                            return;
                          }
                        }
                        console.debug(
                          `Failed to find method ${method_name} at ${this._client_id}`
                        );
                        const error = new Error(
                          `Method not found: ${method_name} at ${this._client_id}`
                        );
                        if (typeof reject2 === "function") {
                          reject2(error);
                        } else {
                          console.warn(
                            "Method not found and no reject callback:",
                            error.message
                          );
                        }
                        return;
                      }
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                        method && typeof method === "function",
                        "Invalid method: " + method_name
                      );
                      if (this._method_annotations.has(method)) {
                        if (this._method_annotations.get(method).visibility === "protected") {
                          if (local_workspace === remote_workspace) {
                          } else if (this._method_annotations.get(method).authorized_workspaces && this._method_annotations.get(method).authorized_workspaces.includes(remote_workspace)) {
                          } else if (remote_workspace === "*" && remote_client_id === this._connection.manager_id) {
                          } else {
                            throw new Error(
                              "Permission denied for invoking protected method " + method_name + ", workspace mismatch: " + local_workspace + " != " + remote_workspace
                            );
                          }
                        }
                      } else {
                        let session_target_id = this._object_store[data.method.split(".")[0]].target_id;
                        if (local_workspace === remote_workspace && session_target_id && session_target_id.indexOf("/") === -1) {
                          session_target_id = local_workspace + "/" + session_target_id;
                        }
                        if (session_target_id !== data.from) {
                          throw new Error(
                            "Access denied for method call (" + method_name + ") from " + data.from + " to target " + session_target_id
                          );
                        }
                      }
                      if (local_parent) {
                        (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                          this._get_session_store(local_parent, true) !== null,
                          "Parent session was closed: " + local_parent
                        );
                      }
                      let args;
                      if (data.args) {
                        args = await this._decode(
                          data.args,
                          data.session,
                          null,
                          remote_workspace,
                          null
                        );
                      } else {
                        args = [];
                      }
                      if (this._method_annotations.has(method) && this._method_annotations.get(method).require_context) {
                        if (args.length + 1 < method.length) {
                          for (let i = args.length; i < method.length - 1; i++) {
                            args.push(void 0);
                          }
                        }
                        args.push(data.ctx);
                      }
                      if (data.promise) {
                        const result = method.apply(null, args);
                        if (result instanceof Promise) {
                          result.then((result2) => {
                            resolve2(result2);
                            clearInterval(heartbeat_task);
                          }).catch((err) => {
                            reject2(err);
                            clearInterval(heartbeat_task);
                          });
                        } else {
                          resolve2(result);
                          clearInterval(heartbeat_task);
                        }
                      } else {
                        method.apply(null, args);
                        clearInterval(heartbeat_task);
                      }
                    } catch (err) {
                      if (reject2) {
                        reject2(err);
                      } else {
                        console.error("Error during calling method: ", err);
                      }
                      clearInterval(heartbeat_task);
                    }
                  }
                  encode(aObject, session_id) {
                    return this._encode(aObject, session_id);
                  }
                  _get_session_store(session_id, create) {
                    if (!session_id) {
                      return null;
                    }
                    let store = this._object_store;
                    const levels = session_id.split(".");
                    if (create) {
                      const last_index = levels.length - 1;
                      for (let level of levels.slice(0, last_index)) {
                        if (!store[level]) {
                          store[level] = {};
                        }
                        store = store[level];
                      }
                      if (!store[levels[last_index]]) {
                        store[levels[last_index]] = {};
                      }
                      return store[levels[last_index]];
                    } else {
                      for (let level of levels) {
                        if (!store[level]) {
                          return null;
                        }
                        store = store[level];
                      }
                      return store;
                    }
                  }
                  /**
                   * Prepares the provided set of remote method arguments for
                   * sending to the remote site, replaces all the callbacks with
                   * identifiers
                   *
                   * @param {Array} args to wrap
                   *
                   * @returns {Array} wrapped arguments
                   */
                  async _encode(aObject, session_id, local_workspace) {
                    const aType = typeof aObject;
                    if (aType === "number" || aType === "string" || aType === "boolean" || aObject === null || aObject === void 0 || aObject instanceof Uint8Array) {
                      return aObject;
                    }
                    if (aObject instanceof ArrayBuffer) {
                      return {
                        _rtype: "memoryview",
                        _rvalue: new Uint8Array(aObject)
                      };
                    }
                    if (aObject.__rpc_object__) {
                      const _server = aObject.__rpc_object__._rserver || this._server_base_url;
                      if (_server === this._server_base_url) {
                        return aObject.__rpc_object__;
                      }
                    }
                    let bObject;
                    if (aObject.constructor instanceof Object && aObject._rtype) {
                      const temp = aObject._rtype;
                      delete aObject._rtype;
                      bObject = await this._encode(aObject, session_id, local_workspace);
                      bObject._rtype = temp;
                      return bObject;
                    }
                    if ((0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.isGenerator)(aObject) || (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.isAsyncGenerator)(aObject)) {
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                        session_id && typeof session_id === "string",
                        "Session ID is required for generator encoding"
                      );
                      const object_id = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.randId)();
                      const store = this._get_session_store(session_id, true);
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                        store !== null,
                        `Failed to create session store ${session_id} due to invalid parent`
                      );
                      const isAsync = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.isAsyncGenerator)(aObject);
                      const nextItemMethod = async () => {
                        if (isAsync) {
                          const iterator = aObject;
                          const result = await iterator.next();
                          if (result.done) {
                            delete store[object_id];
                            return { _rtype: "stop_iteration" };
                          }
                          return result.value;
                        } else {
                          const iterator = aObject;
                          const result = iterator.next();
                          if (result.done) {
                            delete store[object_id];
                            return { _rtype: "stop_iteration" };
                          }
                          return result.value;
                        }
                      };
                      store[object_id] = nextItemMethod;
                      bObject = {
                        _rtype: "generator",
                        _rserver: this._server_base_url,
                        _rtarget: this._client_id,
                        _rmethod: `${session_id}.${object_id}`,
                        _rpromise: "*",
                        _rdoc: "Remote generator"
                      };
                      return bObject;
                    } else if (typeof aObject === "function") {
                      if (this._method_annotations.has(aObject)) {
                        let annotation = this._method_annotations.get(aObject);
                        bObject = {
                          _rtype: "method",
                          _rserver: this._server_base_url,
                          _rtarget: this._client_id,
                          _rmethod: annotation.method_id,
                          _rpromise: "*",
                          _rname: aObject.name
                        };
                      } else {
                        (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(typeof session_id === "string");
                        let object_id;
                        if (aObject.__name__) {
                          object_id = `${(0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.randId)()}#${aObject.__name__}`;
                        } else {
                          object_id = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.randId)();
                        }
                        bObject = {
                          _rtype: "method",
                          _rserver: this._server_base_url,
                          _rtarget: this._client_id,
                          _rmethod: `${session_id}.${object_id}`,
                          _rpromise: "*",
                          _rname: aObject.name
                        };
                        let store = this._get_session_store(session_id, true);
                        (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                          store !== null,
                          `Failed to create session store ${session_id} due to invalid parent`
                        );
                        store[object_id] = aObject;
                      }
                      bObject._rdoc = aObject.__doc__;
                      if (!bObject._rdoc) {
                        try {
                          const funcInfo = getFunctionInfo(aObject);
                          if (funcInfo && !bObject._rdoc) {
                            bObject._rdoc = `${funcInfo.doc}`;
                          }
                        } catch (e) {
                          console.error("Failed to extract function docstring:", aObject);
                        }
                      }
                      bObject._rschema = aObject.__schema__;
                      return bObject;
                    }
                    const isarray = Array.isArray(aObject);
                    for (let tp of Object.keys(this._codecs)) {
                      const codec = this._codecs[tp];
                      if (codec.encoder && aObject instanceof codec.type) {
                        let encodedObj = await Promise.resolve(codec.encoder(aObject));
                        if (encodedObj && !encodedObj._rtype) encodedObj._rtype = codec.name;
                        if (typeof encodedObj === "object") {
                          const temp = encodedObj._rtype;
                          delete encodedObj._rtype;
                          encodedObj = await this._encode(
                            encodedObj,
                            session_id,
                            local_workspace
                          );
                          encodedObj._rtype = temp;
                        }
                        bObject = encodedObj;
                        return bObject;
                      }
                    }
                    if (
                      /*global tf*/
                      typeof tf !== "undefined" && tf.Tensor && aObject instanceof tf.Tensor
                    ) {
                      const v_buffer = aObject.dataSync();
                      bObject = {
                        _rtype: "ndarray",
                        _rvalue: new Uint8Array(v_buffer.buffer),
                        _rshape: aObject.shape,
                        _rdtype: aObject.dtype
                      };
                    } else if (
                      /*global nj*/
                      typeof nj !== "undefined" && nj.NdArray && aObject instanceof nj.NdArray
                    ) {
                      if (!aObject.selection || !aObject.selection.data) {
                        throw new Error("Invalid NumJS array: missing selection or data");
                      }
                      const dtype = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.typedArrayToDtype)(aObject.selection.data);
                      bObject = {
                        _rtype: "ndarray",
                        _rvalue: new Uint8Array(aObject.selection.data.buffer),
                        _rshape: aObject.shape,
                        _rdtype: dtype
                      };
                    } else if (aObject instanceof Error) {
                      console.error(aObject);
                      bObject = {
                        _rtype: "error",
                        _rvalue: aObject.toString(),
                        _rtrace: aObject.stack
                      };
                    } else if (aObject !== Object(aObject) || aObject instanceof Boolean || aObject instanceof String || aObject instanceof Date || aObject instanceof RegExp || typeof ImageData !== "undefined" && aObject instanceof ImageData || typeof FileList !== "undefined" && aObject instanceof FileList || typeof FileSystemDirectoryHandle !== "undefined" && aObject instanceof FileSystemDirectoryHandle || typeof FileSystemFileHandle !== "undefined" && aObject instanceof FileSystemFileHandle || typeof FileSystemHandle !== "undefined" && aObject instanceof FileSystemHandle || typeof FileSystemWritableFileStream !== "undefined" && aObject instanceof FileSystemWritableFileStream) {
                      bObject = aObject;
                    } else if (aObject instanceof Blob) {
                      let seek = function(pos) {
                        _current_pos = pos;
                      };
                      let _current_pos = 0;
                      async function read(length) {
                        let blob;
                        if (length) {
                          blob = aObject.slice(_current_pos, _current_pos + length);
                        } else {
                          blob = aObject.slice(_current_pos);
                        }
                        const ret = new Uint8Array(await blob.arrayBuffer());
                        _current_pos = _current_pos + ret.byteLength;
                        return ret;
                      }
                      bObject = {
                        _rtype: "iostream",
                        _rnative: "js:blob",
                        type: aObject.type,
                        name: aObject.name,
                        size: aObject.size,
                        path: aObject._path || aObject.webkitRelativePath,
                        read: await this._encode(read, session_id, local_workspace),
                        seek: await this._encode(seek, session_id, local_workspace)
                      };
                    } else if (aObject instanceof ArrayBufferView) {
                      const dtype = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.typedArrayToDtype)(aObject);
                      bObject = {
                        _rtype: "typedarray",
                        _rvalue: new Uint8Array(aObject.buffer),
                        _rdtype: dtype
                      };
                    } else if (aObject instanceof DataView) {
                      bObject = {
                        _rtype: "memoryview",
                        _rvalue: new Uint8Array(aObject.buffer)
                      };
                    } else if (aObject instanceof Set) {
                      bObject = {
                        _rtype: "set",
                        _rvalue: await this._encode(
                          Array.from(aObject),
                          session_id,
                          local_workspace
                        )
                      };
                    } else if (aObject instanceof Map) {
                      bObject = {
                        _rtype: "orderedmap",
                        _rvalue: await this._encode(
                          Array.from(aObject),
                          session_id,
                          local_workspace
                        )
                      };
                    } else if (aObject.constructor === Object || Array.isArray(aObject) || aObject instanceof RemoteService) {
                      if (isarray) {
                        if (_allPrimitivesArray(aObject)) return aObject;
                      } else if (!("_rtype" in aObject) && !(aObject instanceof RemoteService)) {
                        if (_allPrimitivesObject(aObject)) return aObject;
                      }
                      bObject = isarray ? [] : {};
                      const keys = Object.keys(aObject);
                      for (let k of keys) {
                        bObject[k] = await this._encode(
                          aObject[k],
                          session_id,
                          local_workspace
                        );
                      }
                    } else {
                      throw `hypha-rpc: Unsupported data type: ${aObject}, you can register a custom codec to encode/decode the object.`;
                    }
                    if (!bObject) {
                      throw new Error("Failed to encode object");
                    }
                    return bObject;
                  }
                  async decode(aObject) {
                    return await this._decode(aObject);
                  }
                  async _decode(aObject, remote_parent, local_parent, remote_workspace, local_workspace) {
                    if (!aObject) {
                      return aObject;
                    }
                    let bObject;
                    if (aObject._rtype) {
                      if (this._codecs[aObject._rtype] && this._codecs[aObject._rtype].decoder) {
                        const temp = aObject._rtype;
                        delete aObject._rtype;
                        aObject = await this._decode(
                          aObject,
                          remote_parent,
                          local_parent,
                          remote_workspace,
                          local_workspace
                        );
                        aObject._rtype = temp;
                        bObject = await Promise.resolve(
                          this._codecs[aObject._rtype].decoder(aObject)
                        );
                      } else if (aObject._rtype === "method") {
                        bObject = this._generate_remote_method(
                          aObject,
                          remote_parent,
                          local_parent,
                          remote_workspace,
                          local_workspace
                        );
                      } else if (aObject._rtype === "generator") {
                        const gen_method = this._generate_remote_method(
                          aObject,
                          remote_parent,
                          local_parent,
                          remote_workspace,
                          local_workspace
                        );
                        async function* asyncGeneratorProxy() {
                          while (true) {
                            try {
                              const next_item = await gen_method();
                              if (next_item && next_item._rtype === "stop_iteration") {
                                break;
                              }
                              yield next_item;
                            } catch (error) {
                              console.error("Error in generator:", error);
                              throw error;
                            }
                          }
                        }
                        bObject = asyncGeneratorProxy();
                      } else if (aObject._rtype === "ndarray") {
                        if (typeof nj !== "undefined" && nj.array) {
                          if (Array.isArray(aObject._rvalue)) {
                            aObject._rvalue = aObject._rvalue.reduce(_appendBuffer);
                          }
                          bObject = nj.array(new Uint8(aObject._rvalue), aObject._rdtype).reshape(aObject._rshape);
                        } else if (typeof tf !== "undefined" && tf.Tensor) {
                          if (Array.isArray(aObject._rvalue)) {
                            aObject._rvalue = aObject._rvalue.reduce(_appendBuffer);
                          }
                          const arraytype = _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.dtypeToTypedArray[aObject._rdtype];
                          bObject = tf.tensor(
                            new arraytype(aObject._rvalue),
                            aObject._rshape,
                            aObject._rdtype
                          );
                        } else {
                          bObject = aObject;
                        }
                      } else if (aObject._rtype === "error") {
                        bObject = new Error(
                          "RemoteError: " + aObject._rvalue + "\n" + (aObject._rtrace || "")
                        );
                      } else if (aObject._rtype === "typedarray") {
                        const arraytype = _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.dtypeToTypedArray[aObject._rdtype];
                        if (!arraytype)
                          throw new Error("unsupported dtype: " + aObject._rdtype);
                        const buffer = aObject._rvalue.buffer.slice(
                          aObject._rvalue.byteOffset,
                          aObject._rvalue.byteOffset + aObject._rvalue.byteLength
                        );
                        bObject = new arraytype(buffer);
                      } else if (aObject._rtype === "memoryview") {
                        bObject = aObject._rvalue.buffer.slice(
                          aObject._rvalue.byteOffset,
                          aObject._rvalue.byteOffset + aObject._rvalue.byteLength
                        );
                      } else if (aObject._rtype === "iostream") {
                        if (aObject._rnative === "js:blob") {
                          const read = await this._generate_remote_method(
                            aObject.read,
                            remote_parent,
                            local_parent,
                            remote_workspace,
                            local_workspace
                          );
                          const bytes = await read();
                          bObject = new Blob([bytes], {
                            type: aObject.type,
                            name: aObject.name
                          });
                        } else {
                          bObject = {};
                          for (let k of Object.keys(aObject)) {
                            if (!k.startsWith("_")) {
                              bObject[k] = await this._decode(
                                aObject[k],
                                remote_parent,
                                local_parent,
                                remote_workspace,
                                local_workspace
                              );
                            }
                          }
                        }
                        bObject["__rpc_object__"] = aObject;
                      } else if (aObject._rtype === "orderedmap") {
                        bObject = new Map(
                          await this._decode(
                            aObject._rvalue,
                            remote_parent,
                            local_parent,
                            remote_workspace,
                            local_workspace
                          )
                        );
                      } else if (aObject._rtype === "set") {
                        bObject = new Set(
                          await this._decode(
                            aObject._rvalue,
                            remote_parent,
                            local_parent,
                            remote_workspace,
                            local_workspace
                          )
                        );
                      } else {
                        const temp = aObject._rtype;
                        delete aObject._rtype;
                        bObject = await this._decode(
                          aObject,
                          remote_parent,
                          local_parent,
                          remote_workspace,
                          local_workspace
                        );
                        bObject._rtype = temp;
                      }
                    } else if (aObject.constructor === Object || Array.isArray(aObject)) {
                      const isarray = Array.isArray(aObject);
                      if (isarray) {
                        if (_allPrimitivesArray(aObject)) return aObject;
                      } else {
                        if (_allPrimitivesObject(aObject)) return aObject;
                      }
                      bObject = isarray ? [] : {};
                      for (let k of Object.keys(aObject)) {
                        if (isarray || aObject.hasOwnProperty(k)) {
                          const v = aObject[k];
                          bObject[k] = await this._decode(
                            v,
                            remote_parent,
                            local_parent,
                            remote_workspace,
                            local_workspace
                          );
                        }
                      }
                    } else {
                      bObject = aObject;
                    }
                    if (bObject === void 0) {
                      throw new Error("Failed to decode object");
                    }
                    return bObject;
                  }
                  _expand_promise(data) {
                    return {
                      heartbeat: {
                        _rtype: "method",
                        _rtarget: data.from.split("/")[1],
                        _rmethod: data.session + ".heartbeat",
                        _rdoc: `heartbeat callback for method: ${data.method}`
                      },
                      resolve: {
                        _rtype: "method",
                        _rtarget: data.from.split("/")[1],
                        _rmethod: data.session + ".resolve",
                        _rdoc: `resolve callback for method: ${data.method}`
                      },
                      reject: {
                        _rtype: "method",
                        _rtarget: data.from.split("/")[1],
                        _rmethod: data.session + ".reject",
                        _rdoc: `reject callback for method: ${data.method}`
                      },
                      interval: data.t
                    };
                  }
                }
              }
            ),
            /***/
            "./src/utils/index.js": (
              /*!****************************!*\
                !*** ./src/utils/index.js ***!
                \****************************/
              /***/
              (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
                __webpack_require__.r(__webpack_exports__);
                __webpack_require__.d(__webpack_exports__, {
                  /* harmony export */
                  MessageEmitter: () => (
                    /* binding */
                    MessageEmitter
                  ),
                  /* harmony export */
                  Semaphore: () => (
                    /* binding */
                    Semaphore
                  ),
                  /* harmony export */
                  assert: () => (
                    /* binding */
                    assert
                  ),
                  /* harmony export */
                  cacheRequirements: () => (
                    /* binding */
                    cacheRequirements
                  ),
                  /* harmony export */
                  convertCase: () => (
                    /* binding */
                    convertCase
                  ),
                  /* harmony export */
                  dtypeToTypedArray: () => (
                    /* binding */
                    dtypeToTypedArray
                  ),
                  /* harmony export */
                  expandKwargs: () => (
                    /* binding */
                    expandKwargs
                  ),
                  /* harmony export */
                  isAsyncGenerator: () => (
                    /* binding */
                    isAsyncGenerator
                  ),
                  /* harmony export */
                  isGenerator: () => (
                    /* binding */
                    isGenerator
                  ),
                  /* harmony export */
                  loadRequirements: () => (
                    /* binding */
                    loadRequirements
                  ),
                  /* harmony export */
                  loadRequirementsInWebworker: () => (
                    /* binding */
                    loadRequirementsInWebworker
                  ),
                  /* harmony export */
                  loadRequirementsInWindow: () => (
                    /* binding */
                    loadRequirementsInWindow
                  ),
                  /* harmony export */
                  normalizeConfig: () => (
                    /* binding */
                    normalizeConfig
                  ),
                  /* harmony export */
                  parseServiceUrl: () => (
                    /* binding */
                    parseServiceUrl
                  ),
                  /* harmony export */
                  randId: () => (
                    /* binding */
                    randId
                  ),
                  /* harmony export */
                  toCamelCase: () => (
                    /* binding */
                    toCamelCase
                  ),
                  /* harmony export */
                  toSnakeCase: () => (
                    /* binding */
                    toSnakeCase
                  ),
                  /* harmony export */
                  typedArrayToDtype: () => (
                    /* binding */
                    typedArrayToDtype
                  ),
                  /* harmony export */
                  typedArrayToDtypeMapping: () => (
                    /* binding */
                    typedArrayToDtypeMapping
                  ),
                  /* harmony export */
                  urlJoin: () => (
                    /* binding */
                    urlJoin
                  ),
                  /* harmony export */
                  waitFor: () => (
                    /* binding */
                    waitFor
                  )
                  /* harmony export */
                });
                function randId() {
                  return Math.random().toString(36).substr(2, 10) + (/* @__PURE__ */ new Date()).getTime();
                }
                function toCamelCase(str) {
                  if (!str.includes("_")) {
                    return str;
                  }
                  return str.replace(/_./g, (match) => match[1].toUpperCase());
                }
                function toSnakeCase(str) {
                  return str.replace(/([A-Z])/g, "_$1").toLowerCase();
                }
                function expandKwargs(obj) {
                  if (typeof obj !== "object" || obj === null) {
                    return obj;
                  }
                  const newObj = Array.isArray(obj) ? [] : {};
                  for (const key in obj) {
                    if (obj.hasOwnProperty(key)) {
                      const value = obj[key];
                      if (typeof value === "function") {
                        newObj[key] = (...args) => {
                          if (args.length === 0) {
                            throw new Error(`Function "${key}" expects at least one argument.`);
                          }
                          const lastArg = args[args.length - 1];
                          let kwargs = {};
                          if (typeof lastArg === "object" && lastArg !== null && !Array.isArray(lastArg)) {
                            kwargs = { ...lastArg, _rkwarg: true };
                            args = args.slice(0, -1);
                          }
                          return value(...args, kwargs);
                        };
                        newObj[key].__name__ = key;
                        if (value.__schema__) {
                          newObj[key].__schema__ = { ...value.__schema__ };
                          newObj[key].__schema__.name = key;
                        }
                      } else {
                        newObj[key] = expandKwargs(value);
                      }
                    }
                  }
                  return newObj;
                }
                function convertCase(obj, caseType) {
                  if (typeof obj !== "object" || obj === null || !caseType) {
                    return obj;
                  }
                  const newObj = Array.isArray(obj) ? [] : {};
                  for (const key in obj) {
                    if (obj.hasOwnProperty(key)) {
                      const value = obj[key];
                      const camelKey = toCamelCase(key);
                      const snakeKey = toSnakeCase(key);
                      if (caseType === "camel") {
                        newObj[camelKey] = convertCase(value, caseType);
                        if (typeof value === "function") {
                          newObj[camelKey].__name__ = camelKey;
                          if (value.__schema__) {
                            newObj[camelKey].__schema__ = { ...value.__schema__ };
                            newObj[camelKey].__schema__.name = camelKey;
                          }
                        }
                      } else if (caseType === "snake") {
                        newObj[snakeKey] = convertCase(value, caseType);
                        if (typeof value === "function") {
                          newObj[snakeKey].__name__ = snakeKey;
                          if (value.__schema__) {
                            newObj[snakeKey].__schema__ = { ...value.__schema__ };
                            newObj[snakeKey].__schema__.name = snakeKey;
                          }
                        }
                      } else {
                        if (caseType.includes("camel")) {
                          newObj[camelKey] = convertCase(value, "camel");
                        }
                        if (caseType.includes("snake")) {
                          newObj[snakeKey] = convertCase(value, "snake");
                        }
                      }
                    }
                  }
                  return newObj;
                }
                function parseServiceUrl(url) {
                  url = url.replace(/\/$/, "");
                  const pattern = new RegExp(
                    "^(https?:\\/\\/[^/]+)\\/([a-z0-9_-]+)\\/services\\/(?:(?<clientId>[a-zA-Z0-9_-]+):)?(?<serviceId>[a-zA-Z0-9_-]+)(?:@(?<appId>[a-zA-Z0-9_-]+))?"
                    // optional app_id
                  );
                  const match = url.match(pattern);
                  if (!match) {
                    throw new Error("URL does not match the expected pattern");
                  }
                  const serverUrl = match[1];
                  const workspace2 = match[2];
                  const clientId = match.groups?.clientId || "*";
                  const serviceId = match.groups?.serviceId;
                  const appId = match.groups?.appId || "*";
                  return { serverUrl, workspace: workspace2, clientId, serviceId, appId };
                }
                const dtypeToTypedArray = {
                  int8: Int8Array,
                  int16: Int16Array,
                  int32: Int32Array,
                  uint8: Uint8Array,
                  uint16: Uint16Array,
                  uint32: Uint32Array,
                  float32: Float32Array,
                  float64: Float64Array,
                  array: Array
                };
                async function loadRequirementsInWindow(requirements) {
                  function _importScript(url) {
                    return new Promise((resolve2, reject2) => {
                      var scriptTag = document.createElement("script");
                      scriptTag.src = url;
                      scriptTag.type = "text/javascript";
                      scriptTag.onload = resolve2;
                      scriptTag.onreadystatechange = function() {
                        if (this.readyState === "loaded" || this.readyState === "complete") {
                          resolve2();
                        }
                      };
                      scriptTag.onerror = reject2;
                      document.head.appendChild(scriptTag);
                    });
                  }
                  async function importScripts2() {
                    var args = Array.prototype.slice.call(arguments), len = args.length, i2 = 0;
                    for (; i2 < len; i2++) {
                      await _importScript(args[i2]);
                    }
                  }
                  if (requirements && (Array.isArray(requirements) || typeof requirements === "string")) {
                    try {
                      var link_node;
                      requirements = typeof requirements === "string" ? [requirements] : requirements;
                      if (Array.isArray(requirements)) {
                        for (var i = 0; i < requirements.length; i++) {
                          if (requirements[i].toLowerCase().endsWith(".css") || requirements[i].startsWith("css:")) {
                            if (requirements[i].startsWith("css:")) {
                              requirements[i] = requirements[i].slice(4);
                            }
                            link_node = document.createElement("link");
                            link_node.rel = "stylesheet";
                            link_node.href = requirements[i];
                            document.head.appendChild(link_node);
                          } else if (requirements[i].toLowerCase().endsWith(".mjs") || requirements[i].startsWith("mjs:")) {
                            if (requirements[i].startsWith("mjs:")) {
                              requirements[i] = requirements[i].slice(4);
                            }
                            await import(
                              /* webpackIgnore: true */
                              requirements[i]
                            );
                          } else if (requirements[i].toLowerCase().endsWith(".js") || requirements[i].startsWith("js:")) {
                            if (requirements[i].startsWith("js:")) {
                              requirements[i] = requirements[i].slice(3);
                            }
                            await importScripts2(requirements[i]);
                          } else if (requirements[i].startsWith("http")) {
                            await importScripts2(requirements[i]);
                          } else if (requirements[i].startsWith("cache:")) {
                          } else {
                            console.log("Unprocessed requirements url: " + requirements[i]);
                          }
                        }
                      } else {
                        throw "unsupported requirements definition";
                      }
                    } catch (e) {
                      throw "failed to import required scripts: " + requirements.toString();
                    }
                  }
                }
                async function loadRequirementsInWebworker(requirements) {
                  if (requirements && (Array.isArray(requirements) || typeof requirements === "string")) {
                    try {
                      if (!Array.isArray(requirements)) {
                        requirements = [requirements];
                      }
                      for (var i = 0; i < requirements.length; i++) {
                        if (requirements[i].toLowerCase().endsWith(".css") || requirements[i].startsWith("css:")) {
                          throw "unable to import css in a webworker";
                        } else if (requirements[i].toLowerCase().endsWith(".js") || requirements[i].startsWith("js:")) {
                          if (requirements[i].startsWith("js:")) {
                            requirements[i] = requirements[i].slice(3);
                          }
                          importScripts(requirements[i]);
                        } else if (requirements[i].startsWith("http")) {
                          importScripts(requirements[i]);
                        } else if (requirements[i].startsWith("cache:")) {
                        } else {
                          console.log("Unprocessed requirements url: " + requirements[i]);
                        }
                      }
                    } catch (e) {
                      throw "failed to import required scripts: " + requirements.toString();
                    }
                  }
                }
                function loadRequirements(requirements) {
                  if (typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope) {
                    return loadRequirementsInWebworker(requirements);
                  } else {
                    return loadRequirementsInWindow(requirements);
                  }
                }
                function normalizeConfig(config2) {
                  config2.version = config2.version || "0.1.0";
                  config2.description = config2.description || `[TODO: add description for ${config2.name} ]`;
                  config2.type = config2.type || "rpc-window";
                  config2.id = config2.id || randId();
                  config2.target_origin = config2.target_origin || "*";
                  config2.allow_execution = config2.allow_execution || false;
                  config2 = Object.keys(config2).reduce((p, c) => {
                    if (typeof config2[c] !== "function") p[c] = config2[c];
                    return p;
                  }, {});
                  return config2;
                }
                const typedArrayToDtypeMapping = {
                  Int8Array: "int8",
                  Int16Array: "int16",
                  Int32Array: "int32",
                  Uint8Array: "uint8",
                  Uint16Array: "uint16",
                  Uint32Array: "uint32",
                  Float32Array: "float32",
                  Float64Array: "float64",
                  Array: "array"
                };
                const typedArrayToDtypeKeys = [];
                for (const arrType of Object.keys(typedArrayToDtypeMapping)) {
                  typedArrayToDtypeKeys.push(globalThis[arrType]);
                }
                function typedArrayToDtype(obj) {
                  let dtype = typedArrayToDtypeMapping[obj.constructor.name];
                  if (!dtype) {
                    const pt = Object.getPrototypeOf(obj);
                    for (const arrType2 of typedArrayToDtypeKeys) {
                      if (pt instanceof arrType2) {
                        dtype = typedArrayToDtypeMapping[arrType2.name];
                        break;
                      }
                    }
                  }
                  return dtype;
                }
                function cacheUrlInServiceWorker(url) {
                  return new Promise(function(resolve2, reject2) {
                    const message = {
                      command: "add",
                      url
                    };
                    if (!navigator.serviceWorker || !navigator.serviceWorker.register) {
                      reject2("Service worker is not supported.");
                      return;
                    }
                    const messageChannel = new MessageChannel();
                    messageChannel.port1.onmessage = function(event2) {
                      if (event2.data && event2.data.error) {
                        reject2(event2.data.error);
                      } else {
                        resolve2(event2.data && event2.data.result);
                      }
                    };
                    if (navigator.serviceWorker && navigator.serviceWorker.controller) {
                      navigator.serviceWorker.controller.postMessage(message, [
                        messageChannel.port2
                      ]);
                    } else {
                      reject2("Service worker controller is not available");
                    }
                  });
                }
                async function cacheRequirements(requirements) {
                  requirements = requirements || [];
                  if (!Array.isArray(requirements)) {
                    requirements = [requirements];
                  }
                  for (let req of requirements) {
                    if (req.startsWith("js:")) req = req.slice(3);
                    if (req.startsWith("css:")) req = req.slice(4);
                    if (req.startsWith("cache:")) req = req.slice(6);
                    if (!req.startsWith("http")) continue;
                    await cacheUrlInServiceWorker(req).catch((e) => {
                      console.error(e);
                    });
                  }
                }
                function assert(condition, message) {
                  if (!condition) {
                    throw new Error(message || "Assertion failed");
                  }
                }
                function urlJoin(...args) {
                  return args.join("/").replace(/[\/]+/g, "/").replace(/^(.+):\//, "$1://").replace(/^file:/, "file:/").replace(/\/(\?|&|#[^!])/g, "$1").replace(/\?/g, "&").replace("&", "?");
                }
                function waitFor(prom, time, error) {
                  let timer;
                  return Promise.race([
                    prom,
                    new Promise(
                      (_r, rej) => timer = setTimeout(() => {
                        rej(error || "Timeout Error");
                      }, time * 1e3)
                    )
                  ]).finally(() => clearTimeout(timer));
                }
                class MessageEmitter {
                  constructor(debug) {
                    this._event_handlers = {};
                    this._once_handlers = {};
                    this._debug = debug;
                  }
                  emit() {
                    throw new Error("emit is not implemented");
                  }
                  on(event2, handler) {
                    if (!this._event_handlers[event2]) {
                      this._event_handlers[event2] = [];
                    }
                    this._event_handlers[event2].push(handler);
                  }
                  once(event2, handler) {
                    handler.___event_run_once = true;
                    this.on(event2, handler);
                  }
                  off(event2, handler) {
                    if (!event2 && !handler) {
                      this._event_handlers = {};
                    } else if (event2 && !handler) {
                      if (this._event_handlers[event2]) this._event_handlers[event2] = [];
                    } else {
                      if (this._event_handlers[event2]) {
                        const idx = this._event_handlers[event2].indexOf(handler);
                        if (idx >= 0) {
                          this._event_handlers[event2].splice(idx, 1);
                        }
                      }
                    }
                  }
                  _fire(event2, data) {
                    if (this._event_handlers[event2]) {
                      var i = this._event_handlers[event2].length;
                      while (i--) {
                        const handler = this._event_handlers[event2][i];
                        try {
                          handler(data);
                        } catch (e) {
                          console.error(e);
                        } finally {
                          if (handler.___event_run_once) {
                            this._event_handlers[event2].splice(i, 1);
                          }
                        }
                      }
                    } else {
                      if (this._debug) {
                        console.warn("unhandled event", event2, data);
                      }
                    }
                  }
                  waitFor(event2, timeout) {
                    return new Promise((resolve2, reject2) => {
                      const handler = (data) => {
                        clearTimeout(timer);
                        resolve2(data);
                      };
                      this.once(event2, handler);
                      const timer = setTimeout(() => {
                        this.off(event2, handler);
                        reject2(new Error("Timeout"));
                      }, timeout * 1e3);
                    });
                  }
                }
                class Semaphore {
                  constructor(max) {
                    this.max = max;
                    this.queue = [];
                    this.current = 0;
                  }
                  async run(task) {
                    if (this.current >= this.max) {
                      await new Promise((resolve2) => this.queue.push(resolve2));
                    }
                    this.current++;
                    try {
                      return await task();
                    } finally {
                      this.current--;
                      if (this.queue.length > 0) {
                        this.queue.shift()();
                      }
                    }
                  }
                }
                function isGenerator(obj) {
                  if (!obj) return false;
                  return typeof obj === "object" && typeof obj.next === "function" && typeof obj.throw === "function" && typeof obj.return === "function";
                }
                function isAsyncGenerator(obj) {
                  if (!obj) return false;
                  return typeof obj === "object" && typeof obj.next === "function" && typeof obj.throw === "function" && typeof obj.return === "function" && Symbol.asyncIterator in Object(obj) && obj[Symbol.toStringTag] === "AsyncGenerator";
                }
              }
            ),
            /***/
            "./src/utils/schema.js": (
              /*!*****************************!*\
                !*** ./src/utils/schema.js ***!
                \*****************************/
              /***/
              (__unused_webpack_module2, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  schemaFunction: () => (
                    /* binding */
                    schemaFunction
                  ),
                  /* harmony export */
                  z: () => (
                    /* binding */
                    z
                  )
                  /* harmony export */
                });
                var _index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./index.js */
                  "./src/utils/index.js"
                );
                const z = {
                  object: (properties) => ({
                    type: "object",
                    properties,
                    required: Object.keys(properties).filter(
                      (key) => !properties[key]._optional
                    )
                  }),
                  string: () => ({ type: "string", _optional: false }),
                  number: () => ({ type: "number", _optional: false }),
                  integer: () => ({ type: "integer", _optional: false }),
                  boolean: () => ({ type: "boolean", _optional: false }),
                  array: (items) => ({ type: "array", items, _optional: false }),
                  // Make field optional
                  optional: (schema) => ({ ...schema, _optional: true })
                };
                ["string", "number", "integer", "boolean", "array"].forEach((type2) => {
                  z[type2] = () => {
                    const schema = {
                      type: type2 === "integer" ? "integer" : type2,
                      _optional: false
                    };
                    schema.describe = (description) => ({ ...schema, description });
                    return schema;
                  };
                });
                function schemaFunction(func, { schema_type = "auto", name: name2 = null, description = null, parameters = null }) {
                  if (!func || typeof func !== "function") {
                    throw Error("func should be a function");
                  }
                  (0, _index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(schema_type === "auto", "schema_type should be auto");
                  const funcName = name2 || func.name;
                  (0, _index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(funcName, "name should not be null");
                  let processedParameters = parameters;
                  if (parameters && typeof parameters === "object" && parameters.type === "object") {
                    processedParameters = {
                      type: "object",
                      properties: parameters.properties || {},
                      required: parameters.required || []
                    };
                    for (const [key, schema] of Object.entries(
                      processedParameters.properties
                    )) {
                      if (schema._optional !== void 0) {
                        delete schema._optional;
                      }
                    }
                  }
                  (0, _index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                    processedParameters && processedParameters.type === "object",
                    "parameters should be an object schema"
                  );
                  func.__schema__ = {
                    name: funcName,
                    description: description || "",
                    parameters: processedParameters
                  };
                  return func;
                }
              }
            ),
            /***/
            "./src/webrtc-client.js": (
              /*!******************************!*\
                !*** ./src/webrtc-client.js ***!
                \******************************/
              /***/
              (__unused_webpack_module2, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  getRTCService: () => (
                    /* binding */
                    getRTCService
                  ),
                  /* harmony export */
                  registerRTCService: () => (
                    /* binding */
                    registerRTCService
                  )
                  /* harmony export */
                });
                var _rpc_js__WEBPACK_IMPORTED_MODULE_0__2 = __webpack_require__2(
                  /*! ./rpc.js */
                  "./src/rpc.js"
                );
                var _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2 = __webpack_require__2(
                  /*! ./utils/index.js */
                  "./src/utils/index.js"
                );
                var _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2 = __webpack_require__2(
                  /*! ./utils/schema.js */
                  "./src/utils/schema.js"
                );
                class WebRTCConnection {
                  constructor(channel) {
                    this._data_channel = channel;
                    this._handle_message = null;
                    this._reconnection_token = null;
                    this._handle_disconnected = null;
                    this._handle_connected = () => {
                    };
                    this.manager_id = null;
                    this._data_channel.onopen = async () => {
                      this._handle_connected && this._handle_connected({ channel: this._data_channel });
                    };
                    this._data_channel.onmessage = async (event2) => {
                      let data = event2.data;
                      if (data instanceof Blob) {
                        data = await data.arrayBuffer();
                      }
                      if (this._handle_message) {
                        this._handle_message(data);
                      }
                    };
                    this._data_channel.onclose = () => {
                      if (this._handle_disconnected) this._handle_disconnected("closed");
                      console.log("data channel closed");
                      this._data_channel = null;
                    };
                  }
                  on_disconnected(handler) {
                    this._handle_disconnected = handler;
                  }
                  on_connected(handler) {
                    this._handle_connected = handler;
                  }
                  on_message(handler) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(handler, "handler is required");
                    this._handle_message = handler;
                  }
                  async emit_message(data) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(this._handle_message, "No handler for message");
                    try {
                      this._data_channel.send(data);
                    } catch (exp) {
                      console.error(`Failed to send data, error: ${exp}`);
                      throw exp;
                    }
                  }
                  async disconnect(reason) {
                    this._data_channel = null;
                    console.info(`data channel connection disconnected (${reason})`);
                  }
                }
                async function _setupRPC(config2) {
                  (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(config2.channel, "No channel provided");
                  (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(config2.workspace, "No workspace provided");
                  const channel = config2.channel;
                  const clientId = config2.client_id || (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.randId)();
                  const connection = new WebRTCConnection(channel);
                  config2.context = config2.context || {};
                  config2.context.connection_type = "webrtc";
                  config2.context.ws = config2.workspace;
                  const rpc = new _rpc_js__WEBPACK_IMPORTED_MODULE_0__2.RPC(connection, {
                    client_id: clientId,
                    default_context: config2.context,
                    name: config2.name,
                    method_timeout: config2.method_timeout || 10,
                    workspace: config2.workspace,
                    app_id: config2.app_id,
                    long_message_chunk_size: config2.long_message_chunk_size
                  });
                  return rpc;
                }
                async function _createOffer(params, server3, config2, onInit, context2) {
                  config2 = config2 || {};
                  let offer = new RTCSessionDescription({
                    sdp: params.sdp,
                    type: params.type
                  });
                  let pc = new RTCPeerConnection({
                    iceServers: config2.ice_servers || [
                      { urls: ["stun:stun.l.google.com:19302"] }
                    ],
                    sdpSemantics: "unified-plan"
                  });
                  if (server3) {
                    pc.addEventListener("datachannel", async (event2) => {
                      const channel = event2.channel;
                      let ctx = null;
                      if (context2 && context2.user) ctx = { user: context2.user, ws: context2.ws };
                      const rpc = await _setupRPC({
                        channel,
                        client_id: channel.label,
                        workspace: server3.config.workspace,
                        context: ctx
                      });
                      rpc._services = server3.rpc._services;
                    });
                  }
                  if (onInit) {
                    await onInit(pc);
                  }
                  await pc.setRemoteDescription(offer);
                  let answer = await pc.createAnswer();
                  await pc.setLocalDescription(answer);
                  await new Promise((resolveIce) => {
                    if (pc.iceGatheringState === "complete") {
                      resolveIce();
                    } else {
                      pc.addEventListener("icegatheringstatechange", () => {
                        if (pc.iceGatheringState === "complete") {
                          resolveIce();
                        }
                      });
                      setTimeout(resolveIce, 5e3);
                    }
                  });
                  return {
                    sdp: pc.localDescription.sdp,
                    type: pc.localDescription.type,
                    workspace: server3.config.workspace
                  };
                }
                async function getRTCService(server3, service_id, config2) {
                  config2 = config2 || {};
                  config2.peer_id = config2.peer_id || (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.randId)();
                  const pc = new RTCPeerConnection({
                    iceServers: config2.ice_servers || [
                      { urls: ["stun:stun.l.google.com:19302"] }
                    ],
                    sdpSemantics: "unified-plan"
                  });
                  return new Promise(async (resolve2, reject2) => {
                    let resolved = false;
                    const timeout = setTimeout(() => {
                      if (!resolved) {
                        resolved = true;
                        pc.close();
                        reject2(new Error("WebRTC Connection timeout"));
                      }
                    }, 3e4);
                    try {
                      pc.addEventListener(
                        "connectionstatechange",
                        () => {
                          console.log("WebRTC Connection state: ", pc.connectionState);
                          if (pc.connectionState === "failed") {
                            if (!resolved) {
                              resolved = true;
                              clearTimeout(timeout);
                              pc.close();
                              reject2(new Error("WebRTC Connection failed"));
                            }
                          } else if (pc.connectionState === "closed") {
                            if (!resolved) {
                              resolved = true;
                              clearTimeout(timeout);
                              reject2(new Error("WebRTC Connection closed"));
                            }
                          } else if (pc.connectionState === "connected") {
                            console.log("WebRTC Connection established successfully");
                          }
                        },
                        false
                      );
                      pc.addEventListener("iceconnectionstatechange", () => {
                        console.log("ICE Connection state: ", pc.iceConnectionState);
                        if (pc.iceConnectionState === "failed") {
                          if (!resolved) {
                            resolved = true;
                            clearTimeout(timeout);
                            pc.close();
                            reject2(new Error("ICE Connection failed"));
                          }
                        }
                      });
                      if (config2.on_init) {
                        await config2.on_init(pc);
                        delete config2.on_init;
                      }
                      let channel = pc.createDataChannel(config2.peer_id, { ordered: true });
                      channel.binaryType = "arraybuffer";
                      const offer = await pc.createOffer();
                      await pc.setLocalDescription(offer);
                      await new Promise((resolveIce) => {
                        if (pc.iceGatheringState === "complete") {
                          resolveIce();
                        } else {
                          pc.addEventListener("icegatheringstatechange", () => {
                            if (pc.iceGatheringState === "complete") {
                              resolveIce();
                            }
                          });
                          setTimeout(resolveIce, 5e3);
                        }
                      });
                      const svc = await server3.getService(service_id);
                      const answer = await svc.offer({
                        sdp: pc.localDescription.sdp,
                        type: pc.localDescription.type
                      });
                      channel.onopen = () => {
                        config2.channel = channel;
                        config2.workspace = answer.workspace;
                        setTimeout(async () => {
                          if (!resolved) {
                            try {
                              const rpc = await _setupRPC(config2);
                              pc.rpc = rpc;
                              async function get_service(name2, ...args) {
                                (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(
                                  !name2.includes(":"),
                                  "WebRTC service name should not contain ':'"
                                );
                                (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(
                                  !name2.includes("/"),
                                  "WebRTC service name should not contain '/'"
                                );
                                return await rpc.get_remote_service(
                                  config2.workspace + "/" + config2.peer_id + ":" + name2,
                                  ...args
                                );
                              }
                              async function disconnect2() {
                                await rpc.disconnect();
                                pc.close();
                              }
                              pc.getService = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2.schemaFunction)(get_service, {
                                name: "getService",
                                description: "Get a remote service via webrtc",
                                parameters: {
                                  type: "object",
                                  properties: {
                                    service_id: {
                                      type: "string",
                                      description: "Service ID. This should be a service id in the format: 'workspace/service_id', 'workspace/client_id:service_id' or 'workspace/client_id:service_id@app_id'"
                                    },
                                    config: {
                                      type: "object",
                                      description: "Options for the service"
                                    }
                                  },
                                  required: ["id"]
                                }
                              });
                              pc.disconnect = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2.schemaFunction)(disconnect2, {
                                name: "disconnect",
                                description: "Disconnect from the webrtc connection via webrtc",
                                parameters: { type: "object", properties: {} }
                              });
                              pc.registerCodec = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2.schemaFunction)(rpc.register_codec, {
                                name: "registerCodec",
                                description: "Register a codec for the webrtc connection",
                                parameters: {
                                  type: "object",
                                  properties: {
                                    codec: {
                                      type: "object",
                                      description: "Codec to register",
                                      properties: {
                                        name: { type: "string" },
                                        type: {},
                                        encoder: { type: "function" },
                                        decoder: { type: "function" }
                                      }
                                    }
                                  }
                                }
                              });
                              resolved = true;
                              clearTimeout(timeout);
                              resolve2(pc);
                            } catch (e) {
                              if (!resolved) {
                                resolved = true;
                                clearTimeout(timeout);
                                reject2(e);
                              }
                            }
                          }
                        }, 1e3);
                      };
                      channel.onclose = () => {
                        if (!resolved) {
                          resolved = true;
                          clearTimeout(timeout);
                          reject2(new Error("Data channel closed"));
                        }
                      };
                      channel.onerror = (error) => {
                        if (!resolved) {
                          resolved = true;
                          clearTimeout(timeout);
                          reject2(new Error(`Data channel error: ${error}`));
                        }
                      };
                      await pc.setRemoteDescription(
                        new RTCSessionDescription({
                          sdp: answer.sdp,
                          type: answer.type
                        })
                      );
                    } catch (e) {
                      if (!resolved) {
                        resolved = true;
                        clearTimeout(timeout);
                        reject2(e);
                      }
                    }
                  });
                }
                async function registerRTCService(server3, service_id, config2) {
                  config2 = config2 || {
                    visibility: "protected",
                    require_context: true
                  };
                  const onInit = config2.on_init;
                  delete config2.on_init;
                  return await server3.registerService({
                    id: service_id,
                    config: config2,
                    offer: (params, context2) => _createOffer(params, server3, config2, onInit, context2)
                  });
                }
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/CachedKeyDecoder.mjs": (
              /*!*************************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/CachedKeyDecoder.mjs ***!
                \*************************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  CachedKeyDecoder: () => (
                    /* binding */
                    CachedKeyDecoder
                  )
                  /* harmony export */
                });
                var _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./utils/utf8.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/utf8.mjs"
                );
                var DEFAULT_MAX_KEY_LENGTH = 16;
                var DEFAULT_MAX_LENGTH_PER_KEY = 16;
                var CachedKeyDecoder = (
                  /** @class */
                  function() {
                    function CachedKeyDecoder2(maxKeyLength, maxLengthPerKey) {
                      if (maxKeyLength === void 0) {
                        maxKeyLength = DEFAULT_MAX_KEY_LENGTH;
                      }
                      if (maxLengthPerKey === void 0) {
                        maxLengthPerKey = DEFAULT_MAX_LENGTH_PER_KEY;
                      }
                      this.maxKeyLength = maxKeyLength;
                      this.maxLengthPerKey = maxLengthPerKey;
                      this.hit = 0;
                      this.miss = 0;
                      this.caches = [];
                      for (var i = 0; i < this.maxKeyLength; i++) {
                        this.caches.push([]);
                      }
                    }
                    CachedKeyDecoder2.prototype.canBeCached = function(byteLength) {
                      return byteLength > 0 && byteLength <= this.maxKeyLength;
                    };
                    CachedKeyDecoder2.prototype.find = function(bytes, inputOffset, byteLength) {
                      var records = this.caches[byteLength - 1];
                      FIND_CHUNK: for (var _i = 0, records_1 = records; _i < records_1.length; _i++) {
                        var record = records_1[_i];
                        var recordBytes = record.bytes;
                        for (var j = 0; j < byteLength; j++) {
                          if (recordBytes[j] !== bytes[inputOffset + j]) {
                            continue FIND_CHUNK;
                          }
                        }
                        return record.str;
                      }
                      return null;
                    };
                    CachedKeyDecoder2.prototype.store = function(bytes, value) {
                      var records = this.caches[bytes.length - 1];
                      var record = { bytes, str: value };
                      if (records.length >= this.maxLengthPerKey) {
                        records[Math.random() * records.length | 0] = record;
                      } else {
                        records.push(record);
                      }
                    };
                    CachedKeyDecoder2.prototype.decode = function(bytes, inputOffset, byteLength) {
                      var cachedValue = this.find(bytes, inputOffset, byteLength);
                      if (cachedValue != null) {
                        this.hit++;
                        return cachedValue;
                      }
                      this.miss++;
                      var str = (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_0__.utf8DecodeJs)(bytes, inputOffset, byteLength);
                      var slicedCopyOfBytes = Uint8Array.prototype.slice.call(bytes, inputOffset, inputOffset + byteLength);
                      this.store(slicedCopyOfBytes, str);
                      return str;
                    };
                    return CachedKeyDecoder2;
                  }()
                );
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/DecodeError.mjs": (
              /*!********************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/DecodeError.mjs ***!
                \********************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  DecodeError: () => (
                    /* binding */
                    DecodeError
                  )
                  /* harmony export */
                });
                var __extends = /* @__PURE__ */ function() {
                  var extendStatics = function(d, b) {
                    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
                      d2.__proto__ = b2;
                    } || function(d2, b2) {
                      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
                    };
                    return extendStatics(d, b);
                  };
                  return function(d, b) {
                    if (typeof b !== "function" && b !== null)
                      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
                    extendStatics(d, b);
                    function __() {
                      this.constructor = d;
                    }
                    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
                  };
                }();
                var DecodeError = (
                  /** @class */
                  function(_super) {
                    __extends(DecodeError2, _super);
                    function DecodeError2(message) {
                      var _this = _super.call(this, message) || this;
                      var proto = Object.create(DecodeError2.prototype);
                      Object.setPrototypeOf(_this, proto);
                      Object.defineProperty(_this, "name", {
                        configurable: true,
                        enumerable: false,
                        value: DecodeError2.name
                      });
                      return _this;
                    }
                    return DecodeError2;
                  }(Error)
                );
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/Decoder.mjs": (
              /*!****************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/Decoder.mjs ***!
                \****************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  DataViewIndexOutOfBoundsError: () => (
                    /* binding */
                    DataViewIndexOutOfBoundsError
                  ),
                  /* harmony export */
                  Decoder: () => (
                    /* binding */
                    Decoder
                  )
                  /* harmony export */
                });
                var _utils_prettyByte_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__2(
                  /*! ./utils/prettyByte.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/prettyByte.mjs"
                );
                var _ExtensionCodec_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__2(
                  /*! ./ExtensionCodec.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/ExtensionCodec.mjs"
                );
                var _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__2(
                  /*! ./utils/int.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/int.mjs"
                );
                var _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__2(
                  /*! ./utils/utf8.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/utf8.mjs"
                );
                var _utils_typedArrays_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__2(
                  /*! ./utils/typedArrays.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/typedArrays.mjs"
                );
                var _CachedKeyDecoder_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./CachedKeyDecoder.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/CachedKeyDecoder.mjs"
                );
                var _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__2(
                  /*! ./DecodeError.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/DecodeError.mjs"
                );
                var __awaiter = function(thisArg, _arguments, P, generator) {
                  function adopt(value) {
                    return value instanceof P ? value : new P(function(resolve2) {
                      resolve2(value);
                    });
                  }
                  return new (P || (P = Promise))(function(resolve2, reject2) {
                    function fulfilled(value) {
                      try {
                        step(generator.next(value));
                      } catch (e) {
                        reject2(e);
                      }
                    }
                    function rejected(value) {
                      try {
                        step(generator["throw"](value));
                      } catch (e) {
                        reject2(e);
                      }
                    }
                    function step(result) {
                      result.done ? resolve2(result.value) : adopt(result.value).then(fulfilled, rejected);
                    }
                    step((generator = generator.apply(thisArg, _arguments || [])).next());
                  });
                };
                var __generator = function(thisArg, body) {
                  var _ = { label: 0, sent: function() {
                    if (t[0] & 1) throw t[1];
                    return t[1];
                  }, trys: [], ops: [] }, f, y, t, g;
                  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
                    return this;
                  }), g;
                  function verb(n) {
                    return function(v) {
                      return step([n, v]);
                    };
                  }
                  function step(op) {
                    if (f) throw new TypeError("Generator is already executing.");
                    while (_) try {
                      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                      if (y = 0, t) op = [op[0] & 2, t.value];
                      switch (op[0]) {
                        case 0:
                        case 1:
                          t = op;
                          break;
                        case 4:
                          _.label++;
                          return { value: op[1], done: false };
                        case 5:
                          _.label++;
                          y = op[1];
                          op = [0];
                          continue;
                        case 7:
                          op = _.ops.pop();
                          _.trys.pop();
                          continue;
                        default:
                          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                            _ = 0;
                            continue;
                          }
                          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                            _.label = op[1];
                            break;
                          }
                          if (op[0] === 6 && _.label < t[1]) {
                            _.label = t[1];
                            t = op;
                            break;
                          }
                          if (t && _.label < t[2]) {
                            _.label = t[2];
                            _.ops.push(op);
                            break;
                          }
                          if (t[2]) _.ops.pop();
                          _.trys.pop();
                          continue;
                      }
                      op = body.call(thisArg, _);
                    } catch (e) {
                      op = [6, e];
                      y = 0;
                    } finally {
                      f = t = 0;
                    }
                    if (op[0] & 5) throw op[1];
                    return { value: op[0] ? op[1] : void 0, done: true };
                  }
                };
                var __asyncValues = function(o) {
                  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
                  var m = o[Symbol.asyncIterator], i;
                  return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
                    return this;
                  }, i);
                  function verb(n) {
                    i[n] = o[n] && function(v) {
                      return new Promise(function(resolve2, reject2) {
                        v = o[n](v), settle(resolve2, reject2, v.done, v.value);
                      });
                    };
                  }
                  function settle(resolve2, reject2, d, v) {
                    Promise.resolve(v).then(function(v2) {
                      resolve2({ value: v2, done: d });
                    }, reject2);
                  }
                };
                var __await = function(v) {
                  return this instanceof __await ? (this.v = v, this) : new __await(v);
                };
                var __asyncGenerator = function(thisArg, _arguments, generator) {
                  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
                  var g = generator.apply(thisArg, _arguments || []), i, q = [];
                  return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
                    return this;
                  }, i;
                  function verb(n) {
                    if (g[n]) i[n] = function(v) {
                      return new Promise(function(a, b) {
                        q.push([n, v, a, b]) > 1 || resume(n, v);
                      });
                    };
                  }
                  function resume(n, v) {
                    try {
                      step(g[n](v));
                    } catch (e) {
                      settle(q[0][3], e);
                    }
                  }
                  function step(r) {
                    r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject2) : settle(q[0][2], r);
                  }
                  function fulfill(value) {
                    resume("next", value);
                  }
                  function reject2(value) {
                    resume("throw", value);
                  }
                  function settle(f, v) {
                    if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
                  }
                };
                var isValidMapKeyType = function(key) {
                  var keyType = typeof key;
                  return keyType === "string" || keyType === "number";
                };
                var HEAD_BYTE_REQUIRED = -1;
                var EMPTY_VIEW = new DataView(new ArrayBuffer(0));
                var EMPTY_BYTES = new Uint8Array(EMPTY_VIEW.buffer);
                var DataViewIndexOutOfBoundsError = function() {
                  try {
                    EMPTY_VIEW.getInt8(0);
                  } catch (e) {
                    return e.constructor;
                  }
                  throw new Error("never reached");
                }();
                var MORE_DATA = new DataViewIndexOutOfBoundsError("Insufficient data");
                var sharedCachedKeyDecoder = new _CachedKeyDecoder_mjs__WEBPACK_IMPORTED_MODULE_0__.CachedKeyDecoder();
                var Decoder = (
                  /** @class */
                  function() {
                    function Decoder2(extensionCodec, context2, maxStrLength, maxBinLength, maxArrayLength, maxMapLength, maxExtLength, keyDecoder) {
                      if (extensionCodec === void 0) {
                        extensionCodec = _ExtensionCodec_mjs__WEBPACK_IMPORTED_MODULE_1__.ExtensionCodec.defaultCodec;
                      }
                      if (context2 === void 0) {
                        context2 = void 0;
                      }
                      if (maxStrLength === void 0) {
                        maxStrLength = _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.UINT32_MAX;
                      }
                      if (maxBinLength === void 0) {
                        maxBinLength = _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.UINT32_MAX;
                      }
                      if (maxArrayLength === void 0) {
                        maxArrayLength = _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.UINT32_MAX;
                      }
                      if (maxMapLength === void 0) {
                        maxMapLength = _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.UINT32_MAX;
                      }
                      if (maxExtLength === void 0) {
                        maxExtLength = _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.UINT32_MAX;
                      }
                      if (keyDecoder === void 0) {
                        keyDecoder = sharedCachedKeyDecoder;
                      }
                      this.extensionCodec = extensionCodec;
                      this.context = context2;
                      this.maxStrLength = maxStrLength;
                      this.maxBinLength = maxBinLength;
                      this.maxArrayLength = maxArrayLength;
                      this.maxMapLength = maxMapLength;
                      this.maxExtLength = maxExtLength;
                      this.keyDecoder = keyDecoder;
                      this.totalPos = 0;
                      this.pos = 0;
                      this.view = EMPTY_VIEW;
                      this.bytes = EMPTY_BYTES;
                      this.headByte = HEAD_BYTE_REQUIRED;
                      this.stack = [];
                    }
                    Decoder2.prototype.reinitializeState = function() {
                      this.totalPos = 0;
                      this.headByte = HEAD_BYTE_REQUIRED;
                      this.stack.length = 0;
                    };
                    Decoder2.prototype.setBuffer = function(buffer) {
                      this.bytes = (0, _utils_typedArrays_mjs__WEBPACK_IMPORTED_MODULE_3__.ensureUint8Array)(buffer);
                      this.view = (0, _utils_typedArrays_mjs__WEBPACK_IMPORTED_MODULE_3__.createDataView)(this.bytes);
                      this.pos = 0;
                    };
                    Decoder2.prototype.appendBuffer = function(buffer) {
                      if (this.headByte === HEAD_BYTE_REQUIRED && !this.hasRemaining(1)) {
                        this.setBuffer(buffer);
                      } else {
                        var remainingData = this.bytes.subarray(this.pos);
                        var newData = (0, _utils_typedArrays_mjs__WEBPACK_IMPORTED_MODULE_3__.ensureUint8Array)(buffer);
                        var newBuffer = new Uint8Array(remainingData.length + newData.length);
                        newBuffer.set(remainingData);
                        newBuffer.set(newData, remainingData.length);
                        this.setBuffer(newBuffer);
                      }
                    };
                    Decoder2.prototype.hasRemaining = function(size) {
                      return this.view.byteLength - this.pos >= size;
                    };
                    Decoder2.prototype.createExtraByteError = function(posToShow) {
                      var _a = this, view = _a.view, pos = _a.pos;
                      return new RangeError("Extra ".concat(view.byteLength - pos, " of ").concat(view.byteLength, " byte(s) found at buffer[").concat(posToShow, "]"));
                    };
                    Decoder2.prototype.decode = function(buffer) {
                      this.reinitializeState();
                      this.setBuffer(buffer);
                      var object = this.doDecodeSync();
                      if (this.hasRemaining(1)) {
                        throw this.createExtraByteError(this.pos);
                      }
                      return object;
                    };
                    Decoder2.prototype.decodeMulti = function(buffer) {
                      return __generator(this, function(_a) {
                        switch (_a.label) {
                          case 0:
                            this.reinitializeState();
                            this.setBuffer(buffer);
                            _a.label = 1;
                          case 1:
                            if (!this.hasRemaining(1)) return [3, 3];
                            return [4, this.doDecodeSync()];
                          case 2:
                            _a.sent();
                            return [3, 1];
                          case 3:
                            return [
                              2
                              /*return*/
                            ];
                        }
                      });
                    };
                    Decoder2.prototype.decodeAsync = function(stream) {
                      var stream_1, stream_1_1;
                      var e_1, _a;
                      return __awaiter(this, void 0, void 0, function() {
                        var decoded, object, buffer, e_1_1, _b, headByte, pos, totalPos;
                        return __generator(this, function(_c) {
                          switch (_c.label) {
                            case 0:
                              decoded = false;
                              _c.label = 1;
                            case 1:
                              _c.trys.push([1, 6, 7, 12]);
                              stream_1 = __asyncValues(stream);
                              _c.label = 2;
                            case 2:
                              return [4, stream_1.next()];
                            case 3:
                              if (!(stream_1_1 = _c.sent(), !stream_1_1.done)) return [3, 5];
                              buffer = stream_1_1.value;
                              if (decoded) {
                                throw this.createExtraByteError(this.totalPos);
                              }
                              this.appendBuffer(buffer);
                              try {
                                object = this.doDecodeSync();
                                decoded = true;
                              } catch (e) {
                                if (!(e instanceof DataViewIndexOutOfBoundsError)) {
                                  throw e;
                                }
                              }
                              this.totalPos += this.pos;
                              _c.label = 4;
                            case 4:
                              return [3, 2];
                            case 5:
                              return [3, 12];
                            case 6:
                              e_1_1 = _c.sent();
                              e_1 = { error: e_1_1 };
                              return [3, 12];
                            case 7:
                              _c.trys.push([7, , 10, 11]);
                              if (!(stream_1_1 && !stream_1_1.done && (_a = stream_1.return))) return [3, 9];
                              return [4, _a.call(stream_1)];
                            case 8:
                              _c.sent();
                              _c.label = 9;
                            case 9:
                              return [3, 11];
                            case 10:
                              if (e_1) throw e_1.error;
                              return [
                                7
                                /*endfinally*/
                              ];
                            case 11:
                              return [
                                7
                                /*endfinally*/
                              ];
                            case 12:
                              if (decoded) {
                                if (this.hasRemaining(1)) {
                                  throw this.createExtraByteError(this.totalPos);
                                }
                                return [2, object];
                              }
                              _b = this, headByte = _b.headByte, pos = _b.pos, totalPos = _b.totalPos;
                              throw new RangeError("Insufficient data in parsing ".concat((0, _utils_prettyByte_mjs__WEBPACK_IMPORTED_MODULE_4__.prettyByte)(headByte), " at ").concat(totalPos, " (").concat(pos, " in the current buffer)"));
                          }
                        });
                      });
                    };
                    Decoder2.prototype.decodeArrayStream = function(stream) {
                      return this.decodeMultiAsync(stream, true);
                    };
                    Decoder2.prototype.decodeStream = function(stream) {
                      return this.decodeMultiAsync(stream, false);
                    };
                    Decoder2.prototype.decodeMultiAsync = function(stream, isArray) {
                      return __asyncGenerator(this, arguments, function decodeMultiAsync_1() {
                        var isArrayHeaderRequired, arrayItemsLeft, stream_2, stream_2_1, buffer, e_2, e_3_1;
                        var e_3, _a;
                        return __generator(this, function(_b) {
                          switch (_b.label) {
                            case 0:
                              isArrayHeaderRequired = isArray;
                              arrayItemsLeft = -1;
                              _b.label = 1;
                            case 1:
                              _b.trys.push([1, 13, 14, 19]);
                              stream_2 = __asyncValues(stream);
                              _b.label = 2;
                            case 2:
                              return [4, __await(stream_2.next())];
                            case 3:
                              if (!(stream_2_1 = _b.sent(), !stream_2_1.done)) return [3, 12];
                              buffer = stream_2_1.value;
                              if (isArray && arrayItemsLeft === 0) {
                                throw this.createExtraByteError(this.totalPos);
                              }
                              this.appendBuffer(buffer);
                              if (isArrayHeaderRequired) {
                                arrayItemsLeft = this.readArraySize();
                                isArrayHeaderRequired = false;
                                this.complete();
                              }
                              _b.label = 4;
                            case 4:
                              _b.trys.push([4, 9, , 10]);
                              _b.label = 5;
                            case 5:
                              if (false) {
                              }
                              return [4, __await(this.doDecodeSync())];
                            case 6:
                              return [4, _b.sent()];
                            case 7:
                              _b.sent();
                              if (--arrayItemsLeft === 0) {
                                return [3, 8];
                              }
                              return [3, 5];
                            case 8:
                              return [3, 10];
                            case 9:
                              e_2 = _b.sent();
                              if (!(e_2 instanceof DataViewIndexOutOfBoundsError)) {
                                throw e_2;
                              }
                              return [3, 10];
                            case 10:
                              this.totalPos += this.pos;
                              _b.label = 11;
                            case 11:
                              return [3, 2];
                            case 12:
                              return [3, 19];
                            case 13:
                              e_3_1 = _b.sent();
                              e_3 = { error: e_3_1 };
                              return [3, 19];
                            case 14:
                              _b.trys.push([14, , 17, 18]);
                              if (!(stream_2_1 && !stream_2_1.done && (_a = stream_2.return))) return [3, 16];
                              return [4, __await(_a.call(stream_2))];
                            case 15:
                              _b.sent();
                              _b.label = 16;
                            case 16:
                              return [3, 18];
                            case 17:
                              if (e_3) throw e_3.error;
                              return [
                                7
                                /*endfinally*/
                              ];
                            case 18:
                              return [
                                7
                                /*endfinally*/
                              ];
                            case 19:
                              return [
                                2
                                /*return*/
                              ];
                          }
                        });
                      });
                    };
                    Decoder2.prototype.doDecodeSync = function() {
                      DECODE: while (true) {
                        var headByte = this.readHeadByte();
                        var object = void 0;
                        if (headByte >= 224) {
                          object = headByte - 256;
                        } else if (headByte < 192) {
                          if (headByte < 128) {
                            object = headByte;
                          } else if (headByte < 144) {
                            var size = headByte - 128;
                            if (size !== 0) {
                              this.pushMapState(size);
                              this.complete();
                              continue DECODE;
                            } else {
                              object = {};
                            }
                          } else if (headByte < 160) {
                            var size = headByte - 144;
                            if (size !== 0) {
                              this.pushArrayState(size);
                              this.complete();
                              continue DECODE;
                            } else {
                              object = [];
                            }
                          } else {
                            var byteLength = headByte - 160;
                            object = this.decodeUtf8String(byteLength, 0);
                          }
                        } else if (headByte === 192) {
                          object = null;
                        } else if (headByte === 194) {
                          object = false;
                        } else if (headByte === 195) {
                          object = true;
                        } else if (headByte === 202) {
                          object = this.readF32();
                        } else if (headByte === 203) {
                          object = this.readF64();
                        } else if (headByte === 204) {
                          object = this.readU8();
                        } else if (headByte === 205) {
                          object = this.readU16();
                        } else if (headByte === 206) {
                          object = this.readU32();
                        } else if (headByte === 207) {
                          object = this.readU64();
                        } else if (headByte === 208) {
                          object = this.readI8();
                        } else if (headByte === 209) {
                          object = this.readI16();
                        } else if (headByte === 210) {
                          object = this.readI32();
                        } else if (headByte === 211) {
                          object = this.readI64();
                        } else if (headByte === 217) {
                          var byteLength = this.lookU8();
                          object = this.decodeUtf8String(byteLength, 1);
                        } else if (headByte === 218) {
                          var byteLength = this.lookU16();
                          object = this.decodeUtf8String(byteLength, 2);
                        } else if (headByte === 219) {
                          var byteLength = this.lookU32();
                          object = this.decodeUtf8String(byteLength, 4);
                        } else if (headByte === 220) {
                          var size = this.readU16();
                          if (size !== 0) {
                            this.pushArrayState(size);
                            this.complete();
                            continue DECODE;
                          } else {
                            object = [];
                          }
                        } else if (headByte === 221) {
                          var size = this.readU32();
                          if (size !== 0) {
                            this.pushArrayState(size);
                            this.complete();
                            continue DECODE;
                          } else {
                            object = [];
                          }
                        } else if (headByte === 222) {
                          var size = this.readU16();
                          if (size !== 0) {
                            this.pushMapState(size);
                            this.complete();
                            continue DECODE;
                          } else {
                            object = {};
                          }
                        } else if (headByte === 223) {
                          var size = this.readU32();
                          if (size !== 0) {
                            this.pushMapState(size);
                            this.complete();
                            continue DECODE;
                          } else {
                            object = {};
                          }
                        } else if (headByte === 196) {
                          var size = this.lookU8();
                          object = this.decodeBinary(size, 1);
                        } else if (headByte === 197) {
                          var size = this.lookU16();
                          object = this.decodeBinary(size, 2);
                        } else if (headByte === 198) {
                          var size = this.lookU32();
                          object = this.decodeBinary(size, 4);
                        } else if (headByte === 212) {
                          object = this.decodeExtension(1, 0);
                        } else if (headByte === 213) {
                          object = this.decodeExtension(2, 0);
                        } else if (headByte === 214) {
                          object = this.decodeExtension(4, 0);
                        } else if (headByte === 215) {
                          object = this.decodeExtension(8, 0);
                        } else if (headByte === 216) {
                          object = this.decodeExtension(16, 0);
                        } else if (headByte === 199) {
                          var size = this.lookU8();
                          object = this.decodeExtension(size, 1);
                        } else if (headByte === 200) {
                          var size = this.lookU16();
                          object = this.decodeExtension(size, 2);
                        } else if (headByte === 201) {
                          var size = this.lookU32();
                          object = this.decodeExtension(size, 4);
                        } else {
                          throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Unrecognized type byte: ".concat((0, _utils_prettyByte_mjs__WEBPACK_IMPORTED_MODULE_4__.prettyByte)(headByte)));
                        }
                        this.complete();
                        var stack = this.stack;
                        while (stack.length > 0) {
                          var state = stack[stack.length - 1];
                          if (state.type === 0) {
                            state.array[state.position] = object;
                            state.position++;
                            if (state.position === state.size) {
                              stack.pop();
                              object = state.array;
                            } else {
                              continue DECODE;
                            }
                          } else if (state.type === 1) {
                            if (!isValidMapKeyType(object)) {
                              throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("The type of key must be string or number but " + typeof object);
                            }
                            if (object === "__proto__") {
                              throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("The key __proto__ is not allowed");
                            }
                            state.key = object;
                            state.type = 2;
                            continue DECODE;
                          } else {
                            state.map[state.key] = object;
                            state.readCount++;
                            if (state.readCount === state.size) {
                              stack.pop();
                              object = state.map;
                            } else {
                              state.key = null;
                              state.type = 1;
                              continue DECODE;
                            }
                          }
                        }
                        return object;
                      }
                    };
                    Decoder2.prototype.readHeadByte = function() {
                      if (this.headByte === HEAD_BYTE_REQUIRED) {
                        this.headByte = this.readU8();
                      }
                      return this.headByte;
                    };
                    Decoder2.prototype.complete = function() {
                      this.headByte = HEAD_BYTE_REQUIRED;
                    };
                    Decoder2.prototype.readArraySize = function() {
                      var headByte = this.readHeadByte();
                      switch (headByte) {
                        case 220:
                          return this.readU16();
                        case 221:
                          return this.readU32();
                        default: {
                          if (headByte < 160) {
                            return headByte - 144;
                          } else {
                            throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Unrecognized array type byte: ".concat((0, _utils_prettyByte_mjs__WEBPACK_IMPORTED_MODULE_4__.prettyByte)(headByte)));
                          }
                        }
                      }
                    };
                    Decoder2.prototype.pushMapState = function(size) {
                      if (size > this.maxMapLength) {
                        throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Max length exceeded: map length (".concat(size, ") > maxMapLengthLength (").concat(this.maxMapLength, ")"));
                      }
                      this.stack.push({
                        type: 1,
                        size,
                        key: null,
                        readCount: 0,
                        map: {}
                      });
                    };
                    Decoder2.prototype.pushArrayState = function(size) {
                      if (size > this.maxArrayLength) {
                        throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Max length exceeded: array length (".concat(size, ") > maxArrayLength (").concat(this.maxArrayLength, ")"));
                      }
                      this.stack.push({
                        type: 0,
                        size,
                        array: new Array(size),
                        position: 0
                      });
                    };
                    Decoder2.prototype.decodeUtf8String = function(byteLength, headerOffset) {
                      var _a;
                      if (byteLength > this.maxStrLength) {
                        throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Max length exceeded: UTF-8 byte length (".concat(byteLength, ") > maxStrLength (").concat(this.maxStrLength, ")"));
                      }
                      if (this.bytes.byteLength < this.pos + headerOffset + byteLength) {
                        throw MORE_DATA;
                      }
                      var offset = this.pos + headerOffset;
                      var object;
                      if (this.stateIsMapKey() && ((_a = this.keyDecoder) === null || _a === void 0 ? void 0 : _a.canBeCached(byteLength))) {
                        object = this.keyDecoder.decode(this.bytes, offset, byteLength);
                      } else if (byteLength > _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_6__.TEXT_DECODER_THRESHOLD) {
                        object = (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_6__.utf8DecodeTD)(this.bytes, offset, byteLength);
                      } else {
                        object = (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_6__.utf8DecodeJs)(this.bytes, offset, byteLength);
                      }
                      this.pos += headerOffset + byteLength;
                      return object;
                    };
                    Decoder2.prototype.stateIsMapKey = function() {
                      if (this.stack.length > 0) {
                        var state = this.stack[this.stack.length - 1];
                        return state.type === 1;
                      }
                      return false;
                    };
                    Decoder2.prototype.decodeBinary = function(byteLength, headOffset) {
                      if (byteLength > this.maxBinLength) {
                        throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Max length exceeded: bin length (".concat(byteLength, ") > maxBinLength (").concat(this.maxBinLength, ")"));
                      }
                      if (!this.hasRemaining(byteLength + headOffset)) {
                        throw MORE_DATA;
                      }
                      var offset = this.pos + headOffset;
                      var object = this.bytes.subarray(offset, offset + byteLength);
                      this.pos += headOffset + byteLength;
                      return object;
                    };
                    Decoder2.prototype.decodeExtension = function(size, headOffset) {
                      if (size > this.maxExtLength) {
                        throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Max length exceeded: ext length (".concat(size, ") > maxExtLength (").concat(this.maxExtLength, ")"));
                      }
                      var extType = this.view.getInt8(this.pos + headOffset);
                      var data = this.decodeBinary(
                        size,
                        headOffset + 1
                        /* extType */
                      );
                      return this.extensionCodec.decode(data, extType, this.context);
                    };
                    Decoder2.prototype.lookU8 = function() {
                      return this.view.getUint8(this.pos);
                    };
                    Decoder2.prototype.lookU16 = function() {
                      return this.view.getUint16(this.pos);
                    };
                    Decoder2.prototype.lookU32 = function() {
                      return this.view.getUint32(this.pos);
                    };
                    Decoder2.prototype.readU8 = function() {
                      var value = this.view.getUint8(this.pos);
                      this.pos++;
                      return value;
                    };
                    Decoder2.prototype.readI8 = function() {
                      var value = this.view.getInt8(this.pos);
                      this.pos++;
                      return value;
                    };
                    Decoder2.prototype.readU16 = function() {
                      var value = this.view.getUint16(this.pos);
                      this.pos += 2;
                      return value;
                    };
                    Decoder2.prototype.readI16 = function() {
                      var value = this.view.getInt16(this.pos);
                      this.pos += 2;
                      return value;
                    };
                    Decoder2.prototype.readU32 = function() {
                      var value = this.view.getUint32(this.pos);
                      this.pos += 4;
                      return value;
                    };
                    Decoder2.prototype.readI32 = function() {
                      var value = this.view.getInt32(this.pos);
                      this.pos += 4;
                      return value;
                    };
                    Decoder2.prototype.readU64 = function() {
                      var value = (0, _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.getUint64)(this.view, this.pos);
                      this.pos += 8;
                      return value;
                    };
                    Decoder2.prototype.readI64 = function() {
                      var value = (0, _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.getInt64)(this.view, this.pos);
                      this.pos += 8;
                      return value;
                    };
                    Decoder2.prototype.readF32 = function() {
                      var value = this.view.getFloat32(this.pos);
                      this.pos += 4;
                      return value;
                    };
                    Decoder2.prototype.readF64 = function() {
                      var value = this.view.getFloat64(this.pos);
                      this.pos += 8;
                      return value;
                    };
                    return Decoder2;
                  }()
                );
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/Encoder.mjs": (
              /*!****************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/Encoder.mjs ***!
                \****************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  DEFAULT_INITIAL_BUFFER_SIZE: () => (
                    /* binding */
                    DEFAULT_INITIAL_BUFFER_SIZE
                  ),
                  /* harmony export */
                  DEFAULT_MAX_DEPTH: () => (
                    /* binding */
                    DEFAULT_MAX_DEPTH
                  ),
                  /* harmony export */
                  Encoder: () => (
                    /* binding */
                    Encoder
                  )
                  /* harmony export */
                });
                var _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__2(
                  /*! ./utils/utf8.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/utf8.mjs"
                );
                var _ExtensionCodec_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./ExtensionCodec.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/ExtensionCodec.mjs"
                );
                var _utils_int_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__2(
                  /*! ./utils/int.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/int.mjs"
                );
                var _utils_typedArrays_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__2(
                  /*! ./utils/typedArrays.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/typedArrays.mjs"
                );
                var DEFAULT_MAX_DEPTH = 100;
                var DEFAULT_INITIAL_BUFFER_SIZE = 2048;
                var Encoder = (
                  /** @class */
                  function() {
                    function Encoder2(extensionCodec, context2, maxDepth, initialBufferSize, sortKeys, forceFloat32, ignoreUndefined, forceIntegerToFloat) {
                      if (extensionCodec === void 0) {
                        extensionCodec = _ExtensionCodec_mjs__WEBPACK_IMPORTED_MODULE_0__.ExtensionCodec.defaultCodec;
                      }
                      if (context2 === void 0) {
                        context2 = void 0;
                      }
                      if (maxDepth === void 0) {
                        maxDepth = DEFAULT_MAX_DEPTH;
                      }
                      if (initialBufferSize === void 0) {
                        initialBufferSize = DEFAULT_INITIAL_BUFFER_SIZE;
                      }
                      if (sortKeys === void 0) {
                        sortKeys = false;
                      }
                      if (forceFloat32 === void 0) {
                        forceFloat32 = false;
                      }
                      if (ignoreUndefined === void 0) {
                        ignoreUndefined = false;
                      }
                      if (forceIntegerToFloat === void 0) {
                        forceIntegerToFloat = false;
                      }
                      this.extensionCodec = extensionCodec;
                      this.context = context2;
                      this.maxDepth = maxDepth;
                      this.initialBufferSize = initialBufferSize;
                      this.sortKeys = sortKeys;
                      this.forceFloat32 = forceFloat32;
                      this.ignoreUndefined = ignoreUndefined;
                      this.forceIntegerToFloat = forceIntegerToFloat;
                      this.pos = 0;
                      this.view = new DataView(new ArrayBuffer(this.initialBufferSize));
                      this.bytes = new Uint8Array(this.view.buffer);
                    }
                    Encoder2.prototype.reinitializeState = function() {
                      this.pos = 0;
                    };
                    Encoder2.prototype.encodeSharedRef = function(object) {
                      this.reinitializeState();
                      this.doEncode(object, 1);
                      return this.bytes.subarray(0, this.pos);
                    };
                    Encoder2.prototype.encode = function(object) {
                      this.reinitializeState();
                      this.doEncode(object, 1);
                      return this.bytes.slice(0, this.pos);
                    };
                    Encoder2.prototype.doEncode = function(object, depth) {
                      if (depth > this.maxDepth) {
                        throw new Error("Too deep objects in depth ".concat(depth));
                      }
                      if (object == null) {
                        this.encodeNil();
                      } else if (typeof object === "boolean") {
                        this.encodeBoolean(object);
                      } else if (typeof object === "number") {
                        this.encodeNumber(object);
                      } else if (typeof object === "string") {
                        this.encodeString(object);
                      } else {
                        this.encodeObject(object, depth);
                      }
                    };
                    Encoder2.prototype.ensureBufferSizeToWrite = function(sizeToWrite) {
                      var requiredSize = this.pos + sizeToWrite;
                      if (this.view.byteLength < requiredSize) {
                        this.resizeBuffer(requiredSize * 2);
                      }
                    };
                    Encoder2.prototype.resizeBuffer = function(newSize) {
                      var newBuffer = new ArrayBuffer(newSize);
                      var newBytes = new Uint8Array(newBuffer);
                      var newView = new DataView(newBuffer);
                      newBytes.set(this.bytes);
                      this.view = newView;
                      this.bytes = newBytes;
                    };
                    Encoder2.prototype.encodeNil = function() {
                      this.writeU8(192);
                    };
                    Encoder2.prototype.encodeBoolean = function(object) {
                      if (object === false) {
                        this.writeU8(194);
                      } else {
                        this.writeU8(195);
                      }
                    };
                    Encoder2.prototype.encodeNumber = function(object) {
                      if (Number.isSafeInteger(object) && !this.forceIntegerToFloat) {
                        if (object >= 0) {
                          if (object < 128) {
                            this.writeU8(object);
                          } else if (object < 256) {
                            this.writeU8(204);
                            this.writeU8(object);
                          } else if (object < 65536) {
                            this.writeU8(205);
                            this.writeU16(object);
                          } else if (object < 4294967296) {
                            this.writeU8(206);
                            this.writeU32(object);
                          } else {
                            this.writeU8(207);
                            this.writeU64(object);
                          }
                        } else {
                          if (object >= -32) {
                            this.writeU8(224 | object + 32);
                          } else if (object >= -128) {
                            this.writeU8(208);
                            this.writeI8(object);
                          } else if (object >= -32768) {
                            this.writeU8(209);
                            this.writeI16(object);
                          } else if (object >= -2147483648) {
                            this.writeU8(210);
                            this.writeI32(object);
                          } else {
                            this.writeU8(211);
                            this.writeI64(object);
                          }
                        }
                      } else {
                        if (this.forceFloat32) {
                          this.writeU8(202);
                          this.writeF32(object);
                        } else {
                          this.writeU8(203);
                          this.writeF64(object);
                        }
                      }
                    };
                    Encoder2.prototype.writeStringHeader = function(byteLength) {
                      if (byteLength < 32) {
                        this.writeU8(160 + byteLength);
                      } else if (byteLength < 256) {
                        this.writeU8(217);
                        this.writeU8(byteLength);
                      } else if (byteLength < 65536) {
                        this.writeU8(218);
                        this.writeU16(byteLength);
                      } else if (byteLength < 4294967296) {
                        this.writeU8(219);
                        this.writeU32(byteLength);
                      } else {
                        throw new Error("Too long string: ".concat(byteLength, " bytes in UTF-8"));
                      }
                    };
                    Encoder2.prototype.encodeString = function(object) {
                      var maxHeaderSize = 1 + 4;
                      var strLength = object.length;
                      if (strLength > _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_1__.TEXT_ENCODER_THRESHOLD) {
                        var byteLength = (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_1__.utf8Count)(object);
                        this.ensureBufferSizeToWrite(maxHeaderSize + byteLength);
                        this.writeStringHeader(byteLength);
                        (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_1__.utf8EncodeTE)(object, this.bytes, this.pos);
                        this.pos += byteLength;
                      } else {
                        var byteLength = (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_1__.utf8Count)(object);
                        this.ensureBufferSizeToWrite(maxHeaderSize + byteLength);
                        this.writeStringHeader(byteLength);
                        (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_1__.utf8EncodeJs)(object, this.bytes, this.pos);
                        this.pos += byteLength;
                      }
                    };
                    Encoder2.prototype.encodeObject = function(object, depth) {
                      var ext = this.extensionCodec.tryToEncode(object, this.context);
                      if (ext != null) {
                        this.encodeExtension(ext);
                      } else if (Array.isArray(object)) {
                        this.encodeArray(object, depth);
                      } else if (ArrayBuffer.isView(object)) {
                        this.encodeBinary(object);
                      } else if (typeof object === "object") {
                        this.encodeMap(object, depth);
                      } else {
                        throw new Error("Unrecognized object: ".concat(Object.prototype.toString.apply(object)));
                      }
                    };
                    Encoder2.prototype.encodeBinary = function(object) {
                      var size = object.byteLength;
                      if (size < 256) {
                        this.writeU8(196);
                        this.writeU8(size);
                      } else if (size < 65536) {
                        this.writeU8(197);
                        this.writeU16(size);
                      } else if (size < 4294967296) {
                        this.writeU8(198);
                        this.writeU32(size);
                      } else {
                        throw new Error("Too large binary: ".concat(size));
                      }
                      var bytes = (0, _utils_typedArrays_mjs__WEBPACK_IMPORTED_MODULE_2__.ensureUint8Array)(object);
                      this.writeU8a(bytes);
                    };
                    Encoder2.prototype.encodeArray = function(object, depth) {
                      var size = object.length;
                      if (size < 16) {
                        this.writeU8(144 + size);
                      } else if (size < 65536) {
                        this.writeU8(220);
                        this.writeU16(size);
                      } else if (size < 4294967296) {
                        this.writeU8(221);
                        this.writeU32(size);
                      } else {
                        throw new Error("Too large array: ".concat(size));
                      }
                      for (var _i = 0, object_1 = object; _i < object_1.length; _i++) {
                        var item = object_1[_i];
                        this.doEncode(item, depth + 1);
                      }
                    };
                    Encoder2.prototype.countWithoutUndefined = function(object, keys) {
                      var count = 0;
                      for (var _i = 0, keys_1 = keys; _i < keys_1.length; _i++) {
                        var key = keys_1[_i];
                        if (object[key] !== void 0) {
                          count++;
                        }
                      }
                      return count;
                    };
                    Encoder2.prototype.encodeMap = function(object, depth) {
                      var keys = Object.keys(object);
                      if (this.sortKeys) {
                        keys.sort();
                      }
                      var size = this.ignoreUndefined ? this.countWithoutUndefined(object, keys) : keys.length;
                      if (size < 16) {
                        this.writeU8(128 + size);
                      } else if (size < 65536) {
                        this.writeU8(222);
                        this.writeU16(size);
                      } else if (size < 4294967296) {
                        this.writeU8(223);
                        this.writeU32(size);
                      } else {
                        throw new Error("Too large map object: ".concat(size));
                      }
                      for (var _i = 0, keys_2 = keys; _i < keys_2.length; _i++) {
                        var key = keys_2[_i];
                        var value = object[key];
                        if (!(this.ignoreUndefined && value === void 0)) {
                          this.encodeString(key);
                          this.doEncode(value, depth + 1);
                        }
                      }
                    };
                    Encoder2.prototype.encodeExtension = function(ext) {
                      var size = ext.data.length;
                      if (size === 1) {
                        this.writeU8(212);
                      } else if (size === 2) {
                        this.writeU8(213);
                      } else if (size === 4) {
                        this.writeU8(214);
                      } else if (size === 8) {
                        this.writeU8(215);
                      } else if (size === 16) {
                        this.writeU8(216);
                      } else if (size < 256) {
                        this.writeU8(199);
                        this.writeU8(size);
                      } else if (size < 65536) {
                        this.writeU8(200);
                        this.writeU16(size);
                      } else if (size < 4294967296) {
                        this.writeU8(201);
                        this.writeU32(size);
                      } else {
                        throw new Error("Too large extension object: ".concat(size));
                      }
                      this.writeI8(ext.type);
                      this.writeU8a(ext.data);
                    };
                    Encoder2.prototype.writeU8 = function(value) {
                      this.ensureBufferSizeToWrite(1);
                      this.view.setUint8(this.pos, value);
                      this.pos++;
                    };
                    Encoder2.prototype.writeU8a = function(values) {
                      var size = values.length;
                      this.ensureBufferSizeToWrite(size);
                      this.bytes.set(values, this.pos);
                      this.pos += size;
                    };
                    Encoder2.prototype.writeI8 = function(value) {
                      this.ensureBufferSizeToWrite(1);
                      this.view.setInt8(this.pos, value);
                      this.pos++;
                    };
                    Encoder2.prototype.writeU16 = function(value) {
                      this.ensureBufferSizeToWrite(2);
                      this.view.setUint16(this.pos, value);
                      this.pos += 2;
                    };
                    Encoder2.prototype.writeI16 = function(value) {
                      this.ensureBufferSizeToWrite(2);
                      this.view.setInt16(this.pos, value);
                      this.pos += 2;
                    };
                    Encoder2.prototype.writeU32 = function(value) {
                      this.ensureBufferSizeToWrite(4);
                      this.view.setUint32(this.pos, value);
                      this.pos += 4;
                    };
                    Encoder2.prototype.writeI32 = function(value) {
                      this.ensureBufferSizeToWrite(4);
                      this.view.setInt32(this.pos, value);
                      this.pos += 4;
                    };
                    Encoder2.prototype.writeF32 = function(value) {
                      this.ensureBufferSizeToWrite(4);
                      this.view.setFloat32(this.pos, value);
                      this.pos += 4;
                    };
                    Encoder2.prototype.writeF64 = function(value) {
                      this.ensureBufferSizeToWrite(8);
                      this.view.setFloat64(this.pos, value);
                      this.pos += 8;
                    };
                    Encoder2.prototype.writeU64 = function(value) {
                      this.ensureBufferSizeToWrite(8);
                      (0, _utils_int_mjs__WEBPACK_IMPORTED_MODULE_3__.setUint64)(this.view, this.pos, value);
                      this.pos += 8;
                    };
                    Encoder2.prototype.writeI64 = function(value) {
                      this.ensureBufferSizeToWrite(8);
                      (0, _utils_int_mjs__WEBPACK_IMPORTED_MODULE_3__.setInt64)(this.view, this.pos, value);
                      this.pos += 8;
                    };
                    return Encoder2;
                  }()
                );
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/ExtData.mjs": (
              /*!****************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/ExtData.mjs ***!
                \****************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  ExtData: () => (
                    /* binding */
                    ExtData
                  )
                  /* harmony export */
                });
                var ExtData = (
                  /** @class */
                  /* @__PURE__ */ function() {
                    function ExtData2(type2, data) {
                      this.type = type2;
                      this.data = data;
                    }
                    return ExtData2;
                  }()
                );
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/ExtensionCodec.mjs": (
              /*!***********************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/ExtensionCodec.mjs ***!
                \***********************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  ExtensionCodec: () => (
                    /* binding */
                    ExtensionCodec
                  )
                  /* harmony export */
                });
                var _ExtData_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__2(
                  /*! ./ExtData.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/ExtData.mjs"
                );
                var _timestamp_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./timestamp.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/timestamp.mjs"
                );
                var ExtensionCodec = (
                  /** @class */
                  function() {
                    function ExtensionCodec2() {
                      this.builtInEncoders = [];
                      this.builtInDecoders = [];
                      this.encoders = [];
                      this.decoders = [];
                      this.register(_timestamp_mjs__WEBPACK_IMPORTED_MODULE_0__.timestampExtension);
                    }
                    ExtensionCodec2.prototype.register = function(_a) {
                      var type2 = _a.type, encode = _a.encode, decode = _a.decode;
                      if (type2 >= 0) {
                        this.encoders[type2] = encode;
                        this.decoders[type2] = decode;
                      } else {
                        var index = 1 + type2;
                        this.builtInEncoders[index] = encode;
                        this.builtInDecoders[index] = decode;
                      }
                    };
                    ExtensionCodec2.prototype.tryToEncode = function(object, context2) {
                      for (var i = 0; i < this.builtInEncoders.length; i++) {
                        var encodeExt = this.builtInEncoders[i];
                        if (encodeExt != null) {
                          var data = encodeExt(object, context2);
                          if (data != null) {
                            var type2 = -1 - i;
                            return new _ExtData_mjs__WEBPACK_IMPORTED_MODULE_1__.ExtData(type2, data);
                          }
                        }
                      }
                      for (var i = 0; i < this.encoders.length; i++) {
                        var encodeExt = this.encoders[i];
                        if (encodeExt != null) {
                          var data = encodeExt(object, context2);
                          if (data != null) {
                            var type2 = i;
                            return new _ExtData_mjs__WEBPACK_IMPORTED_MODULE_1__.ExtData(type2, data);
                          }
                        }
                      }
                      if (object instanceof _ExtData_mjs__WEBPACK_IMPORTED_MODULE_1__.ExtData) {
                        return object;
                      }
                      return null;
                    };
                    ExtensionCodec2.prototype.decode = function(data, type2, context2) {
                      var decodeExt = type2 < 0 ? this.builtInDecoders[-1 - type2] : this.decoders[type2];
                      if (decodeExt) {
                        return decodeExt(data, type2, context2);
                      } else {
                        return new _ExtData_mjs__WEBPACK_IMPORTED_MODULE_1__.ExtData(type2, data);
                      }
                    };
                    ExtensionCodec2.defaultCodec = new ExtensionCodec2();
                    return ExtensionCodec2;
                  }()
                );
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/decode.mjs": (
              /*!***************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/decode.mjs ***!
                \***************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  decode: () => (
                    /* binding */
                    decode
                  ),
                  /* harmony export */
                  decodeMulti: () => (
                    /* binding */
                    decodeMulti
                  ),
                  /* harmony export */
                  defaultDecodeOptions: () => (
                    /* binding */
                    defaultDecodeOptions
                  )
                  /* harmony export */
                });
                var _Decoder_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./Decoder.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/Decoder.mjs"
                );
                var defaultDecodeOptions = {};
                function decode(buffer, options) {
                  if (options === void 0) {
                    options = defaultDecodeOptions;
                  }
                  var decoder = new _Decoder_mjs__WEBPACK_IMPORTED_MODULE_0__.Decoder(options.extensionCodec, options.context, options.maxStrLength, options.maxBinLength, options.maxArrayLength, options.maxMapLength, options.maxExtLength);
                  return decoder.decode(buffer);
                }
                function decodeMulti(buffer, options) {
                  if (options === void 0) {
                    options = defaultDecodeOptions;
                  }
                  var decoder = new _Decoder_mjs__WEBPACK_IMPORTED_MODULE_0__.Decoder(options.extensionCodec, options.context, options.maxStrLength, options.maxBinLength, options.maxArrayLength, options.maxMapLength, options.maxExtLength);
                  return decoder.decodeMulti(buffer);
                }
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/encode.mjs": (
              /*!***************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/encode.mjs ***!
                \***************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  encode: () => (
                    /* binding */
                    encode
                  )
                  /* harmony export */
                });
                var _Encoder_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./Encoder.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/Encoder.mjs"
                );
                var defaultEncodeOptions = {};
                function encode(value, options) {
                  if (options === void 0) {
                    options = defaultEncodeOptions;
                  }
                  var encoder = new _Encoder_mjs__WEBPACK_IMPORTED_MODULE_0__.Encoder(options.extensionCodec, options.context, options.maxDepth, options.initialBufferSize, options.sortKeys, options.forceFloat32, options.ignoreUndefined, options.forceIntegerToFloat);
                  return encoder.encodeSharedRef(value);
                }
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/timestamp.mjs": (
              /*!******************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/timestamp.mjs ***!
                \******************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  EXT_TIMESTAMP: () => (
                    /* binding */
                    EXT_TIMESTAMP
                  ),
                  /* harmony export */
                  decodeTimestampExtension: () => (
                    /* binding */
                    decodeTimestampExtension
                  ),
                  /* harmony export */
                  decodeTimestampToTimeSpec: () => (
                    /* binding */
                    decodeTimestampToTimeSpec
                  ),
                  /* harmony export */
                  encodeDateToTimeSpec: () => (
                    /* binding */
                    encodeDateToTimeSpec
                  ),
                  /* harmony export */
                  encodeTimeSpecToTimestamp: () => (
                    /* binding */
                    encodeTimeSpecToTimestamp
                  ),
                  /* harmony export */
                  encodeTimestampExtension: () => (
                    /* binding */
                    encodeTimestampExtension
                  ),
                  /* harmony export */
                  timestampExtension: () => (
                    /* binding */
                    timestampExtension
                  )
                  /* harmony export */
                });
                var _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__2(
                  /*! ./DecodeError.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/DecodeError.mjs"
                );
                var _utils_int_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./utils/int.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/int.mjs"
                );
                var EXT_TIMESTAMP = -1;
                var TIMESTAMP32_MAX_SEC = 4294967296 - 1;
                var TIMESTAMP64_MAX_SEC = 17179869184 - 1;
                function encodeTimeSpecToTimestamp(_a) {
                  var sec = _a.sec, nsec = _a.nsec;
                  if (sec >= 0 && nsec >= 0 && sec <= TIMESTAMP64_MAX_SEC) {
                    if (nsec === 0 && sec <= TIMESTAMP32_MAX_SEC) {
                      var rv = new Uint8Array(4);
                      var view = new DataView(rv.buffer);
                      view.setUint32(0, sec);
                      return rv;
                    } else {
                      var secHigh = sec / 4294967296;
                      var secLow = sec & 4294967295;
                      var rv = new Uint8Array(8);
                      var view = new DataView(rv.buffer);
                      view.setUint32(0, nsec << 2 | secHigh & 3);
                      view.setUint32(4, secLow);
                      return rv;
                    }
                  } else {
                    var rv = new Uint8Array(12);
                    var view = new DataView(rv.buffer);
                    view.setUint32(0, nsec);
                    (0, _utils_int_mjs__WEBPACK_IMPORTED_MODULE_0__.setInt64)(view, 4, sec);
                    return rv;
                  }
                }
                function encodeDateToTimeSpec(date) {
                  var msec = date.getTime();
                  var sec = Math.floor(msec / 1e3);
                  var nsec = (msec - sec * 1e3) * 1e6;
                  var nsecInSec = Math.floor(nsec / 1e9);
                  return {
                    sec: sec + nsecInSec,
                    nsec: nsec - nsecInSec * 1e9
                  };
                }
                function encodeTimestampExtension(object) {
                  if (object instanceof Date) {
                    var timeSpec = encodeDateToTimeSpec(object);
                    return encodeTimeSpecToTimestamp(timeSpec);
                  } else {
                    return null;
                  }
                }
                function decodeTimestampToTimeSpec(data) {
                  var view = new DataView(data.buffer, data.byteOffset, data.byteLength);
                  switch (data.byteLength) {
                    case 4: {
                      var sec = view.getUint32(0);
                      var nsec = 0;
                      return { sec, nsec };
                    }
                    case 8: {
                      var nsec30AndSecHigh2 = view.getUint32(0);
                      var secLow32 = view.getUint32(4);
                      var sec = (nsec30AndSecHigh2 & 3) * 4294967296 + secLow32;
                      var nsec = nsec30AndSecHigh2 >>> 2;
                      return { sec, nsec };
                    }
                    case 12: {
                      var sec = (0, _utils_int_mjs__WEBPACK_IMPORTED_MODULE_0__.getInt64)(view, 4);
                      var nsec = view.getUint32(0);
                      return { sec, nsec };
                    }
                    default:
                      throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_1__.DecodeError("Unrecognized data size for timestamp (expected 4, 8, or 12): ".concat(data.length));
                  }
                }
                function decodeTimestampExtension(data) {
                  var timeSpec = decodeTimestampToTimeSpec(data);
                  return new Date(timeSpec.sec * 1e3 + timeSpec.nsec / 1e6);
                }
                var timestampExtension = {
                  type: EXT_TIMESTAMP,
                  encode: encodeTimestampExtension,
                  decode: decodeTimestampExtension
                };
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/int.mjs": (
              /*!******************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/utils/int.mjs ***!
                \******************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  UINT32_MAX: () => (
                    /* binding */
                    UINT32_MAX
                  ),
                  /* harmony export */
                  getInt64: () => (
                    /* binding */
                    getInt64
                  ),
                  /* harmony export */
                  getUint64: () => (
                    /* binding */
                    getUint64
                  ),
                  /* harmony export */
                  setInt64: () => (
                    /* binding */
                    setInt64
                  ),
                  /* harmony export */
                  setUint64: () => (
                    /* binding */
                    setUint64
                  )
                  /* harmony export */
                });
                var UINT32_MAX = 4294967295;
                function setUint64(view, offset, value) {
                  var high = value / 4294967296;
                  var low = value;
                  view.setUint32(offset, high);
                  view.setUint32(offset + 4, low);
                }
                function setInt64(view, offset, value) {
                  var high = Math.floor(value / 4294967296);
                  var low = value;
                  view.setUint32(offset, high);
                  view.setUint32(offset + 4, low);
                }
                function getInt64(view, offset) {
                  var high = view.getInt32(offset);
                  var low = view.getUint32(offset + 4);
                  return high * 4294967296 + low;
                }
                function getUint64(view, offset) {
                  var high = view.getUint32(offset);
                  var low = view.getUint32(offset + 4);
                  return high * 4294967296 + low;
                }
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/prettyByte.mjs": (
              /*!*************************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/utils/prettyByte.mjs ***!
                \*************************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  prettyByte: () => (
                    /* binding */
                    prettyByte
                  )
                  /* harmony export */
                });
                function prettyByte(byte) {
                  return "".concat(byte < 0 ? "-" : "", "0x").concat(Math.abs(byte).toString(16).padStart(2, "0"));
                }
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/typedArrays.mjs": (
              /*!**************************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/utils/typedArrays.mjs ***!
                \**************************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  createDataView: () => (
                    /* binding */
                    createDataView
                  ),
                  /* harmony export */
                  ensureUint8Array: () => (
                    /* binding */
                    ensureUint8Array
                  )
                  /* harmony export */
                });
                function ensureUint8Array(buffer) {
                  if (buffer instanceof Uint8Array) {
                    return buffer;
                  } else if (ArrayBuffer.isView(buffer)) {
                    return new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength);
                  } else if (buffer instanceof ArrayBuffer) {
                    return new Uint8Array(buffer);
                  } else {
                    return Uint8Array.from(buffer);
                  }
                }
                function createDataView(buffer) {
                  if (buffer instanceof ArrayBuffer) {
                    return new DataView(buffer);
                  }
                  var bufferView = ensureUint8Array(buffer);
                  return new DataView(bufferView.buffer, bufferView.byteOffset, bufferView.byteLength);
                }
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/utf8.mjs": (
              /*!*******************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/utils/utf8.mjs ***!
                \*******************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  TEXT_DECODER_THRESHOLD: () => (
                    /* binding */
                    TEXT_DECODER_THRESHOLD
                  ),
                  /* harmony export */
                  TEXT_ENCODER_THRESHOLD: () => (
                    /* binding */
                    TEXT_ENCODER_THRESHOLD
                  ),
                  /* harmony export */
                  utf8Count: () => (
                    /* binding */
                    utf8Count
                  ),
                  /* harmony export */
                  utf8DecodeJs: () => (
                    /* binding */
                    utf8DecodeJs
                  ),
                  /* harmony export */
                  utf8DecodeTD: () => (
                    /* binding */
                    utf8DecodeTD
                  ),
                  /* harmony export */
                  utf8EncodeJs: () => (
                    /* binding */
                    utf8EncodeJs
                  ),
                  /* harmony export */
                  utf8EncodeTE: () => (
                    /* binding */
                    utf8EncodeTE
                  )
                  /* harmony export */
                });
                var _int_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./int.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/int.mjs"
                );
                var _a, _b, _c;
                var TEXT_ENCODING_AVAILABLE = (typeof process === "undefined" || ((_a = process === null || process === void 0 ? void 0 : process.env) === null || _a === void 0 ? void 0 : _a["TEXT_ENCODING"]) !== "never") && typeof TextEncoder !== "undefined" && typeof TextDecoder !== "undefined";
                function utf8Count(str) {
                  var strLength = str.length;
                  var byteLength = 0;
                  var pos = 0;
                  while (pos < strLength) {
                    var value = str.charCodeAt(pos++);
                    if ((value & 4294967168) === 0) {
                      byteLength++;
                      continue;
                    } else if ((value & 4294965248) === 0) {
                      byteLength += 2;
                    } else {
                      if (value >= 55296 && value <= 56319) {
                        if (pos < strLength) {
                          var extra = str.charCodeAt(pos);
                          if ((extra & 64512) === 56320) {
                            ++pos;
                            value = ((value & 1023) << 10) + (extra & 1023) + 65536;
                          }
                        }
                      }
                      if ((value & 4294901760) === 0) {
                        byteLength += 3;
                      } else {
                        byteLength += 4;
                      }
                    }
                  }
                  return byteLength;
                }
                function utf8EncodeJs(str, output, outputOffset) {
                  var strLength = str.length;
                  var offset = outputOffset;
                  var pos = 0;
                  while (pos < strLength) {
                    var value = str.charCodeAt(pos++);
                    if ((value & 4294967168) === 0) {
                      output[offset++] = value;
                      continue;
                    } else if ((value & 4294965248) === 0) {
                      output[offset++] = value >> 6 & 31 | 192;
                    } else {
                      if (value >= 55296 && value <= 56319) {
                        if (pos < strLength) {
                          var extra = str.charCodeAt(pos);
                          if ((extra & 64512) === 56320) {
                            ++pos;
                            value = ((value & 1023) << 10) + (extra & 1023) + 65536;
                          }
                        }
                      }
                      if ((value & 4294901760) === 0) {
                        output[offset++] = value >> 12 & 15 | 224;
                        output[offset++] = value >> 6 & 63 | 128;
                      } else {
                        output[offset++] = value >> 18 & 7 | 240;
                        output[offset++] = value >> 12 & 63 | 128;
                        output[offset++] = value >> 6 & 63 | 128;
                      }
                    }
                    output[offset++] = value & 63 | 128;
                  }
                }
                var sharedTextEncoder = TEXT_ENCODING_AVAILABLE ? new TextEncoder() : void 0;
                var TEXT_ENCODER_THRESHOLD = !TEXT_ENCODING_AVAILABLE ? _int_mjs__WEBPACK_IMPORTED_MODULE_0__.UINT32_MAX : typeof process !== "undefined" && ((_b = process === null || process === void 0 ? void 0 : process.env) === null || _b === void 0 ? void 0 : _b["TEXT_ENCODING"]) !== "force" ? 200 : 0;
                function utf8EncodeTEencode(str, output, outputOffset) {
                  output.set(sharedTextEncoder.encode(str), outputOffset);
                }
                function utf8EncodeTEencodeInto(str, output, outputOffset) {
                  sharedTextEncoder.encodeInto(str, output.subarray(outputOffset));
                }
                var utf8EncodeTE = (sharedTextEncoder === null || sharedTextEncoder === void 0 ? void 0 : sharedTextEncoder.encodeInto) ? utf8EncodeTEencodeInto : utf8EncodeTEencode;
                var CHUNK_SIZE = 4096;
                function utf8DecodeJs(bytes, inputOffset, byteLength) {
                  var offset = inputOffset;
                  var end = offset + byteLength;
                  var units = [];
                  var result = "";
                  while (offset < end) {
                    var byte1 = bytes[offset++];
                    if ((byte1 & 128) === 0) {
                      units.push(byte1);
                    } else if ((byte1 & 224) === 192) {
                      var byte2 = bytes[offset++] & 63;
                      units.push((byte1 & 31) << 6 | byte2);
                    } else if ((byte1 & 240) === 224) {
                      var byte2 = bytes[offset++] & 63;
                      var byte3 = bytes[offset++] & 63;
                      units.push((byte1 & 31) << 12 | byte2 << 6 | byte3);
                    } else if ((byte1 & 248) === 240) {
                      var byte2 = bytes[offset++] & 63;
                      var byte3 = bytes[offset++] & 63;
                      var byte4 = bytes[offset++] & 63;
                      var unit = (byte1 & 7) << 18 | byte2 << 12 | byte3 << 6 | byte4;
                      if (unit > 65535) {
                        unit -= 65536;
                        units.push(unit >>> 10 & 1023 | 55296);
                        unit = 56320 | unit & 1023;
                      }
                      units.push(unit);
                    } else {
                      units.push(byte1);
                    }
                    if (units.length >= CHUNK_SIZE) {
                      result += String.fromCharCode.apply(String, units);
                      units.length = 0;
                    }
                  }
                  if (units.length > 0) {
                    result += String.fromCharCode.apply(String, units);
                  }
                  return result;
                }
                var sharedTextDecoder = TEXT_ENCODING_AVAILABLE ? new TextDecoder() : null;
                var TEXT_DECODER_THRESHOLD = !TEXT_ENCODING_AVAILABLE ? _int_mjs__WEBPACK_IMPORTED_MODULE_0__.UINT32_MAX : typeof process !== "undefined" && ((_c = process === null || process === void 0 ? void 0 : process.env) === null || _c === void 0 ? void 0 : _c["TEXT_DECODER"]) !== "force" ? 200 : 0;
                function utf8DecodeTD(bytes, inputOffset, byteLength) {
                  var stringBytes = bytes.subarray(inputOffset, inputOffset + byteLength);
                  return sharedTextDecoder.decode(stringBytes);
                }
              }
            )
            /******/
          };
          var __webpack_module_cache__ = {};
          function __webpack_require__(moduleId) {
            var cachedModule = __webpack_module_cache__[moduleId];
            if (cachedModule !== void 0) {
              return cachedModule.exports;
            }
            var module2 = __webpack_module_cache__[moduleId] = {
              /******/
              // no module.id needed
              /******/
              // no module.loaded needed
              /******/
              exports: {}
              /******/
            };
            __webpack_modules__[moduleId](module2, module2.exports, __webpack_require__);
            return module2.exports;
          }
          __webpack_require__.m = __webpack_modules__;
          (() => {
            __webpack_require__.d = (exports2, definition) => {
              for (var key in definition) {
                if (__webpack_require__.o(definition, key) && !__webpack_require__.o(exports2, key)) {
                  Object.defineProperty(exports2, key, { enumerable: true, get: definition[key] });
                }
              }
            };
          })();
          (() => {
            __webpack_require__.f = {};
            __webpack_require__.e = (chunkId) => {
              return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
                __webpack_require__.f[key](chunkId, promises);
                return promises;
              }, []));
            };
          })();
          (() => {
            __webpack_require__.u = (chunkId) => {
              return "" + chunkId + ".hypha-rpc-websocket.js";
            };
          })();
          (() => {
            __webpack_require__.g = function() {
              if (typeof globalThis === "object") return globalThis;
              try {
                return this || new Function("return this")();
              } catch (e) {
                if (typeof window === "object") return window;
              }
            }();
          })();
          (() => {
            __webpack_require__.o = (obj, prop) => Object.prototype.hasOwnProperty.call(obj, prop);
          })();
          (() => {
            var inProgress = {};
            var dataWebpackPrefix = "hyphaWebsocketClient:";
            __webpack_require__.l = (url, done, key, chunkId) => {
              if (inProgress[url]) {
                inProgress[url].push(done);
                return;
              }
              var script2, needAttach;
              if (key !== void 0) {
                var scripts = document.getElementsByTagName("script");
                for (var i = 0; i < scripts.length; i++) {
                  var s = scripts[i];
                  if (s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) {
                    script2 = s;
                    break;
                  }
                }
              }
              if (!script2) {
                needAttach = true;
                script2 = document.createElement("script");
                script2.charset = "utf-8";
                script2.timeout = 120;
                if (__webpack_require__.nc) {
                  script2.setAttribute("nonce", __webpack_require__.nc);
                }
                script2.setAttribute("data-webpack", dataWebpackPrefix + key);
                script2.src = url;
              }
              inProgress[url] = [done];
              var onScriptComplete = (prev, event2) => {
                script2.onerror = script2.onload = null;
                clearTimeout(timeout);
                var doneFns = inProgress[url];
                delete inProgress[url];
                script2.parentNode && script2.parentNode.removeChild(script2);
                doneFns && doneFns.forEach((fn) => fn(event2));
                if (prev) return prev(event2);
              };
              var timeout = setTimeout(onScriptComplete.bind(null, void 0, { type: "timeout", target: script2 }), 12e4);
              script2.onerror = onScriptComplete.bind(null, script2.onerror);
              script2.onload = onScriptComplete.bind(null, script2.onload);
              needAttach && document.head.appendChild(script2);
            };
          })();
          (() => {
            __webpack_require__.r = (exports2) => {
              if (typeof Symbol !== "undefined" && Symbol.toStringTag) {
                Object.defineProperty(exports2, Symbol.toStringTag, { value: "Module" });
              }
              Object.defineProperty(exports2, "__esModule", { value: true });
            };
          })();
          (() => {
            var scriptUrl;
            if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
            var document2 = __webpack_require__.g.document;
            if (!scriptUrl && document2) {
              if (document2.currentScript)
                scriptUrl = document2.currentScript.src;
              if (!scriptUrl) {
                var scripts = document2.getElementsByTagName("script");
                if (scripts.length) {
                  var i = scripts.length - 1;
                  while (i > -1 && (!scriptUrl || !/^http(s?):/.test(scriptUrl))) scriptUrl = scripts[i--].src;
                }
              }
            }
            if(!scriptUrl)scriptUrl="";
            scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
            __webpack_require__.p = scriptUrl;
          })();
          (() => {
            var installedChunks = {
              /******/
              "hyphaWebsocketClient": 0
              /******/
            };
            __webpack_require__.f.j = (chunkId, promises) => {
              var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : void 0;
              if (installedChunkData !== 0) {
                if (installedChunkData) {
                  promises.push(installedChunkData[2]);
                } else {
                  if (true) {
                    var promise = new Promise((resolve2, reject2) => installedChunkData = installedChunks[chunkId] = [resolve2, reject2]);
                    promises.push(installedChunkData[2] = promise);
                    var url = __webpack_require__.p + __webpack_require__.u(chunkId);
                    var error = new Error();
                    var loadingEnded = (event2) => {
                      if (__webpack_require__.o(installedChunks, chunkId)) {
                        installedChunkData = installedChunks[chunkId];
                        if (installedChunkData !== 0) installedChunks[chunkId] = void 0;
                        if (installedChunkData) {
                          var errorType = event2 && (event2.type === "load" ? "missing" : event2.type);
                          var realSrc = event2 && event2.target && event2.target.src;
                          error.message = "Loading chunk " + chunkId + " failed.\n(" + errorType + ": " + realSrc + ")";
                          error.name = "ChunkLoadError";
                          error.type = errorType;
                          error.request = realSrc;
                          installedChunkData[1](error);
                        }
                      }
                    };
                    __webpack_require__.l(url, loadingEnded, "chunk-" + chunkId, chunkId);
                  }
                }
              }
            };
            var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
              var [chunkIds, moreModules, runtime] = data;
              var moduleId, chunkId, i = 0;
              if (chunkIds.some((id) => installedChunks[id] !== 0)) {
                for (moduleId in moreModules) {
                  if (__webpack_require__.o(moreModules, moduleId)) {
                    __webpack_require__.m[moduleId] = moreModules[moduleId];
                  }
                }
                if (runtime) var result = runtime(__webpack_require__);
              }
              if (parentChunkLoadingFunction) parentChunkLoadingFunction(data);
              for (; i < chunkIds.length; i++) {
                chunkId = chunkIds[i];
                if (__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
                  installedChunks[chunkId][0]();
                }
                installedChunks[chunkId] = 0;
              }
            };
            var chunkLoadingGlobal = exports["webpackChunkhyphaWebsocketClient"] = exports["webpackChunkhyphaWebsocketClient"] || [];
            chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
            chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
          })();
          var __webpack_exports__ = {};
          __webpack_require__.r(__webpack_exports__);
          __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            API_VERSION: () => (
              /* reexport safe */
              _rpc_js__WEBPACK_IMPORTED_MODULE_0__.API_VERSION
            ),
            /* harmony export */
            HTTPStreamingRPCConnection: () => (
              /* reexport safe */
              _http_client_js__WEBPACK_IMPORTED_MODULE_4__.HTTPStreamingRPCConnection
            ),
            /* harmony export */
            LocalWebSocket: () => (
              /* binding */
              LocalWebSocket
            ),
            /* harmony export */
            RPC: () => (
              /* reexport safe */
              _rpc_js__WEBPACK_IMPORTED_MODULE_0__.RPC
            ),
            /* harmony export */
            connectToServer: () => (
              /* binding */
              connectToServer
            ),
            /* harmony export */
            connectToServerHTTP: () => (
              /* reexport safe */
              _http_client_js__WEBPACK_IMPORTED_MODULE_4__.connectToServerHTTP
            ),
            /* harmony export */
            getRTCService: () => (
              /* reexport safe */
              _webrtc_client_js__WEBPACK_IMPORTED_MODULE_3__.getRTCService
            ),
            /* harmony export */
            getRemoteService: () => (
              /* binding */
              getRemoteService
            ),
            /* harmony export */
            getRemoteServiceHTTP: () => (
              /* reexport safe */
              _http_client_js__WEBPACK_IMPORTED_MODULE_4__.getRemoteServiceHTTP
            ),
            /* harmony export */
            loadRequirements: () => (
              /* reexport safe */
              _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.loadRequirements
            ),
            /* harmony export */
            login: () => (
              /* binding */
              login
            ),
            /* harmony export */
            logout: () => (
              /* binding */
              logout
            ),
            /* harmony export */
            normalizeServerUrlHTTP: () => (
              /* reexport safe */
              _http_client_js__WEBPACK_IMPORTED_MODULE_4__.normalizeServerUrl
            ),
            /* harmony export */
            registerRTCService: () => (
              /* reexport safe */
              _webrtc_client_js__WEBPACK_IMPORTED_MODULE_3__.registerRTCService
            ),
            /* harmony export */
            schemaFunction: () => (
              /* reexport safe */
              _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction
            ),
            /* harmony export */
            setupLocalClient: () => (
              /* binding */
              setupLocalClient
            )
            /* harmony export */
          });
          var _rpc_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
            /*! ./rpc.js */
            "./src/rpc.js"
          );
          var _utils_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
            /*! ./utils/index.js */
            "./src/utils/index.js"
          );
          var _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
            /*! ./utils/schema.js */
            "./src/utils/schema.js"
          );
          var _webrtc_client_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
            /*! ./webrtc-client.js */
            "./src/webrtc-client.js"
          );
          var _http_client_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
            /*! ./http-client.js */
            "./src/http-client.js"
          );
          const MAX_RETRY = 1e6;
          class WebsocketRPCConnection {
            constructor(server_url2, client_id2, workspace2, token2, reconnection_token = null, timeout = 60, WebSocketClass = null, token_refresh_interval = 2 * 60 * 60, additional_headers = null) {
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(server_url2 && client_id2, "server_url and client_id are required");
              this._server_url = server_url2;
              this._client_id = client_id2;
              this._workspace = workspace2;
              this._token = token2;
              this._reconnection_token = reconnection_token;
              this._websocket = null;
              this._handle_message = null;
              this._handle_connected = null;
              this._handle_disconnected = null;
              this._timeout = timeout;
              this._WebSocketClass = WebSocketClass || WebSocket;
              this._closed = false;
              this._legacy_auth = null;
              this.connection_info = null;
              this._enable_reconnect = false;
              this._token_refresh_interval = token_refresh_interval;
              this.manager_id = null;
              this._refresh_token_task = null;
              this._reconnect_timeouts = /* @__PURE__ */ new Set();
              this._additional_headers = additional_headers;
            }
            /**
             * Centralized cleanup method to clear all timers and prevent resource leaks
             */
            _cleanup() {
              if (this._refresh_token_task) {
                clearInterval(this._refresh_token_task);
                this._refresh_token_task = null;
              }
              for (const timeoutId of this._reconnect_timeouts) {
                clearTimeout(timeoutId);
              }
              this._reconnect_timeouts.clear();
            }
            on_message(handler) {
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(handler, "handler is required");
              this._handle_message = handler;
            }
            on_connected(handler) {
              this._handle_connected = handler;
            }
            on_disconnected(handler) {
              this._handle_disconnected = handler;
            }
            async _attempt_connection(server_url2, attempt_fallback = true) {
              return new Promise((resolve2, reject2) => {
                this._legacy_auth = false;
                const websocket = new this._WebSocketClass(server_url2);
                websocket.binaryType = "arraybuffer";
                websocket.onopen = () => {
                  console.info("WebSocket connection established");
                  resolve2(websocket);
                };
                websocket.onerror = (event2) => {
                  console.error("WebSocket connection error:", event2);
                  reject2(new Error(`WebSocket connection error: ${event2}`));
                };
                websocket.onclose = (event2) => {
                  if (event2.code === 1003 && attempt_fallback) {
                    console.info(
                      "Received 1003 error, attempting connection with query parameters."
                    );
                    this._legacy_auth = true;
                    this._attempt_connection_with_query_params(server_url2).then(resolve2).catch(reject2);
                  } else if (this._handle_disconnected) {
                    this._handle_disconnected(event2.reason);
                  }
                };
              });
            }
            async _attempt_connection_with_query_params(server_url2) {
              const queryParamsParts = [];
              if (this._client_id)
                queryParamsParts.push(`client_id=${encodeURIComponent(this._client_id)}`);
              if (this._workspace)
                queryParamsParts.push(`workspace=${encodeURIComponent(this._workspace)}`);
              if (this._token)
                queryParamsParts.push(`token=${encodeURIComponent(this._token)}`);
              if (this._reconnection_token)
                queryParamsParts.push(
                  `reconnection_token=${encodeURIComponent(this._reconnection_token)}`
                );
              const queryString = queryParamsParts.length > 0 ? `?${queryParamsParts.join("&")}` : "";
              const full_url = server_url2 + queryString;
              return await this._attempt_connection(full_url, false);
            }
            _establish_connection() {
              return new Promise((resolve2, reject2) => {
                this._websocket.onmessage = (event2) => {
                  const data = event2.data;
                  const first_message = JSON.parse(data);
                  if (first_message.type == "connection_info") {
                    this.connection_info = first_message;
                    if (this._workspace) {
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(
                        this.connection_info.workspace === this._workspace,
                        `Connected to the wrong workspace: ${this.connection_info.workspace}, expected: ${this._workspace}`
                      );
                    }
                    if (this.connection_info.reconnection_token) {
                      this._reconnection_token = this.connection_info.reconnection_token;
                    }
                    if (this.connection_info.reconnection_token_life_time) {
                      if (this._token_refresh_interval > this.connection_info.reconnection_token_life_time / 1.5) {
                        console.warn(
                          `Token refresh interval is too long (${this._token_refresh_interval}), setting it to 1.5 times of the token life time(${this.connection_info.reconnection_token_life_time}).`
                        );
                        this._token_refresh_interval = this.connection_info.reconnection_token_life_time / 1.5;
                      }
                    }
                    this.manager_id = this.connection_info.manager_id || null;
                    console.log(
                      `Successfully connected to the server, workspace: ${this.connection_info.workspace}, manager_id: ${this.manager_id}`
                    );
                    if (this.connection_info.announcement) {
                      console.log(`${this.connection_info.announcement}`);
                    }
                    resolve2(this.connection_info);
                  } else if (first_message.type == "error") {
                    const error = "ConnectionAbortedError: " + first_message.message;
                    console.error("Failed to connect, " + error);
                    reject2(new Error(error));
                    return;
                  } else {
                    console.error(
                      "ConnectionAbortedError: Unexpected message received from the server:",
                      data
                    );
                    reject2(
                      new Error(
                        "ConnectionAbortedError: Unexpected message received from the server"
                      )
                    );
                    return;
                  }
                };
              });
            }
            async open() {
              console.log(
                "Creating a new websocket connection to",
                this._server_url.split("?")[0]
              );
              try {
                this._websocket = await this._attempt_connection(this._server_url);
                if (this._legacy_auth) {
                  throw new Error(
                    "NotImplementedError: Legacy authentication is not supported"
                  );
                }
                const authInfo = JSON.stringify({
                  client_id: this._client_id,
                  workspace: this._workspace,
                  token: this._token,
                  reconnection_token: this._reconnection_token
                });
                this._websocket.send(authInfo);
                await (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.waitFor)(
                  this._establish_connection(),
                  this._timeout,
                  "Failed to receive the first message from the server"
                );
                if (this._token_refresh_interval > 0) {
                  setTimeout(() => {
                    this._send_refresh_token();
                    this._refresh_token_task = setInterval(() => {
                      this._send_refresh_token();
                    }, this._token_refresh_interval * 1e3);
                  }, 2e3);
                }
                this._enable_reconnect = true;
                this._closed = false;
                this._websocket.onmessage = (event2) => {
                  if (typeof event2.data === "string") {
                    const parsedData = JSON.parse(event2.data);
                    if (parsedData.type === "reconnection_token") {
                      this._reconnection_token = parsedData.reconnection_token;
                    } else {
                      console.log("Received message from the server:", parsedData);
                    }
                  } else {
                    this._handle_message(event2.data);
                  }
                };
                this._websocket.onerror = (event2) => {
                  console.error("WebSocket connection error:", event2);
                  this._cleanup();
                };
                this._websocket.onclose = this._handle_close.bind(this);
                if (this._handle_connected) {
                  this._handle_connected(this.connection_info);
                }
                return this.connection_info;
              } catch (error) {
                this._cleanup();
                console.error(
                  "Failed to connect to",
                  this._server_url.split("?")[0],
                  error
                );
                throw error;
              }
            }
            _send_refresh_token() {
              if (this._websocket && this._websocket.readyState === WebSocket.OPEN) {
                const refreshMessage = JSON.stringify({ type: "refresh_token" });
                this._websocket.send(refreshMessage);
              }
            }
            _handle_close(event2) {
              if (!this._closed && this._websocket && this._websocket.readyState === WebSocket.CLOSED) {
                this._cleanup();
                if (this._enable_reconnect) {
                  if ([1e3, 1001].includes(event2.code)) {
                    console.warn(
                      `Websocket connection closed gracefully by server (code: ${event2.code}): ${event2.reason} - attempting reconnect`
                    );
                  } else {
                    console.warn(
                      "Websocket connection closed unexpectedly (code: %s): %s",
                      event2.code,
                      event2.reason
                    );
                  }
                  let retry = 0;
                  const baseDelay = 1e3;
                  const maxDelay = 6e4;
                  const maxJitter = 0.1;
                  const reconnect = async () => {
                    if (this._closed) {
                      console.info("Connection was closed, stopping reconnection");
                      return;
                    }
                    try {
                      console.warn(
                        `Reconnecting to ${this._server_url.split("?")[0]} (attempt #${retry})`
                      );
                      await this.open();
                      await new Promise((resolve2) => setTimeout(resolve2, 500));
                      console.warn(
                        `Successfully reconnected to server ${this._server_url} (services re-registered)`
                      );
                    } catch (e) {
                      if (`${e}`.includes("ConnectionAbortedError:")) {
                        console.warn("Server refused to reconnect:", e);
                        this._closed = true;
                        if (this._handle_disconnected) {
                          this._handle_disconnected(`Server refused reconnection: ${e}`);
                        }
                        return;
                      } else if (`${e}`.includes("NotImplementedError:")) {
                        console.error(
                          `${e}
It appears that you are trying to connect to a hypha server that is older than 0.20.0, please upgrade the hypha server or use the websocket client in imjoy-rpc(https://www.npmjs.com/package/imjoy-rpc) instead`
                        );
                        this._closed = true;
                        if (this._handle_disconnected) {
                          this._handle_disconnected(`Server too old: ${e}`);
                        }
                        return;
                      }
                      if (e.name === "NetworkError" || e.message.includes("network")) {
                        console.error(`Network error during reconnection: ${e.message}`);
                      } else if (e.name === "TimeoutError" || e.message.includes("timeout")) {
                        console.error(
                          `Connection timeout during reconnection: ${e.message}`
                        );
                      } else {
                        console.error(
                          `Unexpected error during reconnection: ${e.message}`
                        );
                      }
                      const delay = Math.min(baseDelay * Math.pow(2, retry), maxDelay);
                      const jitter = (Math.random() * 2 - 1) * maxJitter * delay;
                      const finalDelay = Math.max(100, delay + jitter);
                      console.debug(
                        `Waiting ${(finalDelay / 1e3).toFixed(2)}s before next reconnection attempt`
                      );
                      const timeoutId = setTimeout(async () => {
                        this._reconnect_timeouts.delete(timeoutId);
                        if (this._websocket && this._websocket.readyState === WebSocket.OPEN) {
                          console.info("Connection restored externally");
                          return;
                        }
                        if (this._closed) {
                          console.info("Connection was closed, stopping reconnection");
                          return;
                        }
                        retry += 1;
                        if (retry < MAX_RETRY) {
                          await reconnect();
                        } else {
                          console.error(
                            `Failed to reconnect after ${MAX_RETRY} attempts, giving up.`
                          );
                          this._closed = true;
                          if (this._handle_disconnected) {
                            this._handle_disconnected(
                              "Max reconnection attempts exceeded"
                            );
                          }
                        }
                      }, finalDelay);
                      this._reconnect_timeouts.add(timeoutId);
                    }
                  };
                  reconnect();
                }
              } else {
                this._cleanup();
                if (this._handle_disconnected) {
                  this._handle_disconnected(event2.reason);
                }
              }
            }
            async emit_message(data) {
              if (this._closed) {
                throw new Error("Connection is closed");
              }
              if (!this._websocket || this._websocket.readyState !== WebSocket.OPEN) {
                await this.open();
              }
              try {
                this._websocket.send(data);
              } catch (exp) {
                console.error(`Failed to send data, error: ${exp}`);
                throw exp;
              }
            }
            disconnect(reason) {
              this._closed = true;
              if (this._websocket && this._websocket.readyState !== WebSocket.CLOSED && this._websocket.readyState !== WebSocket.CLOSING) {
                this._websocket.close(1e3, reason);
              }
              this._cleanup();
              console.info(`WebSocket connection disconnected (${reason})`);
            }
          }
          function normalizeServerUrl(server_url2) {
            if (!server_url2) throw new Error("server_url is required");
            if (server_url2.startsWith("http://")) {
              server_url2 = server_url2.replace("http://", "ws://").replace(/\/$/, "") + "/ws";
            } else if (server_url2.startsWith("https://")) {
              server_url2 = server_url2.replace("https://", "wss://").replace(/\/$/, "") + "/ws";
            }
            return server_url2;
          }
          async function login(config2) {
            const service_id = config2.login_service_id || "public/hypha-login";
            const workspace2 = config2.workspace;
            const expires_in = config2.expires_in;
            const timeout = config2.login_timeout || 60;
            const callback = config2.login_callback;
            const profile = config2.profile;
            const additional_headers = config2.additional_headers;
            const transport = config2.transport || "websocket";
            const server3 = await connectToServer({
              name: "initial login client",
              server_url: config2.server_url,
              additional_headers,
              transport
            });
            try {
              const svc = await server3.getService(service_id);
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(svc, `Failed to get the login service: ${service_id}`);
              let context2;
              if (workspace2) {
                context2 = await svc.start({ workspace: workspace2, expires_in, _rkwargs: true });
              } else {
                context2 = await svc.start();
              }
              if (callback) {
                await callback(context2);
              } else {
                console.log(`Please open your browser and login at ${context2.login_url}`);
              }
              return await svc.check(context2.key, { timeout, profile, _rkwargs: true });
            } catch (error) {
              throw error;
            } finally {
              await server3.disconnect();
            }
          }
          async function logout(config2) {
            const service_id = config2.login_service_id || "public/hypha-login";
            const callback = config2.logout_callback;
            const additional_headers = config2.additional_headers;
            const transport = config2.transport || "websocket";
            const server3 = await connectToServer({
              name: "initial logout client",
              server_url: config2.server_url,
              additional_headers,
              transport
            });
            try {
              const svc = await server3.getService(service_id);
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(svc, `Failed to get the login service: ${service_id}`);
              if (!svc.logout) {
                throw new Error(
                  "Logout is not supported by this server. Please upgrade the Hypha server to a version that supports logout."
                );
              }
              const context2 = await svc.logout({});
              if (callback) {
                await callback(context2);
              } else {
                console.log(
                  `Please open your browser to logout at ${context2.logout_url}`
                );
              }
              return context2;
            } catch (error) {
              throw error;
            } finally {
              await server3.disconnect();
            }
          }
          async function webrtcGetService(wm, query, config2) {
            config2 = config2 || {};
            const webrtc = config2.webrtc !== void 0 ? config2.webrtc : "auto";
            const webrtc_config = config2.webrtc_config;
            if (config2.webrtc !== void 0) delete config2.webrtc;
            if (config2.webrtc_config !== void 0) delete config2.webrtc_config;
            (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(
              [void 0, true, false, "auto"].includes(webrtc),
              "webrtc must be true, false or 'auto'"
            );
            const svc = await wm.getService(query, config2);
            if (webrtc === true || webrtc === "auto") {
              if (svc.id.includes(":") && svc.id.includes("/")) {
                try {
                  const wsAndClient = svc.id.split(":")[0];
                  const parts = wsAndClient.split("/");
                  const remoteClientId = parts[parts.length - 1];
                  const remoteWorkspace = parts.slice(0, -1).join("/");
                  const remoteRtcServiceId = `${remoteWorkspace}/${remoteClientId}-rtc`;
                  const peer = await (0, _webrtc_client_js__WEBPACK_IMPORTED_MODULE_3__.getRTCService)(wm, remoteRtcServiceId, webrtc_config);
                  const rtcSvc = await peer.getService(svc.id.split(":")[1], config2);
                  rtcSvc._webrtc = true;
                  rtcSvc._peer = peer;
                  rtcSvc._service = svc;
                  return rtcSvc;
                } catch (e) {
                  console.warn(
                    "Failed to get webrtc service, using websocket connection",
                    e
                  );
                }
              }
              if (webrtc === true) {
                throw new Error("Failed to get the service via webrtc");
              }
            }
            return svc;
          }
          async function connectToServer(config2) {
            const transport = config2.transport || "websocket";
            if (transport === "http") {
              return await (0, _http_client_js__WEBPACK_IMPORTED_MODULE_4__.connectToServerHTTP)(config2);
            }
            if (config2.server) {
              config2.server_url = config2.server_url || config2.server.url;
              config2.WebSocketClass = config2.WebSocketClass || config2.server.WebSocketClass;
            }
            let clientId = config2.client_id;
            if (!clientId) {
              clientId = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.randId)();
              config2.client_id = clientId;
            }
            if (Object.keys(config2).length === 0) {
              if (typeof process !== "undefined" && process.env) {
                config2.server_url = process.env.HYPHA_SERVER_URL;
                config2.token = process.env.HYPHA_TOKEN;
                config2.client_id = process.env.HYPHA_CLIENT_ID;
                config2.workspace = process.env.HYPHA_WORKSPACE;
              } else if (typeof self !== "undefined" && self.env) {
                config2.server_url = self.env.HYPHA_SERVER_URL;
                config2.token = self.env.HYPHA_TOKEN;
                config2.client_id = self.env.HYPHA_CLIENT_ID;
                config2.workspace = self.env.HYPHA_WORKSPACE;
              } else if (typeof globalThis !== "undefined" && globalThis.env) {
                config2.server_url = globalThis.env.HYPHA_SERVER_URL;
                config2.token = globalThis.env.HYPHA_TOKEN;
                config2.client_id = globalThis.env.HYPHA_CLIENT_ID;
                config2.workspace = globalThis.env.HYPHA_WORKSPACE;
              }
            }
            let server_url2 = normalizeServerUrl(config2.server_url);
            let connection = new WebsocketRPCConnection(
              server_url2,
              clientId,
              config2.workspace,
              config2.token,
              config2.reconnection_token,
              config2.method_timeout || 60,
              config2.WebSocketClass,
              config2.token_refresh_interval,
              config2.additional_headers
            );
            const connection_info = await connection.open();
            (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(
              connection_info,
              "Failed to connect to the server, no connection info obtained. This issue is most likely due to an outdated Hypha server version. Please use `imjoy-rpc` for compatibility, or upgrade the Hypha server to the latest version."
            );
            await new Promise((resolve2) => setTimeout(resolve2, 100));
            if (!connection.manager_id) {
              console.warn("Manager ID not set immediately, waiting...");
              const maxWaitTime = 5e3;
              const checkInterval = 100;
              const startTime = Date.now();
              while (!connection.manager_id && Date.now() - startTime < maxWaitTime) {
                await new Promise((resolve2) => setTimeout(resolve2, checkInterval));
              }
              if (!connection.manager_id) {
                console.error("Manager ID still not set after waiting");
                throw new Error("Failed to get manager ID from server");
              } else {
                console.info(`Manager ID set after waiting: ${connection.manager_id}`);
              }
            }
            if (config2.workspace && connection_info.workspace !== config2.workspace) {
              throw new Error(
                `Connected to the wrong workspace: ${connection_info.workspace}, expected: ${config2.workspace}`
              );
            }
            const workspace2 = connection_info.workspace;
            const rpc = new _rpc_js__WEBPACK_IMPORTED_MODULE_0__.RPC(connection, {
              client_id: clientId,
              workspace: workspace2,
              default_context: { connection_type: "websocket" },
              name: config2.name,
              method_timeout: config2.method_timeout,
              app_id: config2.app_id,
              server_base_url: connection_info.public_base_url,
              long_message_chunk_size: config2.long_message_chunk_size
            });
            await rpc.waitFor("services_registered", config2.method_timeout || 120);
            const wm = await rpc.get_manager_service({
              timeout: config2.method_timeout,
              case_conversion: "camel",
              kwargs_expansion: config2.kwargs_expansion || false
            });
            wm.rpc = rpc;
            async function _export(api) {
              api.id = "default";
              api.name = api.name || config2.name || api.id;
              api.description = api.description || config2.description;
              await rpc.register_service(api, { overwrite: true });
            }
            async function getApp(clientId2) {
              clientId2 = clientId2 || "*";
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(!clientId2.includes(":"), "clientId should not contain ':'");
              if (!clientId2.includes("/")) {
                clientId2 = connection_info.workspace + "/" + clientId2;
              }
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(
                clientId2.split("/").length === 2,
                "clientId should match pattern workspace/clientId"
              );
              return await wm.getService(`${clientId2}:default`);
            }
            async function listApps(ws) {
              ws = ws || workspace2;
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(!ws.includes(":"), "workspace should not contain ':'");
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(!ws.includes("/"), "workspace should not contain '/'");
              const query = { workspace: ws, service_id: "default" };
              return await wm.listServices(query);
            }
            if (connection_info) {
              wm.config = Object.assign(wm.config, connection_info);
            }
            wm.export = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(_export, {
              name: "export",
              description: "Export the api.",
              parameters: {
                properties: { api: { description: "The api to export", type: "object" } },
                required: ["api"],
                type: "object"
              }
            });
            wm.getApp = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(getApp, {
              name: "getApp",
              description: "Get the app.",
              parameters: {
                properties: {
                  clientId: { default: "*", description: "The clientId", type: "string" }
                },
                type: "object"
              }
            });
            wm.listApps = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(listApps, {
              name: "listApps",
              description: "List the apps.",
              parameters: {
                properties: {
                  workspace: {
                    default: workspace2,
                    description: "The workspace",
                    type: "string"
                  }
                },
                type: "object"
              }
            });
            wm.disconnect = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.disconnect.bind(rpc), {
              name: "disconnect",
              description: "Disconnect from the server.",
              parameters: { type: "object", properties: {}, required: [] }
            });
            wm.registerCodec = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.register_codec.bind(rpc), {
              name: "registerCodec",
              description: "Register a codec for the webrtc connection",
              parameters: {
                type: "object",
                properties: {
                  codec: {
                    type: "object",
                    description: "Codec to register",
                    properties: {
                      name: { type: "string" },
                      type: {},
                      encoder: { type: "function" },
                      decoder: { type: "function" }
                    }
                  }
                }
              }
            });
            wm.emit = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.emit.bind(rpc), {
              name: "emit",
              description: "Emit a message.",
              parameters: {
                properties: { data: { description: "The data to emit", type: "object" } },
                required: ["data"],
                type: "object"
              }
            });
            wm.on = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.on.bind(rpc), {
              name: "on",
              description: "Register a message handler.",
              parameters: {
                properties: {
                  event: { description: "The event to listen to", type: "string" },
                  handler: { description: "The handler function", type: "function" }
                },
                required: ["event", "handler"],
                type: "object"
              }
            });
            wm.off = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.off.bind(rpc), {
              name: "off",
              description: "Remove a message handler.",
              parameters: {
                properties: {
                  event: { description: "The event to remove", type: "string" },
                  handler: { description: "The handler function", type: "function" }
                },
                required: ["event", "handler"],
                type: "object"
              }
            });
            wm.once = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.once.bind(rpc), {
              name: "once",
              description: "Register a one-time message handler.",
              parameters: {
                properties: {
                  event: { description: "The event to listen to", type: "string" },
                  handler: { description: "The handler function", type: "function" }
                },
                required: ["event", "handler"],
                type: "object"
              }
            });
            wm.getServiceSchema = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.get_service_schema, {
              name: "getServiceSchema",
              description: "Get the service schema.",
              parameters: {
                properties: {
                  service: {
                    description: "The service to extract schema",
                    type: "object"
                  }
                },
                required: ["service"],
                type: "object"
              }
            });
            wm.registerService = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.register_service.bind(rpc), {
              name: "registerService",
              description: "Register a service.",
              parameters: {
                properties: {
                  service: { description: "The service to register", type: "object" },
                  force: {
                    default: false,
                    description: "Force to register the service",
                    type: "boolean"
                  }
                },
                required: ["service"],
                type: "object"
              }
            });
            wm.unregisterService = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.unregister_service.bind(rpc), {
              name: "unregisterService",
              description: "Unregister a service.",
              parameters: {
                properties: {
                  service: {
                    description: "The service id to unregister",
                    type: "string"
                  },
                  notify: {
                    default: true,
                    description: "Notify the workspace manager",
                    type: "boolean"
                  }
                },
                required: ["service"],
                type: "object"
              }
            });
            if (connection.manager_id) {
              rpc.on("force-exit", async (message) => {
                if (message.from === "*/" + connection.manager_id) {
                  console.log("Disconnecting from server, reason:", message.reason);
                  await rpc.disconnect();
                }
              });
            }
            if (config2.webrtc) {
              await (0, _webrtc_client_js__WEBPACK_IMPORTED_MODULE_3__.registerRTCService)(wm, `${clientId}-rtc`, config2.webrtc_config);
              const _wm = Object.assign({}, wm);
              const description = _wm.getService.__schema__.description;
              const parameters = _wm.getService.__schema__.parameters;
              wm.getService = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(
                webrtcGetService.bind(null, _wm),
                {
                  name: "getService",
                  description,
                  parameters
                }
              );
              wm.getRTCService = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(_webrtc_client_js__WEBPACK_IMPORTED_MODULE_3__.getRTCService.bind(null, wm), {
                name: "getRTCService",
                description: "Get the webrtc connection, returns a peer connection.",
                parameters: {
                  properties: {
                    config: {
                      description: "The config for the webrtc service",
                      type: "object"
                    }
                  },
                  required: ["config"],
                  type: "object"
                }
              });
            } else {
              const _getService = wm.getService;
              wm.getService = (query, config3) => {
                config3 = config3 || {};
                return _getService(query, config3);
              };
              wm.getService.__schema__ = _getService.__schema__;
            }
            async function registerProbes(probes) {
              probes.id = "probes";
              probes.name = "Probes";
              probes.config = { visibility: "public" };
              probes.type = "probes";
              probes.description = `Probes Service, visit ${server_url2}/${workspace2}services/probes for the available probes.`;
              return await wm.registerService(probes, { overwrite: true });
            }
            wm.registerProbes = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(registerProbes, {
              name: "registerProbes",
              description: "Register probes service",
              parameters: {
                properties: {
                  probes: {
                    description: "The probes to register, e.g. {'liveness': {'type': 'function', 'description': 'Check the liveness of the service'}}",
                    type: "object"
                  }
                },
                required: ["probes"],
                type: "object"
              }
            });
            return wm;
          }
          async function getRemoteService(serviceUri, config2 = {}) {
            const { serverUrl, workspace: workspace2, clientId, serviceId, appId } = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.parseServiceUrl)(serviceUri);
            const fullServiceId = `${workspace2}/${clientId}:${serviceId}@${appId}`;
            if (config2.serverUrl) {
              if (config2.serverUrl !== serverUrl) {
                throw new Error(
                  "server_url in config does not match the server_url in the url"
                );
              }
            }
            config2.serverUrl = serverUrl;
            const server3 = await connectToServer(config2);
            return await server3.getService(fullServiceId);
          }
          class LocalWebSocket {
            constructor(url, client_id2, workspace2) {
              this.url = url;
              this.onopen = () => {
              };
              this.onmessage = () => {
              };
              this.onclose = () => {
              };
              this.onerror = () => {
              };
              this.client_id = client_id2;
              this.workspace = workspace2;
              const context2 = typeof window !== "undefined" ? window : self;
              const isWindow2 = typeof window !== "undefined";
              this.postMessage = (message) => {
                if (isWindow2) {
                  window.parent.postMessage(message, "*");
                } else {
                  self.postMessage(message);
                }
              };
              this.readyState = WebSocket.CONNECTING;
              context2.addEventListener(
                "message",
                (event2) => {
                  const { type: type2, data, to } = event2.data;
                  if (to !== this.client_id) {
                    return;
                  }
                  switch (type2) {
                    case "message":
                      if (this.readyState === WebSocket.OPEN && this.onmessage) {
                        this.onmessage({ data });
                      }
                      break;
                    case "connected":
                      this.readyState = WebSocket.OPEN;
                      this.onopen(event2);
                      break;
                    case "closed":
                      this.readyState = WebSocket.CLOSED;
                      this.onclose(event2);
                      break;
                    default:
                      break;
                  }
                },
                false
              );
              if (!this.client_id) throw new Error("client_id is required");
              if (!this.workspace) throw new Error("workspace is required");
              this.postMessage({
                type: "connect",
                url: this.url,
                from: this.client_id,
                workspace: this.workspace
              });
            }
            send(data) {
              if (this.readyState === WebSocket.OPEN) {
                this.postMessage({
                  type: "message",
                  data,
                  from: this.client_id,
                  workspace: this.workspace
                });
              }
            }
            close() {
              this.readyState = WebSocket.CLOSING;
              this.postMessage({
                type: "close",
                from: this.client_id,
                workspace: this.workspace
              });
              this.onclose();
            }
            addEventListener(type2, listener) {
              if (type2 === "message") {
                this.onmessage = listener;
              }
              if (type2 === "open") {
                this.onopen = listener;
              }
              if (type2 === "close") {
                this.onclose = listener;
              }
              if (type2 === "error") {
                this.onerror = listener;
              }
            }
          }
          function setupLocalClient({
            enable_execution = false,
            on_ready = null
          }) {
            return new Promise((resolve, reject) => {
              const context = typeof window !== "undefined" ? window : self;
              const isWindow = typeof window !== "undefined";
              context.addEventListener(
                "message",
                (event) => {
                  const {
                    type,
                    server_url,
                    workspace,
                    client_id,
                    token,
                    method_timeout,
                    name,
                    config
                  } = event.data;
                  if (type === "initializeHyphaClient") {
                    if (!server_url || !workspace || !client_id) {
                      console.error("server_url, workspace, and client_id are required.");
                      return;
                    }
                    if (!server_url.startsWith("https://local-hypha-server:")) {
                      console.error(
                        "server_url should start with https://local-hypha-server:"
                      );
                      return;
                    }
                    class FixedLocalWebSocket extends LocalWebSocket {
                      constructor(url) {
                        super(url, client_id, workspace);
                      }
                    }
                    connectToServer({
                      server_url,
                      workspace,
                      client_id,
                      token,
                      method_timeout,
                      name,
                      WebSocketClass: FixedLocalWebSocket
                    }).then(async (server) => {
                      globalThis.api = server;
                      try {
                        if (isWindow && enable_execution) {
                          let loadScript = function(script2) {
                            return new Promise((resolve2, reject2) => {
                              const scriptElement = document.createElement("script");
                              scriptElement.innerHTML = script2.content;
                              scriptElement.lang = script2.lang;
                              scriptElement.onload = () => resolve2();
                              scriptElement.onerror = (e) => reject2(e);
                              document.head.appendChild(scriptElement);
                            });
                          };
                          if (config.styles && config.styles.length > 0) {
                            for (const style of config.styles) {
                              const styleElement = document.createElement("style");
                              styleElement.innerHTML = style.content;
                              styleElement.lang = style.lang;
                              document.head.appendChild(styleElement);
                            }
                          }
                          if (config.links && config.links.length > 0) {
                            for (const link of config.links) {
                              const linkElement = document.createElement("a");
                              linkElement.href = link.url;
                              linkElement.innerText = link.text;
                              document.body.appendChild(linkElement);
                            }
                          }
                          if (config.windows && config.windows.length > 0) {
                            for (const w of config.windows) {
                              document.body.innerHTML = w.content;
                              break;
                            }
                          }
                          if (config.scripts && config.scripts.length > 0) {
                            for (const script2 of config.scripts) {
                              if (script2.lang !== "javascript")
                                throw new Error("Only javascript scripts are supported");
                              await loadScript(script2);
                            }
                          }
                        } else if (!isWindow && enable_execution && config.scripts && config.scripts.length > 0) {
                          for (const script of config.scripts) {
                            if (script.lang !== "javascript")
                              throw new Error("Only javascript scripts are supported");
                            eval(script.content);
                          }
                        }
                        if (on_ready) {
                          await on_ready(server, config);
                        }
                        resolve(server);
                      } catch (e) {
                        reject(e);
                      }
                    });
                  }
                },
                false
              );
              if (isWindow) {
                window.parent.postMessage({ type: "hyphaClientReady" }, "*");
              } else {
                self.postMessage({ type: "hyphaClientReady" });
              }
            });
          }
          return __webpack_exports__;
        })()
      );
    });
  }
});

// node_modules/hypha-rpc/index.js
var require_hypha_rpc = __commonJS({
  "node_modules/hypha-rpc/index.js"(exports2, module2) {
    module2.exports = { hyphaWebsocketClient: require_hypha_rpc_websocket() };
  }
});

// ../extension/src/offscreen.ts
var hyphaRpc = __toESM(require_hypha_rpc());

// src/utils/env.ts
function detectFrameworks() {
  const frameworks = [];
  const w = window;
  if (w.__REACT_DEVTOOLS_GLOBAL_HOOK__?.renderers?.size > 0) {
    frameworks.push("react");
  } else {
    const root = document.querySelector("#root, #app, [data-reactroot]");
    if (root) {
      const hasReactFiber = Object.keys(root).some(
        (k) => k.startsWith("__reactFiber$") || k.startsWith("__reactInternalInstance$")
      );
      if (hasReactFiber) frameworks.push("react");
    }
  }
  if (w.__VUE__ || w.__VUE_DEVTOOLS_GLOBAL_HOOK__) {
    frameworks.push("vue");
  } else {
    const el = document.querySelector("[data-v-app], #app");
    if (el && el.__vue_app__) frameworks.push("vue");
  }
  if (w.ng || document.querySelector("[ng-version]")) {
    frameworks.push("angular");
  }
  if (document.querySelector("[class*='svelte-']")) {
    frameworks.push("svelte");
  }
  if (w.__NEXT_DATA__) {
    frameworks.push("nextjs");
  }
  return frameworks;
}
function collectPageInfo() {
  const perf = performance.getEntriesByType(
    "navigation"
  )[0];
  return {
    url: window.location.href,
    title: document.title,
    viewport: {
      width: window.innerWidth,
      height: window.innerHeight
    },
    document_size: {
      width: document.documentElement.scrollWidth,
      height: document.documentElement.scrollHeight
    },
    user_agent: navigator.userAgent,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    cookies_enabled: navigator.cookieEnabled,
    language: navigator.language,
    platform: navigator.platform,
    online: navigator.onLine,
    performance: {
      load_time_ms: perf ? Math.round(perf.loadEventEnd - perf.startTime) : null,
      dom_content_loaded_ms: perf ? Math.round(perf.domContentLoadedEventEnd - perf.startTime) : null
    },
    frameworks: detectFrameworks()
  };
}

// src/services/info.ts
function getPageInfo(include_logs, log_limit, log_level) {
  const info = collectPageInfo();
  if (include_logs) {
    const logs = window.__HYPHA_DEBUGGER__?.consoleLogs ?? [];
    const limit = log_limit ?? 50;
    let filtered = log_level ? logs.filter((l) => l.level === log_level) : logs;
    info.console_logs = filtered.slice(-limit);
  }
  return info;
}
getPageInfo.__schema__ = {
  name: "getPageInfo",
  description: "Get information about the current web page including URL, title, viewport size, detected frameworks, and performance timing. Optionally include recent console logs.",
  parameters: {
    type: "object",
    properties: {
      include_logs: {
        type: "boolean",
        description: "If true, include recent console output in the response. Default: false."
      },
      log_limit: {
        type: "number",
        description: "Maximum number of console log entries to include (most recent). Default: 50."
      },
      log_level: {
        type: "string",
        description: 'Filter console logs by level: "log", "warn", "error", "info". Omit for all levels.',
        enum: ["log", "warn", "error", "info"]
      }
    }
  }
};
function getConsoleLogs(options) {
  const logs = window.__HYPHA_DEBUGGER__?.consoleLogs ?? [];
  const level = options?.level;
  const limit = options?.limit ?? 100;
  let filtered = level ? logs.filter((l) => l.level === level) : logs;
  return filtered.slice(-limit);
}
getConsoleLogs.__schema__ = {
  name: "getConsoleLogs",
  description: "Retrieve captured console output (log, warn, error, info).",
  parameters: {
    type: "object",
    properties: {
      level: {
        type: "string",
        description: 'Filter by log level: "log", "warn", "error", "info". Omit for all levels.',
        enum: ["log", "warn", "error", "info"]
      },
      limit: {
        type: "number",
        description: "Maximum number of log entries to return (most recent). Default: 100."
      }
    }
  }
};

// src/services/dom.ts
function elementToInfo(el) {
  const rect = el.getBoundingClientRect();
  const attrs = {};
  for (const attr of Array.from(el.attributes)) {
    attrs[attr.name] = attr.value;
  }
  return {
    tag: el.tagName.toLowerCase(),
    id: el.id,
    classes: Array.from(el.classList),
    text: (el.textContent ?? "").trim().slice(0, 500),
    attributes: attrs,
    bounds: {
      x: Math.round(rect.x),
      y: Math.round(rect.y),
      width: Math.round(rect.width),
      height: Math.round(rect.height)
    },
    visible: rect.width > 0 && rect.height > 0 && getComputedStyle(el).visibility !== "hidden" && getComputedStyle(el).display !== "none",
    children_count: el.children.length
  };
}
function queryDom(selector, limit) {
  limit = limit ?? 20;
  const elements = document.querySelectorAll(selector);
  const results = [];
  for (let i = 0; i < Math.min(elements.length, limit); i++) {
    results.push(elementToInfo(elements[i]));
  }
  return results;
}
queryDom.__schema__ = {
  name: "queryDom",
  description: "Query DOM elements by CSS selector. Returns tag, id, classes, text content, attributes, bounding rect, and visibility for each matching element.",
  parameters: {
    type: "object",
    properties: {
      selector: {
        type: "string",
        description: 'CSS selector to query, e.g. "button.primary", "#app > div".'
      },
      limit: {
        type: "number",
        description: "Maximum number of elements to return. Default: 20."
      }
    },
    required: ["selector"]
  }
};
function clickElement(selector) {
  const el = document.querySelector(selector);
  if (!el) {
    return { success: false, message: `No element found for selector: ${selector}` };
  }
  const rect = el.getBoundingClientRect();
  el.dispatchEvent(
    new MouseEvent("click", {
      bubbles: true,
      cancelable: true,
      view: window,
      clientX: rect.left + rect.width / 2,
      clientY: rect.top + rect.height / 2
    })
  );
  return { success: true, message: `Clicked element: ${selector}` };
}
clickElement.__schema__ = {
  name: "clickElement",
  description: "Click a DOM element matching the CSS selector.",
  parameters: {
    type: "object",
    properties: {
      selector: {
        type: "string",
        description: "CSS selector of the element to click."
      }
    },
    required: ["selector"]
  }
};
function fillInput(selector, value) {
  const el = document.querySelector(selector);
  if (!el) {
    return { success: false, message: `No element found for selector: ${selector}` };
  }
  const tag = el.tagName.toLowerCase();
  if (tag === "input" || tag === "textarea") {
    const inputEl = el;
    const proto = tag === "textarea" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const nativeSetter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    if (nativeSetter) {
      nativeSetter.call(inputEl, value);
    } else {
      inputEl.value = value;
    }
    inputEl.dispatchEvent(new Event("input", { bubbles: true }));
    inputEl.dispatchEvent(new Event("change", { bubbles: true }));
    return { success: true, message: `Filled ${selector} with value` };
  }
  if (tag === "select") {
    const selectEl = el;
    const nativeSetter = Object.getOwnPropertyDescriptor(
      HTMLSelectElement.prototype,
      "value"
    )?.set;
    if (nativeSetter) {
      nativeSetter.call(selectEl, value);
    } else {
      selectEl.value = value;
    }
    selectEl.dispatchEvent(new Event("change", { bubbles: true }));
    return { success: true, message: `Set ${selector} to ${value}` };
  }
  return { success: false, message: `Element ${selector} is not an input/textarea/select` };
}
fillInput.__schema__ = {
  name: "fillInput",
  description: "Set the value of an input, textarea, or select element. Works with React controlled components.",
  parameters: {
    type: "object",
    properties: {
      selector: {
        type: "string",
        description: "CSS selector of the input element."
      },
      value: {
        type: "string",
        description: "The value to set."
      }
    },
    required: ["selector", "value"]
  }
};
function scrollTo(target) {
  if (typeof target === "string") {
    const el = document.querySelector(target);
    if (!el) {
      return { success: false, message: `No element found for selector: ${target}` };
    }
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    return { success: true, message: `Scrolled to ${target}` };
  }
  window.scrollTo({ left: target.x, top: target.y, behavior: "smooth" });
  return { success: true, message: `Scrolled to (${target.x}, ${target.y})` };
}
scrollTo.__schema__ = {
  name: "scrollTo",
  description: "Scroll to a DOM element (by CSS selector) or to an absolute position {x, y}.",
  parameters: {
    type: "object",
    properties: {
      target: {
        description: "CSS selector string to scroll to an element, or an object {x, y} for absolute scroll position."
      }
    },
    required: ["target"]
  }
};
function getComputedStyles(selector, properties) {
  const el = document.querySelector(selector);
  if (!el) {
    return { error: `No element found for selector: ${selector}` };
  }
  const computed = getComputedStyle(el);
  const result = {};
  const props = properties ?? [
    "display",
    "position",
    "width",
    "height",
    "color",
    "background-color",
    "font-size",
    "font-family",
    "margin",
    "padding",
    "border",
    "opacity",
    "visibility",
    "overflow",
    "z-index"
  ];
  for (const prop of props) {
    result[prop] = computed.getPropertyValue(prop);
  }
  return result;
}
getComputedStyles.__schema__ = {
  name: "getComputedStyles",
  description: "Get computed CSS styles for an element.",
  parameters: {
    type: "object",
    properties: {
      selector: {
        type: "string",
        description: "CSS selector of the element."
      },
      properties: {
        type: "array",
        items: { type: "string" },
        description: 'CSS property names to retrieve, e.g. ["color", "font-size"]. Omit for common defaults.'
      }
    },
    required: ["selector"]
  }
};
function getElementBounds(selector) {
  const el = document.querySelector(selector);
  if (!el) {
    return { error: `No element found for selector: ${selector}` };
  }
  const rect = el.getBoundingClientRect();
  return {
    bounds: {
      x: Math.round(rect.x),
      y: Math.round(rect.y),
      width: Math.round(rect.width),
      height: Math.round(rect.height)
    },
    visible: rect.width > 0 && rect.height > 0 && getComputedStyle(el).visibility !== "hidden" && getComputedStyle(el).display !== "none"
  };
}
getElementBounds.__schema__ = {
  name: "getElementBounds",
  description: "Get the bounding rectangle and visibility of a DOM element.",
  parameters: {
    type: "object",
    properties: {
      selector: {
        type: "string",
        description: "CSS selector of the element."
      }
    },
    required: ["selector"]
  }
};
function getHtml(selector, outer, max_length) {
  const useOuter = outer ?? true;
  const maxLen = max_length ?? 5e4;
  const el = selector ? document.querySelector(selector) : document.documentElement;
  if (!el) {
    return { error: `No element found for selector: ${selector}` };
  }
  const raw = useOuter ? el.outerHTML : el.innerHTML;
  const truncated = raw.length > maxLen;
  return {
    html: truncated ? raw.slice(0, maxLen) : raw,
    length: raw.length,
    truncated
  };
}
getHtml.__schema__ = {
  name: "getHtml",
  description: "Get the HTML content of the page or a specific element. Returns outerHTML by default. Useful for understanding page structure.",
  parameters: {
    type: "object",
    properties: {
      selector: {
        type: "string",
        description: "CSS selector of the element. Omit to get the full page HTML."
      },
      outer: {
        type: "boolean",
        description: "If true (default), return outerHTML (includes the element itself). If false, return innerHTML (children only)."
      },
      max_length: {
        type: "number",
        description: "Maximum character length of the returned HTML. Default: 50000. Result will be truncated if longer."
      }
    }
  }
};

// node_modules/html-to-image/es/util.js
function resolveUrl(url, baseUrl) {
  if (url.match(/^[a-z]+:\/\//i)) {
    return url;
  }
  if (url.match(/^\/\//)) {
    return window.location.protocol + url;
  }
  if (url.match(/^[a-z]+:/i)) {
    return url;
  }
  const doc = document.implementation.createHTMLDocument();
  const base = doc.createElement("base");
  const a = doc.createElement("a");
  doc.head.appendChild(base);
  doc.body.appendChild(a);
  if (baseUrl) {
    base.href = baseUrl;
  }
  a.href = url;
  return a.href;
}
var uuid = /* @__PURE__ */ (() => {
  let counter = 0;
  const random = () => (
    // eslint-disable-next-line no-bitwise
    `0000${(Math.random() * 36 ** 4 << 0).toString(36)}`.slice(-4)
  );
  return () => {
    counter += 1;
    return `u${random()}${counter}`;
  };
})();
function toArray(arrayLike) {
  const arr = [];
  for (let i = 0, l = arrayLike.length; i < l; i++) {
    arr.push(arrayLike[i]);
  }
  return arr;
}
var styleProps = null;
function getStyleProperties(options = {}) {
  if (styleProps) {
    return styleProps;
  }
  if (options.includeStyleProperties) {
    styleProps = options.includeStyleProperties;
    return styleProps;
  }
  styleProps = toArray(window.getComputedStyle(document.documentElement));
  return styleProps;
}
function px(node, styleProperty) {
  const win = node.ownerDocument.defaultView || window;
  const val = win.getComputedStyle(node).getPropertyValue(styleProperty);
  return val ? parseFloat(val.replace("px", "")) : 0;
}
function getNodeWidth(node) {
  const leftBorder = px(node, "border-left-width");
  const rightBorder = px(node, "border-right-width");
  return node.clientWidth + leftBorder + rightBorder;
}
function getNodeHeight(node) {
  const topBorder = px(node, "border-top-width");
  const bottomBorder = px(node, "border-bottom-width");
  return node.clientHeight + topBorder + bottomBorder;
}
function getImageSize(targetNode, options = {}) {
  const width = options.width || getNodeWidth(targetNode);
  const height = options.height || getNodeHeight(targetNode);
  return { width, height };
}
function getPixelRatio() {
  let ratio;
  let FINAL_PROCESS;
  try {
    FINAL_PROCESS = process;
  } catch (e) {
  }
  const val = FINAL_PROCESS && FINAL_PROCESS.env ? FINAL_PROCESS.env.devicePixelRatio : null;
  if (val) {
    ratio = parseInt(val, 10);
    if (Number.isNaN(ratio)) {
      ratio = 1;
    }
  }
  return ratio || window.devicePixelRatio || 1;
}
var canvasDimensionLimit = 16384;
function checkCanvasDimensions(canvas) {
  if (canvas.width > canvasDimensionLimit || canvas.height > canvasDimensionLimit) {
    if (canvas.width > canvasDimensionLimit && canvas.height > canvasDimensionLimit) {
      if (canvas.width > canvas.height) {
        canvas.height *= canvasDimensionLimit / canvas.width;
        canvas.width = canvasDimensionLimit;
      } else {
        canvas.width *= canvasDimensionLimit / canvas.height;
        canvas.height = canvasDimensionLimit;
      }
    } else if (canvas.width > canvasDimensionLimit) {
      canvas.height *= canvasDimensionLimit / canvas.width;
      canvas.width = canvasDimensionLimit;
    } else {
      canvas.width *= canvasDimensionLimit / canvas.height;
      canvas.height = canvasDimensionLimit;
    }
  }
}
function createImage(url) {
  return new Promise((resolve2, reject2) => {
    const img = new Image();
    img.onload = () => {
      img.decode().then(() => {
        requestAnimationFrame(() => resolve2(img));
      });
    };
    img.onerror = reject2;
    img.crossOrigin = "anonymous";
    img.decoding = "async";
    img.src = url;
  });
}
async function svgToDataURL(svg) {
  return Promise.resolve().then(() => new XMLSerializer().serializeToString(svg)).then(encodeURIComponent).then((html) => `data:image/svg+xml;charset=utf-8,${html}`);
}
async function nodeToDataURL(node, width, height) {
  const xmlns = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(xmlns, "svg");
  const foreignObject = document.createElementNS(xmlns, "foreignObject");
  svg.setAttribute("width", `${width}`);
  svg.setAttribute("height", `${height}`);
  svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  foreignObject.setAttribute("width", "100%");
  foreignObject.setAttribute("height", "100%");
  foreignObject.setAttribute("x", "0");
  foreignObject.setAttribute("y", "0");
  foreignObject.setAttribute("externalResourcesRequired", "true");
  svg.appendChild(foreignObject);
  foreignObject.appendChild(node);
  return svgToDataURL(svg);
}
var isInstanceOfElement = (node, instance) => {
  if (node instanceof instance)
    return true;
  const nodePrototype = Object.getPrototypeOf(node);
  if (nodePrototype === null)
    return false;
  return nodePrototype.constructor.name === instance.name || isInstanceOfElement(nodePrototype, instance);
};

// node_modules/html-to-image/es/clone-pseudos.js
function formatCSSText(style) {
  const content = style.getPropertyValue("content");
  return `${style.cssText} content: '${content.replace(/'|"/g, "")}';`;
}
function formatCSSProperties(style, options) {
  return getStyleProperties(options).map((name2) => {
    const value = style.getPropertyValue(name2);
    const priority = style.getPropertyPriority(name2);
    return `${name2}: ${value}${priority ? " !important" : ""};`;
  }).join(" ");
}
function getPseudoElementStyle(className, pseudo, style, options) {
  const selector = `.${className}:${pseudo}`;
  const cssText = style.cssText ? formatCSSText(style) : formatCSSProperties(style, options);
  return document.createTextNode(`${selector}{${cssText}}`);
}
function clonePseudoElement(nativeNode, clonedNode, pseudo, options) {
  const style = window.getComputedStyle(nativeNode, pseudo);
  const content = style.getPropertyValue("content");
  if (content === "" || content === "none") {
    return;
  }
  const className = uuid();
  try {
    clonedNode.className = `${clonedNode.className} ${className}`;
  } catch (err) {
    return;
  }
  const styleElement = document.createElement("style");
  styleElement.appendChild(getPseudoElementStyle(className, pseudo, style, options));
  clonedNode.appendChild(styleElement);
}
function clonePseudoElements(nativeNode, clonedNode, options) {
  clonePseudoElement(nativeNode, clonedNode, ":before", options);
  clonePseudoElement(nativeNode, clonedNode, ":after", options);
}

// node_modules/html-to-image/es/mimes.js
var WOFF = "application/font-woff";
var JPEG = "image/jpeg";
var mimes = {
  woff: WOFF,
  woff2: WOFF,
  ttf: "application/font-truetype",
  eot: "application/vnd.ms-fontobject",
  png: "image/png",
  jpg: JPEG,
  jpeg: JPEG,
  gif: "image/gif",
  tiff: "image/tiff",
  svg: "image/svg+xml",
  webp: "image/webp"
};
function getExtension(url) {
  const match = /\.([^./]*?)$/g.exec(url);
  return match ? match[1] : "";
}
function getMimeType(url) {
  const extension = getExtension(url).toLowerCase();
  return mimes[extension] || "";
}

// node_modules/html-to-image/es/dataurl.js
function getContentFromDataUrl(dataURL) {
  return dataURL.split(/,/)[1];
}
function isDataUrl(url) {
  return url.search(/^(data:)/) !== -1;
}
function makeDataUrl(content, mimeType) {
  return `data:${mimeType};base64,${content}`;
}
async function fetchAsDataURL(url, init, process2) {
  const res = await fetch(url, init);
  if (res.status === 404) {
    throw new Error(`Resource "${res.url}" not found`);
  }
  const blob = await res.blob();
  return new Promise((resolve2, reject2) => {
    const reader = new FileReader();
    reader.onerror = reject2;
    reader.onloadend = () => {
      try {
        resolve2(process2({ res, result: reader.result }));
      } catch (error) {
        reject2(error);
      }
    };
    reader.readAsDataURL(blob);
  });
}
var cache = {};
function getCacheKey(url, contentType, includeQueryParams) {
  let key = url.replace(/\?.*/, "");
  if (includeQueryParams) {
    key = url;
  }
  if (/ttf|otf|eot|woff2?/i.test(key)) {
    key = key.replace(/.*\//, "");
  }
  return contentType ? `[${contentType}]${key}` : key;
}
async function resourceToDataURL(resourceUrl, contentType, options) {
  const cacheKey = getCacheKey(resourceUrl, contentType, options.includeQueryParams);
  if (cache[cacheKey] != null) {
    return cache[cacheKey];
  }
  if (options.cacheBust) {
    resourceUrl += (/\?/.test(resourceUrl) ? "&" : "?") + (/* @__PURE__ */ new Date()).getTime();
  }
  let dataURL;
  try {
    const content = await fetchAsDataURL(resourceUrl, options.fetchRequestInit, ({ res, result }) => {
      if (!contentType) {
        contentType = res.headers.get("Content-Type") || "";
      }
      return getContentFromDataUrl(result);
    });
    dataURL = makeDataUrl(content, contentType);
  } catch (error) {
    dataURL = options.imagePlaceholder || "";
    let msg = `Failed to fetch resource: ${resourceUrl}`;
    if (error) {
      msg = typeof error === "string" ? error : error.message;
    }
    if (msg) {
      console.warn(msg);
    }
  }
  cache[cacheKey] = dataURL;
  return dataURL;
}

// node_modules/html-to-image/es/clone-node.js
async function cloneCanvasElement(canvas) {
  const dataURL = canvas.toDataURL();
  if (dataURL === "data:,") {
    return canvas.cloneNode(false);
  }
  return createImage(dataURL);
}
async function cloneVideoElement(video, options) {
  if (video.currentSrc) {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    canvas.width = video.clientWidth;
    canvas.height = video.clientHeight;
    ctx === null || ctx === void 0 ? void 0 : ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataURL2 = canvas.toDataURL();
    return createImage(dataURL2);
  }
  const poster = video.poster;
  const contentType = getMimeType(poster);
  const dataURL = await resourceToDataURL(poster, contentType, options);
  return createImage(dataURL);
}
async function cloneIFrameElement(iframe, options) {
  var _a;
  try {
    if ((_a = iframe === null || iframe === void 0 ? void 0 : iframe.contentDocument) === null || _a === void 0 ? void 0 : _a.body) {
      return await cloneNode(iframe.contentDocument.body, options, true);
    }
  } catch (_b) {
  }
  return iframe.cloneNode(false);
}
async function cloneSingleNode(node, options) {
  if (isInstanceOfElement(node, HTMLCanvasElement)) {
    return cloneCanvasElement(node);
  }
  if (isInstanceOfElement(node, HTMLVideoElement)) {
    return cloneVideoElement(node, options);
  }
  if (isInstanceOfElement(node, HTMLIFrameElement)) {
    return cloneIFrameElement(node, options);
  }
  return node.cloneNode(isSVGElement(node));
}
var isSlotElement = (node) => node.tagName != null && node.tagName.toUpperCase() === "SLOT";
var isSVGElement = (node) => node.tagName != null && node.tagName.toUpperCase() === "SVG";
async function cloneChildren(nativeNode, clonedNode, options) {
  var _a, _b;
  if (isSVGElement(clonedNode)) {
    return clonedNode;
  }
  let children = [];
  if (isSlotElement(nativeNode) && nativeNode.assignedNodes) {
    children = toArray(nativeNode.assignedNodes());
  } else if (isInstanceOfElement(nativeNode, HTMLIFrameElement) && ((_a = nativeNode.contentDocument) === null || _a === void 0 ? void 0 : _a.body)) {
    children = toArray(nativeNode.contentDocument.body.childNodes);
  } else {
    children = toArray(((_b = nativeNode.shadowRoot) !== null && _b !== void 0 ? _b : nativeNode).childNodes);
  }
  if (children.length === 0 || isInstanceOfElement(nativeNode, HTMLVideoElement)) {
    return clonedNode;
  }
  await children.reduce((deferred, child) => deferred.then(() => cloneNode(child, options)).then((clonedChild) => {
    if (clonedChild) {
      clonedNode.appendChild(clonedChild);
    }
  }), Promise.resolve());
  return clonedNode;
}
function cloneCSSStyle(nativeNode, clonedNode, options) {
  const targetStyle = clonedNode.style;
  if (!targetStyle) {
    return;
  }
  const sourceStyle = window.getComputedStyle(nativeNode);
  if (sourceStyle.cssText) {
    targetStyle.cssText = sourceStyle.cssText;
    targetStyle.transformOrigin = sourceStyle.transformOrigin;
  } else {
    getStyleProperties(options).forEach((name2) => {
      let value = sourceStyle.getPropertyValue(name2);
      if (name2 === "font-size" && value.endsWith("px")) {
        const reducedFont = Math.floor(parseFloat(value.substring(0, value.length - 2))) - 0.1;
        value = `${reducedFont}px`;
      }
      if (isInstanceOfElement(nativeNode, HTMLIFrameElement) && name2 === "display" && value === "inline") {
        value = "block";
      }
      if (name2 === "d" && clonedNode.getAttribute("d")) {
        value = `path(${clonedNode.getAttribute("d")})`;
      }
      targetStyle.setProperty(name2, value, sourceStyle.getPropertyPriority(name2));
    });
  }
}
function cloneInputValue(nativeNode, clonedNode) {
  if (isInstanceOfElement(nativeNode, HTMLTextAreaElement)) {
    clonedNode.innerHTML = nativeNode.value;
  }
  if (isInstanceOfElement(nativeNode, HTMLInputElement)) {
    clonedNode.setAttribute("value", nativeNode.value);
  }
}
function cloneSelectValue(nativeNode, clonedNode) {
  if (isInstanceOfElement(nativeNode, HTMLSelectElement)) {
    const clonedSelect = clonedNode;
    const selectedOption = Array.from(clonedSelect.children).find((child) => nativeNode.value === child.getAttribute("value"));
    if (selectedOption) {
      selectedOption.setAttribute("selected", "");
    }
  }
}
function decorate(nativeNode, clonedNode, options) {
  if (isInstanceOfElement(clonedNode, Element)) {
    cloneCSSStyle(nativeNode, clonedNode, options);
    clonePseudoElements(nativeNode, clonedNode, options);
    cloneInputValue(nativeNode, clonedNode);
    cloneSelectValue(nativeNode, clonedNode);
  }
  return clonedNode;
}
async function ensureSVGSymbols(clone, options) {
  const uses = clone.querySelectorAll ? clone.querySelectorAll("use") : [];
  if (uses.length === 0) {
    return clone;
  }
  const processedDefs = {};
  for (let i = 0; i < uses.length; i++) {
    const use = uses[i];
    const id = use.getAttribute("xlink:href");
    if (id) {
      const exist = clone.querySelector(id);
      const definition = document.querySelector(id);
      if (!exist && definition && !processedDefs[id]) {
        processedDefs[id] = await cloneNode(definition, options, true);
      }
    }
  }
  const nodes = Object.values(processedDefs);
  if (nodes.length) {
    const ns = "http://www.w3.org/1999/xhtml";
    const svg = document.createElementNS(ns, "svg");
    svg.setAttribute("xmlns", ns);
    svg.style.position = "absolute";
    svg.style.width = "0";
    svg.style.height = "0";
    svg.style.overflow = "hidden";
    svg.style.display = "none";
    const defs = document.createElementNS(ns, "defs");
    svg.appendChild(defs);
    for (let i = 0; i < nodes.length; i++) {
      defs.appendChild(nodes[i]);
    }
    clone.appendChild(svg);
  }
  return clone;
}
async function cloneNode(node, options, isRoot) {
  if (!isRoot && options.filter && !options.filter(node)) {
    return null;
  }
  return Promise.resolve(node).then((clonedNode) => cloneSingleNode(clonedNode, options)).then((clonedNode) => cloneChildren(node, clonedNode, options)).then((clonedNode) => decorate(node, clonedNode, options)).then((clonedNode) => ensureSVGSymbols(clonedNode, options));
}

// node_modules/html-to-image/es/embed-resources.js
var URL_REGEX = /url\((['"]?)([^'"]+?)\1\)/g;
var URL_WITH_FORMAT_REGEX = /url\([^)]+\)\s*format\((["']?)([^"']+)\1\)/g;
var FONT_SRC_REGEX = /src:\s*(?:url\([^)]+\)\s*format\([^)]+\)[,;]\s*)+/g;
function toRegex(url) {
  const escaped = url.replace(/([.*+?^${}()|\[\]\/\\])/g, "\\$1");
  return new RegExp(`(url\\(['"]?)(${escaped})(['"]?\\))`, "g");
}
function parseURLs(cssText) {
  const urls = [];
  cssText.replace(URL_REGEX, (raw, quotation, url) => {
    urls.push(url);
    return raw;
  });
  return urls.filter((url) => !isDataUrl(url));
}
async function embed(cssText, resourceURL, baseURL, options, getContentFromUrl) {
  try {
    const resolvedURL = baseURL ? resolveUrl(resourceURL, baseURL) : resourceURL;
    const contentType = getMimeType(resourceURL);
    let dataURL;
    if (getContentFromUrl) {
      const content = await getContentFromUrl(resolvedURL);
      dataURL = makeDataUrl(content, contentType);
    } else {
      dataURL = await resourceToDataURL(resolvedURL, contentType, options);
    }
    return cssText.replace(toRegex(resourceURL), `$1${dataURL}$3`);
  } catch (error) {
  }
  return cssText;
}
function filterPreferredFontFormat(str, { preferredFontFormat }) {
  return !preferredFontFormat ? str : str.replace(FONT_SRC_REGEX, (match) => {
    while (true) {
      const [src, , format] = URL_WITH_FORMAT_REGEX.exec(match) || [];
      if (!format) {
        return "";
      }
      if (format === preferredFontFormat) {
        return `src: ${src};`;
      }
    }
  });
}
function shouldEmbed(url) {
  return url.search(URL_REGEX) !== -1;
}
async function embedResources(cssText, baseUrl, options) {
  if (!shouldEmbed(cssText)) {
    return cssText;
  }
  const filteredCSSText = filterPreferredFontFormat(cssText, options);
  const urls = parseURLs(filteredCSSText);
  return urls.reduce((deferred, url) => deferred.then((css) => embed(css, url, baseUrl, options)), Promise.resolve(filteredCSSText));
}

// node_modules/html-to-image/es/embed-images.js
async function embedProp(propName, node, options) {
  var _a;
  const propValue = (_a = node.style) === null || _a === void 0 ? void 0 : _a.getPropertyValue(propName);
  if (propValue) {
    const cssString = await embedResources(propValue, null, options);
    node.style.setProperty(propName, cssString, node.style.getPropertyPriority(propName));
    return true;
  }
  return false;
}
async function embedBackground(clonedNode, options) {
  ;
  await embedProp("background", clonedNode, options) || await embedProp("background-image", clonedNode, options);
  await embedProp("mask", clonedNode, options) || await embedProp("-webkit-mask", clonedNode, options) || await embedProp("mask-image", clonedNode, options) || await embedProp("-webkit-mask-image", clonedNode, options);
}
async function embedImageNode(clonedNode, options) {
  const isImageElement = isInstanceOfElement(clonedNode, HTMLImageElement);
  if (!(isImageElement && !isDataUrl(clonedNode.src)) && !(isInstanceOfElement(clonedNode, SVGImageElement) && !isDataUrl(clonedNode.href.baseVal))) {
    return;
  }
  const url = isImageElement ? clonedNode.src : clonedNode.href.baseVal;
  const dataURL = await resourceToDataURL(url, getMimeType(url), options);
  await new Promise((resolve2, reject2) => {
    clonedNode.onload = resolve2;
    clonedNode.onerror = options.onImageErrorHandler ? (...attributes) => {
      try {
        resolve2(options.onImageErrorHandler(...attributes));
      } catch (error) {
        reject2(error);
      }
    } : reject2;
    const image = clonedNode;
    if (image.decode) {
      image.decode = resolve2;
    }
    if (image.loading === "lazy") {
      image.loading = "eager";
    }
    if (isImageElement) {
      clonedNode.srcset = "";
      clonedNode.src = dataURL;
    } else {
      clonedNode.href.baseVal = dataURL;
    }
  });
}
async function embedChildren(clonedNode, options) {
  const children = toArray(clonedNode.childNodes);
  const deferreds = children.map((child) => embedImages(child, options));
  await Promise.all(deferreds).then(() => clonedNode);
}
async function embedImages(clonedNode, options) {
  if (isInstanceOfElement(clonedNode, Element)) {
    await embedBackground(clonedNode, options);
    await embedImageNode(clonedNode, options);
    await embedChildren(clonedNode, options);
  }
}

// node_modules/html-to-image/es/apply-style.js
function applyStyle(node, options) {
  const { style } = node;
  if (options.backgroundColor) {
    style.backgroundColor = options.backgroundColor;
  }
  if (options.width) {
    style.width = `${options.width}px`;
  }
  if (options.height) {
    style.height = `${options.height}px`;
  }
  const manual = options.style;
  if (manual != null) {
    Object.keys(manual).forEach((key) => {
      style[key] = manual[key];
    });
  }
  return node;
}

// node_modules/html-to-image/es/embed-webfonts.js
var cssFetchCache = {};
async function fetchCSS(url) {
  let cache2 = cssFetchCache[url];
  if (cache2 != null) {
    return cache2;
  }
  const res = await fetch(url);
  const cssText = await res.text();
  cache2 = { url, cssText };
  cssFetchCache[url] = cache2;
  return cache2;
}
async function embedFonts(data, options) {
  let cssText = data.cssText;
  const regexUrl = /url\(["']?([^"')]+)["']?\)/g;
  const fontLocs = cssText.match(/url\([^)]+\)/g) || [];
  const loadFonts = fontLocs.map(async (loc) => {
    let url = loc.replace(regexUrl, "$1");
    if (!url.startsWith("https://")) {
      url = new URL(url, data.url).href;
    }
    return fetchAsDataURL(url, options.fetchRequestInit, ({ result }) => {
      cssText = cssText.replace(loc, `url(${result})`);
      return [loc, result];
    });
  });
  return Promise.all(loadFonts).then(() => cssText);
}
function parseCSS(source) {
  if (source == null) {
    return [];
  }
  const result = [];
  const commentsRegex = /(\/\*[\s\S]*?\*\/)/gi;
  let cssText = source.replace(commentsRegex, "");
  const keyframesRegex = new RegExp("((@.*?keyframes [\\s\\S]*?){([\\s\\S]*?}\\s*?)})", "gi");
  while (true) {
    const matches = keyframesRegex.exec(cssText);
    if (matches === null) {
      break;
    }
    result.push(matches[0]);
  }
  cssText = cssText.replace(keyframesRegex, "");
  const importRegex = /@import[\s\S]*?url\([^)]*\)[\s\S]*?;/gi;
  const combinedCSSRegex = "((\\s*?(?:\\/\\*[\\s\\S]*?\\*\\/)?\\s*?@media[\\s\\S]*?){([\\s\\S]*?)}\\s*?})|(([\\s\\S]*?){([\\s\\S]*?)})";
  const unifiedRegex = new RegExp(combinedCSSRegex, "gi");
  while (true) {
    let matches = importRegex.exec(cssText);
    if (matches === null) {
      matches = unifiedRegex.exec(cssText);
      if (matches === null) {
        break;
      } else {
        importRegex.lastIndex = unifiedRegex.lastIndex;
      }
    } else {
      unifiedRegex.lastIndex = importRegex.lastIndex;
    }
    result.push(matches[0]);
  }
  return result;
}
async function getCSSRules(styleSheets, options) {
  const ret = [];
  const deferreds = [];
  styleSheets.forEach((sheet) => {
    if ("cssRules" in sheet) {
      try {
        toArray(sheet.cssRules || []).forEach((item, index) => {
          if (item.type === CSSRule.IMPORT_RULE) {
            let importIndex = index + 1;
            const url = item.href;
            const deferred = fetchCSS(url).then((metadata) => embedFonts(metadata, options)).then((cssText) => parseCSS(cssText).forEach((rule) => {
              try {
                sheet.insertRule(rule, rule.startsWith("@import") ? importIndex += 1 : sheet.cssRules.length);
              } catch (error) {
                console.error("Error inserting rule from remote css", {
                  rule,
                  error
                });
              }
            })).catch((e) => {
              console.error("Error loading remote css", e.toString());
            });
            deferreds.push(deferred);
          }
        });
      } catch (e) {
        const inline = styleSheets.find((a) => a.href == null) || document.styleSheets[0];
        if (sheet.href != null) {
          deferreds.push(fetchCSS(sheet.href).then((metadata) => embedFonts(metadata, options)).then((cssText) => parseCSS(cssText).forEach((rule) => {
            inline.insertRule(rule, inline.cssRules.length);
          })).catch((err) => {
            console.error("Error loading remote stylesheet", err);
          }));
        }
        console.error("Error inlining remote css file", e);
      }
    }
  });
  return Promise.all(deferreds).then(() => {
    styleSheets.forEach((sheet) => {
      if ("cssRules" in sheet) {
        try {
          toArray(sheet.cssRules || []).forEach((item) => {
            ret.push(item);
          });
        } catch (e) {
          console.error(`Error while reading CSS rules from ${sheet.href}`, e);
        }
      }
    });
    return ret;
  });
}
function getWebFontRules(cssRules) {
  return cssRules.filter((rule) => rule.type === CSSRule.FONT_FACE_RULE).filter((rule) => shouldEmbed(rule.style.getPropertyValue("src")));
}
async function parseWebFontRules(node, options) {
  if (node.ownerDocument == null) {
    throw new Error("Provided element is not within a Document");
  }
  const styleSheets = toArray(node.ownerDocument.styleSheets);
  const cssRules = await getCSSRules(styleSheets, options);
  return getWebFontRules(cssRules);
}
function normalizeFontFamily(font) {
  return font.trim().replace(/["']/g, "");
}
function getUsedFonts(node) {
  const fonts = /* @__PURE__ */ new Set();
  function traverse(node2) {
    const fontFamily = node2.style.fontFamily || getComputedStyle(node2).fontFamily;
    fontFamily.split(",").forEach((font) => {
      fonts.add(normalizeFontFamily(font));
    });
    Array.from(node2.children).forEach((child) => {
      if (child instanceof HTMLElement) {
        traverse(child);
      }
    });
  }
  traverse(node);
  return fonts;
}
async function getWebFontCSS(node, options) {
  const rules = await parseWebFontRules(node, options);
  const usedFonts = getUsedFonts(node);
  const cssTexts = await Promise.all(rules.filter((rule) => usedFonts.has(normalizeFontFamily(rule.style.fontFamily))).map((rule) => {
    const baseUrl = rule.parentStyleSheet ? rule.parentStyleSheet.href : null;
    return embedResources(rule.cssText, baseUrl, options);
  }));
  return cssTexts.join("\n");
}
async function embedWebFonts(clonedNode, options) {
  const cssText = options.fontEmbedCSS != null ? options.fontEmbedCSS : options.skipFonts ? null : await getWebFontCSS(clonedNode, options);
  if (cssText) {
    const styleNode = document.createElement("style");
    const sytleContent = document.createTextNode(cssText);
    styleNode.appendChild(sytleContent);
    if (clonedNode.firstChild) {
      clonedNode.insertBefore(styleNode, clonedNode.firstChild);
    } else {
      clonedNode.appendChild(styleNode);
    }
  }
}

// node_modules/html-to-image/es/index.js
async function toSvg(node, options = {}) {
  const { width, height } = getImageSize(node, options);
  const clonedNode = await cloneNode(node, options, true);
  await embedWebFonts(clonedNode, options);
  await embedImages(clonedNode, options);
  applyStyle(clonedNode, options);
  const datauri = await nodeToDataURL(clonedNode, width, height);
  return datauri;
}
async function toCanvas(node, options = {}) {
  const { width, height } = getImageSize(node, options);
  const svg = await toSvg(node, options);
  const img = await createImage(svg);
  const canvas = document.createElement("canvas");
  const context2 = canvas.getContext("2d");
  const ratio = options.pixelRatio || getPixelRatio();
  const canvasWidth = options.canvasWidth || width;
  const canvasHeight = options.canvasHeight || height;
  canvas.width = canvasWidth * ratio;
  canvas.height = canvasHeight * ratio;
  if (!options.skipAutoScale) {
    checkCanvasDimensions(canvas);
  }
  canvas.style.width = `${canvasWidth}`;
  canvas.style.height = `${canvasHeight}`;
  if (options.backgroundColor) {
    context2.fillStyle = options.backgroundColor;
    context2.fillRect(0, 0, canvas.width, canvas.height);
  }
  context2.drawImage(img, 0, 0, canvas.width, canvas.height);
  return canvas;
}
async function toPng(node, options = {}) {
  const canvas = await toCanvas(node, options);
  return canvas.toDataURL();
}
async function toJpeg(node, options = {}) {
  const canvas = await toCanvas(node, options);
  return canvas.toDataURL("image/jpeg", options.quality || 1);
}

// src/services/screenshot.ts
function errorMessage(err) {
  if (!err) return "Unknown error";
  if (typeof err === "string") return err;
  if (err.message) return err.message;
  if (err instanceof Event) return `Event: ${err.type}`;
  try {
    return JSON.stringify(err);
  } catch {
    return String(err);
  }
}
function splitDataUrl(dataUrl) {
  const m = /^data:([^;,]+)(?:;[^,]*)?,(.*)$/.exec(dataUrl);
  if (!m) throw new Error("Output is not a valid data: URL");
  const mediaType = m[1];
  let payload = m[2];
  if (!/;base64/i.test(dataUrl)) {
    throw new Error(
      `Output is not base64-encoded (got ${mediaType}). Capture probably failed silently.`
    );
  }
  return { mediaType, base64: payload };
}
async function resizeDataUrl(dataUrl, maxWidth, maxHeight, format, quality) {
  return new Promise((resolve2, reject2) => {
    const img = new Image();
    img.onload = () => {
      try {
        const srcW = img.naturalWidth;
        const srcH = img.naturalHeight;
        if (!srcW || !srcH) {
          reject2(new Error("Captured image has zero dimensions"));
          return;
        }
        const scale = Math.min(maxWidth / srcW, maxHeight / srcH, 1);
        const dstW = Math.max(1, Math.round(srcW * scale));
        const dstH = Math.max(1, Math.round(srcH * scale));
        const canvas = document.createElement("canvas");
        canvas.width = dstW;
        canvas.height = dstH;
        const ctx = canvas.getContext("2d");
        if (!ctx) {
          reject2(new Error("Could not get 2D canvas context"));
          return;
        }
        if (format === "jpeg") {
          ctx.fillStyle = "#ffffff";
          ctx.fillRect(0, 0, dstW, dstH);
        }
        ctx.drawImage(img, 0, 0, dstW, dstH);
        const mime = format === "jpeg" ? "image/jpeg" : "image/png";
        const out = canvas.toDataURL(mime, quality);
        resolve2({ dataUrl: out, width: dstW, height: dstH });
      } catch (drawErr) {
        reject2(new Error(`Canvas resize failed: ${errorMessage(drawErr)}`));
      }
    };
    img.onerror = (ev) => reject2(
      new Error(
        `Failed to load captured image for resizing${ev instanceof Event ? ` (${ev.type})` : ""}`
      )
    );
    img.src = dataUrl;
  });
}
async function takeScreenshot(selector, format, quality, max_width, max_height, full_page) {
  const fmt = format ?? "jpeg";
  const qual = quality ?? 0.6;
  const maxW = max_width ?? 800;
  const maxH = max_height ?? 800;
  const capturePage = full_page ?? false;
  let target;
  if (selector) {
    target = document.querySelector(selector);
    if (!target) {
      return { error: `No element found for selector: ${selector}` };
    }
  } else if (capturePage) {
    target = document.documentElement;
  } else {
    target = document.body;
  }
  try {
    const node = target;
    const viewportW = window.innerWidth;
    const viewportH = window.innerHeight;
    const TRANSPARENT_PIXEL = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkAAIAAAoAAv/lxKUAAAAASUVORK5CYII=";
    const captureOptions = {
      quality: qual,
      pixelRatio: 1,
      cacheBust: true,
      skipAutoScale: true,
      skipFonts: true,
      imagePlaceholder: TRANSPARENT_PIXEL,
      filter: (el) => {
        return el.id !== "hypha-debugger-host" && el.id !== "hypha-debugger-cursor" && el.id !== "playwright-highlight-container";
      }
    };
    if (!selector && !capturePage) {
      captureOptions.width = viewportW;
      captureOptions.height = viewportH;
    }
    const runCapture = async (opts, timeoutMs = 15e3) => {
      const capturePromise = fmt === "jpeg" ? toJpeg(node, opts) : toPng(node, opts);
      return Promise.race([
        capturePromise,
        new Promise(
          (_, reject2) => setTimeout(
            () => reject2(
              new Error(`Screenshot capture timed out after ${timeoutMs}ms`)
            ),
            timeoutMs
          )
        )
      ]);
    };
    let dataUrl;
    try {
      dataUrl = await runCapture(captureOptions);
    } catch (captureErr) {
      try {
        const noImagesOpts = {
          ...captureOptions,
          filter: (el) => {
            if (!captureOptions.filter(el)) return false;
            const tag = el.tagName?.toLowerCase();
            return tag !== "img" && tag !== "picture" && tag !== "video";
          }
        };
        dataUrl = await runCapture(noImagesOpts, 1e4);
      } catch (retryErr) {
        return {
          error: `Capture failed: ${errorMessage(captureErr)} (retry without images also failed: ${errorMessage(retryErr)})`
        };
      }
    }
    let resized;
    try {
      resized = await resizeDataUrl(dataUrl, maxW, maxH, fmt, qual);
    } catch (resizeErr) {
      return {
        error: `Resize failed: ${errorMessage(resizeErr)} (this usually means the captured image was malformed; try lowering max_width or use full_page:false)`
      };
    }
    let parts;
    try {
      parts = splitDataUrl(resized.dataUrl);
    } catch (validateErr) {
      return { error: `Output validation failed: ${errorMessage(validateErr)}` };
    }
    if (parts.base64.length < 200) {
      return {
        error: `Output too small (${parts.base64.length} chars base64) \u2014 capture likely failed`
      };
    }
    const sizeKb = Math.round(parts.base64.length * 0.75 / 1024);
    return {
      base64: parts.base64,
      media_type: parts.mediaType,
      data_url: resized.dataUrl,
      format: fmt,
      width: resized.width,
      height: resized.height,
      size_kb: sizeKb
    };
  } catch (err) {
    return { error: `Screenshot failed: ${errorMessage(err)}` };
  }
}
takeScreenshot.__schema__ = {
  name: "takeScreenshot",
  description: "Capture a screenshot of the current viewport, a specific element, or the full page. Downscaled to fit within max_width \xD7 max_height (default 800px) and JPEG-encoded at quality 0.6 by default for agent-friendly payload sizes. Returns: { base64, media_type, data_url, format, width, height, size_kb }. Use `base64` (raw base64, no prefix) directly with Claude/GPT image content fields. Use `data_url` for HTML <img src=...> previews. On failure returns { error }.",
  parameters: {
    type: "object",
    properties: {
      selector: {
        type: "string",
        description: "CSS selector of the element to capture. Omit to capture the viewport (or full page if full_page=true)."
      },
      format: {
        type: "string",
        enum: ["png", "jpeg"],
        description: 'Image format. Default: "jpeg" (much smaller than PNG). Use "png" only when sharp text really matters.'
      },
      quality: {
        type: "number",
        description: "JPEG quality (0\u20131). Default: 0.6. Ignored for PNG. Lower = smaller payload."
      },
      max_width: {
        type: "number",
        description: "Maximum output width in pixels. Default: 800. Image scaled down preserving aspect ratio."
      },
      max_height: {
        type: "number",
        description: "Maximum output height in pixels. Default: 800. Image scaled down preserving aspect ratio."
      },
      full_page: {
        type: "boolean",
        description: "If true, capture the entire scrollable page instead of just the viewport. Default: false."
      }
    }
  }
};

// src/services/execute.ts
function isCspEvalError(e) {
  if (!e) return false;
  if (e instanceof EvalError) return true;
  const msg = String(e.message || e);
  return /unsafe-eval|Content Security Policy|call to .*Function/i.test(msg);
}
function autoReturn(code) {
  const trimmed = code.trim();
  if (/\breturn\b/.test(trimmed)) return trimmed;
  let lines = trimmed.split("\n").map((l) => l.trim()).filter(Boolean);
  if (lines.length === 1 && lines[0].includes(";")) {
    lines = lines[0].split(";").map((s) => s.trim()).filter(Boolean);
  }
  if (lines.length === 0) return trimmed;
  const lastLine = lines[lines.length - 1];
  if (/^(if|for|while|switch|try|class|function |const |let |var |import |export )/.test(lastLine)) {
    return trimmed;
  }
  lines[lines.length - 1] = "return (" + lastLine.replace(/;$/, "") + ");";
  return lines.join(";\n");
}
async function executeScript(code, timeout_ms) {
  const timeoutMs = timeout_ms ?? 1e4;
  try {
    let execCode = autoReturn(code);
    let fn;
    try {
      fn = new Function("return (async () => {" + execCode + "})()");
    } catch (e) {
      if (isCspEvalError(e)) {
        return {
          error: "execute_script is unavailable on this page: its Content Security Policy blocks dynamic code evaluation ('unsafe-eval' not allowed). Use the DOM/interaction services (get_browser_state, click_element_by_index, query_dom, etc.) instead \u2014 they do not need eval."
        };
      }
      fn = new Function("return (async () => {" + code + "})()");
    }
    const result = await Promise.race([
      fn(),
      new Promise(
        (_, reject2) => setTimeout(() => reject2(new Error("Execution timed out")), timeoutMs)
      )
    ]);
    let serialized;
    let type2 = typeof result;
    try {
      if (result === void 0) {
        serialized = null;
        type2 = "undefined";
      } else if (result instanceof HTMLElement) {
        serialized = {
          tag: result.tagName.toLowerCase(),
          id: result.id,
          className: result.className,
          text: (result.textContent ?? "").trim().slice(0, 500)
        };
        type2 = "HTMLElement";
      } else if (result instanceof NodeList || result instanceof HTMLCollection) {
        serialized = Array.from(result).map((el) => ({
          tag: el.tagName?.toLowerCase(),
          id: el.id,
          text: (el.textContent ?? "").trim().slice(0, 200)
        }));
        type2 = "NodeList";
      } else {
        serialized = JSON.parse(JSON.stringify(result));
      }
    } catch {
      serialized = String(result);
      type2 = "string (serialized)";
    }
    return { result: serialized, type: type2 };
  } catch (err) {
    return { error: `Execution error: ${err.message ?? err}` };
  }
}
executeScript.__schema__ = {
  name: "executeScript",
  description: `Execute arbitrary JavaScript code in the page context. Supports async/await. The last expression is auto-returned (no need for explicit "return"). Examples: "document.title", "document.querySelectorAll('a').length", "await fetch('/api/data').then(r => r.json())". Returns: { result, type } on success, or { error } on exception.`,
  parameters: {
    type: "object",
    properties: {
      code: {
        type: "string",
        description: `JavaScript code to execute. The last expression is automatically returned. Examples: "document.title", "document.querySelector('h1').textContent".`
      },
      timeout_ms: {
        type: "number",
        description: "Maximum execution time in milliseconds. Default: 10000."
      }
    },
    required: ["code"]
  }
};

// src/services/navigate.ts
var STORAGE_KEY = "__hypha_debugger_config__";
function getScriptUrl() {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    if (raw) {
      const config2 = JSON.parse(raw);
      if (config2.script_url) return config2.script_url;
    }
  } catch {
  }
  return "https://cdn.jsdelivr.net/npm/hypha-debugger/dist/hypha-debugger.min.js";
}
function injectLoader(html, scriptUrl) {
  const loader = `<script src="${scriptUrl}"><\/script>`;
  if (html.includes("</body>")) {
    return html.replace("</body>", loader + "\n</body>");
  }
  if (html.includes("</html>")) {
    return html.replace("</html>", loader + "\n</html>");
  }
  return html + "\n" + loader;
}
function softReplace(url, pushState) {
  const scriptUrl = getScriptUrl();
  fetch(url, { credentials: "same-origin", cache: "reload" }).then((response) => {
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const contentType = response.headers.get("content-type") ?? "";
    if (!contentType.includes("text/html")) {
      throw new Error("Not HTML");
    }
    return response.text();
  }).then((html) => {
    const modified = injectLoader(html, scriptUrl);
    document.open();
    document.write(modified);
    document.close();
    if (pushState) {
      try {
        history.pushState({}, "", pushState);
      } catch {
      }
    }
  }).catch(() => {
    if (pushState) {
      window.location.href = pushState;
    } else {
      window.location.reload();
    }
  });
}
function navigate(url) {
  try {
    const targetUrl = new URL(url, location.href);
    const sameOrigin = targetUrl.origin === location.origin;
    if (sameOrigin) {
      setTimeout(() => softReplace(targetUrl.href, targetUrl.href), 150);
      return {
        success: true,
        message: `Navigating to ${url} (debugger will auto-reconnect)`
      };
    } else {
      window.location.href = url;
      return {
        success: true,
        message: `Navigating to ${url} (cross-origin, debugger will disconnect)`
      };
    }
  } catch (err) {
    return {
      success: false,
      message: `Navigation failed: ${err.message ?? err}`
    };
  }
}
navigate.__schema__ = {
  name: "navigate",
  description: "Navigate the browser to a new URL. For same-origin URLs, the debugger auto-reconnects. Cross-origin navigation will disconnect the debugger.",
  parameters: {
    type: "object",
    properties: {
      url: {
        type: "string",
        description: "The URL to navigate to."
      }
    },
    required: ["url"]
  }
};
function goBack() {
  try {
    window.history.back();
    return {
      success: true,
      message: "Navigated back (debugger will auto-reconnect via popstate)"
    };
  } catch (err) {
    return {
      success: false,
      message: `Back navigation failed: ${err.message ?? err}`
    };
  }
}
goBack.__schema__ = {
  name: "goBack",
  description: "Navigate back in browser history. The debugger auto-reconnects for same-origin pages.",
  parameters: {
    type: "object",
    properties: {}
  }
};
function goForward() {
  try {
    window.history.forward();
    return {
      success: true,
      message: "Navigated forward (debugger will auto-reconnect via popstate)"
    };
  } catch (err) {
    return {
      success: false,
      message: `Forward navigation failed: ${err.message ?? err}`
    };
  }
}
goForward.__schema__ = {
  name: "goForward",
  description: "Navigate forward in browser history. The debugger auto-reconnects for same-origin pages.",
  parameters: {
    type: "object",
    properties: {}
  }
};
function reload() {
  try {
    setTimeout(() => softReplace(location.href), 150);
    return {
      success: true,
      message: "Reloading page (debugger will auto-reconnect)"
    };
  } catch (err) {
    return { success: false, message: `Reload failed: ${err.message ?? err}` };
  }
}
reload.__schema__ = {
  name: "reload",
  description: "Reload the current page. The debugger auto-reconnects after reload using soft page replacement.",
  parameters: {
    type: "object",
    properties: {}
  }
};

// src/services/react.ts
function getFiberFromDOM(node) {
  const keys = Object.keys(node);
  const fiberKey = keys.find(
    (k) => k.startsWith("__reactFiber$") || k.startsWith("__reactInternalInstance$")
  );
  return fiberKey ? node[fiberKey] : null;
}
function findReactRoot() {
  const common = ["#root", "#app", "#__next", "[data-reactroot]", "main", "body"];
  for (const sel of common) {
    const el = document.querySelector(sel);
    if (el && getFiberFromDOM(el)) return el;
  }
  const walker = document.createTreeWalker(
    document.body,
    NodeFilter.SHOW_ELEMENT,
    null
  );
  let node = walker.currentNode;
  while (node) {
    if (node instanceof Element && getFiberFromDOM(node)) return node;
    node = walker.nextNode();
  }
  return null;
}
function getComponentName(fiber) {
  const { type: type2 } = fiber;
  if (!type2) return "(unknown)";
  if (typeof type2 === "string") return type2;
  if (typeof type2 === "function") {
    return type2.displayName || type2.name || "Anonymous";
  }
  if (typeof type2 === "object") {
    if (type2.displayName) return type2.displayName;
    if (type2.render)
      return type2.render.displayName || type2.render.name || "ForwardRef";
    if (type2.type) return getComponentName({ type: type2.type });
    if (type2.$$typeof?.toString() === "Symbol(react.memo)") {
      return `Memo(${getComponentName({ type: type2.type })})`;
    }
  }
  return "(unknown)";
}
function getFiberType(fiber) {
  if (fiber.tag === 0 || fiber.tag === 11 || fiber.tag === 14 || fiber.tag === 15)
    return "function";
  if (fiber.tag === 1) return "class";
  if (fiber.tag === 5 || fiber.tag === 6) return "host";
  return "other";
}
function safeSerialize(obj, depth = 0, maxDepth = 2) {
  if (depth > maxDepth) return "[max depth]";
  if (obj === null || obj === void 0) return obj;
  if (typeof obj === "function") return `[Function: ${obj.name || "anonymous"}]`;
  if (typeof obj !== "object") return obj;
  if (obj instanceof HTMLElement) return `[${obj.tagName.toLowerCase()}#${obj.id}]`;
  if (Array.isArray(obj)) {
    return obj.slice(0, 10).map((v) => safeSerialize(v, depth + 1, maxDepth));
  }
  const result = {};
  const keys = Object.keys(obj).slice(0, 20);
  for (const key of keys) {
    if (key.startsWith("_") || key.startsWith("$$")) continue;
    try {
      result[key] = safeSerialize(obj[key], depth + 1, maxDepth);
    } catch {
      result[key] = "[unserializable]";
    }
  }
  return result;
}
function extractState(fiber) {
  if (fiber.tag === 1 && fiber.stateNode) {
    return safeSerialize(fiber.stateNode.state);
  }
  if (fiber.tag === 0 || fiber.tag === 11 || fiber.tag === 15) {
    const states = [];
    let hook = fiber.memoizedState;
    let i = 0;
    while (hook && i < 20) {
      if (hook.queue !== null && hook.queue !== void 0) {
        states.push(safeSerialize(hook.memoizedState));
      }
      hook = hook.next;
      i++;
    }
    return states.length > 0 ? states : null;
  }
  return null;
}
function fiberToInfo(fiber, depth, maxDepth) {
  const fiberType = getFiberType(fiber);
  const isComponent = fiberType === "function" || fiberType === "class";
  const info = {
    name: getComponentName(fiber),
    type: fiberType,
    props: isComponent ? safeSerialize(fiber.memoizedProps) : {},
    state: isComponent ? extractState(fiber) : null,
    key: fiber.key,
    children: []
  };
  if (depth < maxDepth) {
    let child = fiber.child;
    while (child) {
      const childInfo = fiberToInfo(child, depth + 1, maxDepth);
      if (childInfo) {
        if (childInfo.type !== "host" || childInfo.children.length > 0) {
          info.children.push(childInfo);
        }
      }
      child = child.sibling;
    }
  }
  return info;
}
function getReactTree(selector, max_depth) {
  const maxDepth = max_depth ?? 5;
  let rootEl;
  let usedSelector;
  if (selector) {
    rootEl = document.querySelector(selector);
    usedSelector = selector;
    if (!rootEl) {
      return { error: `No element found for selector: ${selector}` };
    }
  } else {
    rootEl = findReactRoot();
    usedSelector = rootEl?.tagName.toLowerCase() + (rootEl?.id ? "#" + rootEl.id : "") || "(auto)";
    if (!rootEl) {
      return {
        error: "No React root found on this page. Tried #root, #app, #__next, [data-reactroot], main, body \u2014 none had React fibers. This page may not be a React app, or React may not have rendered yet. Pass an explicit `selector` if you know the mount point."
      };
    }
  }
  const fiber = getFiberFromDOM(rootEl);
  if (!fiber) {
    return {
      error: `No React fiber found on element "${usedSelector}". Is this a React app?`
    };
  }
  let current = fiber;
  while (current && current.tag === 3) {
    current = current.child;
  }
  if (!current) {
    return { error: "Could not find root React component fiber." };
  }
  const tree = fiberToInfo(current, 0, maxDepth);
  if (!tree) {
    return { error: "Could not build React component tree." };
  }
  return tree;
}
getReactTree.__schema__ = {
  name: "getReactTree",
  description: "Inspect the React component tree. Returns component names, props, state (including hooks), and children hierarchy. When no selector is provided, auto-detects the React root by scanning common mount points (#root, #app, #__next, [data-reactroot], main, body) and then walking the DOM for any element with a React fiber attached.",
  parameters: {
    type: "object",
    properties: {
      selector: {
        type: "string",
        description: "CSS selector of the React root element. Omit for auto-detection."
      },
      max_depth: {
        type: "number",
        description: "Maximum depth to traverse the component tree. Default: 5."
      }
    }
  }
};

// src/services/skill.ts
function generateSkillMd(serviceFunctions, serviceUrl, pageContext) {
  const frontmatter = [
    "---",
    "name: web-debugger",
    "description: A Hypha debugger injected into a LIVE web page in a real browser. Remotely inspect the DOM, take screenshots, run JavaScript, fill forms, click/type by index, inspect React, and navigate \u2014 all via HTTP API calls.",
    "compatibility: Requires network access to the Hypha server. Works with any HTTP client (curl, fetch, Python requests).",
    "metadata:",
    '  version: "0.1"',
    '  author: "hypha-debugger"',
    "---"
  ].join("\n");
  const attached2 = pageContext?.title || pageContext?.url ? `**Currently attached to:** ${pageContext.title ? `"${pageContext.title}"` : ""}${pageContext.url ? ` \u2014 ${pageContext.url}` : ""} (call \`get_page_info\` for live details).` : "Call `get_page_info` to see the page you are attached to.";
  const intro = [
    "",
    "# Web Debugger \u2014 control a live web page",
    "",
    "**What this is:** a Hypha debugger has been injected into a LIVE web page running in a real browser, and this document is its HTTP API. You (an AI agent) can remotely inspect and control that exact page \u2014 read and modify the DOM, click and type, take screenshots, run JavaScript, and inspect React components. Changes you make are applied to the real page immediately.",
    "",
    attached2,
    "",
    "Every function below is an HTTP endpoint under the service URL. Pick the approach that fits your task \u2014 they combine freely.",
    "",
    "## Approaches",
    "",
    "### execute_script \u2014 Run Arbitrary JavaScript",
    "",
    "The most versatile function. Use it to read/modify page state, call APIs, query the DOM,",
    "or do anything JavaScript can do. The last expression is auto-returned (no need for `return`).",
    "",
    "```bash",
    `# Read page state`,
    `curl -X POST '{SERVICE_URL}/execute_script' \\`,
    `  -H 'Content-Type: application/json' -d '{"code": "document.title"}'`,
    "",
    `# Query DOM`,
    `curl -X POST '{SERVICE_URL}/execute_script' \\`,
    `  -H 'Content-Type: application/json' -d '{"code": "document.querySelector(\\"h1\\").textContent"}'`,
    "",
    `# Call an API`,
    `curl -X POST '{SERVICE_URL}/execute_script' \\`,
    `  -H 'Content-Type: application/json' -d '{"code": "await fetch(\\"/api/data\\").then(r => r.json())"}'`,
    "",
    `# Modify the page`,
    `curl -X POST '{SERVICE_URL}/execute_script' \\`,
    `  -H 'Content-Type: application/json' -d '{"code": "document.getElementById(\\"name\\").value = \\"Alice\\""}'`,
    "```",
    "",
    "### get_browser_state + Index-Based Interaction",
    "",
    "Best for UI interaction as a user would \u2014 clicking buttons, filling forms, selecting options.",
    "All interactive elements are detected and indexed as `[0]`, `[1]`, `[2]`, etc.",
    "",
    "```bash",
    `# Step 1: See all interactive elements`,
    `curl '{SERVICE_URL}/get_browser_state'`,
    "",
    `# Step 2: Act by index`,
    `curl -X POST '{SERVICE_URL}/click_element_by_index' \\`,
    `  -H 'Content-Type: application/json' -d '{"index": 2}'`,
    "",
    `curl -X POST '{SERVICE_URL}/input_text' \\`,
    `  -H 'Content-Type: application/json' -d '{"index": 1, "text": "hello world"}'`,
    "",
    `curl -X POST '{SERVICE_URL}/select_option' \\`,
    `  -H 'Content-Type: application/json' -d '{"index": 3, "option_text": "French"}'`,
    "",
    `curl -X POST '{SERVICE_URL}/scroll' \\`,
    `  -H 'Content-Type: application/json' -d '{"direction": "down"}'`,
    "",
    `# Step 3: Verify visually`,
    `curl '{SERVICE_URL}/take_screenshot'`,
    "```",
    "",
    "### get_react_tree \u2014 Inspect React Components",
    "",
    "If the page uses React, inspect component names, props, state, and hooks:",
    "```bash",
    `curl '{SERVICE_URL}/get_react_tree'`,
    "```",
    "",
    "### CSS Selector-Based Functions",
    "",
    "Use CSS selectors directly when you know the element:",
    "```bash",
    `curl -X POST '{SERVICE_URL}/click_element' \\`,
    `  -H 'Content-Type: application/json' -d '{"selector": "button.submit"}'`,
    "",
    `curl -X POST '{SERVICE_URL}/fill_input' \\`,
    `  -H 'Content-Type: application/json' -d '{"selector": "#email", "value": "user@example.com"}'`,
    "",
    `curl -X POST '{SERVICE_URL}/query_dom' \\`,
    `  -H 'Content-Type: application/json' -d '{"selector": ".product-card"}'`,
    "```",
    "",
    "## How to call functions",
    "",
    "All functions are available as HTTP endpoints. Replace `{SERVICE_URL}` with the actual service URL.",
    "",
    "- **GET** for functions with no required parameters",
    "- **POST** with JSON body for functions with parameters",
    "- Append `?_mode=last` to resolve the most recent instance (recommended after page reloads where the clientId changes)",
    "",
    "## Response format",
    "",
    "All functions return JSON. There are three patterns:",
    "",
    "**1. Data-returning functions** (e.g. `take_screenshot`, `get_page_info`, `execute_script`, `get_browser_state`, `get_html`, `get_react_tree`) return function-specific keys:",
    "",
    "- `take_screenshot` \u2192 `{base64, media_type, data_url, format, width, height, size_kb}`. Use `base64` (raw, no prefix) for Claude/GPT image content fields. Use `data_url` for HTML `<img src=...>` previews.",
    "- `execute_script` \u2192 `{result, type}` (or `{error}` on exception)",
    "- `get_browser_state` \u2192 `{url, title, header, content, footer, element_count}`",
    "- `get_page_info` \u2192 `{url, title, viewport_width, viewport_height, ...}`",
    "- `get_html` \u2192 `{html, length, truncated}`",
    "",
    "**2. Action functions** (e.g. `click_*`, `input_text`, `select_option`, `scroll`, `navigate`) return:",
    "",
    '- `{success: true, message: "..."}` \u2014 action succeeded',
    '- `{success: false, message: "..."}` \u2014 action failed (element not found, etc.)',
    "",
    "**3. Errors from the Hypha gateway** (NOT from the service itself) return:",
    "",
    '- `{success: false, detail: "..."}` \u2014 e.g. service not found, call timed out, disconnected. If you see this, the browser tab is probably closed or the debugger crashed.',
    ""
  ].join("\n");
  const functionDocs = ["## Available Functions", ""];
  const entries = Object.entries(serviceFunctions).filter(
    ([name2, fn]) => fn?.__schema__ && name2 !== "get_skill_md"
  );
  for (const [name2, fn] of entries) {
    const schema = fn.__schema__;
    functionDocs.push(`### \`${name2}\``);
    functionDocs.push("");
    functionDocs.push(schema.description);
    functionDocs.push("");
    const props = schema.parameters?.properties;
    const required = schema.parameters?.required ?? [];
    if (props && Object.keys(props).length > 0) {
      functionDocs.push("**Parameters:**");
      functionDocs.push("");
      functionDocs.push("| Parameter | Type | Required | Description |");
      functionDocs.push("|-----------|------|----------|-------------|");
      for (const [param, info] of Object.entries(props)) {
        const isRequired = required.includes(param);
        let typeStr = info.type ?? "any";
        if (info.enum) {
          typeStr = info.enum.map((e) => `"${e}"`).join(" / ");
        }
        if (info.items) typeStr = `${info.items.type}[]`;
        const desc = (info.description ?? "").replace(/\|/g, "\\|");
        functionDocs.push(
          `| \`${param}\` | ${typeStr} | ${isRequired ? "Yes" : "No"} | ${desc} |`
        );
      }
      functionDocs.push("");
      if (required.length > 0) {
        const exampleParams = {};
        for (const p of required) {
          const info = props[p];
          if (info?.type === "string") exampleParams[p] = `<${p}>`;
          else if (info?.type === "number") exampleParams[p] = "0";
          else exampleParams[p] = `<${p}>`;
        }
        functionDocs.push("**Example:**");
        functionDocs.push("```bash");
        functionDocs.push(
          `curl -X POST '{SERVICE_URL}/${name2}' \\`
        );
        functionDocs.push(`  -H 'Content-Type: application/json' \\`);
        functionDocs.push(`  -d '${JSON.stringify(exampleParams)}'`);
        functionDocs.push("```");
      } else {
        functionDocs.push("**Example:**");
        functionDocs.push("```bash");
        functionDocs.push(
          `curl '{SERVICE_URL}/${name2}'`
        );
        functionDocs.push("```");
      }
    } else {
      functionDocs.push("**Parameters:** None");
      functionDocs.push("");
      functionDocs.push("**Example:**");
      functionDocs.push("```bash");
      functionDocs.push(
        `curl '{SERVICE_URL}/${name2}'`
      );
      functionDocs.push("```");
    }
    functionDocs.push("");
  }
  const tips = [
    "## Tips",
    "",
    "- **`execute_script` is the most versatile** \u2014 use it for reading state, calling APIs, DOM queries, or anything not covered by other functions. The last expression is auto-returned. Returns `{result, type}`.",
    "- **`get_browser_state` is the best way to see what's on the page** \u2014 it detects all interactive elements and shows them as indexed items.",
    "- **After each action, call `get_browser_state` again** \u2014 element indices change when the DOM updates.",
    "- **Use `take_screenshot`** to visually verify the page state. The response includes `base64` (raw, ready for Claude/GPT image fields) and `data_url` (for HTML previews). Default size is 800px JPEG q=0.6 \u2014 bump `max_width` if you need more detail.",
    "- **Use `remove_highlights`** before a screenshot for a clean view.",
    "- **Use `scroll`** with an element index to scroll inside a specific container (e.g. a chat window, sidebar).",
    "- **Use `get_page_info` with `include_logs=true`** to check for JavaScript errors or debug output.",
    "- **Use `get_react_tree`** if the page uses React \u2014 it gives you component names, props, and state without needing DevTools.",
    "- **Use `navigate`** to go to other pages \u2014 same-origin navigation auto-reconnects the debugger.",
    '- **If you get `{success: false, detail: "Service not found"}`** \u2014 the browser tab was closed or the debugger disconnected. The user needs to re-click the bookmarklet.',
    "- **Append `?_mode=last`** to the URL if the service clientId changed (e.g. after page reload) \u2014 resolves to the most recent instance.",
    "- All POST endpoints accept JSON body with the parameter names as keys.",
    ""
  ].join("\n");
  return [frontmatter, intro, functionDocs.join("\n"), tips].join("\n");
}

// src/page-controller/dom-tree.js
var dom_tree_default = (args = {
  doHighlightElements: true,
  focusHighlightIndex: -1,
  viewportExpansion: 0,
  debugMode: false,
  /**
   * @edit
   */
  /** @type {Element[]} */
  interactiveBlacklist: [],
  /** @type {Element[]} */
  interactiveWhitelist: [],
  highlightOpacity: 0.1,
  highlightLabelOpacity: 0.5
}) => {
  const { interactiveBlacklist, interactiveWhitelist, highlightOpacity, highlightLabelOpacity } = args;
  const { doHighlightElements, focusHighlightIndex, viewportExpansion, debugMode } = args;
  let highlightIndex = 0;
  const extraData = /* @__PURE__ */ new WeakMap();
  function addExtraData(element, data) {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) return;
    extraData.set(element, { ...extraData.get(element), ...data });
  }
  const DOM_CACHE = {
    boundingRects: /* @__PURE__ */ new WeakMap(),
    clientRects: /* @__PURE__ */ new WeakMap(),
    computedStyles: /* @__PURE__ */ new WeakMap(),
    clearCache: () => {
      DOM_CACHE.boundingRects = /* @__PURE__ */ new WeakMap();
      DOM_CACHE.clientRects = /* @__PURE__ */ new WeakMap();
      DOM_CACHE.computedStyles = /* @__PURE__ */ new WeakMap();
    }
  };
  function getCachedBoundingRect(element) {
    if (!element) return null;
    if (DOM_CACHE.boundingRects.has(element)) {
      return DOM_CACHE.boundingRects.get(element);
    }
    const rect = element.getBoundingClientRect();
    if (rect) {
      DOM_CACHE.boundingRects.set(element, rect);
    }
    return rect;
  }
  function getCachedComputedStyle(element) {
    if (!element) return null;
    if (DOM_CACHE.computedStyles.has(element)) {
      return DOM_CACHE.computedStyles.get(element);
    }
    const style = window.getComputedStyle(element);
    if (style) {
      DOM_CACHE.computedStyles.set(element, style);
    }
    return style;
  }
  function getCachedClientRects(element) {
    if (!element) return null;
    if (DOM_CACHE.clientRects.has(element)) {
      return DOM_CACHE.clientRects.get(element);
    }
    const rects = element.getClientRects();
    if (rects) {
      DOM_CACHE.clientRects.set(element, rects);
    }
    return rects;
  }
  const DOM_HASH_MAP = {};
  const ID = { current: 0 };
  const HIGHLIGHT_CONTAINER_ID = "playwright-highlight-container";
  const xpathCache = /* @__PURE__ */ new WeakMap();
  function highlightElement(element, index, parentIframe = null) {
    if (!element) return index;
    const overlays = [];
    let label = null;
    let labelWidth = 20;
    let labelHeight = 16;
    let cleanupFn = null;
    try {
      let container = document.getElementById(HIGHLIGHT_CONTAINER_ID);
      if (!container) {
        container = document.createElement("div");
        container.id = HIGHLIGHT_CONTAINER_ID;
        container.style.position = "fixed";
        container.style.pointerEvents = "none";
        container.style.top = "0";
        container.style.left = "0";
        container.style.width = "100%";
        container.style.height = "100%";
        container.style.zIndex = "2147483640";
        container.style.backgroundColor = "transparent";
        document.body.appendChild(container);
      }
      const rects = element.getClientRects();
      if (!rects || rects.length === 0) return index;
      const colors = [
        "#FF0000",
        "#00FF00",
        "#0000FF",
        "#FFA500",
        "#800080",
        "#008080",
        "#FF69B4",
        "#4B0082",
        "#FF4500",
        "#2E8B57",
        "#DC143C",
        "#4682B4"
      ];
      const colorIndex = index % colors.length;
      let baseColor = colors[colorIndex];
      const backgroundColor = baseColor + Math.floor(highlightOpacity * 255).toString(16).padStart(2, "0");
      baseColor = baseColor + Math.floor(highlightLabelOpacity * 255).toString(16).padStart(2, "0");
      let iframeOffset = { x: 0, y: 0 };
      if (parentIframe) {
        const iframeRect = parentIframe.getBoundingClientRect();
        iframeOffset.x = iframeRect.left;
        iframeOffset.y = iframeRect.top;
      }
      const fragment = document.createDocumentFragment();
      for (const rect of rects) {
        if (rect.width === 0 || rect.height === 0) continue;
        const overlay = document.createElement("div");
        overlay.style.position = "fixed";
        overlay.style.border = `2px solid ${baseColor}`;
        overlay.style.backgroundColor = backgroundColor;
        overlay.style.pointerEvents = "none";
        overlay.style.boxSizing = "border-box";
        const top = rect.top + iframeOffset.y;
        const left = rect.left + iframeOffset.x;
        overlay.style.top = `${top}px`;
        overlay.style.left = `${left}px`;
        overlay.style.width = `${rect.width}px`;
        overlay.style.height = `${rect.height}px`;
        fragment.appendChild(overlay);
        overlays.push({ element: overlay, initialRect: rect });
      }
      const firstRect = rects[0];
      label = document.createElement("div");
      label.className = "playwright-highlight-label";
      label.style.position = "fixed";
      label.style.background = baseColor;
      label.style.color = "white";
      label.style.padding = "1px 4px";
      label.style.borderRadius = "4px";
      label.style.fontSize = `${Math.min(12, Math.max(8, firstRect.height / 2))}px`;
      label.textContent = index.toString();
      labelWidth = label.offsetWidth > 0 ? label.offsetWidth : labelWidth;
      labelHeight = label.offsetHeight > 0 ? label.offsetHeight : labelHeight;
      const firstRectTop = firstRect.top + iframeOffset.y;
      const firstRectLeft = firstRect.left + iframeOffset.x;
      let labelTop = firstRectTop + 2;
      let labelLeft = firstRectLeft + firstRect.width - labelWidth - 2;
      if (firstRect.width < labelWidth + 4 || firstRect.height < labelHeight + 4) {
        labelTop = firstRectTop - labelHeight - 2;
        labelLeft = firstRectLeft + firstRect.width - labelWidth;
        if (labelLeft < iframeOffset.x) labelLeft = firstRectLeft;
      }
      labelTop = Math.max(0, Math.min(labelTop, window.innerHeight - labelHeight));
      labelLeft = Math.max(0, Math.min(labelLeft, window.innerWidth - labelWidth));
      label.style.top = `${labelTop}px`;
      label.style.left = `${labelLeft}px`;
      fragment.appendChild(label);
      const updatePositions = () => {
        const newRects = element.getClientRects();
        let newIframeOffset = { x: 0, y: 0 };
        if (parentIframe) {
          const iframeRect = parentIframe.getBoundingClientRect();
          newIframeOffset.x = iframeRect.left;
          newIframeOffset.y = iframeRect.top;
        }
        overlays.forEach((overlayData, i) => {
          if (i < newRects.length) {
            const newRect = newRects[i];
            const newTop = newRect.top + newIframeOffset.y;
            const newLeft = newRect.left + newIframeOffset.x;
            overlayData.element.style.top = `${newTop}px`;
            overlayData.element.style.left = `${newLeft}px`;
            overlayData.element.style.width = `${newRect.width}px`;
            overlayData.element.style.height = `${newRect.height}px`;
            overlayData.element.style.display = newRect.width === 0 || newRect.height === 0 ? "none" : "block";
          } else {
            overlayData.element.style.display = "none";
          }
        });
        if (newRects.length < overlays.length) {
          for (let i = newRects.length; i < overlays.length; i++) {
            overlays[i].element.style.display = "none";
          }
        }
        if (label && newRects.length > 0) {
          const firstNewRect = newRects[0];
          const firstNewRectTop = firstNewRect.top + newIframeOffset.y;
          const firstNewRectLeft = firstNewRect.left + newIframeOffset.x;
          let newLabelTop = firstNewRectTop + 2;
          let newLabelLeft = firstNewRectLeft + firstNewRect.width - labelWidth - 2;
          if (firstNewRect.width < labelWidth + 4 || firstNewRect.height < labelHeight + 4) {
            newLabelTop = firstNewRectTop - labelHeight - 2;
            newLabelLeft = firstNewRectLeft + firstNewRect.width - labelWidth;
            if (newLabelLeft < newIframeOffset.x) newLabelLeft = firstNewRectLeft;
          }
          newLabelTop = Math.max(0, Math.min(newLabelTop, window.innerHeight - labelHeight));
          newLabelLeft = Math.max(0, Math.min(newLabelLeft, window.innerWidth - labelWidth));
          label.style.top = `${newLabelTop}px`;
          label.style.left = `${newLabelLeft}px`;
          label.style.display = "block";
        } else if (label) {
          label.style.display = "none";
        }
      };
      const throttleFunction = (func, delay) => {
        let lastCall = 0;
        return (...args2) => {
          const now = performance.now();
          if (now - lastCall < delay) return;
          lastCall = now;
          return func(...args2);
        };
      };
      const throttledUpdatePositions = throttleFunction(updatePositions, 16);
      window.addEventListener("scroll", throttledUpdatePositions, true);
      window.addEventListener("resize", throttledUpdatePositions);
      cleanupFn = () => {
        window.removeEventListener("scroll", throttledUpdatePositions, true);
        window.removeEventListener("resize", throttledUpdatePositions);
        overlays.forEach((overlay) => overlay.element.remove());
        if (label) label.remove();
      };
      container.appendChild(fragment);
      return index + 1;
    } finally {
      if (cleanupFn) {
        ;
        (window._highlightCleanupFunctions = window._highlightCleanupFunctions || []).push(
          cleanupFn
        );
      }
    }
  }
  function getElementPosition(currentElement) {
    if (!currentElement.parentElement) {
      return 0;
    }
    const tagName = currentElement.nodeName.toLowerCase();
    const siblings = Array.from(currentElement.parentElement.children).filter(
      (sib) => sib.nodeName.toLowerCase() === tagName
    );
    if (siblings.length === 1) {
      return 0;
    }
    const index = siblings.indexOf(currentElement) + 1;
    return index;
  }
  function getXPathTree(element, stopAtBoundary = true) {
    if (xpathCache.has(element)) return xpathCache.get(element);
    const segments = [];
    let currentElement = element;
    while (currentElement && currentElement.nodeType === Node.ELEMENT_NODE) {
      if (stopAtBoundary && (currentElement.parentNode instanceof ShadowRoot || currentElement.parentNode instanceof HTMLIFrameElement)) {
        break;
      }
      const position = getElementPosition(currentElement);
      const tagName = currentElement.nodeName.toLowerCase();
      const xpathIndex = position > 0 ? `[${position}]` : "";
      segments.unshift(`${tagName}${xpathIndex}`);
      currentElement = currentElement.parentNode;
    }
    const result = segments.join("/");
    xpathCache.set(element, result);
    return result;
  }
  function isScrollableElement(element) {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) {
      return null;
    }
    const style = getCachedComputedStyle(element);
    if (!style) return null;
    const display = style.display;
    if (display === "inline" || display === "inline-block") {
      return null;
    }
    const overflowX = style.overflowX;
    const overflowY = style.overflowY;
    const scrollableX = overflowX === "auto" || overflowX === "scroll";
    const scrollableY = overflowY === "auto" || overflowY === "scroll";
    if (!scrollableX && !scrollableY) {
      return null;
    }
    const scrollWidth = element.scrollWidth - element.clientWidth;
    const scrollHeight = element.scrollHeight - element.clientHeight;
    const threshold = 4;
    if (scrollWidth < threshold && scrollHeight < threshold) {
      return null;
    }
    if (!scrollableY && scrollWidth < threshold) {
      return null;
    }
    if (!scrollableX && scrollHeight < threshold) {
      return null;
    }
    const distanceToTop = element.scrollTop;
    const distanceToLeft = element.scrollLeft;
    const distanceToRight = element.scrollWidth - element.clientWidth - element.scrollLeft;
    const distanceToBottom = element.scrollHeight - element.clientHeight - element.scrollTop;
    const scrollData = {
      top: distanceToTop,
      right: distanceToRight,
      bottom: distanceToBottom,
      left: distanceToLeft
    };
    addExtraData(element, {
      scrollable: true,
      scrollData
    });
    return scrollData;
  }
  function isTextNodeVisible(textNode) {
    try {
      if (viewportExpansion === -1) {
        const parentElement2 = textNode.parentElement;
        if (!parentElement2) return false;
        try {
          return parentElement2.checkVisibility({
            checkOpacity: true,
            checkVisibilityCSS: true
          });
        } catch (e) {
          const style = window.getComputedStyle(parentElement2);
          return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
        }
      }
      const range = document.createRange();
      range.selectNodeContents(textNode);
      const rects = range.getClientRects();
      if (!rects || rects.length === 0) {
        return false;
      }
      let isAnyRectVisible = false;
      let isAnyRectInViewport = false;
      for (const rect of rects) {
        if (rect.width > 0 && rect.height > 0) {
          isAnyRectVisible = true;
          if (!(rect.bottom < -viewportExpansion || rect.top > window.innerHeight + viewportExpansion || rect.right < -viewportExpansion || rect.left > window.innerWidth + viewportExpansion)) {
            isAnyRectInViewport = true;
            break;
          }
        }
      }
      if (!isAnyRectVisible || !isAnyRectInViewport) {
        return false;
      }
      const parentElement = textNode.parentElement;
      if (!parentElement) return false;
      try {
        return parentElement.checkVisibility({
          checkOpacity: true,
          checkVisibilityCSS: true
        });
      } catch (e) {
        const style = window.getComputedStyle(parentElement);
        return style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
      }
    } catch (e) {
      console.warn("Error checking text node visibility:", e);
      return false;
    }
  }
  function isElementAccepted(element) {
    if (!element || !element.tagName) return false;
    const alwaysAccept = /* @__PURE__ */ new Set([
      "body",
      "div",
      "main",
      "article",
      "section",
      "nav",
      "header",
      "footer"
    ]);
    const tagName = element.tagName.toLowerCase();
    if (alwaysAccept.has(tagName)) return true;
    const leafElementDenyList = /* @__PURE__ */ new Set([
      "svg",
      "script",
      "style",
      "link",
      "meta",
      "noscript",
      "template"
    ]);
    return !leafElementDenyList.has(tagName);
  }
  function isElementVisible(element) {
    const style = getCachedComputedStyle(element);
    return element.offsetWidth > 0 && element.offsetHeight > 0 && style?.visibility !== "hidden" && style?.display !== "none";
  }
  function isInteractiveElement(element) {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) {
      return false;
    }
    if (interactiveBlacklist.includes(element)) {
      return false;
    }
    if (interactiveWhitelist.includes(element)) {
      return true;
    }
    const tagName = element.tagName.toLowerCase();
    const style = getCachedComputedStyle(element);
    const interactiveCursors = /* @__PURE__ */ new Set([
      "pointer",
      // Link/clickable elements
      "move",
      // Movable elements
      "text",
      // Text selection
      "grab",
      // Grabbable elements
      "grabbing",
      // Currently grabbing
      "cell",
      // Table cell selection
      "copy",
      // Copy operation
      "alias",
      // Alias creation
      "all-scroll",
      // Scrollable content
      "col-resize",
      // Column resize
      "context-menu",
      // Context menu available
      "crosshair",
      // Precise selection
      "e-resize",
      // East resize
      "ew-resize",
      // East-west resize
      "help",
      // Help available
      "n-resize",
      // North resize
      "ne-resize",
      // Northeast resize
      "nesw-resize",
      // Northeast-southwest resize
      "ns-resize",
      // North-south resize
      "nw-resize",
      // Northwest resize
      "nwse-resize",
      // Northwest-southeast resize
      "row-resize",
      // Row resize
      "s-resize",
      // South resize
      "se-resize",
      // Southeast resize
      "sw-resize",
      // Southwest resize
      "vertical-text",
      // Vertical text selection
      "w-resize",
      // West resize
      "zoom-in",
      // Zoom in
      "zoom-out"
      // Zoom out
    ]);
    const nonInteractiveCursors = /* @__PURE__ */ new Set([
      "not-allowed",
      // Action not allowed
      "no-drop",
      // Drop not allowed
      "wait",
      // Processing
      "progress",
      // In progress
      "initial",
      // Initial value
      "inherit"
      // Inherited value
      //? Let's just include all potentially clickable elements that are not specifically blocked
      // 'none',        // No cursor
      // 'default',     // Default cursor
      // 'auto',        // Browser default
    ]);
    function doesElementHaveInteractivePointer(element2) {
      if (element2.tagName.toLowerCase() === "html") return false;
      if (style?.cursor && interactiveCursors.has(style.cursor)) return true;
      return false;
    }
    let isInteractiveCursor = doesElementHaveInteractivePointer(element);
    if (isInteractiveCursor) {
      return true;
    }
    const interactiveElements = /* @__PURE__ */ new Set([
      "a",
      // Links
      "button",
      // Buttons
      "input",
      // All input types (text, checkbox, radio, etc.)
      "select",
      // Dropdown menus
      "textarea",
      // Text areas
      "details",
      // Expandable details
      "summary",
      // Summary element (clickable part of details)
      "label",
      // Form labels (often clickable)
      "option",
      // Select options
      "optgroup",
      // Option groups
      "fieldset",
      // Form fieldsets (can be interactive with legend)
      "legend"
      // Fieldset legends
    ]);
    const explicitDisableTags = /* @__PURE__ */ new Set([
      "disabled",
      // Standard disabled attribute
      // 'aria-disabled',      // ARIA disabled state
      "readonly"
      // Read-only state
      // 'aria-readonly',     // ARIA read-only state
      // 'aria-hidden',       // Hidden from accessibility
      // 'hidden',            // Hidden attribute
      // 'inert',             // Inert attribute
      // 'aria-inert',        // ARIA inert state
      // 'tabindex="-1"',     // Removed from tab order
      // 'aria-hidden="true"' // Hidden from screen readers
    ]);
    if (interactiveElements.has(tagName)) {
      if (style?.cursor && nonInteractiveCursors.has(style.cursor)) {
        return false;
      }
      for (const disableTag of explicitDisableTags) {
        if (element.hasAttribute(disableTag) || element.getAttribute(disableTag) === "true" || element.getAttribute(disableTag) === "") {
          return false;
        }
      }
      if (element.disabled) {
        return false;
      }
      if (element.readOnly) {
        return false;
      }
      if (element.inert) {
        return false;
      }
      return true;
    }
    const role = element.getAttribute("role");
    const ariaRole = element.getAttribute("aria-role");
    if (element.getAttribute("contenteditable") === "true" || element.isContentEditable) {
      return true;
    }
    if (element.classList && (element.classList.contains("button") || element.classList.contains("dropdown-toggle") || element.getAttribute("data-index") || element.getAttribute("data-toggle") === "dropdown" || element.getAttribute("aria-haspopup") === "true")) {
      return true;
    }
    const interactiveRoles = /* @__PURE__ */ new Set([
      "button",
      // Directly clickable element
      // 'link',            // Clickable link
      "menu",
      // Menu container (ARIA menus)
      "menubar",
      // Menu bar container
      "menuitem",
      // Clickable menu item
      "menuitemradio",
      // Radio-style menu item (selectable)
      "menuitemcheckbox",
      // Checkbox-style menu item (toggleable)
      "radio",
      // Radio button (selectable)
      "checkbox",
      // Checkbox (toggleable)
      "tab",
      // Tab (clickable to switch content)
      "switch",
      // Toggle switch (clickable to change state)
      "slider",
      // Slider control (draggable)
      "spinbutton",
      // Number input with up/down controls
      "combobox",
      // Dropdown with text input
      "searchbox",
      // Search input field
      "textbox",
      // Text input field
      "listbox",
      // Selectable list
      "option",
      // Selectable option in a list
      "scrollbar"
      // Scrollable control
    ]);
    const hasInteractiveRole = interactiveElements.has(tagName) || role && interactiveRoles.has(role) || ariaRole && interactiveRoles.has(ariaRole);
    if (hasInteractiveRole) return true;
    try {
      if (typeof getEventListeners === "function") {
        const listeners = getEventListeners(element);
        const mouseEvents = ["click", "mousedown", "mouseup", "dblclick"];
        for (const eventType of mouseEvents) {
          if (listeners[eventType] && listeners[eventType].length > 0) {
            return true;
          }
        }
      }
      const getEventListenersForNode = element?.ownerDocument?.defaultView?.getEventListenersForNode || window.getEventListenersForNode;
      if (typeof getEventListenersForNode === "function") {
        const listeners = getEventListenersForNode(element);
        const interactionEvents = [
          "click",
          "mousedown",
          "mouseup",
          "keydown",
          "keyup",
          "submit",
          "change",
          "input",
          "focus",
          "blur"
        ];
        for (const eventType of interactionEvents) {
          for (const listener of listeners) {
            if (listener.type === eventType) {
              return true;
            }
          }
        }
      }
      const commonMouseAttrs = ["onclick", "onmousedown", "onmouseup", "ondblclick"];
      for (const attr of commonMouseAttrs) {
        if (element.hasAttribute(attr) || typeof element[attr] === "function") {
          return true;
        }
      }
    } catch (e) {
    }
    if (isScrollableElement(element)) {
      return true;
    }
    return false;
  }
  function isTopElement(element) {
    if (viewportExpansion === -1) {
      return true;
    }
    const rects = getCachedClientRects(element);
    if (!rects || rects.length === 0) {
      return false;
    }
    let isAnyRectInViewport = false;
    for (const rect2 of rects) {
      if (rect2.width > 0 && rect2.height > 0 && !// Only check non-empty rects
      (rect2.bottom < -viewportExpansion || rect2.top > window.innerHeight + viewportExpansion || rect2.right < -viewportExpansion || rect2.left > window.innerWidth + viewportExpansion)) {
        isAnyRectInViewport = true;
        break;
      }
    }
    if (!isAnyRectInViewport) {
      return false;
    }
    let doc = element.ownerDocument;
    if (doc !== window.document) {
      return true;
    }
    let rect = Array.from(rects).find((r) => r.width > 0 && r.height > 0);
    if (!rect) {
      return false;
    }
    const shadowRoot = element.getRootNode();
    if (shadowRoot instanceof ShadowRoot) {
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      try {
        const topEl = shadowRoot.elementFromPoint(centerX, centerY);
        if (!topEl) return false;
        let current = topEl;
        while (current && current !== shadowRoot) {
          if (current === element) return true;
          current = current.parentElement;
        }
        return false;
      } catch (e) {
        return true;
      }
    }
    const margin = 5;
    const checkPoints = [
      // Initially only this was used, but it was not enough
      { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 },
      { x: rect.left + margin, y: rect.top + margin },
      // top left
      // { x: rect.right - margin, y: rect.top + margin },    // top right
      // { x: rect.left + margin, y: rect.bottom - margin },  // bottom left
      { x: rect.right - margin, y: rect.bottom - margin }
      // bottom right
    ];
    return checkPoints.some(({ x, y }) => {
      try {
        const topEl = document.elementFromPoint(x, y);
        if (!topEl) return false;
        let current = topEl;
        while (current && current !== document.documentElement) {
          if (current === element) return true;
          current = current.parentElement;
        }
        return false;
      } catch (e) {
        return true;
      }
    });
  }
  function isInExpandedViewport(element, viewportExpansion2) {
    if (viewportExpansion2 === -1) {
      return true;
    }
    const rects = element.getClientRects();
    if (!rects || rects.length === 0) {
      const boundingRect = getCachedBoundingRect(element);
      if (!boundingRect || boundingRect.width === 0 || boundingRect.height === 0) {
        return false;
      }
      return !(boundingRect.bottom < -viewportExpansion2 || boundingRect.top > window.innerHeight + viewportExpansion2 || boundingRect.right < -viewportExpansion2 || boundingRect.left > window.innerWidth + viewportExpansion2);
    }
    for (const rect of rects) {
      if (rect.width === 0 || rect.height === 0) continue;
      if (!(rect.bottom < -viewportExpansion2 || rect.top > window.innerHeight + viewportExpansion2 || rect.right < -viewportExpansion2 || rect.left > window.innerWidth + viewportExpansion2)) {
        return true;
      }
    }
    return false;
  }
  function isInteractiveCandidate(element) {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) return false;
    const tagName = element.tagName.toLowerCase();
    const interactiveElements = /* @__PURE__ */ new Set([
      "a",
      "button",
      "input",
      "select",
      "textarea",
      "details",
      "summary",
      "label"
    ]);
    if (interactiveElements.has(tagName)) return true;
    const hasQuickInteractiveAttr = element.hasAttribute("onclick") || element.hasAttribute("role") || element.hasAttribute("tabindex") || element.hasAttribute("aria-") || element.hasAttribute("data-action") || element.getAttribute("contenteditable") === "true";
    return hasQuickInteractiveAttr;
  }
  const DISTINCT_INTERACTIVE_TAGS = /* @__PURE__ */ new Set([
    "a",
    "button",
    "input",
    "select",
    "textarea",
    "summary",
    "details",
    "label",
    "option"
  ]);
  const INTERACTIVE_ROLES = /* @__PURE__ */ new Set([
    "button",
    "link",
    "menuitem",
    "menuitemradio",
    "menuitemcheckbox",
    "radio",
    "checkbox",
    "tab",
    "switch",
    "slider",
    "spinbutton",
    "combobox",
    "searchbox",
    "textbox",
    "listbox",
    "option",
    "scrollbar"
  ]);
  function isHeuristicallyInteractive(element) {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) return false;
    if (!isElementVisible(element)) return false;
    const hasInteractiveAttributes = element.hasAttribute("role") || element.hasAttribute("tabindex") || element.hasAttribute("onclick") || typeof element.onclick === "function";
    const hasInteractiveClass = /\b(btn|clickable|menu|item|entry|link)\b/i.test(
      element.className || ""
    );
    const isInKnownContainer = Boolean(
      element.closest('button,a,[role="button"],.menu,.dropdown,.list,.toolbar')
    );
    const hasVisibleChildren = [...element.children].some(isElementVisible);
    const isParentBody = element.parentElement && element.parentElement.isSameNode(document.body);
    return (isInteractiveElement(element) || hasInteractiveAttributes || hasInteractiveClass) && hasVisibleChildren && isInKnownContainer && !isParentBody;
  }
  function isElementDistinctInteraction(element) {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) {
      return false;
    }
    const tagName = element.tagName.toLowerCase();
    const role = element.getAttribute("role");
    if (tagName === "iframe") {
      return true;
    }
    if (DISTINCT_INTERACTIVE_TAGS.has(tagName)) {
      return true;
    }
    if (role && INTERACTIVE_ROLES.has(role)) {
      return true;
    }
    if (element.isContentEditable || element.getAttribute("contenteditable") === "true") {
      return true;
    }
    if (element.hasAttribute("data-testid") || element.hasAttribute("data-cy") || element.hasAttribute("data-test")) {
      return true;
    }
    if (element.hasAttribute("onclick") || typeof element.onclick === "function") {
      return true;
    }
    try {
      const getEventListenersForNode = element?.ownerDocument?.defaultView?.getEventListenersForNode || window.getEventListenersForNode;
      if (typeof getEventListenersForNode === "function") {
        const listeners = getEventListenersForNode(element);
        const interactionEvents = [
          "click",
          "mousedown",
          "mouseup",
          "keydown",
          "keyup",
          "submit",
          "change",
          "input",
          "focus",
          "blur"
        ];
        for (const eventType of interactionEvents) {
          for (const listener of listeners) {
            if (listener.type === eventType) {
              return true;
            }
          }
        }
      }
      const commonEventAttrs = [
        "onmousedown",
        "onmouseup",
        "onkeydown",
        "onkeyup",
        "onsubmit",
        "onchange",
        "oninput",
        "onfocus",
        "onblur"
      ];
      if (commonEventAttrs.some((attr) => element.hasAttribute(attr))) {
        return true;
      }
    } catch (e) {
    }
    if (isHeuristicallyInteractive(element)) {
      return true;
    }
    return false;
  }
  function handleHighlighting(nodeData, node, parentIframe, isParentHighlighted) {
    if (!nodeData.isInteractive) return false;
    let shouldHighlight = false;
    if (!isParentHighlighted) {
      shouldHighlight = true;
    } else {
      if (isElementDistinctInteraction(node)) {
        shouldHighlight = true;
      } else {
        shouldHighlight = false;
      }
    }
    if (shouldHighlight) {
      nodeData.isInViewport = isInExpandedViewport(node, viewportExpansion);
      if (nodeData.isInViewport || viewportExpansion === -1) {
        nodeData.highlightIndex = highlightIndex++;
        if (doHighlightElements) {
          if (focusHighlightIndex >= 0) {
            if (focusHighlightIndex === nodeData.highlightIndex) {
              highlightElement(node, nodeData.highlightIndex, parentIframe);
            }
          } else {
            highlightElement(node, nodeData.highlightIndex, parentIframe);
          }
          return true;
        }
      } else {
      }
    }
    return false;
  }
  function buildDomTree(node, parentIframe = null, isParentHighlighted = false) {
    if (!node || node.id === HIGHLIGHT_CONTAINER_ID || node.nodeType !== Node.ELEMENT_NODE && node.nodeType !== Node.TEXT_NODE) {
      return null;
    }
    if (!node || node.id === HIGHLIGHT_CONTAINER_ID) {
      return null;
    }
    if (node.dataset?.browserUseIgnore === "true" || node.dataset?.pageAgentIgnore === "true") {
      return null;
    }
    if (node.getAttribute && node.getAttribute("aria-hidden") === "true") {
      return null;
    }
    if (node === document.body) {
      const nodeData2 = {
        tagName: "body",
        attributes: {},
        xpath: "/body",
        children: []
      };
      for (const child of node.childNodes) {
        const domElement = buildDomTree(child, parentIframe, false);
        if (domElement) nodeData2.children.push(domElement);
      }
      const id2 = `${ID.current++}`;
      DOM_HASH_MAP[id2] = nodeData2;
      return id2;
    }
    if (node.nodeType !== Node.ELEMENT_NODE && node.nodeType !== Node.TEXT_NODE) {
      return null;
    }
    if (node.nodeType === Node.TEXT_NODE) {
      const textContent = node.textContent?.trim();
      if (!textContent) {
        return null;
      }
      const parentElement = node.parentElement;
      if (!parentElement || parentElement.tagName.toLowerCase() === "script") {
        return null;
      }
      const id2 = `${ID.current++}`;
      DOM_HASH_MAP[id2] = {
        type: "TEXT_NODE",
        text: textContent,
        isVisible: isTextNodeVisible(node)
      };
      return id2;
    }
    if (node.nodeType === Node.ELEMENT_NODE && !isElementAccepted(node)) {
      return null;
    }
    if (viewportExpansion !== -1 && !node.shadowRoot) {
      const rect = getCachedBoundingRect(node);
      const style = getCachedComputedStyle(node);
      const isFixedOrSticky = style && (style.position === "fixed" || style.position === "sticky");
      const hasSize = node.offsetWidth > 0 || node.offsetHeight > 0;
      if (!rect || !isFixedOrSticky && !hasSize && (rect.bottom < -viewportExpansion || rect.top > window.innerHeight + viewportExpansion || rect.right < -viewportExpansion || rect.left > window.innerWidth + viewportExpansion)) {
        return null;
      }
    }
    const nodeData = {
      tagName: node.tagName.toLowerCase(),
      attributes: {},
      /**
       * @edit no need for xpath
       */
      // xpath: getXPathTree(node, true),
      children: []
    };
    if (isInteractiveCandidate(node) || node.tagName.toLowerCase() === "iframe" || node.tagName.toLowerCase() === "body") {
      const attributeNames = node.getAttributeNames?.() || [];
      for (const name2 of attributeNames) {
        const value = node.getAttribute(name2);
        nodeData.attributes[name2] = value;
      }
      if (node.tagName.toLowerCase() === "input" && (node.type === "checkbox" || node.type === "radio")) {
        nodeData.attributes.checked = node.checked ? "true" : "false";
      }
    }
    let nodeWasHighlighted = false;
    if (node.nodeType === Node.ELEMENT_NODE) {
      nodeData.isVisible = isElementVisible(node);
      if (nodeData.isVisible) {
        nodeData.isTopElement = isTopElement(node);
        const role = node.getAttribute("role");
        const isMenuContainer = role === "menu" || role === "menubar" || role === "listbox";
        if (nodeData.isTopElement || isMenuContainer) {
          nodeData.isInteractive = isInteractiveElement(node);
          nodeWasHighlighted = handleHighlighting(nodeData, node, parentIframe, isParentHighlighted);
          nodeData.ref = node;
          if (nodeData.isInteractive && Object.keys(nodeData.attributes).length === 0) {
            const attributeNames = node.getAttributeNames?.() || [];
            for (const name2 of attributeNames) {
              const value = node.getAttribute(name2);
              nodeData.attributes[name2] = value;
            }
          }
        }
      }
    }
    if (node.tagName) {
      const tagName = node.tagName.toLowerCase();
      if (tagName === "iframe") {
        try {
          const iframeDoc = node.contentDocument || node.contentWindow?.document;
          if (iframeDoc) {
            for (const child of iframeDoc.childNodes) {
              const domElement = buildDomTree(child, node, false);
              if (domElement) nodeData.children.push(domElement);
            }
          }
        } catch (e) {
          console.warn("Unable to access iframe:", e);
        }
      } else if (node.isContentEditable || node.getAttribute("contenteditable") === "true" || node.id === "tinymce" || node.classList.contains("mce-content-body") || tagName === "body" && node.getAttribute("data-id")?.startsWith("mce_")) {
        for (const child of node.childNodes) {
          const domElement = buildDomTree(child, parentIframe, nodeWasHighlighted);
          if (domElement) nodeData.children.push(domElement);
        }
      } else {
        if (node.shadowRoot) {
          nodeData.shadowRoot = true;
          for (const child of node.shadowRoot.childNodes) {
            const domElement = buildDomTree(child, parentIframe, nodeWasHighlighted);
            if (domElement) nodeData.children.push(domElement);
          }
        }
        for (const child of node.childNodes) {
          const passHighlightStatusToChild = nodeWasHighlighted || isParentHighlighted;
          const domElement = buildDomTree(child, parentIframe, passHighlightStatusToChild);
          if (domElement) nodeData.children.push(domElement);
        }
      }
    }
    if (nodeData.tagName === "a" && nodeData.children.length === 0 && !nodeData.attributes.href) {
      const rect = getCachedBoundingRect(node);
      const hasSize = rect && rect.width > 0 && rect.height > 0 || node.offsetWidth > 0 || node.offsetHeight > 0;
      if (!hasSize) {
        return null;
      }
    }
    nodeData.extra = extraData.get(node) || null;
    const id = `${ID.current++}`;
    DOM_HASH_MAP[id] = nodeData;
    return id;
  }
  const rootId = buildDomTree(document.body);
  DOM_CACHE.clearCache();
  return { rootId, map: DOM_HASH_MAP };
};

// src/page-controller/dom.ts
var DEFAULT_VIEWPORT_EXPANSION = -1;
function resolveViewportExpansion(viewportExpansion) {
  return viewportExpansion ?? DEFAULT_VIEWPORT_EXPANSION;
}
var newElementsCache = /* @__PURE__ */ new WeakMap();
function getFlatTree(config2) {
  const viewportExpansion = resolveViewportExpansion(config2.viewportExpansion);
  const interactiveBlacklist = [];
  for (const item of config2.interactiveBlacklist || []) {
    if (typeof item === "function") {
      interactiveBlacklist.push(item());
    } else {
      interactiveBlacklist.push(item);
    }
  }
  const interactiveWhitelist = [];
  for (const item of config2.interactiveWhitelist || []) {
    if (typeof item === "function") {
      interactiveWhitelist.push(item());
    } else {
      interactiveWhitelist.push(item);
    }
  }
  const elements = dom_tree_default({
    doHighlightElements: true,
    debugMode: true,
    focusHighlightIndex: -1,
    viewportExpansion,
    interactiveBlacklist,
    interactiveWhitelist,
    highlightOpacity: config2.highlightOpacity ?? 0,
    highlightLabelOpacity: config2.highlightLabelOpacity ?? 0.1
  });
  for (const nodeId in elements.map) {
    const node = elements.map[nodeId];
    if (node.isInteractive && node.ref) {
      const ref = node.ref;
      if (!newElementsCache.has(ref)) {
        newElementsCache.set(ref, window.location.href);
        node.isNew = true;
      }
    }
  }
  return elements;
}
var globRegexCache = /* @__PURE__ */ new Map();
function globToRegex(pattern) {
  let regex = globRegexCache.get(pattern);
  if (!regex) {
    const escaped = pattern.replace(/[.+^${}()|[\]\\]/g, "\\$&");
    regex = new RegExp(`^${escaped.replace(/\*/g, ".*")}$`);
    globRegexCache.set(pattern, regex);
  }
  return regex;
}
function matchAttributes(attrs, patterns) {
  const result = {};
  for (const pattern of patterns) {
    if (pattern.includes("*")) {
      const regex = globToRegex(pattern);
      for (const key of Object.keys(attrs)) {
        if (regex.test(key) && attrs[key].trim()) {
          result[key] = attrs[key].trim();
        }
      }
    } else {
      const value = attrs[pattern];
      if (value && value.trim()) {
        result[pattern] = value.trim();
      }
    }
  }
  return result;
}
function flatTreeToString(flatTree, includeAttributes) {
  const DEFAULT_INCLUDE_ATTRIBUTES = [
    "title",
    "type",
    "checked",
    "name",
    "role",
    "value",
    "placeholder",
    "data-date-format",
    "alt",
    "aria-label",
    "aria-expanded",
    "data-state",
    "aria-checked",
    "id",
    "for",
    "target",
    "aria-haspopup",
    "aria-controls",
    "aria-owns",
    "contenteditable"
  ];
  const includeAttrs = [
    ...includeAttributes || [],
    ...DEFAULT_INCLUDE_ATTRIBUTES
  ];
  const capTextLength = (text, maxLength) => {
    if (text.length > maxLength) {
      return text.substring(0, maxLength) + "...";
    }
    return text;
  };
  const buildTreeNode = (nodeId) => {
    const node = flatTree.map[nodeId];
    if (!node) return null;
    if (node.type === "TEXT_NODE") {
      const textNode = node;
      return {
        type: "text",
        text: textNode.text,
        isVisible: textNode.isVisible,
        parent: null,
        children: []
      };
    } else {
      const elementNode = node;
      const children = [];
      if (elementNode.children) {
        for (const childId of elementNode.children) {
          const child = buildTreeNode(childId);
          if (child) {
            children.push(child);
          }
        }
      }
      return {
        type: "element",
        tagName: elementNode.tagName,
        attributes: elementNode.attributes ?? {},
        isVisible: elementNode.isVisible ?? false,
        isInteractive: elementNode.isInteractive ?? false,
        isTopElement: elementNode.isTopElement ?? false,
        isNew: elementNode.isNew ?? false,
        highlightIndex: elementNode.highlightIndex,
        parent: null,
        children,
        extra: elementNode.extra ?? {}
      };
    }
  };
  const setParentReferences = (node, parent = null) => {
    node.parent = parent;
    for (const child of node.children) {
      setParentReferences(child, node);
    }
  };
  const rootNode = buildTreeNode(flatTree.rootId);
  if (!rootNode) return "";
  setParentReferences(rootNode);
  const hasParentWithHighlightIndex = (node) => {
    let current = node.parent;
    while (current) {
      if (current.type === "element" && current.highlightIndex !== void 0) {
        return true;
      }
      current = current.parent;
    }
    return false;
  };
  const processNode = (node, depth, result2) => {
    let nextDepth = depth;
    const depthStr = "	".repeat(depth);
    if (node.type === "element") {
      if (node.highlightIndex !== void 0) {
        nextDepth += 1;
        const text = getAllTextTillNextClickableElement(node);
        let attributesHtmlStr = "";
        if (includeAttrs.length > 0 && node.attributes) {
          const attributesToInclude = matchAttributes(
            node.attributes,
            includeAttrs
          );
          const keys = Object.keys(attributesToInclude);
          if (keys.length > 1) {
            const keysToRemove = /* @__PURE__ */ new Set();
            const seenValues = {};
            for (const key of keys) {
              const value = attributesToInclude[key];
              if (value.length > 5) {
                if (value in seenValues) {
                  keysToRemove.add(key);
                } else {
                  seenValues[value] = key;
                }
              }
            }
            for (const key of keysToRemove) {
              delete attributesToInclude[key];
            }
          }
          if (attributesToInclude.role === node.tagName) {
            delete attributesToInclude.role;
          }
          const attrsToRemoveIfTextMatches = [
            "aria-label",
            "placeholder",
            "title"
          ];
          for (const attr of attrsToRemoveIfTextMatches) {
            if (attributesToInclude[attr] && attributesToInclude[attr].toLowerCase().trim() === text.toLowerCase().trim()) {
              delete attributesToInclude[attr];
            }
          }
          if (Object.keys(attributesToInclude).length > 0) {
            attributesHtmlStr = Object.entries(attributesToInclude).map(([key, value]) => `${key}=${capTextLength(value, 20)}`).join(" ");
          }
        }
        const highlightIndicator = node.isNew ? `*[${node.highlightIndex}]` : `[${node.highlightIndex}]`;
        let line = `${depthStr}${highlightIndicator}<${node.tagName ?? ""}`;
        if (attributesHtmlStr) {
          line += ` ${attributesHtmlStr}`;
        }
        if (node.extra) {
          if (node.extra.scrollable) {
            let scrollDataText = "";
            if (node.extra.scrollData?.left)
              scrollDataText += `left=${node.extra.scrollData.left}, `;
            if (node.extra.scrollData?.top)
              scrollDataText += `top=${node.extra.scrollData.top}, `;
            if (node.extra.scrollData?.right)
              scrollDataText += `right=${node.extra.scrollData.right}, `;
            if (node.extra.scrollData?.bottom)
              scrollDataText += `bottom=${node.extra.scrollData.bottom}`;
            line += ` data-scrollable="${scrollDataText}"`;
          }
        }
        if (text) {
          const trimmedText = text.trim();
          if (!attributesHtmlStr) {
            line += " ";
          }
          line += `>${trimmedText}`;
        } else if (!attributesHtmlStr) {
          line += " ";
        }
        line += " />";
        result2.push(line);
      }
      for (const child of node.children) {
        processNode(child, nextDepth, result2);
      }
    } else if (node.type === "text") {
      if (hasParentWithHighlightIndex(node)) {
        return;
      }
      if (node.parent && node.parent.type === "element" && node.parent.isVisible && node.parent.isTopElement) {
        result2.push(`${depthStr}${node.text ?? ""}`);
      }
    }
  };
  const result = [];
  processNode(rootNode, 0, result);
  return result.join("\n");
}
var getAllTextTillNextClickableElement = (node, maxDepth = -1) => {
  const textParts = [];
  const collectText = (currentNode, currentDepth) => {
    if (maxDepth !== -1 && currentDepth > maxDepth) {
      return;
    }
    if (currentNode.type === "element" && currentNode !== node && currentNode.highlightIndex !== void 0) {
      return;
    }
    if (currentNode.type === "text" && currentNode.text) {
      textParts.push(currentNode.text);
    } else if (currentNode.type === "element") {
      for (const child of currentNode.children) {
        collectText(child, currentDepth + 1);
      }
    }
  };
  collectText(node, 0);
  return textParts.join("\n").trim();
};
function getSelectorMap(flatTree) {
  const selectorMap = /* @__PURE__ */ new Map();
  const keys = Object.keys(flatTree.map);
  for (const key of keys) {
    const node = flatTree.map[key];
    if (node.isInteractive && typeof node.highlightIndex === "number") {
      selectorMap.set(
        node.highlightIndex,
        node
      );
    }
  }
  return selectorMap;
}
function getElementTextMap(simplifiedHTML) {
  const lines = simplifiedHTML.split("\n").map((line) => line.trim()).filter((line) => line.length > 0);
  const elementTextMap = /* @__PURE__ */ new Map();
  for (const line of lines) {
    const regex = /^\[(\d+)\]<[^>]+>([^<]*)/;
    const match = regex.exec(line);
    if (match) {
      const index = parseInt(match[1], 10);
      elementTextMap.set(index, line);
    }
  }
  return elementTextMap;
}
function cleanUpHighlights() {
  const cleanupFunctions = window._highlightCleanupFunctions || [];
  for (const cleanup of cleanupFunctions) {
    if (typeof cleanup === "function") {
      cleanup();
    }
  }
  window._highlightCleanupFunctions = [];
}

// src/page-controller/actions.ts
async function waitFor2(seconds) {
  await new Promise((resolve2) => setTimeout(resolve2, seconds * 1e3));
}
function getElementByIndex(selectorMap, index) {
  const interactiveNode = selectorMap.get(index);
  if (!interactiveNode) {
    throw new Error(`No interactive element found at index ${index}`);
  }
  const element = interactiveNode.ref;
  if (!element) {
    throw new Error(`Element at index ${index} does not have a reference`);
  }
  if (!(element instanceof HTMLElement)) {
    throw new Error(`Element at index ${index} is not an HTMLElement`);
  }
  return element;
}
var lastClickedElement = null;
function blurLastClickedElement() {
  if (lastClickedElement) {
    lastClickedElement.blur();
    lastClickedElement.dispatchEvent(
      new MouseEvent("mouseout", { bubbles: true, cancelable: true })
    );
    lastClickedElement = null;
  }
}
async function scrollIntoViewIfNeeded(element) {
  const rect = element.getBoundingClientRect();
  const inViewport = rect.top >= 0 && rect.bottom <= window.innerHeight && rect.left >= 0 && rect.right <= window.innerWidth;
  if (!inViewport) {
    element.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
    await waitFor2(0.4);
  }
}
async function movePointerToElement(element) {
  const rect = element.getBoundingClientRect();
  const x = rect.left + rect.width / 2;
  const y = rect.top + rect.height / 2;
  window.dispatchEvent(
    new CustomEvent("HyphaDebugger::MovePointerTo", { detail: { x, y } })
  );
  await waitFor2(0.3);
}
async function clickElement2(element) {
  blurLastClickedElement();
  lastClickedElement = element;
  await scrollIntoViewIfNeeded(element);
  await movePointerToElement(element);
  window.dispatchEvent(new CustomEvent("HyphaDebugger::ClickPointer"));
  await waitFor2(0.05);
  element.dispatchEvent(
    new MouseEvent("mouseenter", { bubbles: true, cancelable: true })
  );
  element.dispatchEvent(
    new MouseEvent("mouseover", { bubbles: true, cancelable: true })
  );
  element.dispatchEvent(
    new MouseEvent("mousedown", { bubbles: true, cancelable: true })
  );
  element.focus();
  element.dispatchEvent(
    new MouseEvent("mouseup", { bubbles: true, cancelable: true })
  );
  element.dispatchEvent(
    new MouseEvent("click", { bubbles: true, cancelable: true })
  );
  await waitFor2(0.2);
}
var _nativeInputValueSetter = null;
var _nativeTextAreaValueSetter = null;
function getNativeInputValueSetter() {
  if (!_nativeInputValueSetter) {
    _nativeInputValueSetter = Object.getOwnPropertyDescriptor(
      window.HTMLInputElement.prototype,
      "value"
    ).set;
  }
  return _nativeInputValueSetter;
}
function getNativeTextAreaValueSetter() {
  if (!_nativeTextAreaValueSetter) {
    _nativeTextAreaValueSetter = Object.getOwnPropertyDescriptor(
      window.HTMLTextAreaElement.prototype,
      "value"
    ).set;
  }
  return _nativeTextAreaValueSetter;
}
async function inputTextElement(element, text) {
  const isContentEditable = element.isContentEditable;
  if (!(element instanceof HTMLInputElement) && !(element instanceof HTMLTextAreaElement) && !isContentEditable) {
    throw new Error("Element is not an input, textarea, or contenteditable");
  }
  await clickElement2(element);
  if (isContentEditable) {
    if (element.dispatchEvent(
      new InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        inputType: "deleteContent"
      })
    )) {
      element.innerText = "";
      element.dispatchEvent(
        new InputEvent("input", {
          bubbles: true,
          inputType: "deleteContent"
        })
      );
    }
    if (element.dispatchEvent(
      new InputEvent("beforeinput", {
        bubbles: true,
        cancelable: true,
        inputType: "insertText",
        data: text
      })
    )) {
      element.innerText = text;
      element.dispatchEvent(
        new InputEvent("input", {
          bubbles: true,
          inputType: "insertText",
          data: text
        })
      );
    }
    element.dispatchEvent(new Event("change", { bubbles: true }));
    element.blur();
  } else if (element instanceof HTMLTextAreaElement) {
    getNativeTextAreaValueSetter().call(element, text);
  } else {
    getNativeInputValueSetter().call(element, text);
  }
  if (!isContentEditable) {
    element.dispatchEvent(new Event("input", { bubbles: true }));
  }
  await waitFor2(0.1);
  blurLastClickedElement();
}
async function selectOptionElement(selectElement, optionText) {
  if (!(selectElement instanceof HTMLSelectElement)) {
    throw new Error("Element is not a select element");
  }
  await scrollIntoViewIfNeeded(selectElement);
  const rect = selectElement.getBoundingClientRect();
  window.dispatchEvent(
    new CustomEvent("HyphaDebugger::MovePointerTo", {
      detail: { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 }
    })
  );
  await waitFor2(0.3);
  window.dispatchEvent(new CustomEvent("HyphaDebugger::ClickPointer"));
  const options = Array.from(selectElement.options);
  const option = options.find(
    (opt) => opt.textContent?.trim() === optionText.trim()
  );
  if (!option) {
    throw new Error(
      `Option with text "${optionText}" not found in select element`
    );
  }
  selectElement.value = option.value;
  selectElement.dispatchEvent(new Event("change", { bubbles: true }));
  await waitFor2(0.1);
}
async function scrollVertically(down, scroll_amount, element) {
  if (element) {
    let currentElement = element;
    let scrollSuccess = false;
    let scrolledElement = null;
    let scrollDelta = 0;
    let attempts = 0;
    const dy2 = scroll_amount;
    while (currentElement && attempts < 10) {
      const computedStyle = window.getComputedStyle(currentElement);
      const hasScrollableY = /(auto|scroll|overlay)/.test(
        computedStyle.overflowY
      );
      const canScrollVertically = currentElement.scrollHeight > currentElement.clientHeight;
      if (hasScrollableY && canScrollVertically) {
        const beforeScroll = currentElement.scrollTop;
        const maxScroll = currentElement.scrollHeight - currentElement.clientHeight;
        let scrollAmount = dy2 / 3;
        if (scrollAmount > 0) {
          scrollAmount = Math.min(scrollAmount, maxScroll - beforeScroll);
        } else {
          scrollAmount = Math.max(scrollAmount, -beforeScroll);
        }
        currentElement.scrollTop = beforeScroll + scrollAmount;
        const afterScroll = currentElement.scrollTop;
        const actualScrollDelta = afterScroll - beforeScroll;
        if (Math.abs(actualScrollDelta) > 0.5) {
          scrollSuccess = true;
          scrolledElement = currentElement;
          scrollDelta = actualScrollDelta;
          break;
        }
      }
      if (currentElement === document.body || currentElement === document.documentElement) {
        break;
      }
      currentElement = currentElement.parentElement;
      attempts++;
    }
    if (scrollSuccess) {
      return `Scrolled container (${scrolledElement?.tagName}) by ${scrollDelta}px`;
    } else {
      return `No scrollable container found for element (${element.tagName})`;
    }
  }
  const dy = scroll_amount;
  const bigEnough = (el2) => el2.clientHeight >= window.innerHeight * 0.5;
  const canScroll = (el2) => el2 && /(auto|scroll|overlay)/.test(getComputedStyle(el2).overflowY) && el2.scrollHeight > el2.clientHeight && bigEnough(el2);
  let el = document.activeElement;
  while (el && !canScroll(el) && el !== document.body) el = el.parentElement;
  el = canScroll(el) ? el : Array.from(document.querySelectorAll("*")).find(canScroll) || document.scrollingElement || document.documentElement;
  if (el === document.scrollingElement || el === document.documentElement || el === document.body) {
    const scrollBefore = window.scrollY;
    window.scrollBy(0, dy);
    const scrollAfter = window.scrollY;
    const scrolled = scrollAfter - scrollBefore;
    if (Math.abs(scrolled) < 1) {
      return dy > 0 ? "Already at the bottom of the page." : "Already at the top of the page.";
    }
    const scrollMax = document.documentElement.scrollHeight - window.innerHeight;
    const reachedBottom = dy > 0 && scrollAfter >= scrollMax - 1;
    const reachedTop = dy < 0 && scrollAfter <= 1;
    if (reachedBottom)
      return `Scrolled page by ${scrolled}px. Reached the bottom.`;
    if (reachedTop) return `Scrolled page by ${scrolled}px. Reached the top.`;
    return `Scrolled page by ${scrolled}px.`;
  } else {
    const scrollBefore = el.scrollTop;
    const scrollMax = el.scrollHeight - el.clientHeight;
    el.scrollBy({ top: dy, behavior: "smooth" });
    await waitFor2(0.1);
    const scrollAfter = el.scrollTop;
    const scrolled = scrollAfter - scrollBefore;
    if (Math.abs(scrolled) < 1) {
      return dy > 0 ? `Already at the bottom of container (${el.tagName}).` : `Already at the top of container (${el.tagName}).`;
    }
    const reachedBottom = dy > 0 && scrollAfter >= scrollMax - 1;
    const reachedTop = dy < 0 && scrollAfter <= 1;
    if (reachedBottom)
      return `Scrolled container (${el.tagName}) by ${scrolled}px. Reached the bottom.`;
    if (reachedTop)
      return `Scrolled container (${el.tagName}) by ${scrolled}px. Reached the top.`;
    return `Scrolled container (${el.tagName}) by ${scrolled}px.`;
  }
}
async function scrollHorizontally(right, scroll_amount, element) {
  if (element) {
    let currentElement = element;
    let scrollSuccess = false;
    let scrolledElement = null;
    let scrollDelta = 0;
    let attempts = 0;
    const dx2 = right ? scroll_amount : -scroll_amount;
    while (currentElement && attempts < 10) {
      const computedStyle = window.getComputedStyle(currentElement);
      const hasScrollableX = /(auto|scroll|overlay)/.test(
        computedStyle.overflowX
      );
      const canScrollHorizontally = currentElement.scrollWidth > currentElement.clientWidth;
      if (hasScrollableX && canScrollHorizontally) {
        const beforeScroll = currentElement.scrollLeft;
        const maxScroll = currentElement.scrollWidth - currentElement.clientWidth;
        let scrollAmount = dx2 / 3;
        if (scrollAmount > 0) {
          scrollAmount = Math.min(scrollAmount, maxScroll - beforeScroll);
        } else {
          scrollAmount = Math.max(scrollAmount, -beforeScroll);
        }
        currentElement.scrollLeft = beforeScroll + scrollAmount;
        const afterScroll = currentElement.scrollLeft;
        const actualScrollDelta = afterScroll - beforeScroll;
        if (Math.abs(actualScrollDelta) > 0.5) {
          scrollSuccess = true;
          scrolledElement = currentElement;
          scrollDelta = actualScrollDelta;
          break;
        }
      }
      if (currentElement === document.body || currentElement === document.documentElement) {
        break;
      }
      currentElement = currentElement.parentElement;
      attempts++;
    }
    if (scrollSuccess) {
      return `Scrolled container (${scrolledElement?.tagName}) horizontally by ${scrollDelta}px`;
    } else {
      return `No horizontally scrollable container found for element (${element.tagName})`;
    }
  }
  const dx = right ? scroll_amount : -scroll_amount;
  const bigEnough = (el2) => el2.clientWidth >= window.innerWidth * 0.5;
  const canScroll = (el2) => el2 && /(auto|scroll|overlay)/.test(getComputedStyle(el2).overflowX) && el2.scrollWidth > el2.clientWidth && bigEnough(el2);
  let el = document.activeElement;
  while (el && !canScroll(el) && el !== document.body) el = el.parentElement;
  el = canScroll(el) ? el : Array.from(document.querySelectorAll("*")).find(canScroll) || document.scrollingElement || document.documentElement;
  if (el === document.scrollingElement || el === document.documentElement || el === document.body) {
    const scrollBefore = window.scrollX;
    const scrollMax = document.documentElement.scrollWidth - window.innerWidth;
    window.scrollBy(dx, 0);
    const scrollAfter = window.scrollX;
    const scrolled = scrollAfter - scrollBefore;
    if (Math.abs(scrolled) < 1) {
      return dx > 0 ? "Already at the right edge of the page." : "Already at the left edge of the page.";
    }
    const reachedRight = dx > 0 && scrollAfter >= scrollMax - 1;
    const reachedLeft = dx < 0 && scrollAfter <= 1;
    if (reachedRight)
      return `Scrolled page by ${scrolled}px. Reached the right edge.`;
    if (reachedLeft)
      return `Scrolled page by ${scrolled}px. Reached the left edge.`;
    return `Scrolled page horizontally by ${scrolled}px.`;
  } else {
    const scrollBefore = el.scrollLeft;
    const scrollMax = el.scrollWidth - el.clientWidth;
    el.scrollBy({ left: dx, behavior: "smooth" });
    await waitFor2(0.1);
    const scrollAfter = el.scrollLeft;
    const scrolled = scrollAfter - scrollBefore;
    if (Math.abs(scrolled) < 1) {
      return dx > 0 ? `Already at the right edge of container (${el.tagName}).` : `Already at the left edge of container (${el.tagName}).`;
    }
    const reachedRight = dx > 0 && scrollAfter >= scrollMax - 1;
    const reachedLeft = dx < 0 && scrollAfter <= 1;
    if (reachedRight)
      return `Scrolled container (${el.tagName}) by ${scrolled}px. Reached the right edge.`;
    if (reachedLeft)
      return `Scrolled container (${el.tagName}) by ${scrolled}px. Reached the left edge.`;
    return `Scrolled container (${el.tagName}) horizontally by ${scrolled}px.`;
  }
}

// src/page-controller/page-info.ts
function getPageScrollInfo() {
  const viewport_width = window.innerWidth;
  const viewport_height = window.innerHeight;
  const page_width = Math.max(
    document.documentElement.scrollWidth,
    document.body.scrollWidth || 0
  );
  const page_height = Math.max(
    document.documentElement.scrollHeight,
    document.body.scrollHeight || 0
  );
  const scroll_x = window.scrollX || window.pageXOffset || document.documentElement.scrollLeft || 0;
  const scroll_y = window.scrollY || window.pageYOffset || document.documentElement.scrollTop || 0;
  const pixels_below = Math.max(
    0,
    page_height - (window.innerHeight + scroll_y)
  );
  const pixels_right = Math.max(
    0,
    page_width - (window.innerWidth + scroll_x)
  );
  return {
    viewport_width,
    viewport_height,
    page_width,
    page_height,
    scroll_x,
    scroll_y,
    pixels_above: scroll_y,
    pixels_below,
    pages_above: viewport_height > 0 ? scroll_y / viewport_height : 0,
    pages_below: viewport_height > 0 ? pixels_below / viewport_height : 0,
    total_pages: viewport_height > 0 ? page_height / viewport_height : 0,
    current_page_position: scroll_y / Math.max(1, page_height - viewport_height),
    pixels_left: scroll_x,
    pixels_right
  };
}

// src/page-controller/index.ts
var PageController = class {
  config;
  flatTree = null;
  selectorMap = /* @__PURE__ */ new Map();
  elementTextMap = /* @__PURE__ */ new Map();
  simplifiedHTML = "";
  isIndexed = false;
  constructor(config2 = {}) {
    this.config = config2;
  }
  /**
   * Get structured browser state for LLM consumption.
   * Builds the DOM tree, highlights interactive elements, and returns
   * a simplified text representation with numeric indices.
   */
  async getBrowserState() {
    const url = window.location.href;
    const title = document.title;
    const pi = getPageScrollInfo();
    const viewportExpansion = resolveViewportExpansion(
      this.config.viewportExpansion
    );
    await this.updateTree();
    const content = this.simplifiedHTML;
    const titleLine = `Current Page: [${title}](${url})`;
    const pageInfoLine = `Page info: ${pi.viewport_width}x${pi.viewport_height}px viewport, ${pi.page_width}x${pi.page_height}px total, ${pi.pages_above.toFixed(1)} pages above, ${pi.pages_below.toFixed(1)} pages below, at ${(pi.current_page_position * 100).toFixed(0)}%`;
    const elementsLabel = viewportExpansion === -1 ? "Interactive elements (full page):" : "Interactive elements (viewport):";
    const hasContentAbove = pi.pixels_above > 4;
    const scrollHintAbove = hasContentAbove && viewportExpansion !== -1 ? `... ${pi.pixels_above} pixels above - scroll to see more ...` : "[Start of page]";
    const header = `${titleLine}
${pageInfoLine}

${elementsLabel}

${scrollHintAbove}`;
    const hasContentBelow = pi.pixels_below > 4;
    const footer = hasContentBelow && viewportExpansion !== -1 ? `... ${pi.pixels_below} pixels below - scroll to see more ...` : "[End of page]";
    return {
      url,
      title,
      header,
      content,
      footer,
      element_count: this.selectorMap.size
    };
  }
  /**
   * Update DOM tree, returns simplified HTML for LLM.
   */
  async updateTree() {
    cleanUpHighlights();
    this.flatTree = getFlatTree(this.config);
    this.simplifiedHTML = flatTreeToString(
      this.flatTree,
      this.config.includeAttributes
    );
    this.selectorMap.clear();
    this.selectorMap = getSelectorMap(this.flatTree);
    this.elementTextMap.clear();
    this.elementTextMap = getElementTextMap(this.simplifiedHTML);
    this.isIndexed = true;
    return this.simplifiedHTML;
  }
  async cleanUpHighlights() {
    cleanUpHighlights();
  }
  assertIndexed() {
    if (!this.isIndexed) {
      throw new Error(
        "DOM tree not indexed yet. Call get_browser_state first."
      );
    }
  }
  /** Clean up highlights after performing an action. */
  cleanUpAfterAction() {
    cleanUpHighlights();
  }
  async clickElement(index) {
    try {
      this.assertIndexed();
      const element = getElementByIndex(this.selectorMap, index);
      const elemText = this.elementTextMap.get(index);
      this.cleanUpAfterAction();
      await clickElement2(element);
      if (element instanceof HTMLAnchorElement && element.target === "_blank") {
        return {
          success: true,
          message: `Clicked element (${elemText ?? index}). Link opened in a new tab.`
        };
      }
      return {
        success: true,
        message: `Clicked element (${elemText ?? index}).`
      };
    } catch (error) {
      return {
        success: false,
        message: `Failed to click element: ${error}`
      };
    }
  }
  async inputText(index, text) {
    try {
      this.assertIndexed();
      const element = getElementByIndex(this.selectorMap, index);
      const elemText = this.elementTextMap.get(index);
      this.cleanUpAfterAction();
      await inputTextElement(element, text);
      return {
        success: true,
        message: `Input text "${text}" into element (${elemText ?? index}).`
      };
    } catch (error) {
      return {
        success: false,
        message: `Failed to input text: ${error}`
      };
    }
  }
  async selectOption(index, optionText) {
    try {
      this.assertIndexed();
      const element = getElementByIndex(this.selectorMap, index);
      const elemText = this.elementTextMap.get(index);
      this.cleanUpAfterAction();
      await selectOptionElement(element, optionText);
      return {
        success: true,
        message: `Selected option "${optionText}" in element (${elemText ?? index}).`
      };
    } catch (error) {
      return {
        success: false,
        message: `Failed to select option: ${error}`
      };
    }
  }
  async scroll(options) {
    try {
      this.assertIndexed();
      this.cleanUpAfterAction();
      const { direction, amount, index } = options;
      const element = index !== void 0 ? getElementByIndex(this.selectorMap, index) : null;
      let message;
      if (direction === "left" || direction === "right") {
        const pixels = amount ?? window.innerWidth * 0.8;
        message = await scrollHorizontally(
          direction === "right",
          pixels,
          element
        );
      } else {
        const pixels = amount ?? window.innerHeight * 0.8;
        const scrollAmount = direction === "down" ? pixels : -pixels;
        message = await scrollVertically(
          direction === "down",
          scrollAmount,
          element
        );
      }
      return { success: true, message };
    } catch (error) {
      return {
        success: false,
        message: `Failed to scroll: ${error}`
      };
    }
  }
  dispose() {
    cleanUpHighlights();
    this.flatTree = null;
    this.selectorMap.clear();
    this.elementTextMap.clear();
    this.simplifiedHTML = "";
    this.isIndexed = false;
  }
};

// src/services/page-controller.ts
var controller = null;
function getController() {
  if (!controller) {
    controller = new PageController({
      viewportExpansion: -1,
      // full page by default
      highlightOpacity: 0.1,
      // 10% fill on element boxes
      highlightLabelOpacity: 0.5
      // 50% opacity on number labels + borders
    });
  }
  return controller;
}
async function getBrowserState(viewport_only) {
  const ctrl = getController();
  if (viewport_only !== void 0) {
    ctrl.config.viewportExpansion = viewport_only ? 0 : -1;
  }
  const timeoutMs = 15e3;
  return Promise.race([
    ctrl.getBrowserState(),
    new Promise(
      (_, reject2) => setTimeout(
        () => reject2(
          new Error(
            `get_browser_state timed out after ${timeoutMs}ms (complex DOM or cross-origin iframes)`
          )
        ),
        timeoutMs
      )
    )
  ]);
}
getBrowserState.__schema__ = {
  name: "getBrowserState",
  description: "Get the current page state with all interactive elements indexed as [0], [1], [2], etc. Returns a simplified HTML representation optimized for LLM consumption. Interactive elements (buttons, links, inputs, scrollable areas) are detected via smart heuristics (CSS cursor, ARIA roles, event listeners, tag names). Use the returned indices with click_element_by_index, input_text, select_option, or scroll. Call this first to understand the page before performing any actions.",
  parameters: {
    type: "object",
    properties: {
      viewport_only: {
        type: "boolean",
        description: "If true, only return elements visible in the current viewport. Default: false (full page)."
      }
    }
  }
};
async function clickElementByIndex(index) {
  return getController().clickElement(index);
}
clickElementByIndex.__schema__ = {
  name: "clickElementByIndex",
  description: "Click an interactive element by its numeric index from get_browser_state output. Simulates a full mouse event sequence (hover, mousedown, focus, mouseup, click) to trigger all event listeners including React/Vue handlers.",
  parameters: {
    type: "object",
    properties: {
      index: {
        type: "number",
        description: "The element index from get_browser_state (e.g. 0 for [0], 5 for [5])."
      }
    },
    required: ["index"]
  }
};
async function inputText(index, text) {
  return getController().inputText(index, text);
}
inputText.__schema__ = {
  name: "inputText",
  description: "Type text into an input, textarea, or contenteditable element by its index. Replaces existing content. Works with React controlled components, contenteditable editors (LinkedIn, Quill), and native inputs.",
  parameters: {
    type: "object",
    properties: {
      index: {
        type: "number",
        description: "The element index from get_browser_state."
      },
      text: {
        type: "string",
        description: "The text to type into the element."
      }
    },
    required: ["index", "text"]
  }
};
async function selectOption(index, option_text) {
  return getController().selectOption(index, option_text);
}
selectOption.__schema__ = {
  name: "selectOption",
  description: "Select a dropdown option in a <select> element by its index and the visible option text.",
  parameters: {
    type: "object",
    properties: {
      index: {
        type: "number",
        description: "The <select> element index from get_browser_state."
      },
      option_text: {
        type: "string",
        description: "The visible text of the option to select (case-sensitive, trimmed)."
      }
    },
    required: ["index", "option_text"]
  }
};
async function scroll(direction, amount, index) {
  return getController().scroll({ direction, amount, index });
}
scroll.__schema__ = {
  name: "scroll",
  description: "Scroll the page or a specific scrollable container. If index is provided, scrolls the nearest scrollable ancestor of that element. Otherwise scrolls the page or the largest scrollable container.",
  parameters: {
    type: "object",
    properties: {
      direction: {
        type: "string",
        enum: ["up", "down", "left", "right"],
        description: "Scroll direction."
      },
      amount: {
        type: "number",
        description: "Scroll amount in pixels. Default: ~80% of viewport height (vertical) or width (horizontal)."
      },
      index: {
        type: "number",
        description: "Optional element index. If provided, scrolls the nearest scrollable ancestor of this element."
      }
    },
    required: ["direction"]
  }
};
async function removeHighlights() {
  getController().cleanUpHighlights();
  return { success: true, message: "Highlights removed." };
}
removeHighlights.__schema__ = {
  name: "removeHighlights",
  description: "Remove all visual element index labels/highlights from the page. Useful after taking a screenshot if you want a clean view.",
  parameters: {
    type: "object",
    properties: {}
  }
};

// src/relay/service-map.ts
function createServiceMap(ctx = {}) {
  const base = {
    get_page_info: getPageInfo,
    get_html: getHtml,
    query_dom: queryDom,
    click_element: clickElement,
    fill_input: fillInput,
    scroll_to: scrollTo,
    take_screenshot: takeScreenshot,
    execute_script: executeScript,
    navigate,
    get_react_tree: getReactTree,
    // Smart DOM analysis + index-based interaction (from page-controller)
    get_browser_state: getBrowserState,
    click_element_by_index: clickElementByIndex,
    input_text: inputText,
    select_option: selectOption,
    scroll,
    remove_highlights: removeHighlights
  };
  const getSkillMd = () => {
    const schemaFns = {};
    for (const [name2, f] of Object.entries(base)) {
      if (f.__schema__) schemaFns[name2] = f;
    }
    const url = ctx.getServiceUrl?.() ?? "{SERVICE_URL}";
    const pageContext = typeof document !== "undefined" ? { title: document.title, url: location?.href } : void 0;
    return generateSkillMd(schemaFns, url, pageContext);
  };
  getSkillMd.__schema__ = {
    name: "getSkillMd",
    description: "Get the SKILL.md document describing all available debugger functions, their parameters, and usage examples. Follows the agentskills.io specification.",
    parameters: { type: "object", properties: {} }
  };
  const entries = Object.entries(base).map(([name2, fn]) => ({
    name: name2,
    fn,
    schema: fn.__schema__
  }));
  entries.push({
    name: "get_skill_md",
    fn: getSkillMd,
    schema: getSkillMd.__schema__
  });
  return entries;
}

// ../extension/src/browser-tools.ts
var attached = /* @__PURE__ */ new Set();
async function ensureAttached(tabId) {
  if (attached.has(tabId)) return;
  await chrome.debugger.attach({ tabId }, "1.3");
  attached.add(tabId);
  try {
    await chrome.debugger.sendCommand({ tabId }, "Page.enable");
    await chrome.debugger.sendCommand({ tabId }, "Page.setBypassCSP", { enabled: true });
    await chrome.debugger.sendCommand({ tabId }, "Runtime.enable");
  } catch {
  }
}
async function cdpEval(tabId, code) {
  if (!chrome.debugger) {
    return {
      error: "execute_script is disabled. Enable \u201CAllow running JS\u201D in the Hypha Debugger side panel (it needs the debugger permission). The DOM tools (get_browser_state, click_element_by_index, query_dom, \u2026) work without it."
    };
  }
  try {
    await ensureAttached(tabId);
  } catch (e) {
    return {
      error: "Could not attach the debugger to this tab: " + (e?.message ?? e) + ". Enable \u201CAllow running JS\u201D in the side panel, or this may be a restricted page (chrome://, Web Store)."
    };
  }
  const expression = `(async () => { ${autoReturn(code)} })()`;
  const res = await chrome.debugger.sendCommand({ tabId }, "Runtime.evaluate", {
    expression,
    returnByValue: true,
    awaitPromise: true,
    userGesture: true,
    replMode: true
  });
  if (res?.exceptionDetails) {
    const ex = res.exceptionDetails;
    return { error: ex.exception?.description || ex.exception?.value || ex.text || "Evaluation error" };
  }
  const r = res?.result || {};
  return { result: r.value !== void 0 ? r.value : r.description ?? null, type: r.type };
}
function tabSummary(t) {
  return {
    id: t.id,
    title: t.title,
    url: t.url,
    active: t.active,
    window_id: t.windowId,
    status: t.status
  };
}
async function resolveTarget(ctx) {
  let id = ctx.getTarget();
  if (id != null) {
    try {
      await chrome.tabs.get(id);
      return id;
    } catch {
    }
  }
  const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!active) throw new Error("No active tab");
  ctx.setTarget(active.id);
  return active.id;
}
var BROWSER_TOOLS = {
  list_tabs: {
    schema: {
      name: "list_tabs",
      description: "List all open browser tabs across windows. Returns id, title, url, active, window_id, status. Use the id with activate_tab / close_tab / navigate.",
      parameters: { type: "object", properties: {} }
    },
    run: async () => (await chrome.tabs.query({})).map(tabSummary)
  },
  get_active_tab: {
    schema: {
      name: "get_active_tab",
      description: "Get the currently targeted tab (the tab that page-level tools act on). Defaults to the browser's active tab.",
      parameters: { type: "object", properties: {} }
    },
    run: async (ctx) => {
      const id = await resolveTarget(ctx);
      return tabSummary(await chrome.tabs.get(id));
    }
  },
  open_tab: {
    schema: {
      name: "open_tab",
      description: "Open a new tab at a URL and make it the target for page-level tools. Returns the new tab.",
      parameters: {
        type: "object",
        properties: {
          url: { type: "string", description: "URL to open (include https://)" },
          focus: { type: "boolean", description: "Focus the new tab (default true)" }
        },
        required: ["url"]
      }
    },
    run: async (ctx, [url, focus = true]) => {
      const t = await chrome.tabs.create({ url, active: !!focus });
      ctx.setTarget(t.id);
      return tabSummary(t);
    }
  },
  close_tab: {
    schema: {
      name: "close_tab",
      description: "Close a tab by id.",
      parameters: {
        type: "object",
        properties: { tab_id: { type: "number", description: "Tab id to close" } },
        required: ["tab_id"]
      }
    },
    run: async (_ctx, [tab_id]) => {
      await chrome.tabs.remove(tab_id);
      return { success: true };
    }
  },
  activate_tab: {
    schema: {
      name: "activate_tab",
      description: "Focus a tab by id and make it the target for page-level tools (get_browser_state, click_element_by_index, screenshot, \u2026).",
      parameters: {
        type: "object",
        properties: { tab_id: { type: "number", description: "Tab id to target" } },
        required: ["tab_id"]
      }
    },
    run: async (ctx, [tab_id]) => {
      const t = await chrome.tabs.get(tab_id);
      await chrome.tabs.update(tab_id, { active: true });
      try {
        await chrome.windows.update(t.windowId, { focused: true });
      } catch {
      }
      ctx.setTarget(tab_id);
      return { success: true, tab: tabSummary(await chrome.tabs.get(tab_id)) };
    }
  },
  navigate: {
    schema: {
      name: "navigate",
      description: "Navigate the target tab to a URL (full page load). Use open_tab to navigate in a new tab instead.",
      parameters: {
        type: "object",
        properties: { url: { type: "string", description: "URL to navigate to" } },
        required: ["url"]
      }
    },
    run: async (ctx, [url]) => {
      const id = await resolveTarget(ctx);
      await chrome.tabs.update(id, { url });
      return { success: true, url };
    }
  },
  reload_tab: {
    schema: {
      name: "reload_tab",
      description: "Reload the target tab.",
      parameters: {
        type: "object",
        properties: {
          bypass_cache: { type: "boolean", description: "Hard reload (default false)" }
        }
      }
    },
    run: async (ctx, [bypass_cache = false]) => {
      const id = await resolveTarget(ctx);
      await chrome.tabs.reload(id, { bypassCache: !!bypass_cache });
      return { success: true };
    }
  },
  go_back: {
    schema: {
      name: "go_back",
      description: "Go back in the target tab's history.",
      parameters: { type: "object", properties: {} }
    },
    run: async (ctx) => {
      await chrome.tabs.goBack(await resolveTarget(ctx));
      return { success: true };
    }
  },
  go_forward: {
    schema: {
      name: "go_forward",
      description: "Go forward in the target tab's history.",
      parameters: { type: "object", properties: {} }
    },
    run: async (ctx) => {
      await chrome.tabs.goForward(await resolveTarget(ctx));
      return { success: true };
    }
  },
  execute_script: {
    schema: {
      name: "execute_script",
      description: "Run arbitrary JavaScript in the target tab's page context and return the result. Uses the Chrome debugger (Page.setBypassCSP), so it works even on strict-CSP pages that block 'unsafe-eval'. The last expression is auto-returned; async code is awaited. Attaching shows Chrome's 'debugging this browser' banner.",
      parameters: {
        type: "object",
        properties: { code: { type: "string", description: "JavaScript to execute" } },
        required: ["code"]
      }
    },
    run: async (ctx, [code]) => cdpEval(await resolveTarget(ctx), String(code ?? ""))
  }
};
var BROWSER_TOOL_NAMES = new Set(Object.keys(BROWSER_TOOLS));

// ../extension/src/service-catalog.ts
var PAGE_EXCLUDE = /* @__PURE__ */ new Set(["navigate", "get_skill_md", "execute_script"]);
function buildCatalog() {
  const out = [];
  for (const e of createServiceMap()) {
    if (PAGE_EXCLUDE.has(e.name)) continue;
    out.push({ name: e.name, schema: e.schema, kind: "page" });
  }
  for (const [name2, t] of Object.entries(BROWSER_TOOLS)) {
    out.push({ name: name2, schema: t.schema, kind: "browser" });
  }
  return out;
}

// src/relay/service-url.ts
function buildServiceUrl(serverUrl, serviceId) {
  const base = serverUrl.replace(/\/+$/, "");
  const slashIdx = serviceId.indexOf("/");
  if (slashIdx !== -1) {
    const workspace2 = serviceId.substring(0, slashIdx);
    const svcPart = serviceId.substring(slashIdx + 1);
    const colonIdx = svcPart.indexOf(":");
    const svcName = colonIdx !== -1 ? svcPart.substring(colonIdx + 1) : svcPart;
    return `${base}/${workspace2}/services/${svcName}`;
  }
  return `${base}/services/${serviceId}`;
}
function randomHex(bytes = 8) {
  const arr = new Uint8Array(bytes);
  crypto.getRandomValues(arr);
  return Array.from(arr, (b) => b.toString(16).padStart(2, "0")).join("");
}

// src/utils/wrap-fn.ts
function wrapFn(fn) {
  const schema = fn.__schema__;
  const paramNames = schema?.parameters?.properties ? Object.keys(schema.parameters.properties) : [];
  if (paramNames.length === 0) {
    return fn;
  }
  const wrapper = async function(...args) {
    if (args.length === 1 && args[0] != null && typeof args[0] === "object" && !Array.isArray(args[0]) && !(args[0] instanceof Date) && // Plain-object check that is realm-agnostic (kwargs may be created in a
    // different realm — e.g. hypha-rpc's HTTP handler, or relayed across a
    // postMessage/extension boundary). `constructor === Object` fails across
    // realms, so also accept the constructor name and a null prototype.
    isPlainObject(args[0])) {
      const kw = args[0];
      const keys = Object.keys(kw);
      if (keys.length === 0) {
        return fn();
      }
      if (paramNames.indexOf(keys[0]) !== -1) {
        return fn.apply(null, paramNames.map((n) => kw[n]));
      }
    }
    return fn.apply(null, args);
  };
  const fakeSource = `function (${paramNames.join(", ")}) {}`;
  try {
    Object.defineProperty(wrapper, "toString", {
      value: () => fakeSource,
      writable: true,
      configurable: true
    });
    Object.defineProperty(wrapper, "length", {
      value: paramNames.length,
      configurable: true
    });
  } catch {
    wrapper.toString = () => fakeSource;
  }
  if (schema) wrapper.__schema__ = schema;
  return wrapper;
}
function isPlainObject(x) {
  const proto = Object.getPrototypeOf(x);
  return proto === null || proto === Object.prototype || proto?.constructor?.name === "Object";
}

// ../extension/src/offscreen.ts
var server2 = null;
var connecting = false;
function getConnect() {
  const override = globalThis.__HYPHA_CONNECT__;
  if (typeof override === "function") return override;
  const mod = hyphaRpc;
  if (mod.connectToServer) return mod.connectToServer;
  if (mod.hyphaWebsocketClient?.connectToServer)
    return mod.hyphaWebsocketClient.connectToServer;
  throw new Error("hypha-rpc connectToServer not found");
}
function ui(data) {
  chrome.runtime.sendMessage({ __ui: true, ...data }).catch(() => {
  });
}
function makeProxy(name2, schema) {
  const inner = async (...args) => {
    const r = await chrome.runtime.sendMessage({ __hyphaCall: true, method: name2, args });
    if (r && r.__error) throw new Error(r.__error);
    return r ? r.value : void 0;
  };
  inner.__schema__ = schema;
  return wrapFn(inner);
}
function withTimeout(p, ms, what) {
  return Promise.race([
    p,
    new Promise(
      (_, reject2) => setTimeout(() => reject2(new Error(`${what} timed out after ${Math.round(ms / 1e3)}s`)), ms)
    )
  ]);
}
async function connect(config2) {
  if (connecting) return;
  connecting = true;
  if (server2) {
    try {
      server2.disconnect?.();
    } catch {
    }
    server2 = null;
  }
  try {
    await chrome.storage.local.set({ hyphaStatus: "connecting" });
    ui({ type: "status", status: "connecting" });
    ui({ type: "log", msg: `connecting to ${config2.server_url} \u2026`, kind: "status" });
    console.log("[hypha-offscreen] connecting to", config2.server_url);
    const connectToServer2 = getConnect();
    const baseCfg = { server_url: config2.server_url };
    if (config2.token) baseCfg.token = config2.token;
    const cfg = { ...baseCfg };
    if (config2.workspace) cfg.workspace = config2.workspace;
    try {
      server2 = await withTimeout(connectToServer2(cfg), 25e3, "connect");
    } catch (e) {
      if (config2.workspace) {
        ui({ type: "log", msg: "retrying without the saved workspace \u2026", kind: "status" });
        server2 = await withTimeout(connectToServer2({ ...baseCfg }), 25e3, "connect");
      } else {
        throw e;
      }
    }
    ui({
      type: "log",
      msg: `connected (workspace ${server2.config?.workspace ?? "?"}), registering tools \u2026`,
      kind: "status"
    });
    const catalog = buildCatalog();
    const serviceId = config2.service_id || `web-debugger-${randomHex(16)}`;
    const def = {
      id: serviceId,
      name: config2.service_name || "Browser Debugger",
      type: "debugger",
      description: "Remote browser automation: drive tabs (open/close/navigate/switch) and inspect & control the target page (DOM, screenshots, click/type by index, React).",
      config: { visibility: config2.require_token ? "protected" : "unlisted" }
    };
    for (const { name: name2, schema } of catalog) def[name2] = makeProxy(name2, schema);
    let serviceUrl = "{SERVICE_URL}";
    const skillFn = () => {
      const fns = {};
      for (const { name: name2, schema } of catalog) fns[name2] = { __schema__: schema };
      return generateSkillMd(fns, serviceUrl);
    };
    skillFn.__schema__ = {
      name: "get_skill_md",
      description: "Full API documentation for all browser + page tools, with usage examples.",
      parameters: { type: "object", properties: {} }
    };
    def.get_skill_md = wrapFn(skillFn);
    const info = await withTimeout(
      server2.registerService(def),
      25e3,
      "register service"
    );
    serviceUrl = buildServiceUrl(config2.server_url, info.id ?? serviceId);
    const workspace2 = server2.config?.workspace ?? "";
    const token2 = config2.require_token ? await server2.generateToken({ expires_in: 86400 }) : "";
    await chrome.storage.local.set({
      hyphaStatus: "connected",
      hyphaServiceUrl: serviceUrl,
      hyphaToken: token2,
      hyphaWorkspace: workspace2
    });
    ui({ type: "ready", service_url: serviceUrl, token: token2, workspace: workspace2 });
    ui({ type: "status", status: "connected", detail: serviceUrl });
  } catch (e) {
    server2 = null;
    console.error("[hypha-offscreen] connect failed:", e);
    await chrome.storage.local.set({ hyphaStatus: "error", hyphaServiceUrl: "" });
    ui({ type: "status", status: "error", detail: e?.message ?? String(e) });
  } finally {
    connecting = false;
  }
}
async function disconnect() {
  const s = server2;
  server2 = null;
  try {
    s?.disconnect?.();
  } catch {
  }
  await chrome.storage.local.set({ hyphaStatus: "disconnected", hyphaServiceUrl: "" });
  ui({ type: "status", status: "disconnected" });
}
chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  if (msg.__off === "connect") void connect(msg.config);
  else if (msg.__off === "disconnect") void disconnect();
});
chrome.storage.local.get(["hyphaConnected", "hyphaConfig"]).then((r) => {
  if (r.hyphaConnected && r.hyphaConfig) void connect(r.hyphaConfig);
});
setInterval(() => {
  chrome.runtime.sendMessage({ __off: "keepalive", connected: !!server2 }).catch(() => {
  });
}, 2e4);
