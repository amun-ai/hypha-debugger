var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/hypha-rpc/dist/hypha-rpc-websocket.js
var require_hypha_rpc_websocket = __commonJS({
  "node_modules/hypha-rpc/dist/hypha-rpc-websocket.js"(exports, module) {
    (function webpackUniversalModuleDefinition(root, factory) {
      if (typeof exports === "object" && typeof module === "object")
        module.exports = factory();
      else if (typeof define === "function" && define.amd)
        define("hyphaWebsocketClient", [], factory);
      else if (typeof exports === "object")
        exports["hyphaWebsocketClient"] = factory();
      else
        root["hyphaWebsocketClient"] = factory();
    })(exports, () => {
      return (
        /******/
        (() => {
          "use strict";
          var __webpack_modules__ = {
            /***/
            "./src/http-client.js": (
              /*!****************************!*\
                !*** ./src/http-client.js ***!
                \****************************/
              /***/
              (__unused_webpack_module2, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  HTTPStreamingRPCConnection: () => (
                    /* binding */
                    HTTPStreamingRPCConnection
                  ),
                  /* harmony export */
                  _connectToServerHTTP: () => (
                    /* binding */
                    _connectToServerHTTP
                  ),
                  /* harmony export */
                  connectToServerHTTP: () => (
                    /* binding */
                    connectToServerHTTP
                  ),
                  /* harmony export */
                  getRemoteServiceHTTP: () => (
                    /* binding */
                    getRemoteServiceHTTP
                  ),
                  /* harmony export */
                  normalizeServerUrl: () => (
                    /* binding */
                    normalizeServerUrl2
                  )
                  /* harmony export */
                });
                var _rpc_js__WEBPACK_IMPORTED_MODULE_0__2 = __webpack_require__2(
                  /*! ./rpc.js */
                  "./src/rpc.js"
                );
                var _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2 = __webpack_require__2(
                  /*! ./utils/index.js */
                  "./src/utils/index.js"
                );
                var _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2 = __webpack_require__2(
                  /*! ./utils/schema.js */
                  "./src/utils/schema.js"
                );
                var _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__2(
                  /*! @msgpack/msgpack */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/decode.mjs"
                );
                const MAX_RETRY2 = 1e6;
                class HTTPStreamingRPCConnection {
                  /**
                   * Initialize HTTP streaming connection.
                   *
                   * @param {string} server_url - The server URL (http:// or https://)
                   * @param {string} client_id - Unique client identifier
                   * @param {string} workspace - Target workspace (optional)
                   * @param {string} token - Authentication token (optional)
                   * @param {string} reconnection_token - Token for reconnection (optional)
                   * @param {number} timeout - Request timeout in seconds (default: 60)
                   * @param {number} token_refresh_interval - Interval for token refresh (default: 2 hours)
                   */
                  constructor(server_url2, client_id2, workspace2 = null, token2 = null, reconnection_token = null, timeout = 60, token_refresh_interval = 2 * 60 * 60) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(server_url2 && client_id2, "server_url and client_id are required");
                    this._server_url = server_url2.replace(/\/$/, "");
                    this._client_id = client_id2;
                    this._workspace = workspace2;
                    this._token = token2;
                    this._reconnection_token = reconnection_token;
                    this._timeout = timeout;
                    this._token_refresh_interval = token_refresh_interval;
                    this._handle_message = null;
                    this._handle_disconnected = null;
                    this._handle_connected = null;
                    this._closed = false;
                    this._enable_reconnect = false;
                    this._is_reconnection = false;
                    this.connection_info = null;
                    this.manager_id = null;
                    this._abort_controller = null;
                    this._refresh_token_task = null;
                  }
                  /**
                   * Register message handler.
                   */
                  on_message(handler) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(handler, "handler is required");
                    this._handle_message = handler;
                  }
                  /**
                   * Register disconnection handler.
                   */
                  on_disconnected(handler) {
                    this._handle_disconnected = handler;
                  }
                  /**
                   * Register connection handler.
                   */
                  on_connected(handler) {
                    this._handle_connected = handler;
                  }
                  /**
                   * Get HTTP headers with authentication.
                   *
                   * @param {boolean} for_stream - If true, set Accept header for msgpack stream
                   * @returns {Object} Headers object
                   */
                  _get_headers(for_stream = false) {
                    const headers = {
                      "Content-Type": "application/msgpack"
                    };
                    if (for_stream) {
                      headers["Accept"] = "application/x-msgpack-stream";
                    }
                    if (this._token) {
                      headers["Authorization"] = `Bearer ${this._token}`;
                    }
                    return headers;
                  }
                  /**
                   * Open the streaming connection.
                   */
                  async open() {
                    console.info(`Opening HTTP streaming connection to ${this._server_url}`);
                    const ws = this._workspace || "public";
                    const stream_url = `${this._server_url}/${ws}/rpc?client_id=${this._client_id}`;
                    this._startStreamLoop(stream_url);
                    const start = Date.now();
                    while (this.connection_info === null) {
                      await new Promise((resolve2) => setTimeout(resolve2, 100));
                      if (Date.now() - start > this._timeout * 1e3) {
                        throw new Error("Timeout waiting for connection info");
                      }
                      if (this._closed) {
                        throw new Error("Connection closed during setup");
                      }
                    }
                    this.manager_id = this.connection_info.manager_id;
                    if (this._workspace) {
                      const actual_ws = this.connection_info.workspace;
                      if (actual_ws !== this._workspace) {
                        throw new Error(
                          `Connected to wrong workspace: ${actual_ws}, expected: ${this._workspace}`
                        );
                      }
                    }
                    this._workspace = this.connection_info.workspace;
                    if (this.connection_info.reconnection_token) {
                      this._reconnection_token = this.connection_info.reconnection_token;
                    }
                    if (this.connection_info.reconnection_token_life_time) {
                      const token_life_time = this.connection_info.reconnection_token_life_time;
                      if (this._token_refresh_interval > token_life_time / 1.5) {
                        console.warn(
                          `Token refresh interval (${this._token_refresh_interval}s) is too long, adjusting to ${(token_life_time / 1.5).toFixed(0)}s based on token lifetime`
                        );
                        this._token_refresh_interval = token_life_time / 1.5;
                      }
                    }
                    console.info(
                      `HTTP streaming connected to workspace: ${this._workspace}, manager_id: ${this.manager_id}`
                    );
                    if (this._token_refresh_interval > 0) {
                      this._startTokenRefresh();
                    }
                    if (this._handle_connected) {
                      await this._handle_connected(this.connection_info);
                    }
                    return this.connection_info;
                  }
                  /**
                   * Start periodic token refresh via POST.
                   */
                  _startTokenRefresh() {
                    if (this._refresh_token_task) {
                      clearInterval(this._refresh_token_task);
                    }
                    setTimeout(() => {
                      this._sendRefreshToken();
                      this._refresh_token_task = setInterval(() => {
                        this._sendRefreshToken();
                      }, this._token_refresh_interval * 1e3);
                    }, 2e3);
                  }
                  /**
                   * Send a token refresh request via POST.
                   */
                  async _sendRefreshToken() {
                    if (this._closed) return;
                    try {
                      const ws = this._workspace || "public";
                      const url = `${this._server_url}/${ws}/rpc?client_id=${this._client_id}`;
                      const { encode } = await __webpack_require__2.e(
                        /*! import() */
                        "vendors-node_modules_msgpack_msgpack_dist_es5_esm_index_mjs"
                      ).then(__webpack_require__2.bind(
                        __webpack_require__2,
                        /*! @msgpack/msgpack */
                        "./node_modules/@msgpack/msgpack/dist.es5+esm/index.mjs"
                      ));
                      const body = encode({ type: "refresh_token" });
                      const response = await fetch(url, {
                        method: "POST",
                        headers: this._get_headers(false),
                        body
                      });
                      if (response.ok) {
                        console.debug("Token refresh requested successfully");
                      } else {
                        console.warn(`Token refresh request failed: ${response.status}`);
                      }
                    } catch (e) {
                      console.warn(`Failed to send refresh token request: ${e.message}`);
                    }
                  }
                  /**
                   * Start the streaming loop.
                   *
                   * OPTIMIZATION: Modern browsers automatically:
                   * - Negotiate HTTP/2 when server supports it
                   * - Use connection pooling for multiple requests to same origin
                   * - Handle keep-alive for persistent connections
                   * - Stream responses efficiently with backpressure handling
                   */
                  async _startStreamLoop(url) {
                    this._enable_reconnect = true;
                    this._closed = false;
                    let retry = 0;
                    this._is_reconnection = false;
                    while (!this._closed && retry < MAX_RETRY2) {
                      try {
                        const ws = this._workspace || "public";
                        let stream_url = `${this._server_url}/${ws}/rpc?client_id=${this._client_id}`;
                        if (this._reconnection_token) {
                          stream_url += `&reconnection_token=${encodeURIComponent(this._reconnection_token)}`;
                        }
                        this._abort_controller = new AbortController();
                        const response = await fetch(stream_url, {
                          method: "GET",
                          headers: this._get_headers(true),
                          signal: this._abort_controller.signal
                        });
                        if (!response.ok) {
                          const error_text = await response.text();
                          throw new Error(
                            `Stream failed with status ${response.status}: ${error_text}`
                          );
                        }
                        retry = 0;
                        await this._processMsgpackStream(response);
                      } catch (error) {
                        if (this._closed) break;
                        console.error(`Connection error: ${error.message}`);
                        if (!this._enable_reconnect) {
                          break;
                        }
                      }
                      this._is_reconnection = true;
                      if (!this._closed && this._enable_reconnect) {
                        retry += 1;
                        const delay = Math.min(Math.pow(2, Math.min(retry, 6)), 60);
                        console.warn(
                          `Stream disconnected, reconnecting in ${delay.toFixed(1)}s (attempt ${retry})`
                        );
                        await new Promise((resolve2) => setTimeout(resolve2, delay * 1e3));
                      } else {
                        break;
                      }
                    }
                    if (!this._closed && this._handle_disconnected) {
                      this._handle_disconnected("Stream ended");
                    }
                  }
                  /**
                   * Check if frame data is a control message and decode it.
                   *
                   * Control messages vs RPC messages:
                   * - Control messages: Single msgpack object with "type" field (connection_info, ping, etc.)
                   * - RPC messages: May contain multiple concatenated msgpack objects (main message + extra data)
                   *
                   * We only need to decode the first object to check if it's a control message.
                   * RPC messages are passed as raw bytes to the handler.
                   *
                   * @param {Uint8Array} frame_data - The msgpack frame data
                   * @returns {Object|null} Decoded control message or null
                   */
                  _tryDecodeControlMessage(frame_data) {
                    try {
                      const decoded = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__.decode)(frame_data);
                      if (typeof decoded === "object" && decoded !== null && decoded.type) {
                        const controlTypes = [
                          "connection_info",
                          "ping",
                          "pong",
                          "reconnection_token",
                          "error"
                        ];
                        if (controlTypes.includes(decoded.type)) {
                          return decoded;
                        }
                      }
                      return null;
                    } catch {
                      return null;
                    }
                  }
                  /**
                   * Process msgpack stream with 4-byte length prefix.
                   */
                  async _processMsgpackStream(response) {
                    const reader = response.body.getReader();
                    let buffer = new Uint8Array(4096);
                    let bufferLen = 0;
                    while (!this._closed) {
                      const { done, value } = await reader.read();
                      if (done) break;
                      const needed = bufferLen + value.length;
                      if (needed > buffer.length) {
                        let newSize = buffer.length;
                        while (newSize < needed) newSize *= 2;
                        const grown = new Uint8Array(newSize);
                        grown.set(buffer.subarray(0, bufferLen));
                        buffer = grown;
                      }
                      buffer.set(value, bufferLen);
                      bufferLen += value.length;
                      let offset = 0;
                      while (bufferLen - offset >= 4) {
                        const length = buffer[offset] << 24 | buffer[offset + 1] << 16 | buffer[offset + 2] << 8 | buffer[offset + 3];
                        if (bufferLen - offset < 4 + length) {
                          break;
                        }
                        const frame_data = buffer.slice(offset + 4, offset + 4 + length);
                        offset += 4 + length;
                        const controlMsg = this._tryDecodeControlMessage(frame_data);
                        if (controlMsg) {
                          const msg_type = controlMsg.type;
                          if (msg_type === "connection_info") {
                            this.connection_info = controlMsg;
                            if (this._is_reconnection) {
                              this._handleReconnection(controlMsg).catch((err) => {
                                console.error(`Reconnection handling failed: ${err.message}`);
                              });
                            }
                            continue;
                          } else if (msg_type === "ping" || msg_type === "pong") {
                            continue;
                          } else if (msg_type === "reconnection_token") {
                            this._reconnection_token = controlMsg.reconnection_token;
                            continue;
                          } else if (msg_type === "error") {
                            console.error(`Server error: ${controlMsg.message}`);
                            continue;
                          }
                        }
                        if (this._handle_message) {
                          try {
                            await this._handle_message(frame_data);
                          } catch (error) {
                            console.error(`Error in message handler: ${error.message}`);
                          }
                        }
                      }
                      if (offset > 0) {
                        const remaining = bufferLen - offset;
                        if (remaining > 0) {
                          buffer.copyWithin(0, offset, bufferLen);
                        }
                        bufferLen = remaining;
                      }
                    }
                  }
                  /**
                   * Handle reconnection: update state and notify RPC layer.
                   */
                  async _handleReconnection(connection_info) {
                    this.manager_id = connection_info.manager_id;
                    this._workspace = connection_info.workspace;
                    if (connection_info.reconnection_token) {
                      this._reconnection_token = connection_info.reconnection_token;
                    }
                    if (connection_info.reconnection_token_life_time) {
                      const token_life_time = connection_info.reconnection_token_life_time;
                      if (this._token_refresh_interval > token_life_time / 1.5) {
                        this._token_refresh_interval = token_life_time / 1.5;
                      }
                    }
                    console.warn(
                      `Stream reconnected to workspace: ${this._workspace}, manager_id: ${this.manager_id}`
                    );
                    if (this._handle_connected) {
                      await this._handle_connected(this.connection_info);
                    }
                    await new Promise((resolve2) => setTimeout(resolve2, 500));
                  }
                  /**
                   * Send a message to the server via HTTP POST.
                   *
                   * OPTIMIZATION: Uses keepalive flag for connection reuse.
                   * Modern browsers automatically:
                   * - Use HTTP/2 when available (multiplexing, header compression)
                   * - Manage connection pooling with HTTP/1.1 keep-alive
                   * - Reuse connections for same-origin requests
                   */
                  async emit_message(data) {
                    if (this._closed) {
                      throw new Error("Connection is closed");
                    }
                    const ws = this._workspace || "public";
                    let post_url = `${this._server_url}/${ws}/rpc?client_id=${this._client_id}`;
                    const body = data instanceof Uint8Array ? data : new Uint8Array(data);
                    const maxRetries = 3;
                    for (let attempt = 0; attempt < maxRetries; attempt++) {
                      try {
                        const useKeepalive = body.length < 6e4;
                        const response = await fetch(post_url, {
                          method: "POST",
                          headers: this._get_headers(false),
                          body,
                          ...useKeepalive && { keepalive: true }
                        });
                        if (!response.ok) {
                          const error_text = await response.text();
                          if (response.status === 400 && attempt < maxRetries - 1) {
                            console.warn(
                              `POST failed (attempt ${attempt + 1}/${maxRetries}): ${error_text}, retrying...`
                            );
                            await new Promise(
                              (r) => setTimeout(r, 500 * (attempt + 1))
                            );
                            continue;
                          }
                          throw new Error(
                            `POST failed with status ${response.status}: ${error_text}`
                          );
                        }
                        return true;
                      } catch (error) {
                        if (attempt < maxRetries - 1 && !this._closed) {
                          console.warn(
                            `Failed to send message (attempt ${attempt + 1}/${maxRetries}): ${error.message}, retrying...`
                          );
                          await new Promise(
                            (r) => setTimeout(r, 500 * (attempt + 1))
                          );
                        } else {
                          console.error(`Failed to send message: ${error.message}`);
                          throw error;
                        }
                      }
                    }
                  }
                  /**
                   * Set reconnection flag.
                   */
                  set_reconnection(value) {
                    this._enable_reconnect = value;
                  }
                  /**
                   * Close the connection.
                   */
                  async disconnect(reason = "client disconnect") {
                    if (this._closed) return;
                    this._closed = true;
                    if (this._refresh_token_task) {
                      clearInterval(this._refresh_token_task);
                      this._refresh_token_task = null;
                    }
                    if (this._abort_controller) {
                      this._abort_controller.abort();
                      this._abort_controller = null;
                    }
                    if (this._handle_disconnected) {
                      this._handle_disconnected(reason);
                    }
                  }
                }
                function normalizeServerUrl2(server_url2) {
                  if (!server_url2) {
                    throw new Error("server_url is required");
                  }
                  if (server_url2.startsWith("ws://")) {
                    server_url2 = server_url2.replace("ws://", "http://");
                  } else if (server_url2.startsWith("wss://")) {
                    server_url2 = server_url2.replace("wss://", "https://");
                  }
                  if (server_url2.endsWith("/ws")) {
                    server_url2 = server_url2.slice(0, -3);
                  }
                  return server_url2.replace(/\/$/, "");
                }
                async function _connectToServerHTTP(config2) {
                  let clientId = config2.clientId || config2.client_id;
                  if (!clientId) {
                    clientId = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.randId)();
                  }
                  const server_url2 = normalizeServerUrl2(config2.serverUrl || config2.server_url);
                  const connection = new HTTPStreamingRPCConnection(
                    server_url2,
                    clientId,
                    config2.workspace,
                    config2.token,
                    config2.reconnection_token,
                    config2.method_timeout || 30,
                    config2.token_refresh_interval || 2 * 60 * 60
                  );
                  const connection_info = await connection.open();
                  (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(connection_info, "Failed to connect to server");
                  await new Promise((resolve2) => setTimeout(resolve2, 100));
                  const workspace2 = connection_info.workspace;
                  const rpc = new _rpc_js__WEBPACK_IMPORTED_MODULE_0__2.RPC(connection, {
                    client_id: clientId,
                    workspace: workspace2,
                    default_context: { connection_type: "http_streaming" },
                    name: config2.name,
                    method_timeout: config2.method_timeout,
                    app_id: config2.app_id,
                    server_base_url: connection_info.public_base_url
                  });
                  await rpc.waitFor("services_registered", config2.method_timeout || 120);
                  const wm = await rpc.get_manager_service({
                    timeout: config2.method_timeout || 30,
                    case_conversion: "camel"
                  });
                  wm.rpc = rpc;
                  wm.disconnect = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2.schemaFunction)(rpc.disconnect.bind(rpc), {
                    name: "disconnect",
                    description: "Disconnect from server",
                    parameters: { properties: {}, type: "object" }
                  });
                  wm.registerService = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2.schemaFunction)(rpc.register_service.bind(rpc), {
                    name: "registerService",
                    description: "Register a service",
                    parameters: {
                      properties: {
                        service: { description: "Service to register", type: "object" }
                      },
                      required: ["service"],
                      type: "object"
                    }
                  });
                  const _getService = wm.getService;
                  wm.getService = async (query, config3 = {}) => {
                    return await _getService(query, config3);
                  };
                  if (_getService.__schema__) {
                    wm.getService.__schema__ = _getService.__schema__;
                  }
                  async function serve() {
                    await new Promise(() => {
                    });
                  }
                  wm.serve = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2.schemaFunction)(serve, {
                    name: "serve",
                    description: "Run event loop forever",
                    parameters: { type: "object", properties: {} }
                  });
                  if (connection_info) {
                    wm.config = Object.assign(wm.config || {}, connection_info);
                  }
                  if (connection.manager_id) {
                    rpc.on("force-exit", async (message) => {
                      if (message.from === "*/" + connection.manager_id) {
                        console.info(`Disconnecting from server: ${message.reason}`);
                        await rpc.disconnect();
                      }
                    });
                  }
                  return wm;
                }
                async function connectToServerHTTP(config2 = {}) {
                  return await _connectToServerHTTP(config2);
                }
                async function getRemoteServiceHTTP(serviceUri, config2 = {}) {
                  const { serverUrl, workspace: workspace2, clientId, serviceId, appId } = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.parseServiceUrl)(serviceUri);
                  const fullServiceId = `${workspace2}/${clientId}:${serviceId}@${appId}`;
                  if (config2.serverUrl) {
                    if (config2.serverUrl !== serverUrl) {
                      throw new Error("server_url mismatch");
                    }
                  }
                  config2.serverUrl = serverUrl;
                  const server2 = await connectToServerHTTP(config2);
                  return await server2.getService(fullServiceId);
                }
              }
            ),
            /***/
            "./src/rpc.js": (
              /*!********************!*\
                !*** ./src/rpc.js ***!
                \********************/
              /***/
              (__unused_webpack_module2, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  API_VERSION: () => (
                    /* binding */
                    API_VERSION
                  ),
                  /* harmony export */
                  RPC: () => (
                    /* binding */
                    RPC
                  )
                  /* harmony export */
                });
                var _utils_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./utils/index.js */
                  "./src/utils/index.js"
                );
                var _utils_schema_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__2(
                  /*! ./utils/schema.js */
                  "./src/utils/schema.js"
                );
                var _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__2(
                  /*! @msgpack/msgpack */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/decode.mjs"
                );
                var _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__2(
                  /*! @msgpack/msgpack */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/encode.mjs"
                );
                const API_VERSION = 3;
                const CHUNK_SIZE = 1024 * 256;
                const CONCURRENCY_LIMIT = 30;
                const ArrayBufferView = Object.getPrototypeOf(
                  Object.getPrototypeOf(new Uint8Array())
                ).constructor;
                function _isPrimitive(v) {
                  if (v === null || v === void 0) return true;
                  const t = typeof v;
                  return t === "number" || t === "string" || t === "boolean";
                }
                function _allPrimitivesArray(arr) {
                  for (let i = 0; i < arr.length; i++) {
                    const v = arr[i];
                    if (_isPrimitive(v)) continue;
                    if (v instanceof Uint8Array) continue;
                    if (Array.isArray(v)) {
                      if (!_allPrimitivesArray(v)) return false;
                      continue;
                    }
                    if (v && v.constructor === Object) {
                      if ("_rtype" in v) return false;
                      if (!_allPrimitivesObject(v)) return false;
                      continue;
                    }
                    return false;
                  }
                  return true;
                }
                function _allPrimitivesObject(obj) {
                  const values = Object.values(obj);
                  for (let i = 0; i < values.length; i++) {
                    const v = values[i];
                    if (_isPrimitive(v)) continue;
                    if (v instanceof Uint8Array) continue;
                    if (Array.isArray(v)) {
                      if (!_allPrimitivesArray(v)) return false;
                      continue;
                    }
                    if (v && v.constructor === Object) {
                      if ("_rtype" in v) return false;
                      if (!_allPrimitivesObject(v)) return false;
                      continue;
                    }
                    return false;
                  }
                  return true;
                }
                function _appendBuffer(buffer1, buffer2) {
                  const tmp = new Uint8Array(buffer1.byteLength + buffer2.byteLength);
                  tmp.set(new Uint8Array(buffer1), 0);
                  tmp.set(new Uint8Array(buffer2), buffer1.byteLength);
                  return tmp.buffer;
                }
                function withTimeout(promise, timeoutMs, message = "Operation timed out") {
                  return new Promise((resolve2, reject2) => {
                    const timeoutId = setTimeout(() => {
                      reject2(new Error(`TimeoutError: ${message}`));
                    }, timeoutMs);
                    promise.then((result) => {
                      clearTimeout(timeoutId);
                      resolve2(result);
                    }).catch((error) => {
                      clearTimeout(timeoutId);
                      reject2(error);
                    });
                  });
                }
                function indexObject(obj, is) {
                  if (!is) throw new Error("undefined index");
                  if (typeof is === "string") return indexObject(obj, is.split("."));
                  else if (is.length === 0) return obj;
                  else return indexObject(obj[is[0]], is.slice(1));
                }
                function _get_schema(obj, name2 = null, skipContext = false) {
                  if (Array.isArray(obj)) {
                    return obj.map((v, i) => _get_schema(v, null, skipContext));
                  } else if (typeof obj === "object" && obj !== null) {
                    let schema = {};
                    for (let k in obj) {
                      schema[k] = _get_schema(obj[k], k, skipContext);
                    }
                    return schema;
                  } else if (typeof obj === "function") {
                    if (obj.__schema__) {
                      const schema = JSON.parse(JSON.stringify(obj.__schema__));
                      if (name2) {
                        schema.name = name2;
                        obj.__schema__.name = name2;
                      }
                      if (skipContext) {
                        if (schema.parameters && schema.parameters.properties) {
                          delete schema.parameters.properties["context"];
                        }
                        if (schema.parameters && schema.parameters.required) {
                          const contextIndex = schema.parameters.required.indexOf("context");
                          if (contextIndex > -1) {
                            schema.parameters.required.splice(contextIndex, 1);
                          }
                        }
                      }
                      return { type: "function", function: schema };
                    } else {
                      const funcName = name2 || obj.name || "function";
                      return {
                        type: "function",
                        function: {
                          name: funcName
                        }
                      };
                    }
                  } else if (typeof obj === "number") {
                    return { type: "number" };
                  } else if (typeof obj === "string") {
                    return { type: "string" };
                  } else if (typeof obj === "boolean") {
                    return { type: "boolean" };
                  } else if (obj === null) {
                    return { type: "null" };
                  } else {
                    return {};
                  }
                }
                function _annotate_service(service, serviceTypeInfo) {
                  function validateKeys(serviceDict, schemaDict, path = "root") {
                    for (let key in schemaDict) {
                      if (!serviceDict.hasOwnProperty(key)) {
                        throw new Error(`Missing key '${key}' in service at path '${path}'`);
                      }
                    }
                    for (let key in serviceDict) {
                      if (key !== "type" && !schemaDict.hasOwnProperty(key)) {
                        throw new Error(`Unexpected key '${key}' in service at path '${path}'`);
                      }
                    }
                  }
                  function annotateRecursive(newService, schemaInfo, path = "root") {
                    if (typeof newService === "object" && !Array.isArray(newService)) {
                      validateKeys(newService, schemaInfo, path);
                      for (let k in newService) {
                        let v = newService[k];
                        let newPath = `${path}.${k}`;
                        if (typeof v === "object" && !Array.isArray(v)) {
                          annotateRecursive(v, schemaInfo[k], newPath);
                        } else if (typeof v === "function") {
                          if (schemaInfo.hasOwnProperty(k)) {
                            newService[k] = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_1__.schemaFunction)(v, {
                              name: schemaInfo[k]["name"],
                              description: schemaInfo[k].description || "",
                              parameters: schemaInfo[k]["parameters"]
                            });
                          } else {
                            throw new Error(
                              `Missing schema for function '${k}' at path '${newPath}'`
                            );
                          }
                        }
                      }
                    } else if (Array.isArray(newService)) {
                      if (newService.length !== schemaInfo.length) {
                        throw new Error(`Length mismatch at path '${path}'`);
                      }
                      newService.forEach((v, i) => {
                        let newPath = `${path}[${i}]`;
                        if (typeof v === "object" && !Array.isArray(v)) {
                          annotateRecursive(v, schemaInfo[i], newPath);
                        } else if (typeof v === "function") {
                          if (schemaInfo.hasOwnProperty(i)) {
                            newService[i] = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_1__.schemaFunction)(v, {
                              name: schemaInfo[i]["name"],
                              description: schemaInfo[i].description || "",
                              parameters: schemaInfo[i]["parameters"]
                            });
                          } else {
                            throw new Error(
                              `Missing schema for function at index ${i} in path '${newPath}'`
                            );
                          }
                        }
                      });
                    }
                  }
                  validateKeys(service, serviceTypeInfo["definition"]);
                  annotateRecursive(service, serviceTypeInfo["definition"]);
                  return service;
                }
                function getFunctionInfo(func) {
                  const funcString = func.toString();
                  const nameMatch = funcString.match(/function\s*(\w*)/);
                  const name2 = nameMatch && nameMatch[1] || "";
                  const paramsMatch = funcString.match(/\(([^)]*)\)/);
                  let params = "";
                  if (paramsMatch) {
                    params = paramsMatch[1].split(",").map(
                      (p) => p.replace(/\/\*.*?\*\//g, "").replace(/\/\/.*$/g, "")
                    ).filter((p) => p.trim().length > 0).map((p) => p.trim()).join(", ");
                  }
                  let docMatch = funcString.match(/\)\s*\{\s*\/\*([\s\S]*?)\*\//);
                  const docstringBlock = docMatch && docMatch[1].trim() || "";
                  docMatch = funcString.match(/\)\s*\{\s*(\/\/[\s\S]*?)\n\s*[^\s\/]/);
                  const docstringLine = docMatch && docMatch[1].split("\n").map((s) => s.replace(/^\/\/\s*/, "").trim()).join("\n") || "";
                  const docstring = docstringBlock || docstringLine;
                  return name2 && params.length > 0 && {
                    name: name2,
                    sig: params,
                    doc: docstring
                  };
                }
                function concatArrayBuffers(buffers) {
                  var buffersLengths = buffers.map(function(b) {
                    return b.byteLength;
                  }), totalBufferlength = buffersLengths.reduce(function(p, c) {
                    return p + c;
                  }, 0), unit8Arr = new Uint8Array(totalBufferlength);
                  buffersLengths.reduce(function(p, c, i) {
                    unit8Arr.set(new Uint8Array(buffers[i]), p);
                    return p + c;
                  }, 0);
                  return unit8Arr.buffer;
                }
                class Timer {
                  constructor(timeout, callback, args, label) {
                    this._timeout = timeout;
                    this._callback = callback;
                    this._args = args;
                    this._label = label || "timer";
                    this._task = null;
                    this.started = false;
                  }
                  start() {
                    if (this.started) {
                      this.reset();
                    } else {
                      this._task = setTimeout(() => {
                        this._callback.apply(this, this._args);
                      }, this._timeout * 1e3);
                      this.started = true;
                    }
                  }
                  clear() {
                    if (this._task && this.started) {
                      clearTimeout(this._task);
                      this._task = null;
                      this.started = false;
                    } else {
                      console.warn(`Clearing a timer (${this._label}) which is not started`);
                    }
                  }
                  reset() {
                    if (this._task) {
                      clearTimeout(this._task);
                    }
                    this._task = setTimeout(() => {
                      this._callback.apply(this, this._args);
                    }, this._timeout * 1e3);
                    this.started = true;
                  }
                }
                class RemoteService extends Object {
                }
                class RPC extends _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.MessageEmitter {
                  constructor(connection, {
                    client_id: client_id2 = null,
                    default_context = null,
                    name: name2 = null,
                    codecs = null,
                    method_timeout: method_timeout2 = null,
                    max_message_buffer_size = 0,
                    debug = false,
                    workspace: workspace2 = null,
                    silent = false,
                    app_id = null,
                    server_base_url = null,
                    long_message_chunk_size = null
                  }) {
                    super(debug);
                    this._codecs = codecs || {};
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(client_id2 && typeof client_id2 === "string");
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(client_id2, "client_id is required");
                    this._client_id = client_id2;
                    this._name = name2;
                    this._app_id = app_id || "*";
                    this._local_workspace = workspace2;
                    this._silent = silent;
                    this.default_context = default_context || {};
                    this._method_annotations = /* @__PURE__ */ new WeakMap();
                    this._max_message_buffer_size = max_message_buffer_size;
                    this._chunk_store = {};
                    this._method_timeout = method_timeout2 || 30;
                    this._server_base_url = server_base_url;
                    this._long_message_chunk_size = long_message_chunk_size || CHUNK_SIZE;
                    this._services = {};
                    this._object_store = {
                      services: this._services
                    };
                    this._targetIdIndex = {};
                    this._background_tasks = /* @__PURE__ */ new Set();
                    const handleUnhandledRejection = (event2) => {
                      const reason = event2.reason;
                      if (reason && typeof reason === "object") {
                        const reasonStr = reason.toString();
                        if (reasonStr.includes("Method not found") || reasonStr.includes("Session not found") || reasonStr.includes("Method expired") || reasonStr.includes("Session not found")) {
                          console.debug(
                            "Ignoring expected method/session not found error:",
                            reason
                          );
                          event2.preventDefault();
                          return;
                        }
                      }
                      console.warn("Unhandled RPC promise rejection:", reason);
                    };
                    if (typeof window !== "undefined" && !window._hypha_rejection_handler_set) {
                      window.addEventListener("unhandledrejection", handleUnhandledRejection);
                      window._hypha_rejection_handler_set = true;
                    } else if (typeof process !== "undefined" && !process._hypha_rejection_handler_set) {
                      process.on("unhandledRejection", (reason, promise) => {
                        handleUnhandledRejection({ reason, promise, preventDefault: () => {
                        } });
                      });
                      process._hypha_rejection_handler_set = true;
                    }
                    if (connection) {
                      this.add_service({
                        id: "built-in",
                        type: "built-in",
                        name: `Built-in services for ${this._local_workspace}/${this._client_id}`,
                        config: {
                          require_context: true,
                          visibility: "public",
                          api_version: API_VERSION
                        },
                        ping: this._ping.bind(this),
                        get_service: this.get_local_service.bind(this),
                        message_cache: {
                          create: this._create_message.bind(this),
                          append: this._append_message.bind(this),
                          set: this._set_message.bind(this),
                          process: this._process_message.bind(this),
                          remove: this._remove_message.bind(this)
                        }
                      });
                      this.on("method", this._handle_method.bind(this));
                      this.on("error", console.error);
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(connection.emit_message && connection.on_message);
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                        connection.manager_id !== void 0,
                        "Connection must have manager_id"
                      );
                      this._emit_message = connection.emit_message.bind(connection);
                      connection.on_message(this._on_message.bind(this));
                      this._connection = connection;
                      const onConnected = async (connectionInfo) => {
                        if (!this._silent && this._connection.manager_id) {
                          console.debug("Connection established, reporting services...");
                          try {
                            const manager = await this._get_manager_with_retry();
                            const services = Object.values(this._services);
                            const servicesCount = services.length;
                            let registeredCount = 0;
                            const failedServices = [];
                            const serviceRegistrationTimeout = this._method_timeout || 3e4;
                            for (let service of services) {
                              try {
                                const serviceInfo = this._extract_service_info(service);
                                await withTimeout(
                                  manager.registerService(serviceInfo),
                                  serviceRegistrationTimeout,
                                  `Timeout registering service ${service.id || "unknown"}`
                                );
                                registeredCount++;
                                console.debug(
                                  `Successfully registered service: ${service.id || "unknown"}`
                                );
                              } catch (serviceError) {
                                failedServices.push(service.id || "unknown");
                                if (serviceError.message && serviceError.message.includes("TimeoutError")) {
                                  console.error(
                                    `Timeout registering service ${service.id || "unknown"}`
                                  );
                                } else {
                                  console.error(
                                    `Failed to register service ${service.id || "unknown"}: ${serviceError}`
                                  );
                                }
                              }
                            }
                            if (registeredCount === servicesCount) {
                              console.info(
                                `Successfully registered all ${registeredCount} services with the server`
                              );
                            } else {
                              console.warn(
                                `Only registered ${registeredCount} out of ${servicesCount} services with the server. Failed services: ${failedServices.join(", ")}`
                              );
                            }
                            this._fire("services_registered", {
                              total: servicesCount,
                              registered: registeredCount,
                              failed: failedServices
                            });
                            try {
                              if (manager.subscribe && typeof manager.subscribe === "function") {
                                console.debug("Subscribing to client_disconnected events");
                                const handleClientDisconnected = async (event2) => {
                                  const clientId = event2.data?.id || event2.client;
                                  const workspace3 = event2.data?.workspace;
                                  if (clientId && workspace3) {
                                    const fullClientId = `${workspace3}/${clientId}`;
                                    console.debug(
                                      `Client ${fullClientId} disconnected, cleaning up sessions`
                                    );
                                    await this._handleClientDisconnected(fullClientId);
                                  } else if (clientId) {
                                    console.debug(
                                      `Client ${clientId} disconnected, cleaning up sessions`
                                    );
                                    await this._handleClientDisconnected(clientId);
                                  }
                                };
                                this._clientDisconnectedSubscription = await withTimeout(
                                  manager.subscribe(["client_disconnected"]),
                                  serviceRegistrationTimeout,
                                  "Timeout subscribing to client_disconnected events"
                                );
                                this.on("client_disconnected", handleClientDisconnected);
                                console.debug(
                                  "Successfully subscribed to client_disconnected events"
                                );
                              } else {
                                console.debug(
                                  "Manager does not support subscribe method, skipping client_disconnected handling"
                                );
                                this._clientDisconnectedSubscription = null;
                              }
                            } catch (subscribeError) {
                              console.warn(
                                `Failed to subscribe to client_disconnected events: ${subscribeError}`
                              );
                              this._clientDisconnectedSubscription = null;
                            }
                          } catch (managerError) {
                            console.error(
                              `Failed to get manager service for registering services: ${managerError}`
                            );
                            this._fire("services_registration_failed", {
                              error: managerError.toString(),
                              total_services: Object.keys(this._services).length
                            });
                          }
                        } else {
                        }
                        if (connectionInfo) {
                          if (connectionInfo.public_base_url) {
                            this._server_base_url = connectionInfo.public_base_url;
                          }
                          this._fire("connected", connectionInfo);
                        }
                      };
                      connection.on_connected(onConnected);
                      onConnected();
                    } else {
                      this._emit_message = function() {
                        console.log("No connection to emit message");
                      };
                    }
                  }
                  register_codec(config2) {
                    if (!config2["name"] || !config2["encoder"] && !config2["decoder"]) {
                      throw new Error(
                        "Invalid codec format, please make sure you provide a name, type, encoder and decoder."
                      );
                    } else {
                      if (config2.type) {
                        for (let k of Object.keys(this._codecs)) {
                          if (this._codecs[k].type === config2.type || k === config2.name) {
                            delete this._codecs[k];
                            console.warn("Remove duplicated codec: " + k);
                          }
                        }
                      }
                      this._codecs[config2["name"]] = config2;
                    }
                  }
                  async _ping(msg, context2) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(msg == "ping");
                    return "pong";
                  }
                  async ping(client_id2, timeout) {
                    let method = this._generate_remote_method({
                      _rserver: this._server_base_url,
                      _rtarget: client_id2,
                      _rmethod: "services.built-in.ping",
                      _rpromise: true,
                      _rdoc: "Ping a remote client"
                    });
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(await method("ping", timeout) == "pong");
                  }
                  _create_message(key, heartbeat, overwrite, context2) {
                    if (heartbeat) {
                      if (!this._object_store[key]) {
                        throw new Error(`session does not exist anymore: ${key}`);
                      }
                      this._object_store[key]["timer"].reset();
                    }
                    if (!this._object_store["message_cache"]) {
                      this._object_store["message_cache"] = {};
                    }
                    if (!overwrite && this._object_store["message_cache"][key]) {
                      throw new Error(
                        `Message with the same key (${key}) already exists in the cache store, please use overwrite=true or remove it first.`
                      );
                    }
                    this._object_store["message_cache"][key] = [];
                  }
                  _append_message(key, data, heartbeat, context2) {
                    if (heartbeat) {
                      if (!this._object_store[key]) {
                        throw new Error(`session does not exist anymore: ${key}`);
                      }
                      this._object_store[key]["timer"].reset();
                    }
                    const cache = this._object_store["message_cache"];
                    if (!cache[key]) {
                      throw new Error(`Message with key ${key} does not exists.`);
                    }
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(data instanceof ArrayBufferView);
                    cache[key].push(data);
                  }
                  _set_message(key, index, data, heartbeat, context2) {
                    if (heartbeat) {
                      if (!this._object_store[key]) {
                        throw new Error(`session does not exist anymore: ${key}`);
                      }
                      this._object_store[key]["timer"].reset();
                    }
                    const cache = this._object_store["message_cache"];
                    if (!cache[key]) {
                      throw new Error(`Message with key ${key} does not exists.`);
                    }
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(data instanceof ArrayBufferView);
                    cache[key][index] = data;
                  }
                  _remove_message(key, context2) {
                    const cache = this._object_store["message_cache"];
                    if (!cache[key]) {
                      throw new Error(`Message with key ${key} does not exists.`);
                    }
                    delete cache[key];
                  }
                  _process_message(key, heartbeat, context2) {
                    if (heartbeat) {
                      if (!this._object_store[key]) {
                        throw new Error(`session does not exist anymore: ${key}`);
                      }
                      this._object_store[key]["timer"].reset();
                    }
                    const cache = this._object_store["message_cache"];
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(!!context2, "Context is required");
                    if (!cache[key]) {
                      throw new Error(`Message with key ${key} does not exists.`);
                    }
                    cache[key] = concatArrayBuffers(cache[key]);
                    let unpacker = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_2__.decodeMulti)(cache[key]);
                    const { done, value } = unpacker.next();
                    const main = value;
                    Object.assign(main, {
                      from: context2.from,
                      to: context2.to,
                      ws: context2.ws,
                      user: context2.user
                    });
                    main["ctx"] = JSON.parse(JSON.stringify(main));
                    Object.assign(main["ctx"], this.default_context);
                    if (!done) {
                      let extra = unpacker.next();
                      Object.assign(main, extra.value);
                    }
                    this._fire(main["type"], main);
                    delete cache[key];
                  }
                  _on_message(message) {
                    if (typeof message === "string") {
                      const main = JSON.parse(message);
                      main["ctx"] = Object.assign({}, main, this.default_context);
                      this._fire(main["type"], main);
                    } else if (message instanceof ArrayBuffer || ArrayBuffer.isView(message)) {
                      let unpacker = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_2__.decodeMulti)(message);
                      const { done, value } = unpacker.next();
                      const main = value;
                      main["ctx"] = Object.assign({}, main, this.default_context);
                      if (!done) {
                        let extra = unpacker.next();
                        Object.assign(main, extra.value);
                      }
                      this._fire(main["type"], main);
                    } else if (typeof message === "object") {
                      message["ctx"] = Object.assign({}, message, this.default_context);
                      this._fire(message["type"], message);
                    } else {
                      throw new Error("Invalid message format");
                    }
                  }
                  reset() {
                    this._event_handlers = {};
                    this._services = {};
                  }
                  close() {
                    this._cleanupOnDisconnect();
                    for (const session_id in this._object_store) {
                      if (this._object_store.hasOwnProperty(session_id)) {
                        const session = this._object_store[session_id];
                        if (session && session.heartbeat_task) {
                          clearInterval(session.heartbeat_task);
                        }
                        if (session && session.timer) {
                          session.timer.clear();
                        }
                      }
                    }
                    if (this._clientDisconnectedSubscription) {
                      this.off("client_disconnected");
                      this._clientDisconnectedSubscription = null;
                    }
                    try {
                      for (const task of this._background_tasks) {
                        if (task && typeof task.cancel === "function") {
                          try {
                            task.cancel();
                          } catch (e) {
                            console.debug(`Error canceling background task: ${e}`);
                          }
                        }
                      }
                      this._background_tasks.clear();
                    } catch (e) {
                      console.debug(`Error cleaning up background tasks: ${e}`);
                    }
                    try {
                      this._connection = null;
                      this._emit_message = function() {
                        console.debug("RPC connection closed, ignoring message");
                        return Promise.reject(new Error("Connection is closed"));
                      };
                    } catch (e) {
                      console.debug(`Error during connection cleanup: ${e}`);
                    }
                    this._fire("disconnected");
                  }
                  async _handleClientDisconnected(clientId) {
                    try {
                      console.debug(`Handling disconnection for client: ${clientId}`);
                      const sessionsCleaned = this._cleanupSessionsForClient(clientId);
                      if (sessionsCleaned > 0) {
                        console.debug(
                          `Cleaned up ${sessionsCleaned} sessions for disconnected client: ${clientId}`
                        );
                      }
                      this._fire("remote_client_disconnected", {
                        client_id: clientId,
                        sessions_cleaned: sessionsCleaned
                      });
                    } catch (e) {
                      console.error(
                        `Error handling client disconnection for ${clientId}: ${e}`
                      );
                    }
                  }
                  _removeFromTargetIdIndex(sessionId) {
                    const topKey = sessionId.split(".")[0];
                    const session = this._object_store[topKey];
                    if (session && typeof session === "object") {
                      const targetId = session.target_id;
                      if (targetId && targetId in this._targetIdIndex) {
                        this._targetIdIndex[targetId].delete(topKey);
                        if (this._targetIdIndex[targetId].size === 0) {
                          delete this._targetIdIndex[targetId];
                        }
                      }
                    }
                  }
                  _cleanupSessionsForClient(clientId) {
                    let sessionsCleaned = 0;
                    const sessionKeys = this._targetIdIndex[clientId];
                    if (!sessionKeys) return 0;
                    for (const sessionKey of sessionKeys) {
                      const session = this._object_store[sessionKey];
                      if (!session || typeof session !== "object") {
                        continue;
                      }
                      if (session.target_id !== clientId) {
                        continue;
                      }
                      if (session.reject && typeof session.reject === "function") {
                        console.debug(`Rejecting session ${sessionKey}`);
                        try {
                          session.reject(new Error(`Client disconnected: ${clientId}`));
                        } catch (e) {
                          console.warn(`Error rejecting session ${sessionKey}: ${e}`);
                        }
                      }
                      if (session.resolve && typeof session.resolve === "function") {
                        console.debug(`Resolving session ${sessionKey} with error`);
                        try {
                          session.resolve(new Error(`Client disconnected: ${clientId}`));
                        } catch (e) {
                          console.warn(`Error resolving session ${sessionKey}: ${e}`);
                        }
                      }
                      if (session.timer && typeof session.timer.clear === "function") {
                        try {
                          session.timer.clear();
                        } catch (e) {
                          console.warn(`Error clearing timer for ${sessionKey}: ${e}`);
                        }
                      }
                      if (session.heartbeat_task) {
                        try {
                          clearInterval(session.heartbeat_task);
                        } catch (e) {
                          console.warn(`Error clearing heartbeat for ${sessionKey}: ${e}`);
                        }
                      }
                      delete this._object_store[sessionKey];
                      sessionsCleaned++;
                      console.debug(`Cleaned up session: ${sessionKey}`);
                    }
                    delete this._targetIdIndex[clientId];
                    return sessionsCleaned;
                  }
                  _cleanupOnDisconnect() {
                    try {
                      console.debug("Cleaning up all sessions due to local RPC disconnection");
                      const keysToDelete = [];
                      for (const key of Object.keys(this._object_store)) {
                        if (key === "services") {
                          continue;
                        }
                        const value = this._object_store[key];
                        if (typeof value === "object" && value !== null) {
                          if (value.reject && typeof value.reject === "function") {
                            try {
                              value.reject(new Error("RPC connection closed"));
                            } catch (e) {
                              console.debug(`Error rejecting promise during cleanup: ${e}`);
                            }
                          }
                          if (value.heartbeat_task) {
                            clearInterval(value.heartbeat_task);
                          }
                          if (value.timer && typeof value.timer.clear === "function") {
                            try {
                              value.timer.clear();
                            } catch (e) {
                              console.debug(`Error clearing timer: ${e}`);
                            }
                          }
                        }
                        keysToDelete.push(key);
                      }
                      for (const key of keysToDelete) {
                        delete this._object_store[key];
                      }
                      this._targetIdIndex = {};
                    } catch (e) {
                      console.error(`Error during cleanup on disconnect: ${e}`);
                    }
                  }
                  async disconnect() {
                    const connection = this._connection;
                    this.close();
                    if (connection) {
                      try {
                        await connection.disconnect();
                      } catch (e) {
                        console.debug(`Error disconnecting underlying connection: ${e}`);
                      }
                    }
                  }
                  async _get_manager_with_retry(maxRetries = 20) {
                    const baseDelay = 500;
                    const maxDelay = 1e4;
                    let lastError = null;
                    for (let attempt = 0; attempt < maxRetries; attempt++) {
                      try {
                        const svc = await this.get_remote_service(
                          `*/${this._connection.manager_id}:default`,
                          { timeout: 20, case_conversion: "camel" }
                        );
                        return svc;
                      } catch (e) {
                        lastError = e;
                        console.warn(
                          `Failed to get manager service (attempt ${attempt + 1}/${maxRetries}): ${e.message}`
                        );
                        if (attempt < maxRetries - 1) {
                          const delay = Math.min(baseDelay * Math.pow(2, attempt), maxDelay);
                          await new Promise((resolve2) => setTimeout(resolve2, delay));
                        }
                      }
                    }
                    throw lastError;
                  }
                  async get_manager_service(config2) {
                    config2 = config2 || {};
                    const maxRetries = 20;
                    for (let attempt = 0; attempt < maxRetries; attempt++) {
                      const retryDelay = Math.min(500 * Math.pow(2, attempt), 1e4);
                      if (!this._connection.manager_id) {
                        if (attempt < maxRetries - 1) {
                          console.warn(
                            `Manager ID not set, retrying in ${retryDelay}ms (attempt ${attempt + 1}/${maxRetries})`
                          );
                          await new Promise((resolve2) => setTimeout(resolve2, retryDelay));
                          continue;
                        } else {
                          throw new Error("Manager ID not set after maximum retries");
                        }
                      }
                      try {
                        const svc = await this.get_remote_service(
                          `*/${this._connection.manager_id}:default`,
                          config2
                        );
                        return svc;
                      } catch (e) {
                        if (attempt < maxRetries - 1) {
                          console.warn(
                            `Failed to get manager service, retrying in ${retryDelay}ms: ${e.message}`
                          );
                          await new Promise((resolve2) => setTimeout(resolve2, retryDelay));
                        } else {
                          throw e;
                        }
                      }
                    }
                  }
                  get_all_local_services() {
                    return this._services;
                  }
                  get_local_service(service_id, context2) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(service_id);
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(context2, "Context is required");
                    const [ws, client_id2] = context2["to"].split("/");
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                      client_id2 === this._client_id,
                      "Services can only be accessed locally"
                    );
                    const service = this._services[service_id];
                    if (!service) {
                      throw new Error("Service not found: " + service_id);
                    }
                    if (service.config.visibility == "public" || service.config.visibility == "unlisted") {
                      return service;
                    }
                    if (context2["ws"] === ws) {
                      return service;
                    }
                    const authorized_workspaces = service.config.authorized_workspaces;
                    if (authorized_workspaces && authorized_workspaces.includes(context2["ws"])) {
                      return service;
                    }
                    throw new Error(
                      `Permission denied for getting protected service: ${service_id}, workspace mismatch: ${ws} != ${context2["ws"]}`
                    );
                  }
                  async get_remote_service(service_uri, config2) {
                    let { timeout, case_conversion, kwargs_expansion } = config2 || {};
                    timeout = timeout === void 0 ? this._method_timeout : timeout;
                    if (!service_uri && this._connection.manager_id) {
                      service_uri = "*/" + this._connection.manager_id;
                    } else if (!service_uri.includes(":")) {
                      service_uri = this._client_id + ":" + service_uri;
                    }
                    const provider = service_uri.split(":")[0];
                    let service_id = service_uri.split(":")[1];
                    if (service_id.includes("@")) {
                      service_id = service_id.split("@")[0];
                      const app_id = service_uri.split("@")[1];
                      if (this._app_id && this._app_id !== "*")
                        (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                          app_id === this._app_id,
                          `Invalid app id: ${app_id} != ${this._app_id}`
                        );
                    }
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(provider, `Invalid service uri: ${service_uri}`);
                    try {
                      const method = this._generate_remote_method({
                        _rserver: this._server_base_url,
                        _rtarget: provider,
                        _rmethod: "services.built-in.get_service",
                        _rpromise: true,
                        _rdoc: "Get a remote service"
                      });
                      let svc = await (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.waitFor)(
                        method(service_id),
                        timeout,
                        "Timeout Error: Failed to get remote service: " + service_uri
                      );
                      svc.id = `${provider}:${service_id}`;
                      if (kwargs_expansion) {
                        svc = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.expandKwargs)(svc);
                      }
                      if (case_conversion)
                        return Object.assign(
                          new RemoteService(),
                          (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.convertCase)(svc, case_conversion)
                        );
                      else return Object.assign(new RemoteService(), svc);
                    } catch (e) {
                      console.warn("Failed to get remote service: " + service_uri, e);
                      throw e;
                    }
                  }
                  _annotate_service_methods(aObject, object_id, require_context, run_in_executor, visibility, authorized_workspaces) {
                    if (typeof aObject === "function") {
                      let method_name = object_id.split(".")[1];
                      this._method_annotations.set(aObject, {
                        require_context: Array.isArray(require_context) ? require_context.includes(method_name) : !!require_context,
                        run_in_executor,
                        method_id: "services." + object_id,
                        visibility,
                        authorized_workspaces
                      });
                    } else if (aObject instanceof Array || aObject instanceof Object) {
                      for (let key of Object.keys(aObject)) {
                        let val = aObject[key];
                        if (typeof val === "function" && val.__rpc_object__) {
                          let client_id2 = val.__rpc_object__._rtarget;
                          if (client_id2.includes("/")) {
                            client_id2 = client_id2.split("/")[1];
                          }
                          if (this._client_id === client_id2) {
                            if (aObject instanceof Array) {
                              aObject = aObject.slice();
                            }
                            aObject[key] = indexObject(
                              this._object_store,
                              val.__rpc_object__._rmethod
                            );
                            val = aObject[key];
                          } else {
                            throw new Error(
                              `Local method not found: ${val.__rpc_object__._rmethod}, client id mismatch ${this._client_id} != ${client_id2}`
                            );
                          }
                        }
                        this._annotate_service_methods(
                          val,
                          object_id + "." + key,
                          require_context,
                          run_in_executor,
                          visibility,
                          authorized_workspaces
                        );
                      }
                    }
                  }
                  add_service(api, overwrite) {
                    if (!api || Array.isArray(api)) throw new Error("Invalid service object");
                    if (api.constructor === Object) {
                      api = Object.assign({}, api);
                    } else {
                      const normApi = {};
                      const props = Object.getOwnPropertyNames(api).concat(
                        Object.getOwnPropertyNames(Object.getPrototypeOf(api))
                      );
                      for (let k of props) {
                        if (k !== "constructor") {
                          if (typeof api[k] === "function") normApi[k] = api[k].bind(api);
                          else normApi[k] = api[k];
                        }
                      }
                      api.id = api.id || "default";
                      api = normApi;
                    }
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                      api.id && typeof api.id === "string",
                      `Service id not found: ${api}`
                    );
                    if (!api.name) {
                      api.name = api.id;
                    }
                    if (!api.config) {
                      api.config = {};
                    }
                    if (!api.type) {
                      api.type = "generic";
                    }
                    let require_context = false, run_in_executor = false;
                    if (api.config.require_context)
                      require_context = api.config.require_context;
                    if (api.config.run_in_executor) run_in_executor = true;
                    const visibility = api.config.visibility || "protected";
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(["protected", "public", "unlisted"].includes(visibility));
                    const authorized_workspaces = api.config.authorized_workspaces;
                    if (authorized_workspaces !== void 0) {
                      if (visibility !== "protected") {
                        throw new Error(
                          `authorized_workspaces can only be set when visibility is 'protected', got visibility='${visibility}'`
                        );
                      }
                      if (!Array.isArray(authorized_workspaces)) {
                        throw new Error(
                          "authorized_workspaces must be an array of workspace ids"
                        );
                      }
                      for (const ws_id of authorized_workspaces) {
                        if (typeof ws_id !== "string") {
                          throw new Error(
                            `Each workspace id in authorized_workspaces must be a string, got ${typeof ws_id}`
                          );
                        }
                      }
                    }
                    this._annotate_service_methods(
                      api,
                      api["id"],
                      require_context,
                      run_in_executor,
                      visibility,
                      authorized_workspaces
                    );
                    if (this._services[api.id]) {
                      if (overwrite) {
                        delete this._services[api.id];
                      } else {
                        throw new Error(
                          `Service already exists: ${api.id}, please specify a different id (not ${api.id}) or overwrite=true`
                        );
                      }
                    }
                    this._services[api.id] = api;
                    return api;
                  }
                  _extract_service_info(service) {
                    const config2 = service.config || {};
                    config2.workspace = config2.workspace || this._local_workspace || this._connection.workspace;
                    if (!config2.workspace) {
                      throw new Error(
                        "Workspace is not set. Please ensure the connection has a workspace or set local_workspace."
                      );
                    }
                    const skipContext = config2.require_context;
                    const excludeKeys = [
                      "id",
                      "config",
                      "name",
                      "description",
                      "type",
                      "docs",
                      "app_id",
                      "service_schema"
                    ];
                    const filteredService = {};
                    for (const key of Object.keys(service)) {
                      if (!excludeKeys.includes(key)) {
                        filteredService[key] = service[key];
                      }
                    }
                    const serviceSchema = _get_schema(filteredService, null, skipContext);
                    const serviceInfo = {
                      config: config2,
                      id: `${config2.workspace}/${this._client_id}:${service["id"]}`,
                      name: service.name || service["id"],
                      description: service.description || "",
                      type: service.type || "generic",
                      docs: service.docs || null,
                      app_id: this._app_id,
                      service_schema: serviceSchema
                    };
                    return serviceInfo;
                  }
                  async get_service_schema(service) {
                    const skipContext = service.config.require_context;
                    return _get_schema(service, null, skipContext);
                  }
                  async register_service(api, config2) {
                    let { check_type, notify, overwrite } = config2 || {};
                    notify = notify === void 0 ? true : notify;
                    let manager;
                    if (check_type && api.type) {
                      try {
                        manager = await this.get_manager_service({
                          timeout: 10,
                          case_conversion: "camel"
                        });
                        const type_info = await manager.get_service_type(api.type);
                        api = _annotate_service(api, type_info);
                      } catch (e) {
                        throw new Error(`Failed to get service type ${api.type}, error: ${e}`);
                      }
                    }
                    const service = this.add_service(api, overwrite);
                    const serviceInfo = this._extract_service_info(service);
                    if (notify) {
                      try {
                        manager = manager || await this.get_manager_service({
                          timeout: 10,
                          case_conversion: "camel"
                        });
                        await manager.registerService(serviceInfo);
                      } catch (e) {
                        throw new Error(`Failed to notify workspace manager: ${e}`);
                      }
                    }
                    return serviceInfo;
                  }
                  async unregister_service(service, notify) {
                    notify = notify === void 0 ? true : notify;
                    let service_id;
                    if (typeof service === "string") {
                      service_id = service;
                    } else {
                      service_id = service.id;
                    }
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                      service_id && typeof service_id === "string",
                      `Invalid service id: ${service_id}`
                    );
                    if (service_id.includes(":")) {
                      service_id = service_id.split(":")[1];
                    }
                    if (service_id.includes("@")) {
                      service_id = service_id.split("@")[0];
                    }
                    if (!this._services[service_id]) {
                      throw new Error(`Service not found: ${service_id}`);
                    }
                    if (notify) {
                      const manager = await this.get_manager_service({
                        timeout: 10,
                        case_conversion: "camel"
                      });
                      await manager.unregisterService(service_id);
                    }
                    delete this._services[service_id];
                  }
                  _ndarray(typedArray, shape, dtype) {
                    const _dtype = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.typedArrayToDtype)(typedArray);
                    if (dtype && dtype !== _dtype) {
                      throw "dtype doesn't match the type of the array: " + _dtype + " != " + dtype;
                    }
                    shape = shape || [typedArray.length];
                    return {
                      _rtype: "ndarray",
                      _rvalue: typedArray.buffer,
                      _rshape: shape,
                      _rdtype: _dtype
                    };
                  }
                  _encode_callback(name2, callback, session_id, clear_after_called, timer, local_workspace, description) {
                    let method_id = `${session_id}.${name2}`;
                    let encoded = {
                      _rtype: "method",
                      _rtarget: local_workspace ? `${local_workspace}/${this._client_id}` : this._client_id,
                      _rmethod: method_id,
                      _rpromise: false
                    };
                    const self2 = this;
                    let wrapped_callback = function() {
                      try {
                        callback.apply(null, Array.prototype.slice.call(arguments));
                      } catch (error) {
                        console.error(
                          `Error in callback(${method_id}, ${description}): ${error}`
                        );
                      } finally {
                        if (timer && timer.started) {
                          timer.clear();
                        }
                        if (clear_after_called && self2._object_store[session_id]) {
                          if (name2 === "resolve" || name2 === "reject") {
                            self2._removeFromTargetIdIndex(session_id);
                            delete self2._object_store[session_id];
                          } else {
                            self2._cleanup_session_if_needed(session_id, name2);
                          }
                        }
                      }
                    };
                    wrapped_callback.__name__ = `callback(${method_id})`;
                    return [encoded, wrapped_callback];
                  }
                  _cleanup_session_if_needed(session_id, callback_name) {
                    if (!session_id) {
                      console.debug("Cannot cleanup session: session_id is empty");
                      return;
                    }
                    try {
                      const store = this._get_session_store(session_id, false);
                      if (!store) {
                        console.debug(`Session ${session_id} not found for cleanup`);
                        return;
                      }
                      let should_cleanup = false;
                      if (store._promise_manager) {
                        try {
                          const promise_manager = store._promise_manager;
                          if (promise_manager.should_cleanup_on_callback && promise_manager.should_cleanup_on_callback(callback_name)) {
                            if (promise_manager.settle) {
                              promise_manager.settle();
                            }
                            should_cleanup = true;
                            console.debug(
                              `Promise session ${session_id} settled and marked for cleanup`
                            );
                          }
                        } catch (e) {
                          console.warn(
                            `Error in promise manager cleanup for session ${session_id}:`,
                            e
                          );
                        }
                      } else {
                        if ((callback_name === "resolve" || callback_name === "reject") && store._callbacks && Object.keys(store._callbacks).includes(callback_name)) {
                          should_cleanup = true;
                          console.debug(
                            `Regular session ${session_id} marked for cleanup after ${callback_name}`
                          );
                        }
                      }
                      if (should_cleanup) {
                        this._cleanup_session_completely(session_id);
                      }
                    } catch (error) {
                      console.warn(`Error during session cleanup for ${session_id}:`, error);
                    }
                  }
                  _cleanup_session_completely(session_id) {
                    try {
                      this._removeFromTargetIdIndex(session_id);
                      const store = this._get_session_store(session_id, false);
                      if (!store) {
                        console.debug(`Session ${session_id} already cleaned up`);
                        return;
                      }
                      if (store.timer && typeof store.timer.clear === "function") {
                        try {
                          store.timer.clear();
                        } catch (error) {
                          console.warn(
                            `Error clearing timer for session ${session_id}:`,
                            error
                          );
                        }
                      }
                      if (store.heartbeat_task && typeof store.heartbeat_task.cancel === "function") {
                        try {
                          store.heartbeat_task.cancel();
                        } catch (error) {
                          console.warn(
                            `Error canceling heartbeat for session ${session_id}:`,
                            error
                          );
                        }
                      }
                      const levels = session_id.split(".");
                      let current_store = this._object_store;
                      for (let i = 0; i < levels.length - 1; i++) {
                        const level = levels[i];
                        if (!current_store[level]) {
                          console.debug(
                            `Session path ${session_id} not found at level ${level}`
                          );
                          return;
                        }
                        current_store = current_store[level];
                      }
                      const final_key = levels[levels.length - 1];
                      if (current_store[final_key]) {
                        delete current_store[final_key];
                        console.debug(`Cleaned up session ${session_id}`);
                        this._cleanup_empty_containers(levels.slice(0, -1));
                      }
                    } catch (error) {
                      console.warn(
                        `Error in complete session cleanup for ${session_id}:`,
                        error
                      );
                    }
                  }
                  _cleanup_empty_containers(path_levels) {
                    try {
                      for (let depth = path_levels.length - 1; depth >= 0; depth--) {
                        let current_store = this._object_store;
                        for (let i = 0; i < depth; i++) {
                          current_store = current_store[path_levels[i]];
                          if (!current_store) return;
                        }
                        const container_key = path_levels[depth];
                        const container = current_store[container_key];
                        if (container && typeof container === "object" && Object.keys(container).length === 0) {
                          delete current_store[container_key];
                          console.debug(
                            `Cleaned up empty container at depth ${depth}: ${path_levels.slice(0, depth + 1).join(".")}`
                          );
                        } else {
                          break;
                        }
                      }
                    } catch (error) {
                      console.warn("Error cleaning up empty containers:", error);
                    }
                  }
                  get_session_stats() {
                    const stats = {
                      total_sessions: 0,
                      promise_sessions: 0,
                      regular_sessions: 0,
                      sessions_with_timers: 0,
                      sessions_with_heartbeat: 0,
                      system_stores: {},
                      session_ids: [],
                      memory_usage: 0
                    };
                    if (!this._object_store) {
                      return stats;
                    }
                    for (const key in this._object_store) {
                      const value = this._object_store[key];
                      if (["services", "message_cache"].includes(key)) {
                        stats.system_stores[key] = {
                          size: typeof value === "object" && value ? Object.keys(value).length : 0
                        };
                        continue;
                      }
                      if (value && typeof value === "object") {
                        const sessionKeys = Object.keys(value);
                        if (sessionKeys.length > 0) {
                          stats.total_sessions++;
                          stats.session_ids.push(key);
                          if (value._promise_manager) {
                            stats.promise_sessions++;
                          } else {
                            stats.regular_sessions++;
                          }
                          if (value._timer || value.timer) stats.sessions_with_timers++;
                          if (value._heartbeat || value.heartbeat)
                            stats.sessions_with_heartbeat++;
                          stats.memory_usage += JSON.stringify(value).length;
                        }
                      }
                    }
                    return stats;
                  }
                  _force_cleanup_all_sessions() {
                    if (!this._object_store) {
                      console.debug("Force cleaning up 0 sessions");
                      return;
                    }
                    let cleaned_count = 0;
                    const keys_to_delete = [];
                    for (const key in this._object_store) {
                      if (!["services", "message_cache"].includes(key)) {
                        const value = this._object_store[key];
                        if (value && typeof value === "object" && Object.keys(value).length > 0) {
                          keys_to_delete.push(key);
                          cleaned_count++;
                        }
                      }
                    }
                    for (const key of keys_to_delete) {
                      delete this._object_store[key];
                    }
                    this._targetIdIndex = {};
                    console.debug(`Force cleaning up ${cleaned_count} sessions`);
                  }
                  // Clean helper to identify promise method calls by session type
                  _is_promise_method_call(method_path) {
                    const session_id = method_path.split(".")[0];
                    const session = this._get_session_store(session_id, false);
                    return session && session._promise_manager;
                  }
                  // Simplified Promise Manager - enhanced version
                  _create_promise_manager() {
                    return {
                      should_cleanup_on_callback: (callback_name) => {
                        return ["resolve", "reject"].includes(callback_name);
                      },
                      settle: () => {
                        console.debug("Promise settled");
                      }
                    };
                  }
                  async _encode_promise(resolve2, reject2, session_id, clear_after_called, timer, local_workspace, description) {
                    let store = this._get_session_store(session_id, true);
                    if (!store) {
                      console.warn(
                        `Failed to create session store ${session_id}, session management may be impaired`
                      );
                      store = {};
                    }
                    store._promise_manager = this._create_promise_manager();
                    let encoded = {};
                    if (timer && reject2 && this._method_timeout) {
                      [encoded.heartbeat, store.heartbeat] = this._encode_callback(
                        "heartbeat",
                        timer.reset.bind(timer),
                        session_id,
                        false,
                        null,
                        local_workspace
                      );
                      store.timer = timer;
                      encoded.interval = this._method_timeout / 2;
                    } else {
                      timer = null;
                    }
                    [encoded.resolve, store.resolve] = this._encode_callback(
                      "resolve",
                      resolve2,
                      session_id,
                      clear_after_called,
                      timer,
                      local_workspace,
                      `resolve (${description})`
                    );
                    [encoded.reject, store.reject] = this._encode_callback(
                      "reject",
                      reject2,
                      session_id,
                      clear_after_called,
                      timer,
                      local_workspace,
                      `reject (${description})`
                    );
                    return encoded;
                  }
                  async _send_chunks(data, target_id, session_id) {
                    const remote_services = await this.get_remote_service(
                      `${target_id}:built-in`
                    );
                    if (!remote_services.message_cache) {
                      throw new Error(
                        "Remote client does not support message caching for large messages."
                      );
                    }
                    const message_cache = remote_services.message_cache;
                    const message_id = session_id || (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.randId)();
                    const total_size = data.length;
                    const start_time = Date.now();
                    const chunk_num = Math.ceil(total_size / this._long_message_chunk_size);
                    if (remote_services.config.api_version >= 3) {
                      await message_cache.create(message_id, !!session_id);
                      const semaphore = new _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.Semaphore(CONCURRENCY_LIMIT);
                      const tasks = [];
                      for (let idx = 0; idx < chunk_num; idx++) {
                        const startByte = idx * this._long_message_chunk_size;
                        const chunk = data.slice(
                          startByte,
                          startByte + this._long_message_chunk_size
                        );
                        const taskFn = async () => {
                          await message_cache.set(message_id, idx, chunk, !!session_id);
                        };
                        tasks.push(semaphore.run(taskFn));
                      }
                      try {
                        await Promise.all(tasks);
                      } catch (error) {
                        try {
                          await message_cache.remove(message_id);
                        } catch (cleanupError) {
                          console.error(
                            `Failed to clean up message cache after error: ${cleanupError}`
                          );
                        }
                        throw error;
                      }
                    } else {
                      await message_cache.create(message_id, !!session_id);
                      for (let idx = 0; idx < chunk_num; idx++) {
                        const startByte = idx * this._long_message_chunk_size;
                        const chunk = data.slice(
                          startByte,
                          startByte + this._long_message_chunk_size
                        );
                        await message_cache.append(message_id, chunk, !!session_id);
                      }
                    }
                    await message_cache.process(message_id, !!session_id);
                    const durationSec = ((Date.now() - start_time) / 1e3).toFixed(2);
                  }
                  emit(main_message, extra_data) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                      typeof main_message === "object" && main_message.type,
                      "Invalid message, must be an object with a `type` fields."
                    );
                    if (!main_message.to) {
                      this._fire(main_message.type, main_message);
                      return;
                    }
                    let message_package = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__.encode)(main_message);
                    if (extra_data) {
                      const extra = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__.encode)(extra_data);
                      const combined = new Uint8Array(message_package.length + extra.length);
                      combined.set(message_package);
                      combined.set(extra, message_package.length);
                      message_package = combined;
                    }
                    const total_size = message_package.length;
                    if (total_size > this._long_message_chunk_size + 1024) {
                      console.warn(`Sending large message (size=${total_size})`);
                    }
                    return this._emit_message(message_package);
                  }
                  _generate_remote_method(encoded_method, remote_parent, local_parent, remote_workspace, local_workspace) {
                    let target_id = encoded_method._rtarget;
                    if (remote_workspace && !target_id.includes("/")) {
                      if (!target_id.startsWith("*/")) {
                        if (remote_workspace !== target_id) {
                          target_id = remote_workspace + "/" + target_id;
                        }
                        encoded_method._rtarget = target_id;
                      }
                    }
                    let method_id = encoded_method._rmethod;
                    let with_promise = encoded_method._rpromise || false;
                    const description = `method: ${method_id}, docs: ${encoded_method._rdoc}`;
                    const self2 = this;
                    function remote_method() {
                      return new Promise(async (resolve2, reject2) => {
                        try {
                          let local_session_id = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.randId)();
                          if (local_parent) {
                            local_session_id = local_parent + "." + local_session_id;
                          }
                          let store = self2._get_session_store(local_session_id, true);
                          if (!store) {
                            reject2(
                              new Error(
                                `Runtime Error: Failed to get session store ${local_session_id} (context: ${description})`
                              )
                            );
                            return;
                          }
                          store["target_id"] = target_id;
                          const topKey = local_session_id.split(".")[0];
                          if (!(target_id in self2._targetIdIndex)) {
                            self2._targetIdIndex[target_id] = /* @__PURE__ */ new Set();
                          }
                          self2._targetIdIndex[target_id].add(topKey);
                          const args = await self2._encode(
                            Array.prototype.slice.call(arguments),
                            local_session_id,
                            local_workspace
                          );
                          const argLength = args.length;
                          const withKwargs = argLength > 0 && typeof args[argLength - 1] === "object" && args[argLength - 1] !== null && args[argLength - 1]._rkwargs;
                          if (withKwargs) delete args[argLength - 1]._rkwargs;
                          let from_client;
                          if (!self2._local_workspace) {
                            from_client = self2._client_id;
                          } else {
                            from_client = self2._local_workspace + "/" + self2._client_id;
                          }
                          let main_message = {
                            type: "method",
                            from: from_client,
                            to: target_id,
                            method: method_id
                          };
                          let extra_data = {};
                          if (args) {
                            extra_data["args"] = args;
                          }
                          if (withKwargs) {
                            extra_data["with_kwargs"] = withKwargs;
                          }
                          if (remote_parent) {
                            main_message["parent"] = remote_parent;
                          }
                          let timer = null;
                          if (with_promise) {
                            let hasInterfaceObject = function(obj) {
                              if (!obj || typeof obj !== "object") return false;
                              if (obj._rintf === true) return true;
                              if (Array.isArray(obj)) {
                                return obj.some((item) => hasInterfaceObject(item));
                              }
                              if (obj.constructor === Object) {
                                return Object.values(obj).some(
                                  (value) => hasInterfaceObject(value)
                                );
                              }
                              return false;
                            };
                            main_message["session"] = local_session_id;
                            let method_name = `${target_id}:${method_id}`;
                            const timeoutCallback = function(error_msg) {
                              reject2(error_msg);
                              if (self2._object_store[local_session_id]) {
                                self2._removeFromTargetIdIndex(local_session_id);
                                delete self2._object_store[local_session_id];
                                console.debug(
                                  `Cleaned up session ${local_session_id} after timeout`
                                );
                              }
                            };
                            timer = new Timer(
                              self2._method_timeout,
                              timeoutCallback,
                              [`Method call timed out: ${method_name}, context: ${description}`],
                              method_name
                            );
                            let clear_after_called = !hasInterfaceObject(args);
                            const promiseData = await self2._encode_promise(
                              resolve2,
                              reject2,
                              local_session_id,
                              clear_after_called,
                              timer,
                              local_workspace,
                              description
                            );
                            if (with_promise === true) {
                              extra_data["promise"] = promiseData;
                            } else if (with_promise === "*") {
                              extra_data["promise"] = "*";
                              extra_data["t"] = self2._method_timeout / 2;
                            } else {
                              throw new Error(`Unsupported promise type: ${with_promise}`);
                            }
                          }
                          let message_package = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__.encode)(main_message);
                          if (extra_data) {
                            const extra = (0, _msgpack_msgpack__WEBPACK_IMPORTED_MODULE_3__.encode)(extra_data);
                            const combined = new Uint8Array(message_package.length + extra.length);
                            combined.set(message_package);
                            combined.set(extra, message_package.length);
                            message_package = combined;
                          }
                          const total_size = message_package.length;
                          if (total_size <= self2._long_message_chunk_size + 1024 || remote_method.__no_chunk__) {
                            self2._emit_message(message_package).then(function() {
                              if (timer) {
                                timer.start();
                              }
                            }).catch(function(err) {
                              const error_msg = `Failed to send the request when calling method (${target_id}:${method_id}), error: ${err}`;
                              if (reject2) {
                                reject2(new Error(error_msg));
                              } else {
                                console.warn("Unhandled RPC method call error:", error_msg);
                              }
                              if (timer) {
                                timer.clear();
                              }
                            });
                          } else {
                            self2._send_chunks(message_package, target_id, remote_parent).then(function() {
                              if (timer) {
                                timer.start();
                              }
                            }).catch(function(err) {
                              const error_msg = `Failed to send the request when calling method (${target_id}:${method_id}), error: ${err}`;
                              if (reject2) {
                                reject2(new Error(error_msg));
                              } else {
                                console.warn("Unhandled RPC method call error:", error_msg);
                              }
                              if (timer) {
                                timer.clear();
                              }
                            });
                          }
                        } catch (err) {
                          reject2(err);
                        }
                      });
                    }
                    remote_method.__rpc_object__ = encoded_method;
                    const parts = method_id.split(".");
                    remote_method.__name__ = encoded_method._rname || parts[parts.length - 1];
                    if (remote_method.__name__.includes("#")) {
                      remote_method.__name__ = remote_method.__name__.split("#")[1];
                    }
                    remote_method.__doc__ = encoded_method._rdoc || `Remote method: ${method_id}`;
                    remote_method.__schema__ = encoded_method._rschema;
                    remote_method.__no_chunk__ = encoded_method._rmethod === "services.built-in.message_cache.append";
                    return remote_method;
                  }
                  get_client_info() {
                    const services = [];
                    for (let service of Object.values(this._services)) {
                      services.push(this._extract_service_info(service));
                    }
                    return {
                      id: this._client_id,
                      services
                    };
                  }
                  async _handle_method(data) {
                    let resolve2 = null;
                    let reject2 = null;
                    let heartbeat_task = null;
                    try {
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(data.method && data.ctx && data.from);
                      const method_name = data.from + ":" + data.method;
                      const remote_workspace = data.from.split("/")[0];
                      const remote_client_id = data.from.split("/")[1];
                      data["to"] = data["to"].includes("/") ? data["to"] : remote_workspace + "/" + data["to"];
                      data["ctx"]["to"] = data["to"];
                      let local_workspace;
                      if (!this._local_workspace) {
                        local_workspace = data["to"].split("/")[0];
                      } else {
                        if (this._local_workspace && this._local_workspace !== "*") {
                          (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                            data["to"].split("/")[0] === this._local_workspace,
                            "Workspace mismatch: " + data["to"].split("/")[0] + " != " + this._local_workspace
                          );
                        }
                        local_workspace = this._local_workspace;
                      }
                      const local_parent = data.parent;
                      if (data.promise) {
                        const promise = await this._decode(
                          data.promise === "*" ? this._expand_promise(data) : data.promise,
                          data.session,
                          local_parent,
                          remote_workspace,
                          local_workspace
                        );
                        resolve2 = promise.resolve;
                        reject2 = promise.reject;
                        if (promise.heartbeat && promise.interval) {
                          async function heartbeat() {
                            try {
                              await promise.heartbeat();
                            } catch (err) {
                              console.error(err);
                            }
                          }
                          heartbeat_task = setInterval(heartbeat, promise.interval * 1e3);
                          if (data.session) {
                            const session_store = this._get_session_store(data.session, false);
                            if (session_store) {
                              session_store.heartbeat_task = heartbeat_task;
                            }
                          }
                        }
                      }
                      let method;
                      try {
                        method = indexObject(this._object_store, data["method"]);
                      } catch (e) {
                        if (this._is_promise_method_call(data["method"])) {
                          console.debug(
                            `Promise method ${data["method"]} not available (detected by session type), ignoring: ${method_name}`
                          );
                          return;
                        }
                        const method_parts = data["method"].split(".");
                        if (method_parts.length > 1) {
                          const session_id = method_parts[0];
                          if (session_id in this._object_store) {
                            console.debug(
                              `Session ${session_id} exists but method ${data["method"]} not found, likely expired callback: ${method_name}`
                            );
                            if (typeof reject2 === "function") {
                              reject2(new Error(`Method expired or not found: ${method_name}`));
                            }
                            return;
                          } else {
                            console.debug(
                              `Session ${session_id} not found for method ${data["method"]}, likely cleaned up: ${method_name}`
                            );
                            if (typeof reject2 === "function") {
                              reject2(new Error(`Session not found: ${method_name}`));
                            }
                            return;
                          }
                        }
                        console.debug(
                          `Failed to find method ${method_name} at ${this._client_id}`
                        );
                        const error = new Error(
                          `Method not found: ${method_name} at ${this._client_id}`
                        );
                        if (typeof reject2 === "function") {
                          reject2(error);
                        } else {
                          console.warn(
                            "Method not found and no reject callback:",
                            error.message
                          );
                        }
                        return;
                      }
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                        method && typeof method === "function",
                        "Invalid method: " + method_name
                      );
                      if (this._method_annotations.has(method)) {
                        if (this._method_annotations.get(method).visibility === "protected") {
                          if (local_workspace === remote_workspace) {
                          } else if (this._method_annotations.get(method).authorized_workspaces && this._method_annotations.get(method).authorized_workspaces.includes(remote_workspace)) {
                          } else if (remote_workspace === "*" && remote_client_id === this._connection.manager_id) {
                          } else {
                            throw new Error(
                              "Permission denied for invoking protected method " + method_name + ", workspace mismatch: " + local_workspace + " != " + remote_workspace
                            );
                          }
                        }
                      } else {
                        let session_target_id = this._object_store[data.method.split(".")[0]].target_id;
                        if (local_workspace === remote_workspace && session_target_id && session_target_id.indexOf("/") === -1) {
                          session_target_id = local_workspace + "/" + session_target_id;
                        }
                        if (session_target_id !== data.from) {
                          throw new Error(
                            "Access denied for method call (" + method_name + ") from " + data.from + " to target " + session_target_id
                          );
                        }
                      }
                      if (local_parent) {
                        (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                          this._get_session_store(local_parent, true) !== null,
                          "Parent session was closed: " + local_parent
                        );
                      }
                      let args;
                      if (data.args) {
                        args = await this._decode(
                          data.args,
                          data.session,
                          null,
                          remote_workspace,
                          null
                        );
                      } else {
                        args = [];
                      }
                      if (this._method_annotations.has(method) && this._method_annotations.get(method).require_context) {
                        if (args.length + 1 < method.length) {
                          for (let i = args.length; i < method.length - 1; i++) {
                            args.push(void 0);
                          }
                        }
                        args.push(data.ctx);
                      }
                      if (data.promise) {
                        const result = method.apply(null, args);
                        if (result instanceof Promise) {
                          result.then((result2) => {
                            resolve2(result2);
                            clearInterval(heartbeat_task);
                          }).catch((err) => {
                            reject2(err);
                            clearInterval(heartbeat_task);
                          });
                        } else {
                          resolve2(result);
                          clearInterval(heartbeat_task);
                        }
                      } else {
                        method.apply(null, args);
                        clearInterval(heartbeat_task);
                      }
                    } catch (err) {
                      if (reject2) {
                        reject2(err);
                      } else {
                        console.error("Error during calling method: ", err);
                      }
                      clearInterval(heartbeat_task);
                    }
                  }
                  encode(aObject, session_id) {
                    return this._encode(aObject, session_id);
                  }
                  _get_session_store(session_id, create) {
                    if (!session_id) {
                      return null;
                    }
                    let store = this._object_store;
                    const levels = session_id.split(".");
                    if (create) {
                      const last_index = levels.length - 1;
                      for (let level of levels.slice(0, last_index)) {
                        if (!store[level]) {
                          store[level] = {};
                        }
                        store = store[level];
                      }
                      if (!store[levels[last_index]]) {
                        store[levels[last_index]] = {};
                      }
                      return store[levels[last_index]];
                    } else {
                      for (let level of levels) {
                        if (!store[level]) {
                          return null;
                        }
                        store = store[level];
                      }
                      return store;
                    }
                  }
                  /**
                   * Prepares the provided set of remote method arguments for
                   * sending to the remote site, replaces all the callbacks with
                   * identifiers
                   *
                   * @param {Array} args to wrap
                   *
                   * @returns {Array} wrapped arguments
                   */
                  async _encode(aObject, session_id, local_workspace) {
                    const aType = typeof aObject;
                    if (aType === "number" || aType === "string" || aType === "boolean" || aObject === null || aObject === void 0 || aObject instanceof Uint8Array) {
                      return aObject;
                    }
                    if (aObject instanceof ArrayBuffer) {
                      return {
                        _rtype: "memoryview",
                        _rvalue: new Uint8Array(aObject)
                      };
                    }
                    if (aObject.__rpc_object__) {
                      const _server = aObject.__rpc_object__._rserver || this._server_base_url;
                      if (_server === this._server_base_url) {
                        return aObject.__rpc_object__;
                      }
                    }
                    let bObject;
                    if (aObject.constructor instanceof Object && aObject._rtype) {
                      const temp = aObject._rtype;
                      delete aObject._rtype;
                      bObject = await this._encode(aObject, session_id, local_workspace);
                      bObject._rtype = temp;
                      return bObject;
                    }
                    if ((0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.isGenerator)(aObject) || (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.isAsyncGenerator)(aObject)) {
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                        session_id && typeof session_id === "string",
                        "Session ID is required for generator encoding"
                      );
                      const object_id = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.randId)();
                      const store = this._get_session_store(session_id, true);
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                        store !== null,
                        `Failed to create session store ${session_id} due to invalid parent`
                      );
                      const isAsync = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.isAsyncGenerator)(aObject);
                      const nextItemMethod = async () => {
                        if (isAsync) {
                          const iterator = aObject;
                          const result = await iterator.next();
                          if (result.done) {
                            delete store[object_id];
                            return { _rtype: "stop_iteration" };
                          }
                          return result.value;
                        } else {
                          const iterator = aObject;
                          const result = iterator.next();
                          if (result.done) {
                            delete store[object_id];
                            return { _rtype: "stop_iteration" };
                          }
                          return result.value;
                        }
                      };
                      store[object_id] = nextItemMethod;
                      bObject = {
                        _rtype: "generator",
                        _rserver: this._server_base_url,
                        _rtarget: this._client_id,
                        _rmethod: `${session_id}.${object_id}`,
                        _rpromise: "*",
                        _rdoc: "Remote generator"
                      };
                      return bObject;
                    } else if (typeof aObject === "function") {
                      if (this._method_annotations.has(aObject)) {
                        let annotation = this._method_annotations.get(aObject);
                        bObject = {
                          _rtype: "method",
                          _rserver: this._server_base_url,
                          _rtarget: this._client_id,
                          _rmethod: annotation.method_id,
                          _rpromise: "*",
                          _rname: aObject.name
                        };
                      } else {
                        (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(typeof session_id === "string");
                        let object_id;
                        if (aObject.__name__) {
                          object_id = `${(0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.randId)()}#${aObject.__name__}`;
                        } else {
                          object_id = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.randId)();
                        }
                        bObject = {
                          _rtype: "method",
                          _rserver: this._server_base_url,
                          _rtarget: this._client_id,
                          _rmethod: `${session_id}.${object_id}`,
                          _rpromise: "*",
                          _rname: aObject.name
                        };
                        let store = this._get_session_store(session_id, true);
                        (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                          store !== null,
                          `Failed to create session store ${session_id} due to invalid parent`
                        );
                        store[object_id] = aObject;
                      }
                      bObject._rdoc = aObject.__doc__;
                      if (!bObject._rdoc) {
                        try {
                          const funcInfo = getFunctionInfo(aObject);
                          if (funcInfo && !bObject._rdoc) {
                            bObject._rdoc = `${funcInfo.doc}`;
                          }
                        } catch (e) {
                          console.error("Failed to extract function docstring:", aObject);
                        }
                      }
                      bObject._rschema = aObject.__schema__;
                      return bObject;
                    }
                    const isarray = Array.isArray(aObject);
                    for (let tp of Object.keys(this._codecs)) {
                      const codec = this._codecs[tp];
                      if (codec.encoder && aObject instanceof codec.type) {
                        let encodedObj = await Promise.resolve(codec.encoder(aObject));
                        if (encodedObj && !encodedObj._rtype) encodedObj._rtype = codec.name;
                        if (typeof encodedObj === "object") {
                          const temp = encodedObj._rtype;
                          delete encodedObj._rtype;
                          encodedObj = await this._encode(
                            encodedObj,
                            session_id,
                            local_workspace
                          );
                          encodedObj._rtype = temp;
                        }
                        bObject = encodedObj;
                        return bObject;
                      }
                    }
                    if (
                      /*global tf*/
                      typeof tf !== "undefined" && tf.Tensor && aObject instanceof tf.Tensor
                    ) {
                      const v_buffer = aObject.dataSync();
                      bObject = {
                        _rtype: "ndarray",
                        _rvalue: new Uint8Array(v_buffer.buffer),
                        _rshape: aObject.shape,
                        _rdtype: aObject.dtype
                      };
                    } else if (
                      /*global nj*/
                      typeof nj !== "undefined" && nj.NdArray && aObject instanceof nj.NdArray
                    ) {
                      if (!aObject.selection || !aObject.selection.data) {
                        throw new Error("Invalid NumJS array: missing selection or data");
                      }
                      const dtype = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.typedArrayToDtype)(aObject.selection.data);
                      bObject = {
                        _rtype: "ndarray",
                        _rvalue: new Uint8Array(aObject.selection.data.buffer),
                        _rshape: aObject.shape,
                        _rdtype: dtype
                      };
                    } else if (aObject instanceof Error) {
                      console.error(aObject);
                      bObject = {
                        _rtype: "error",
                        _rvalue: aObject.toString(),
                        _rtrace: aObject.stack
                      };
                    } else if (aObject !== Object(aObject) || aObject instanceof Boolean || aObject instanceof String || aObject instanceof Date || aObject instanceof RegExp || typeof ImageData !== "undefined" && aObject instanceof ImageData || typeof FileList !== "undefined" && aObject instanceof FileList || typeof FileSystemDirectoryHandle !== "undefined" && aObject instanceof FileSystemDirectoryHandle || typeof FileSystemFileHandle !== "undefined" && aObject instanceof FileSystemFileHandle || typeof FileSystemHandle !== "undefined" && aObject instanceof FileSystemHandle || typeof FileSystemWritableFileStream !== "undefined" && aObject instanceof FileSystemWritableFileStream) {
                      bObject = aObject;
                    } else if (aObject instanceof Blob) {
                      let seek = function(pos) {
                        _current_pos = pos;
                      };
                      let _current_pos = 0;
                      async function read(length) {
                        let blob;
                        if (length) {
                          blob = aObject.slice(_current_pos, _current_pos + length);
                        } else {
                          blob = aObject.slice(_current_pos);
                        }
                        const ret = new Uint8Array(await blob.arrayBuffer());
                        _current_pos = _current_pos + ret.byteLength;
                        return ret;
                      }
                      bObject = {
                        _rtype: "iostream",
                        _rnative: "js:blob",
                        type: aObject.type,
                        name: aObject.name,
                        size: aObject.size,
                        path: aObject._path || aObject.webkitRelativePath,
                        read: await this._encode(read, session_id, local_workspace),
                        seek: await this._encode(seek, session_id, local_workspace)
                      };
                    } else if (aObject instanceof ArrayBufferView) {
                      const dtype = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.typedArrayToDtype)(aObject);
                      bObject = {
                        _rtype: "typedarray",
                        _rvalue: new Uint8Array(aObject.buffer),
                        _rdtype: dtype
                      };
                    } else if (aObject instanceof DataView) {
                      bObject = {
                        _rtype: "memoryview",
                        _rvalue: new Uint8Array(aObject.buffer)
                      };
                    } else if (aObject instanceof Set) {
                      bObject = {
                        _rtype: "set",
                        _rvalue: await this._encode(
                          Array.from(aObject),
                          session_id,
                          local_workspace
                        )
                      };
                    } else if (aObject instanceof Map) {
                      bObject = {
                        _rtype: "orderedmap",
                        _rvalue: await this._encode(
                          Array.from(aObject),
                          session_id,
                          local_workspace
                        )
                      };
                    } else if (aObject.constructor === Object || Array.isArray(aObject) || aObject instanceof RemoteService) {
                      if (isarray) {
                        if (_allPrimitivesArray(aObject)) return aObject;
                      } else if (!("_rtype" in aObject) && !(aObject instanceof RemoteService)) {
                        if (_allPrimitivesObject(aObject)) return aObject;
                      }
                      bObject = isarray ? [] : {};
                      const keys = Object.keys(aObject);
                      for (let k of keys) {
                        bObject[k] = await this._encode(
                          aObject[k],
                          session_id,
                          local_workspace
                        );
                      }
                    } else {
                      throw `hypha-rpc: Unsupported data type: ${aObject}, you can register a custom codec to encode/decode the object.`;
                    }
                    if (!bObject) {
                      throw new Error("Failed to encode object");
                    }
                    return bObject;
                  }
                  async decode(aObject) {
                    return await this._decode(aObject);
                  }
                  async _decode(aObject, remote_parent, local_parent, remote_workspace, local_workspace) {
                    if (!aObject) {
                      return aObject;
                    }
                    let bObject;
                    if (aObject._rtype) {
                      if (this._codecs[aObject._rtype] && this._codecs[aObject._rtype].decoder) {
                        const temp = aObject._rtype;
                        delete aObject._rtype;
                        aObject = await this._decode(
                          aObject,
                          remote_parent,
                          local_parent,
                          remote_workspace,
                          local_workspace
                        );
                        aObject._rtype = temp;
                        bObject = await Promise.resolve(
                          this._codecs[aObject._rtype].decoder(aObject)
                        );
                      } else if (aObject._rtype === "method") {
                        bObject = this._generate_remote_method(
                          aObject,
                          remote_parent,
                          local_parent,
                          remote_workspace,
                          local_workspace
                        );
                      } else if (aObject._rtype === "generator") {
                        const gen_method = this._generate_remote_method(
                          aObject,
                          remote_parent,
                          local_parent,
                          remote_workspace,
                          local_workspace
                        );
                        async function* asyncGeneratorProxy() {
                          while (true) {
                            try {
                              const next_item = await gen_method();
                              if (next_item && next_item._rtype === "stop_iteration") {
                                break;
                              }
                              yield next_item;
                            } catch (error) {
                              console.error("Error in generator:", error);
                              throw error;
                            }
                          }
                        }
                        bObject = asyncGeneratorProxy();
                      } else if (aObject._rtype === "ndarray") {
                        if (typeof nj !== "undefined" && nj.array) {
                          if (Array.isArray(aObject._rvalue)) {
                            aObject._rvalue = aObject._rvalue.reduce(_appendBuffer);
                          }
                          bObject = nj.array(new Uint8(aObject._rvalue), aObject._rdtype).reshape(aObject._rshape);
                        } else if (typeof tf !== "undefined" && tf.Tensor) {
                          if (Array.isArray(aObject._rvalue)) {
                            aObject._rvalue = aObject._rvalue.reduce(_appendBuffer);
                          }
                          const arraytype = _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.dtypeToTypedArray[aObject._rdtype];
                          bObject = tf.tensor(
                            new arraytype(aObject._rvalue),
                            aObject._rshape,
                            aObject._rdtype
                          );
                        } else {
                          bObject = aObject;
                        }
                      } else if (aObject._rtype === "error") {
                        bObject = new Error(
                          "RemoteError: " + aObject._rvalue + "\n" + (aObject._rtrace || "")
                        );
                      } else if (aObject._rtype === "typedarray") {
                        const arraytype = _utils_index_js__WEBPACK_IMPORTED_MODULE_0__.dtypeToTypedArray[aObject._rdtype];
                        if (!arraytype)
                          throw new Error("unsupported dtype: " + aObject._rdtype);
                        const buffer = aObject._rvalue.buffer.slice(
                          aObject._rvalue.byteOffset,
                          aObject._rvalue.byteOffset + aObject._rvalue.byteLength
                        );
                        bObject = new arraytype(buffer);
                      } else if (aObject._rtype === "memoryview") {
                        bObject = aObject._rvalue.buffer.slice(
                          aObject._rvalue.byteOffset,
                          aObject._rvalue.byteOffset + aObject._rvalue.byteLength
                        );
                      } else if (aObject._rtype === "iostream") {
                        if (aObject._rnative === "js:blob") {
                          const read = await this._generate_remote_method(
                            aObject.read,
                            remote_parent,
                            local_parent,
                            remote_workspace,
                            local_workspace
                          );
                          const bytes = await read();
                          bObject = new Blob([bytes], {
                            type: aObject.type,
                            name: aObject.name
                          });
                        } else {
                          bObject = {};
                          for (let k of Object.keys(aObject)) {
                            if (!k.startsWith("_")) {
                              bObject[k] = await this._decode(
                                aObject[k],
                                remote_parent,
                                local_parent,
                                remote_workspace,
                                local_workspace
                              );
                            }
                          }
                        }
                        bObject["__rpc_object__"] = aObject;
                      } else if (aObject._rtype === "orderedmap") {
                        bObject = new Map(
                          await this._decode(
                            aObject._rvalue,
                            remote_parent,
                            local_parent,
                            remote_workspace,
                            local_workspace
                          )
                        );
                      } else if (aObject._rtype === "set") {
                        bObject = new Set(
                          await this._decode(
                            aObject._rvalue,
                            remote_parent,
                            local_parent,
                            remote_workspace,
                            local_workspace
                          )
                        );
                      } else {
                        const temp = aObject._rtype;
                        delete aObject._rtype;
                        bObject = await this._decode(
                          aObject,
                          remote_parent,
                          local_parent,
                          remote_workspace,
                          local_workspace
                        );
                        bObject._rtype = temp;
                      }
                    } else if (aObject.constructor === Object || Array.isArray(aObject)) {
                      const isarray = Array.isArray(aObject);
                      if (isarray) {
                        if (_allPrimitivesArray(aObject)) return aObject;
                      } else {
                        if (_allPrimitivesObject(aObject)) return aObject;
                      }
                      bObject = isarray ? [] : {};
                      for (let k of Object.keys(aObject)) {
                        if (isarray || aObject.hasOwnProperty(k)) {
                          const v = aObject[k];
                          bObject[k] = await this._decode(
                            v,
                            remote_parent,
                            local_parent,
                            remote_workspace,
                            local_workspace
                          );
                        }
                      }
                    } else {
                      bObject = aObject;
                    }
                    if (bObject === void 0) {
                      throw new Error("Failed to decode object");
                    }
                    return bObject;
                  }
                  _expand_promise(data) {
                    return {
                      heartbeat: {
                        _rtype: "method",
                        _rtarget: data.from.split("/")[1],
                        _rmethod: data.session + ".heartbeat",
                        _rdoc: `heartbeat callback for method: ${data.method}`
                      },
                      resolve: {
                        _rtype: "method",
                        _rtarget: data.from.split("/")[1],
                        _rmethod: data.session + ".resolve",
                        _rdoc: `resolve callback for method: ${data.method}`
                      },
                      reject: {
                        _rtype: "method",
                        _rtarget: data.from.split("/")[1],
                        _rmethod: data.session + ".reject",
                        _rdoc: `reject callback for method: ${data.method}`
                      },
                      interval: data.t
                    };
                  }
                }
              }
            ),
            /***/
            "./src/utils/index.js": (
              /*!****************************!*\
                !*** ./src/utils/index.js ***!
                \****************************/
              /***/
              (__unused_webpack_module, __webpack_exports__, __webpack_require__) => {
                __webpack_require__.r(__webpack_exports__);
                __webpack_require__.d(__webpack_exports__, {
                  /* harmony export */
                  MessageEmitter: () => (
                    /* binding */
                    MessageEmitter
                  ),
                  /* harmony export */
                  Semaphore: () => (
                    /* binding */
                    Semaphore
                  ),
                  /* harmony export */
                  assert: () => (
                    /* binding */
                    assert
                  ),
                  /* harmony export */
                  cacheRequirements: () => (
                    /* binding */
                    cacheRequirements
                  ),
                  /* harmony export */
                  convertCase: () => (
                    /* binding */
                    convertCase
                  ),
                  /* harmony export */
                  dtypeToTypedArray: () => (
                    /* binding */
                    dtypeToTypedArray
                  ),
                  /* harmony export */
                  expandKwargs: () => (
                    /* binding */
                    expandKwargs
                  ),
                  /* harmony export */
                  isAsyncGenerator: () => (
                    /* binding */
                    isAsyncGenerator
                  ),
                  /* harmony export */
                  isGenerator: () => (
                    /* binding */
                    isGenerator
                  ),
                  /* harmony export */
                  loadRequirements: () => (
                    /* binding */
                    loadRequirements
                  ),
                  /* harmony export */
                  loadRequirementsInWebworker: () => (
                    /* binding */
                    loadRequirementsInWebworker
                  ),
                  /* harmony export */
                  loadRequirementsInWindow: () => (
                    /* binding */
                    loadRequirementsInWindow
                  ),
                  /* harmony export */
                  normalizeConfig: () => (
                    /* binding */
                    normalizeConfig
                  ),
                  /* harmony export */
                  parseServiceUrl: () => (
                    /* binding */
                    parseServiceUrl
                  ),
                  /* harmony export */
                  randId: () => (
                    /* binding */
                    randId
                  ),
                  /* harmony export */
                  toCamelCase: () => (
                    /* binding */
                    toCamelCase
                  ),
                  /* harmony export */
                  toSnakeCase: () => (
                    /* binding */
                    toSnakeCase
                  ),
                  /* harmony export */
                  typedArrayToDtype: () => (
                    /* binding */
                    typedArrayToDtype
                  ),
                  /* harmony export */
                  typedArrayToDtypeMapping: () => (
                    /* binding */
                    typedArrayToDtypeMapping
                  ),
                  /* harmony export */
                  urlJoin: () => (
                    /* binding */
                    urlJoin
                  ),
                  /* harmony export */
                  waitFor: () => (
                    /* binding */
                    waitFor
                  )
                  /* harmony export */
                });
                function randId() {
                  return Math.random().toString(36).substr(2, 10) + (/* @__PURE__ */ new Date()).getTime();
                }
                function toCamelCase(str) {
                  if (!str.includes("_")) {
                    return str;
                  }
                  return str.replace(/_./g, (match) => match[1].toUpperCase());
                }
                function toSnakeCase(str) {
                  return str.replace(/([A-Z])/g, "_$1").toLowerCase();
                }
                function expandKwargs(obj) {
                  if (typeof obj !== "object" || obj === null) {
                    return obj;
                  }
                  const newObj = Array.isArray(obj) ? [] : {};
                  for (const key in obj) {
                    if (obj.hasOwnProperty(key)) {
                      const value = obj[key];
                      if (typeof value === "function") {
                        newObj[key] = (...args) => {
                          if (args.length === 0) {
                            throw new Error(`Function "${key}" expects at least one argument.`);
                          }
                          const lastArg = args[args.length - 1];
                          let kwargs = {};
                          if (typeof lastArg === "object" && lastArg !== null && !Array.isArray(lastArg)) {
                            kwargs = { ...lastArg, _rkwarg: true };
                            args = args.slice(0, -1);
                          }
                          return value(...args, kwargs);
                        };
                        newObj[key].__name__ = key;
                        if (value.__schema__) {
                          newObj[key].__schema__ = { ...value.__schema__ };
                          newObj[key].__schema__.name = key;
                        }
                      } else {
                        newObj[key] = expandKwargs(value);
                      }
                    }
                  }
                  return newObj;
                }
                function convertCase(obj, caseType) {
                  if (typeof obj !== "object" || obj === null || !caseType) {
                    return obj;
                  }
                  const newObj = Array.isArray(obj) ? [] : {};
                  for (const key in obj) {
                    if (obj.hasOwnProperty(key)) {
                      const value = obj[key];
                      const camelKey = toCamelCase(key);
                      const snakeKey = toSnakeCase(key);
                      if (caseType === "camel") {
                        newObj[camelKey] = convertCase(value, caseType);
                        if (typeof value === "function") {
                          newObj[camelKey].__name__ = camelKey;
                          if (value.__schema__) {
                            newObj[camelKey].__schema__ = { ...value.__schema__ };
                            newObj[camelKey].__schema__.name = camelKey;
                          }
                        }
                      } else if (caseType === "snake") {
                        newObj[snakeKey] = convertCase(value, caseType);
                        if (typeof value === "function") {
                          newObj[snakeKey].__name__ = snakeKey;
                          if (value.__schema__) {
                            newObj[snakeKey].__schema__ = { ...value.__schema__ };
                            newObj[snakeKey].__schema__.name = snakeKey;
                          }
                        }
                      } else {
                        if (caseType.includes("camel")) {
                          newObj[camelKey] = convertCase(value, "camel");
                        }
                        if (caseType.includes("snake")) {
                          newObj[snakeKey] = convertCase(value, "snake");
                        }
                      }
                    }
                  }
                  return newObj;
                }
                function parseServiceUrl(url) {
                  url = url.replace(/\/$/, "");
                  const pattern = new RegExp(
                    "^(https?:\\/\\/[^/]+)\\/([a-z0-9_-]+)\\/services\\/(?:(?<clientId>[a-zA-Z0-9_-]+):)?(?<serviceId>[a-zA-Z0-9_-]+)(?:@(?<appId>[a-zA-Z0-9_-]+))?"
                    // optional app_id
                  );
                  const match = url.match(pattern);
                  if (!match) {
                    throw new Error("URL does not match the expected pattern");
                  }
                  const serverUrl = match[1];
                  const workspace2 = match[2];
                  const clientId = match.groups?.clientId || "*";
                  const serviceId = match.groups?.serviceId;
                  const appId = match.groups?.appId || "*";
                  return { serverUrl, workspace: workspace2, clientId, serviceId, appId };
                }
                const dtypeToTypedArray = {
                  int8: Int8Array,
                  int16: Int16Array,
                  int32: Int32Array,
                  uint8: Uint8Array,
                  uint16: Uint16Array,
                  uint32: Uint32Array,
                  float32: Float32Array,
                  float64: Float64Array,
                  array: Array
                };
                async function loadRequirementsInWindow(requirements) {
                  function _importScript(url) {
                    return new Promise((resolve2, reject2) => {
                      var scriptTag = document.createElement("script");
                      scriptTag.src = url;
                      scriptTag.type = "text/javascript";
                      scriptTag.onload = resolve2;
                      scriptTag.onreadystatechange = function() {
                        if (this.readyState === "loaded" || this.readyState === "complete") {
                          resolve2();
                        }
                      };
                      scriptTag.onerror = reject2;
                      document.head.appendChild(scriptTag);
                    });
                  }
                  async function importScripts2() {
                    var args = Array.prototype.slice.call(arguments), len = args.length, i2 = 0;
                    for (; i2 < len; i2++) {
                      await _importScript(args[i2]);
                    }
                  }
                  if (requirements && (Array.isArray(requirements) || typeof requirements === "string")) {
                    try {
                      var link_node;
                      requirements = typeof requirements === "string" ? [requirements] : requirements;
                      if (Array.isArray(requirements)) {
                        for (var i = 0; i < requirements.length; i++) {
                          if (requirements[i].toLowerCase().endsWith(".css") || requirements[i].startsWith("css:")) {
                            if (requirements[i].startsWith("css:")) {
                              requirements[i] = requirements[i].slice(4);
                            }
                            link_node = document.createElement("link");
                            link_node.rel = "stylesheet";
                            link_node.href = requirements[i];
                            document.head.appendChild(link_node);
                          } else if (requirements[i].toLowerCase().endsWith(".mjs") || requirements[i].startsWith("mjs:")) {
                            if (requirements[i].startsWith("mjs:")) {
                              requirements[i] = requirements[i].slice(4);
                            }
                            await import(
                              /* webpackIgnore: true */
                              requirements[i]
                            );
                          } else if (requirements[i].toLowerCase().endsWith(".js") || requirements[i].startsWith("js:")) {
                            if (requirements[i].startsWith("js:")) {
                              requirements[i] = requirements[i].slice(3);
                            }
                            await importScripts2(requirements[i]);
                          } else if (requirements[i].startsWith("http")) {
                            await importScripts2(requirements[i]);
                          } else if (requirements[i].startsWith("cache:")) {
                          } else {
                            console.log("Unprocessed requirements url: " + requirements[i]);
                          }
                        }
                      } else {
                        throw "unsupported requirements definition";
                      }
                    } catch (e) {
                      throw "failed to import required scripts: " + requirements.toString();
                    }
                  }
                }
                async function loadRequirementsInWebworker(requirements) {
                  if (requirements && (Array.isArray(requirements) || typeof requirements === "string")) {
                    try {
                      if (!Array.isArray(requirements)) {
                        requirements = [requirements];
                      }
                      for (var i = 0; i < requirements.length; i++) {
                        if (requirements[i].toLowerCase().endsWith(".css") || requirements[i].startsWith("css:")) {
                          throw "unable to import css in a webworker";
                        } else if (requirements[i].toLowerCase().endsWith(".js") || requirements[i].startsWith("js:")) {
                          if (requirements[i].startsWith("js:")) {
                            requirements[i] = requirements[i].slice(3);
                          }
                          importScripts(requirements[i]);
                        } else if (requirements[i].startsWith("http")) {
                          importScripts(requirements[i]);
                        } else if (requirements[i].startsWith("cache:")) {
                        } else {
                          console.log("Unprocessed requirements url: " + requirements[i]);
                        }
                      }
                    } catch (e) {
                      throw "failed to import required scripts: " + requirements.toString();
                    }
                  }
                }
                function loadRequirements(requirements) {
                  if (typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope) {
                    return loadRequirementsInWebworker(requirements);
                  } else {
                    return loadRequirementsInWindow(requirements);
                  }
                }
                function normalizeConfig(config2) {
                  config2.version = config2.version || "0.1.0";
                  config2.description = config2.description || `[TODO: add description for ${config2.name} ]`;
                  config2.type = config2.type || "rpc-window";
                  config2.id = config2.id || randId();
                  config2.target_origin = config2.target_origin || "*";
                  config2.allow_execution = config2.allow_execution || false;
                  config2 = Object.keys(config2).reduce((p, c) => {
                    if (typeof config2[c] !== "function") p[c] = config2[c];
                    return p;
                  }, {});
                  return config2;
                }
                const typedArrayToDtypeMapping = {
                  Int8Array: "int8",
                  Int16Array: "int16",
                  Int32Array: "int32",
                  Uint8Array: "uint8",
                  Uint16Array: "uint16",
                  Uint32Array: "uint32",
                  Float32Array: "float32",
                  Float64Array: "float64",
                  Array: "array"
                };
                const typedArrayToDtypeKeys = [];
                for (const arrType of Object.keys(typedArrayToDtypeMapping)) {
                  typedArrayToDtypeKeys.push(globalThis[arrType]);
                }
                function typedArrayToDtype(obj) {
                  let dtype = typedArrayToDtypeMapping[obj.constructor.name];
                  if (!dtype) {
                    const pt = Object.getPrototypeOf(obj);
                    for (const arrType2 of typedArrayToDtypeKeys) {
                      if (pt instanceof arrType2) {
                        dtype = typedArrayToDtypeMapping[arrType2.name];
                        break;
                      }
                    }
                  }
                  return dtype;
                }
                function cacheUrlInServiceWorker(url) {
                  return new Promise(function(resolve2, reject2) {
                    const message = {
                      command: "add",
                      url
                    };
                    if (!navigator.serviceWorker || !navigator.serviceWorker.register) {
                      reject2("Service worker is not supported.");
                      return;
                    }
                    const messageChannel = new MessageChannel();
                    messageChannel.port1.onmessage = function(event2) {
                      if (event2.data && event2.data.error) {
                        reject2(event2.data.error);
                      } else {
                        resolve2(event2.data && event2.data.result);
                      }
                    };
                    if (navigator.serviceWorker && navigator.serviceWorker.controller) {
                      navigator.serviceWorker.controller.postMessage(message, [
                        messageChannel.port2
                      ]);
                    } else {
                      reject2("Service worker controller is not available");
                    }
                  });
                }
                async function cacheRequirements(requirements) {
                  requirements = requirements || [];
                  if (!Array.isArray(requirements)) {
                    requirements = [requirements];
                  }
                  for (let req of requirements) {
                    if (req.startsWith("js:")) req = req.slice(3);
                    if (req.startsWith("css:")) req = req.slice(4);
                    if (req.startsWith("cache:")) req = req.slice(6);
                    if (!req.startsWith("http")) continue;
                    await cacheUrlInServiceWorker(req).catch((e) => {
                      console.error(e);
                    });
                  }
                }
                function assert(condition, message) {
                  if (!condition) {
                    throw new Error(message || "Assertion failed");
                  }
                }
                function urlJoin(...args) {
                  return args.join("/").replace(/[\/]+/g, "/").replace(/^(.+):\//, "$1://").replace(/^file:/, "file:/").replace(/\/(\?|&|#[^!])/g, "$1").replace(/\?/g, "&").replace("&", "?");
                }
                function waitFor(prom, time, error) {
                  let timer;
                  return Promise.race([
                    prom,
                    new Promise(
                      (_r, rej) => timer = setTimeout(() => {
                        rej(error || "Timeout Error");
                      }, time * 1e3)
                    )
                  ]).finally(() => clearTimeout(timer));
                }
                class MessageEmitter {
                  constructor(debug) {
                    this._event_handlers = {};
                    this._once_handlers = {};
                    this._debug = debug;
                  }
                  emit() {
                    throw new Error("emit is not implemented");
                  }
                  on(event2, handler) {
                    if (!this._event_handlers[event2]) {
                      this._event_handlers[event2] = [];
                    }
                    this._event_handlers[event2].push(handler);
                  }
                  once(event2, handler) {
                    handler.___event_run_once = true;
                    this.on(event2, handler);
                  }
                  off(event2, handler) {
                    if (!event2 && !handler) {
                      this._event_handlers = {};
                    } else if (event2 && !handler) {
                      if (this._event_handlers[event2]) this._event_handlers[event2] = [];
                    } else {
                      if (this._event_handlers[event2]) {
                        const idx = this._event_handlers[event2].indexOf(handler);
                        if (idx >= 0) {
                          this._event_handlers[event2].splice(idx, 1);
                        }
                      }
                    }
                  }
                  _fire(event2, data) {
                    if (this._event_handlers[event2]) {
                      var i = this._event_handlers[event2].length;
                      while (i--) {
                        const handler = this._event_handlers[event2][i];
                        try {
                          handler(data);
                        } catch (e) {
                          console.error(e);
                        } finally {
                          if (handler.___event_run_once) {
                            this._event_handlers[event2].splice(i, 1);
                          }
                        }
                      }
                    } else {
                      if (this._debug) {
                        console.warn("unhandled event", event2, data);
                      }
                    }
                  }
                  waitFor(event2, timeout) {
                    return new Promise((resolve2, reject2) => {
                      const handler = (data) => {
                        clearTimeout(timer);
                        resolve2(data);
                      };
                      this.once(event2, handler);
                      const timer = setTimeout(() => {
                        this.off(event2, handler);
                        reject2(new Error("Timeout"));
                      }, timeout * 1e3);
                    });
                  }
                }
                class Semaphore {
                  constructor(max) {
                    this.max = max;
                    this.queue = [];
                    this.current = 0;
                  }
                  async run(task) {
                    if (this.current >= this.max) {
                      await new Promise((resolve2) => this.queue.push(resolve2));
                    }
                    this.current++;
                    try {
                      return await task();
                    } finally {
                      this.current--;
                      if (this.queue.length > 0) {
                        this.queue.shift()();
                      }
                    }
                  }
                }
                function isGenerator(obj) {
                  if (!obj) return false;
                  return typeof obj === "object" && typeof obj.next === "function" && typeof obj.throw === "function" && typeof obj.return === "function";
                }
                function isAsyncGenerator(obj) {
                  if (!obj) return false;
                  return typeof obj === "object" && typeof obj.next === "function" && typeof obj.throw === "function" && typeof obj.return === "function" && Symbol.asyncIterator in Object(obj) && obj[Symbol.toStringTag] === "AsyncGenerator";
                }
              }
            ),
            /***/
            "./src/utils/schema.js": (
              /*!*****************************!*\
                !*** ./src/utils/schema.js ***!
                \*****************************/
              /***/
              (__unused_webpack_module2, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  schemaFunction: () => (
                    /* binding */
                    schemaFunction
                  ),
                  /* harmony export */
                  z: () => (
                    /* binding */
                    z
                  )
                  /* harmony export */
                });
                var _index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./index.js */
                  "./src/utils/index.js"
                );
                const z = {
                  object: (properties) => ({
                    type: "object",
                    properties,
                    required: Object.keys(properties).filter(
                      (key) => !properties[key]._optional
                    )
                  }),
                  string: () => ({ type: "string", _optional: false }),
                  number: () => ({ type: "number", _optional: false }),
                  integer: () => ({ type: "integer", _optional: false }),
                  boolean: () => ({ type: "boolean", _optional: false }),
                  array: (items) => ({ type: "array", items, _optional: false }),
                  // Make field optional
                  optional: (schema) => ({ ...schema, _optional: true })
                };
                ["string", "number", "integer", "boolean", "array"].forEach((type2) => {
                  z[type2] = () => {
                    const schema = {
                      type: type2 === "integer" ? "integer" : type2,
                      _optional: false
                    };
                    schema.describe = (description) => ({ ...schema, description });
                    return schema;
                  };
                });
                function schemaFunction(func, { schema_type = "auto", name: name2 = null, description = null, parameters = null }) {
                  if (!func || typeof func !== "function") {
                    throw Error("func should be a function");
                  }
                  (0, _index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(schema_type === "auto", "schema_type should be auto");
                  const funcName = name2 || func.name;
                  (0, _index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(funcName, "name should not be null");
                  let processedParameters = parameters;
                  if (parameters && typeof parameters === "object" && parameters.type === "object") {
                    processedParameters = {
                      type: "object",
                      properties: parameters.properties || {},
                      required: parameters.required || []
                    };
                    for (const [key, schema] of Object.entries(
                      processedParameters.properties
                    )) {
                      if (schema._optional !== void 0) {
                        delete schema._optional;
                      }
                    }
                  }
                  (0, _index_js__WEBPACK_IMPORTED_MODULE_0__.assert)(
                    processedParameters && processedParameters.type === "object",
                    "parameters should be an object schema"
                  );
                  func.__schema__ = {
                    name: funcName,
                    description: description || "",
                    parameters: processedParameters
                  };
                  return func;
                }
              }
            ),
            /***/
            "./src/webrtc-client.js": (
              /*!******************************!*\
                !*** ./src/webrtc-client.js ***!
                \******************************/
              /***/
              (__unused_webpack_module2, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  getRTCService: () => (
                    /* binding */
                    getRTCService
                  ),
                  /* harmony export */
                  registerRTCService: () => (
                    /* binding */
                    registerRTCService
                  )
                  /* harmony export */
                });
                var _rpc_js__WEBPACK_IMPORTED_MODULE_0__2 = __webpack_require__2(
                  /*! ./rpc.js */
                  "./src/rpc.js"
                );
                var _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2 = __webpack_require__2(
                  /*! ./utils/index.js */
                  "./src/utils/index.js"
                );
                var _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2 = __webpack_require__2(
                  /*! ./utils/schema.js */
                  "./src/utils/schema.js"
                );
                class WebRTCConnection {
                  constructor(channel) {
                    this._data_channel = channel;
                    this._handle_message = null;
                    this._reconnection_token = null;
                    this._handle_disconnected = null;
                    this._handle_connected = () => {
                    };
                    this.manager_id = null;
                    this._data_channel.onopen = async () => {
                      this._handle_connected && this._handle_connected({ channel: this._data_channel });
                    };
                    this._data_channel.onmessage = async (event2) => {
                      let data = event2.data;
                      if (data instanceof Blob) {
                        data = await data.arrayBuffer();
                      }
                      if (this._handle_message) {
                        this._handle_message(data);
                      }
                    };
                    this._data_channel.onclose = () => {
                      if (this._handle_disconnected) this._handle_disconnected("closed");
                      console.log("data channel closed");
                      this._data_channel = null;
                    };
                  }
                  on_disconnected(handler) {
                    this._handle_disconnected = handler;
                  }
                  on_connected(handler) {
                    this._handle_connected = handler;
                  }
                  on_message(handler) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(handler, "handler is required");
                    this._handle_message = handler;
                  }
                  async emit_message(data) {
                    (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(this._handle_message, "No handler for message");
                    try {
                      this._data_channel.send(data);
                    } catch (exp) {
                      console.error(`Failed to send data, error: ${exp}`);
                      throw exp;
                    }
                  }
                  async disconnect(reason) {
                    this._data_channel = null;
                    console.info(`data channel connection disconnected (${reason})`);
                  }
                }
                async function _setupRPC(config2) {
                  (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(config2.channel, "No channel provided");
                  (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(config2.workspace, "No workspace provided");
                  const channel = config2.channel;
                  const clientId = config2.client_id || (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.randId)();
                  const connection = new WebRTCConnection(channel);
                  config2.context = config2.context || {};
                  config2.context.connection_type = "webrtc";
                  config2.context.ws = config2.workspace;
                  const rpc = new _rpc_js__WEBPACK_IMPORTED_MODULE_0__2.RPC(connection, {
                    client_id: clientId,
                    default_context: config2.context,
                    name: config2.name,
                    method_timeout: config2.method_timeout || 10,
                    workspace: config2.workspace,
                    app_id: config2.app_id,
                    long_message_chunk_size: config2.long_message_chunk_size
                  });
                  return rpc;
                }
                async function _createOffer(params, server2, config2, onInit, context2) {
                  config2 = config2 || {};
                  let offer = new RTCSessionDescription({
                    sdp: params.sdp,
                    type: params.type
                  });
                  let pc = new RTCPeerConnection({
                    iceServers: config2.ice_servers || [
                      { urls: ["stun:stun.l.google.com:19302"] }
                    ],
                    sdpSemantics: "unified-plan"
                  });
                  if (server2) {
                    pc.addEventListener("datachannel", async (event2) => {
                      const channel = event2.channel;
                      let ctx = null;
                      if (context2 && context2.user) ctx = { user: context2.user, ws: context2.ws };
                      const rpc = await _setupRPC({
                        channel,
                        client_id: channel.label,
                        workspace: server2.config.workspace,
                        context: ctx
                      });
                      rpc._services = server2.rpc._services;
                    });
                  }
                  if (onInit) {
                    await onInit(pc);
                  }
                  await pc.setRemoteDescription(offer);
                  let answer = await pc.createAnswer();
                  await pc.setLocalDescription(answer);
                  await new Promise((resolveIce) => {
                    if (pc.iceGatheringState === "complete") {
                      resolveIce();
                    } else {
                      pc.addEventListener("icegatheringstatechange", () => {
                        if (pc.iceGatheringState === "complete") {
                          resolveIce();
                        }
                      });
                      setTimeout(resolveIce, 5e3);
                    }
                  });
                  return {
                    sdp: pc.localDescription.sdp,
                    type: pc.localDescription.type,
                    workspace: server2.config.workspace
                  };
                }
                async function getRTCService(server2, service_id, config2) {
                  config2 = config2 || {};
                  config2.peer_id = config2.peer_id || (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.randId)();
                  const pc = new RTCPeerConnection({
                    iceServers: config2.ice_servers || [
                      { urls: ["stun:stun.l.google.com:19302"] }
                    ],
                    sdpSemantics: "unified-plan"
                  });
                  return new Promise(async (resolve2, reject2) => {
                    let resolved = false;
                    const timeout = setTimeout(() => {
                      if (!resolved) {
                        resolved = true;
                        pc.close();
                        reject2(new Error("WebRTC Connection timeout"));
                      }
                    }, 3e4);
                    try {
                      pc.addEventListener(
                        "connectionstatechange",
                        () => {
                          console.log("WebRTC Connection state: ", pc.connectionState);
                          if (pc.connectionState === "failed") {
                            if (!resolved) {
                              resolved = true;
                              clearTimeout(timeout);
                              pc.close();
                              reject2(new Error("WebRTC Connection failed"));
                            }
                          } else if (pc.connectionState === "closed") {
                            if (!resolved) {
                              resolved = true;
                              clearTimeout(timeout);
                              reject2(new Error("WebRTC Connection closed"));
                            }
                          } else if (pc.connectionState === "connected") {
                            console.log("WebRTC Connection established successfully");
                          }
                        },
                        false
                      );
                      pc.addEventListener("iceconnectionstatechange", () => {
                        console.log("ICE Connection state: ", pc.iceConnectionState);
                        if (pc.iceConnectionState === "failed") {
                          if (!resolved) {
                            resolved = true;
                            clearTimeout(timeout);
                            pc.close();
                            reject2(new Error("ICE Connection failed"));
                          }
                        }
                      });
                      if (config2.on_init) {
                        await config2.on_init(pc);
                        delete config2.on_init;
                      }
                      let channel = pc.createDataChannel(config2.peer_id, { ordered: true });
                      channel.binaryType = "arraybuffer";
                      const offer = await pc.createOffer();
                      await pc.setLocalDescription(offer);
                      await new Promise((resolveIce) => {
                        if (pc.iceGatheringState === "complete") {
                          resolveIce();
                        } else {
                          pc.addEventListener("icegatheringstatechange", () => {
                            if (pc.iceGatheringState === "complete") {
                              resolveIce();
                            }
                          });
                          setTimeout(resolveIce, 5e3);
                        }
                      });
                      const svc = await server2.getService(service_id);
                      const answer = await svc.offer({
                        sdp: pc.localDescription.sdp,
                        type: pc.localDescription.type
                      });
                      channel.onopen = () => {
                        config2.channel = channel;
                        config2.workspace = answer.workspace;
                        setTimeout(async () => {
                          if (!resolved) {
                            try {
                              const rpc = await _setupRPC(config2);
                              pc.rpc = rpc;
                              async function get_service(name2, ...args) {
                                (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(
                                  !name2.includes(":"),
                                  "WebRTC service name should not contain ':'"
                                );
                                (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__2.assert)(
                                  !name2.includes("/"),
                                  "WebRTC service name should not contain '/'"
                                );
                                return await rpc.get_remote_service(
                                  config2.workspace + "/" + config2.peer_id + ":" + name2,
                                  ...args
                                );
                              }
                              async function disconnect() {
                                await rpc.disconnect();
                                pc.close();
                              }
                              pc.getService = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2.schemaFunction)(get_service, {
                                name: "getService",
                                description: "Get a remote service via webrtc",
                                parameters: {
                                  type: "object",
                                  properties: {
                                    service_id: {
                                      type: "string",
                                      description: "Service ID. This should be a service id in the format: 'workspace/service_id', 'workspace/client_id:service_id' or 'workspace/client_id:service_id@app_id'"
                                    },
                                    config: {
                                      type: "object",
                                      description: "Options for the service"
                                    }
                                  },
                                  required: ["id"]
                                }
                              });
                              pc.disconnect = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2.schemaFunction)(disconnect, {
                                name: "disconnect",
                                description: "Disconnect from the webrtc connection via webrtc",
                                parameters: { type: "object", properties: {} }
                              });
                              pc.registerCodec = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__2.schemaFunction)(rpc.register_codec, {
                                name: "registerCodec",
                                description: "Register a codec for the webrtc connection",
                                parameters: {
                                  type: "object",
                                  properties: {
                                    codec: {
                                      type: "object",
                                      description: "Codec to register",
                                      properties: {
                                        name: { type: "string" },
                                        type: {},
                                        encoder: { type: "function" },
                                        decoder: { type: "function" }
                                      }
                                    }
                                  }
                                }
                              });
                              resolved = true;
                              clearTimeout(timeout);
                              resolve2(pc);
                            } catch (e) {
                              if (!resolved) {
                                resolved = true;
                                clearTimeout(timeout);
                                reject2(e);
                              }
                            }
                          }
                        }, 1e3);
                      };
                      channel.onclose = () => {
                        if (!resolved) {
                          resolved = true;
                          clearTimeout(timeout);
                          reject2(new Error("Data channel closed"));
                        }
                      };
                      channel.onerror = (error) => {
                        if (!resolved) {
                          resolved = true;
                          clearTimeout(timeout);
                          reject2(new Error(`Data channel error: ${error}`));
                        }
                      };
                      await pc.setRemoteDescription(
                        new RTCSessionDescription({
                          sdp: answer.sdp,
                          type: answer.type
                        })
                      );
                    } catch (e) {
                      if (!resolved) {
                        resolved = true;
                        clearTimeout(timeout);
                        reject2(e);
                      }
                    }
                  });
                }
                async function registerRTCService(server2, service_id, config2) {
                  config2 = config2 || {
                    visibility: "protected",
                    require_context: true
                  };
                  const onInit = config2.on_init;
                  delete config2.on_init;
                  return await server2.registerService({
                    id: service_id,
                    config: config2,
                    offer: (params, context2) => _createOffer(params, server2, config2, onInit, context2)
                  });
                }
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/CachedKeyDecoder.mjs": (
              /*!*************************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/CachedKeyDecoder.mjs ***!
                \*************************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  CachedKeyDecoder: () => (
                    /* binding */
                    CachedKeyDecoder
                  )
                  /* harmony export */
                });
                var _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./utils/utf8.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/utf8.mjs"
                );
                var DEFAULT_MAX_KEY_LENGTH = 16;
                var DEFAULT_MAX_LENGTH_PER_KEY = 16;
                var CachedKeyDecoder = (
                  /** @class */
                  function() {
                    function CachedKeyDecoder2(maxKeyLength, maxLengthPerKey) {
                      if (maxKeyLength === void 0) {
                        maxKeyLength = DEFAULT_MAX_KEY_LENGTH;
                      }
                      if (maxLengthPerKey === void 0) {
                        maxLengthPerKey = DEFAULT_MAX_LENGTH_PER_KEY;
                      }
                      this.maxKeyLength = maxKeyLength;
                      this.maxLengthPerKey = maxLengthPerKey;
                      this.hit = 0;
                      this.miss = 0;
                      this.caches = [];
                      for (var i = 0; i < this.maxKeyLength; i++) {
                        this.caches.push([]);
                      }
                    }
                    CachedKeyDecoder2.prototype.canBeCached = function(byteLength) {
                      return byteLength > 0 && byteLength <= this.maxKeyLength;
                    };
                    CachedKeyDecoder2.prototype.find = function(bytes, inputOffset, byteLength) {
                      var records = this.caches[byteLength - 1];
                      FIND_CHUNK: for (var _i = 0, records_1 = records; _i < records_1.length; _i++) {
                        var record = records_1[_i];
                        var recordBytes = record.bytes;
                        for (var j = 0; j < byteLength; j++) {
                          if (recordBytes[j] !== bytes[inputOffset + j]) {
                            continue FIND_CHUNK;
                          }
                        }
                        return record.str;
                      }
                      return null;
                    };
                    CachedKeyDecoder2.prototype.store = function(bytes, value) {
                      var records = this.caches[bytes.length - 1];
                      var record = { bytes, str: value };
                      if (records.length >= this.maxLengthPerKey) {
                        records[Math.random() * records.length | 0] = record;
                      } else {
                        records.push(record);
                      }
                    };
                    CachedKeyDecoder2.prototype.decode = function(bytes, inputOffset, byteLength) {
                      var cachedValue = this.find(bytes, inputOffset, byteLength);
                      if (cachedValue != null) {
                        this.hit++;
                        return cachedValue;
                      }
                      this.miss++;
                      var str = (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_0__.utf8DecodeJs)(bytes, inputOffset, byteLength);
                      var slicedCopyOfBytes = Uint8Array.prototype.slice.call(bytes, inputOffset, inputOffset + byteLength);
                      this.store(slicedCopyOfBytes, str);
                      return str;
                    };
                    return CachedKeyDecoder2;
                  }()
                );
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/DecodeError.mjs": (
              /*!********************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/DecodeError.mjs ***!
                \********************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  DecodeError: () => (
                    /* binding */
                    DecodeError
                  )
                  /* harmony export */
                });
                var __extends = /* @__PURE__ */ function() {
                  var extendStatics = function(d, b) {
                    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
                      d2.__proto__ = b2;
                    } || function(d2, b2) {
                      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
                    };
                    return extendStatics(d, b);
                  };
                  return function(d, b) {
                    if (typeof b !== "function" && b !== null)
                      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
                    extendStatics(d, b);
                    function __() {
                      this.constructor = d;
                    }
                    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
                  };
                }();
                var DecodeError = (
                  /** @class */
                  function(_super) {
                    __extends(DecodeError2, _super);
                    function DecodeError2(message) {
                      var _this = _super.call(this, message) || this;
                      var proto = Object.create(DecodeError2.prototype);
                      Object.setPrototypeOf(_this, proto);
                      Object.defineProperty(_this, "name", {
                        configurable: true,
                        enumerable: false,
                        value: DecodeError2.name
                      });
                      return _this;
                    }
                    return DecodeError2;
                  }(Error)
                );
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/Decoder.mjs": (
              /*!****************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/Decoder.mjs ***!
                \****************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  DataViewIndexOutOfBoundsError: () => (
                    /* binding */
                    DataViewIndexOutOfBoundsError
                  ),
                  /* harmony export */
                  Decoder: () => (
                    /* binding */
                    Decoder
                  )
                  /* harmony export */
                });
                var _utils_prettyByte_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__2(
                  /*! ./utils/prettyByte.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/prettyByte.mjs"
                );
                var _ExtensionCodec_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__2(
                  /*! ./ExtensionCodec.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/ExtensionCodec.mjs"
                );
                var _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__2(
                  /*! ./utils/int.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/int.mjs"
                );
                var _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__2(
                  /*! ./utils/utf8.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/utf8.mjs"
                );
                var _utils_typedArrays_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__2(
                  /*! ./utils/typedArrays.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/typedArrays.mjs"
                );
                var _CachedKeyDecoder_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./CachedKeyDecoder.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/CachedKeyDecoder.mjs"
                );
                var _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__2(
                  /*! ./DecodeError.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/DecodeError.mjs"
                );
                var __awaiter = function(thisArg, _arguments, P, generator) {
                  function adopt(value) {
                    return value instanceof P ? value : new P(function(resolve2) {
                      resolve2(value);
                    });
                  }
                  return new (P || (P = Promise))(function(resolve2, reject2) {
                    function fulfilled(value) {
                      try {
                        step(generator.next(value));
                      } catch (e) {
                        reject2(e);
                      }
                    }
                    function rejected(value) {
                      try {
                        step(generator["throw"](value));
                      } catch (e) {
                        reject2(e);
                      }
                    }
                    function step(result) {
                      result.done ? resolve2(result.value) : adopt(result.value).then(fulfilled, rejected);
                    }
                    step((generator = generator.apply(thisArg, _arguments || [])).next());
                  });
                };
                var __generator = function(thisArg, body) {
                  var _ = { label: 0, sent: function() {
                    if (t[0] & 1) throw t[1];
                    return t[1];
                  }, trys: [], ops: [] }, f, y, t, g;
                  return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() {
                    return this;
                  }), g;
                  function verb(n) {
                    return function(v) {
                      return step([n, v]);
                    };
                  }
                  function step(op) {
                    if (f) throw new TypeError("Generator is already executing.");
                    while (_) try {
                      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                      if (y = 0, t) op = [op[0] & 2, t.value];
                      switch (op[0]) {
                        case 0:
                        case 1:
                          t = op;
                          break;
                        case 4:
                          _.label++;
                          return { value: op[1], done: false };
                        case 5:
                          _.label++;
                          y = op[1];
                          op = [0];
                          continue;
                        case 7:
                          op = _.ops.pop();
                          _.trys.pop();
                          continue;
                        default:
                          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                            _ = 0;
                            continue;
                          }
                          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                            _.label = op[1];
                            break;
                          }
                          if (op[0] === 6 && _.label < t[1]) {
                            _.label = t[1];
                            t = op;
                            break;
                          }
                          if (t && _.label < t[2]) {
                            _.label = t[2];
                            _.ops.push(op);
                            break;
                          }
                          if (t[2]) _.ops.pop();
                          _.trys.pop();
                          continue;
                      }
                      op = body.call(thisArg, _);
                    } catch (e) {
                      op = [6, e];
                      y = 0;
                    } finally {
                      f = t = 0;
                    }
                    if (op[0] & 5) throw op[1];
                    return { value: op[0] ? op[1] : void 0, done: true };
                  }
                };
                var __asyncValues = function(o) {
                  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
                  var m = o[Symbol.asyncIterator], i;
                  return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
                    return this;
                  }, i);
                  function verb(n) {
                    i[n] = o[n] && function(v) {
                      return new Promise(function(resolve2, reject2) {
                        v = o[n](v), settle(resolve2, reject2, v.done, v.value);
                      });
                    };
                  }
                  function settle(resolve2, reject2, d, v) {
                    Promise.resolve(v).then(function(v2) {
                      resolve2({ value: v2, done: d });
                    }, reject2);
                  }
                };
                var __await = function(v) {
                  return this instanceof __await ? (this.v = v, this) : new __await(v);
                };
                var __asyncGenerator = function(thisArg, _arguments, generator) {
                  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
                  var g = generator.apply(thisArg, _arguments || []), i, q = [];
                  return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
                    return this;
                  }, i;
                  function verb(n) {
                    if (g[n]) i[n] = function(v) {
                      return new Promise(function(a, b) {
                        q.push([n, v, a, b]) > 1 || resume(n, v);
                      });
                    };
                  }
                  function resume(n, v) {
                    try {
                      step(g[n](v));
                    } catch (e) {
                      settle(q[0][3], e);
                    }
                  }
                  function step(r) {
                    r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject2) : settle(q[0][2], r);
                  }
                  function fulfill(value) {
                    resume("next", value);
                  }
                  function reject2(value) {
                    resume("throw", value);
                  }
                  function settle(f, v) {
                    if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
                  }
                };
                var isValidMapKeyType = function(key) {
                  var keyType = typeof key;
                  return keyType === "string" || keyType === "number";
                };
                var HEAD_BYTE_REQUIRED = -1;
                var EMPTY_VIEW = new DataView(new ArrayBuffer(0));
                var EMPTY_BYTES = new Uint8Array(EMPTY_VIEW.buffer);
                var DataViewIndexOutOfBoundsError = function() {
                  try {
                    EMPTY_VIEW.getInt8(0);
                  } catch (e) {
                    return e.constructor;
                  }
                  throw new Error("never reached");
                }();
                var MORE_DATA = new DataViewIndexOutOfBoundsError("Insufficient data");
                var sharedCachedKeyDecoder = new _CachedKeyDecoder_mjs__WEBPACK_IMPORTED_MODULE_0__.CachedKeyDecoder();
                var Decoder = (
                  /** @class */
                  function() {
                    function Decoder2(extensionCodec, context2, maxStrLength, maxBinLength, maxArrayLength, maxMapLength, maxExtLength, keyDecoder) {
                      if (extensionCodec === void 0) {
                        extensionCodec = _ExtensionCodec_mjs__WEBPACK_IMPORTED_MODULE_1__.ExtensionCodec.defaultCodec;
                      }
                      if (context2 === void 0) {
                        context2 = void 0;
                      }
                      if (maxStrLength === void 0) {
                        maxStrLength = _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.UINT32_MAX;
                      }
                      if (maxBinLength === void 0) {
                        maxBinLength = _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.UINT32_MAX;
                      }
                      if (maxArrayLength === void 0) {
                        maxArrayLength = _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.UINT32_MAX;
                      }
                      if (maxMapLength === void 0) {
                        maxMapLength = _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.UINT32_MAX;
                      }
                      if (maxExtLength === void 0) {
                        maxExtLength = _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.UINT32_MAX;
                      }
                      if (keyDecoder === void 0) {
                        keyDecoder = sharedCachedKeyDecoder;
                      }
                      this.extensionCodec = extensionCodec;
                      this.context = context2;
                      this.maxStrLength = maxStrLength;
                      this.maxBinLength = maxBinLength;
                      this.maxArrayLength = maxArrayLength;
                      this.maxMapLength = maxMapLength;
                      this.maxExtLength = maxExtLength;
                      this.keyDecoder = keyDecoder;
                      this.totalPos = 0;
                      this.pos = 0;
                      this.view = EMPTY_VIEW;
                      this.bytes = EMPTY_BYTES;
                      this.headByte = HEAD_BYTE_REQUIRED;
                      this.stack = [];
                    }
                    Decoder2.prototype.reinitializeState = function() {
                      this.totalPos = 0;
                      this.headByte = HEAD_BYTE_REQUIRED;
                      this.stack.length = 0;
                    };
                    Decoder2.prototype.setBuffer = function(buffer) {
                      this.bytes = (0, _utils_typedArrays_mjs__WEBPACK_IMPORTED_MODULE_3__.ensureUint8Array)(buffer);
                      this.view = (0, _utils_typedArrays_mjs__WEBPACK_IMPORTED_MODULE_3__.createDataView)(this.bytes);
                      this.pos = 0;
                    };
                    Decoder2.prototype.appendBuffer = function(buffer) {
                      if (this.headByte === HEAD_BYTE_REQUIRED && !this.hasRemaining(1)) {
                        this.setBuffer(buffer);
                      } else {
                        var remainingData = this.bytes.subarray(this.pos);
                        var newData = (0, _utils_typedArrays_mjs__WEBPACK_IMPORTED_MODULE_3__.ensureUint8Array)(buffer);
                        var newBuffer = new Uint8Array(remainingData.length + newData.length);
                        newBuffer.set(remainingData);
                        newBuffer.set(newData, remainingData.length);
                        this.setBuffer(newBuffer);
                      }
                    };
                    Decoder2.prototype.hasRemaining = function(size) {
                      return this.view.byteLength - this.pos >= size;
                    };
                    Decoder2.prototype.createExtraByteError = function(posToShow) {
                      var _a = this, view = _a.view, pos = _a.pos;
                      return new RangeError("Extra ".concat(view.byteLength - pos, " of ").concat(view.byteLength, " byte(s) found at buffer[").concat(posToShow, "]"));
                    };
                    Decoder2.prototype.decode = function(buffer) {
                      this.reinitializeState();
                      this.setBuffer(buffer);
                      var object = this.doDecodeSync();
                      if (this.hasRemaining(1)) {
                        throw this.createExtraByteError(this.pos);
                      }
                      return object;
                    };
                    Decoder2.prototype.decodeMulti = function(buffer) {
                      return __generator(this, function(_a) {
                        switch (_a.label) {
                          case 0:
                            this.reinitializeState();
                            this.setBuffer(buffer);
                            _a.label = 1;
                          case 1:
                            if (!this.hasRemaining(1)) return [3, 3];
                            return [4, this.doDecodeSync()];
                          case 2:
                            _a.sent();
                            return [3, 1];
                          case 3:
                            return [
                              2
                              /*return*/
                            ];
                        }
                      });
                    };
                    Decoder2.prototype.decodeAsync = function(stream) {
                      var stream_1, stream_1_1;
                      var e_1, _a;
                      return __awaiter(this, void 0, void 0, function() {
                        var decoded, object, buffer, e_1_1, _b, headByte, pos, totalPos;
                        return __generator(this, function(_c) {
                          switch (_c.label) {
                            case 0:
                              decoded = false;
                              _c.label = 1;
                            case 1:
                              _c.trys.push([1, 6, 7, 12]);
                              stream_1 = __asyncValues(stream);
                              _c.label = 2;
                            case 2:
                              return [4, stream_1.next()];
                            case 3:
                              if (!(stream_1_1 = _c.sent(), !stream_1_1.done)) return [3, 5];
                              buffer = stream_1_1.value;
                              if (decoded) {
                                throw this.createExtraByteError(this.totalPos);
                              }
                              this.appendBuffer(buffer);
                              try {
                                object = this.doDecodeSync();
                                decoded = true;
                              } catch (e) {
                                if (!(e instanceof DataViewIndexOutOfBoundsError)) {
                                  throw e;
                                }
                              }
                              this.totalPos += this.pos;
                              _c.label = 4;
                            case 4:
                              return [3, 2];
                            case 5:
                              return [3, 12];
                            case 6:
                              e_1_1 = _c.sent();
                              e_1 = { error: e_1_1 };
                              return [3, 12];
                            case 7:
                              _c.trys.push([7, , 10, 11]);
                              if (!(stream_1_1 && !stream_1_1.done && (_a = stream_1.return))) return [3, 9];
                              return [4, _a.call(stream_1)];
                            case 8:
                              _c.sent();
                              _c.label = 9;
                            case 9:
                              return [3, 11];
                            case 10:
                              if (e_1) throw e_1.error;
                              return [
                                7
                                /*endfinally*/
                              ];
                            case 11:
                              return [
                                7
                                /*endfinally*/
                              ];
                            case 12:
                              if (decoded) {
                                if (this.hasRemaining(1)) {
                                  throw this.createExtraByteError(this.totalPos);
                                }
                                return [2, object];
                              }
                              _b = this, headByte = _b.headByte, pos = _b.pos, totalPos = _b.totalPos;
                              throw new RangeError("Insufficient data in parsing ".concat((0, _utils_prettyByte_mjs__WEBPACK_IMPORTED_MODULE_4__.prettyByte)(headByte), " at ").concat(totalPos, " (").concat(pos, " in the current buffer)"));
                          }
                        });
                      });
                    };
                    Decoder2.prototype.decodeArrayStream = function(stream) {
                      return this.decodeMultiAsync(stream, true);
                    };
                    Decoder2.prototype.decodeStream = function(stream) {
                      return this.decodeMultiAsync(stream, false);
                    };
                    Decoder2.prototype.decodeMultiAsync = function(stream, isArray) {
                      return __asyncGenerator(this, arguments, function decodeMultiAsync_1() {
                        var isArrayHeaderRequired, arrayItemsLeft, stream_2, stream_2_1, buffer, e_2, e_3_1;
                        var e_3, _a;
                        return __generator(this, function(_b) {
                          switch (_b.label) {
                            case 0:
                              isArrayHeaderRequired = isArray;
                              arrayItemsLeft = -1;
                              _b.label = 1;
                            case 1:
                              _b.trys.push([1, 13, 14, 19]);
                              stream_2 = __asyncValues(stream);
                              _b.label = 2;
                            case 2:
                              return [4, __await(stream_2.next())];
                            case 3:
                              if (!(stream_2_1 = _b.sent(), !stream_2_1.done)) return [3, 12];
                              buffer = stream_2_1.value;
                              if (isArray && arrayItemsLeft === 0) {
                                throw this.createExtraByteError(this.totalPos);
                              }
                              this.appendBuffer(buffer);
                              if (isArrayHeaderRequired) {
                                arrayItemsLeft = this.readArraySize();
                                isArrayHeaderRequired = false;
                                this.complete();
                              }
                              _b.label = 4;
                            case 4:
                              _b.trys.push([4, 9, , 10]);
                              _b.label = 5;
                            case 5:
                              if (false) {
                              }
                              return [4, __await(this.doDecodeSync())];
                            case 6:
                              return [4, _b.sent()];
                            case 7:
                              _b.sent();
                              if (--arrayItemsLeft === 0) {
                                return [3, 8];
                              }
                              return [3, 5];
                            case 8:
                              return [3, 10];
                            case 9:
                              e_2 = _b.sent();
                              if (!(e_2 instanceof DataViewIndexOutOfBoundsError)) {
                                throw e_2;
                              }
                              return [3, 10];
                            case 10:
                              this.totalPos += this.pos;
                              _b.label = 11;
                            case 11:
                              return [3, 2];
                            case 12:
                              return [3, 19];
                            case 13:
                              e_3_1 = _b.sent();
                              e_3 = { error: e_3_1 };
                              return [3, 19];
                            case 14:
                              _b.trys.push([14, , 17, 18]);
                              if (!(stream_2_1 && !stream_2_1.done && (_a = stream_2.return))) return [3, 16];
                              return [4, __await(_a.call(stream_2))];
                            case 15:
                              _b.sent();
                              _b.label = 16;
                            case 16:
                              return [3, 18];
                            case 17:
                              if (e_3) throw e_3.error;
                              return [
                                7
                                /*endfinally*/
                              ];
                            case 18:
                              return [
                                7
                                /*endfinally*/
                              ];
                            case 19:
                              return [
                                2
                                /*return*/
                              ];
                          }
                        });
                      });
                    };
                    Decoder2.prototype.doDecodeSync = function() {
                      DECODE: while (true) {
                        var headByte = this.readHeadByte();
                        var object = void 0;
                        if (headByte >= 224) {
                          object = headByte - 256;
                        } else if (headByte < 192) {
                          if (headByte < 128) {
                            object = headByte;
                          } else if (headByte < 144) {
                            var size = headByte - 128;
                            if (size !== 0) {
                              this.pushMapState(size);
                              this.complete();
                              continue DECODE;
                            } else {
                              object = {};
                            }
                          } else if (headByte < 160) {
                            var size = headByte - 144;
                            if (size !== 0) {
                              this.pushArrayState(size);
                              this.complete();
                              continue DECODE;
                            } else {
                              object = [];
                            }
                          } else {
                            var byteLength = headByte - 160;
                            object = this.decodeUtf8String(byteLength, 0);
                          }
                        } else if (headByte === 192) {
                          object = null;
                        } else if (headByte === 194) {
                          object = false;
                        } else if (headByte === 195) {
                          object = true;
                        } else if (headByte === 202) {
                          object = this.readF32();
                        } else if (headByte === 203) {
                          object = this.readF64();
                        } else if (headByte === 204) {
                          object = this.readU8();
                        } else if (headByte === 205) {
                          object = this.readU16();
                        } else if (headByte === 206) {
                          object = this.readU32();
                        } else if (headByte === 207) {
                          object = this.readU64();
                        } else if (headByte === 208) {
                          object = this.readI8();
                        } else if (headByte === 209) {
                          object = this.readI16();
                        } else if (headByte === 210) {
                          object = this.readI32();
                        } else if (headByte === 211) {
                          object = this.readI64();
                        } else if (headByte === 217) {
                          var byteLength = this.lookU8();
                          object = this.decodeUtf8String(byteLength, 1);
                        } else if (headByte === 218) {
                          var byteLength = this.lookU16();
                          object = this.decodeUtf8String(byteLength, 2);
                        } else if (headByte === 219) {
                          var byteLength = this.lookU32();
                          object = this.decodeUtf8String(byteLength, 4);
                        } else if (headByte === 220) {
                          var size = this.readU16();
                          if (size !== 0) {
                            this.pushArrayState(size);
                            this.complete();
                            continue DECODE;
                          } else {
                            object = [];
                          }
                        } else if (headByte === 221) {
                          var size = this.readU32();
                          if (size !== 0) {
                            this.pushArrayState(size);
                            this.complete();
                            continue DECODE;
                          } else {
                            object = [];
                          }
                        } else if (headByte === 222) {
                          var size = this.readU16();
                          if (size !== 0) {
                            this.pushMapState(size);
                            this.complete();
                            continue DECODE;
                          } else {
                            object = {};
                          }
                        } else if (headByte === 223) {
                          var size = this.readU32();
                          if (size !== 0) {
                            this.pushMapState(size);
                            this.complete();
                            continue DECODE;
                          } else {
                            object = {};
                          }
                        } else if (headByte === 196) {
                          var size = this.lookU8();
                          object = this.decodeBinary(size, 1);
                        } else if (headByte === 197) {
                          var size = this.lookU16();
                          object = this.decodeBinary(size, 2);
                        } else if (headByte === 198) {
                          var size = this.lookU32();
                          object = this.decodeBinary(size, 4);
                        } else if (headByte === 212) {
                          object = this.decodeExtension(1, 0);
                        } else if (headByte === 213) {
                          object = this.decodeExtension(2, 0);
                        } else if (headByte === 214) {
                          object = this.decodeExtension(4, 0);
                        } else if (headByte === 215) {
                          object = this.decodeExtension(8, 0);
                        } else if (headByte === 216) {
                          object = this.decodeExtension(16, 0);
                        } else if (headByte === 199) {
                          var size = this.lookU8();
                          object = this.decodeExtension(size, 1);
                        } else if (headByte === 200) {
                          var size = this.lookU16();
                          object = this.decodeExtension(size, 2);
                        } else if (headByte === 201) {
                          var size = this.lookU32();
                          object = this.decodeExtension(size, 4);
                        } else {
                          throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Unrecognized type byte: ".concat((0, _utils_prettyByte_mjs__WEBPACK_IMPORTED_MODULE_4__.prettyByte)(headByte)));
                        }
                        this.complete();
                        var stack = this.stack;
                        while (stack.length > 0) {
                          var state = stack[stack.length - 1];
                          if (state.type === 0) {
                            state.array[state.position] = object;
                            state.position++;
                            if (state.position === state.size) {
                              stack.pop();
                              object = state.array;
                            } else {
                              continue DECODE;
                            }
                          } else if (state.type === 1) {
                            if (!isValidMapKeyType(object)) {
                              throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("The type of key must be string or number but " + typeof object);
                            }
                            if (object === "__proto__") {
                              throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("The key __proto__ is not allowed");
                            }
                            state.key = object;
                            state.type = 2;
                            continue DECODE;
                          } else {
                            state.map[state.key] = object;
                            state.readCount++;
                            if (state.readCount === state.size) {
                              stack.pop();
                              object = state.map;
                            } else {
                              state.key = null;
                              state.type = 1;
                              continue DECODE;
                            }
                          }
                        }
                        return object;
                      }
                    };
                    Decoder2.prototype.readHeadByte = function() {
                      if (this.headByte === HEAD_BYTE_REQUIRED) {
                        this.headByte = this.readU8();
                      }
                      return this.headByte;
                    };
                    Decoder2.prototype.complete = function() {
                      this.headByte = HEAD_BYTE_REQUIRED;
                    };
                    Decoder2.prototype.readArraySize = function() {
                      var headByte = this.readHeadByte();
                      switch (headByte) {
                        case 220:
                          return this.readU16();
                        case 221:
                          return this.readU32();
                        default: {
                          if (headByte < 160) {
                            return headByte - 144;
                          } else {
                            throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Unrecognized array type byte: ".concat((0, _utils_prettyByte_mjs__WEBPACK_IMPORTED_MODULE_4__.prettyByte)(headByte)));
                          }
                        }
                      }
                    };
                    Decoder2.prototype.pushMapState = function(size) {
                      if (size > this.maxMapLength) {
                        throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Max length exceeded: map length (".concat(size, ") > maxMapLengthLength (").concat(this.maxMapLength, ")"));
                      }
                      this.stack.push({
                        type: 1,
                        size,
                        key: null,
                        readCount: 0,
                        map: {}
                      });
                    };
                    Decoder2.prototype.pushArrayState = function(size) {
                      if (size > this.maxArrayLength) {
                        throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Max length exceeded: array length (".concat(size, ") > maxArrayLength (").concat(this.maxArrayLength, ")"));
                      }
                      this.stack.push({
                        type: 0,
                        size,
                        array: new Array(size),
                        position: 0
                      });
                    };
                    Decoder2.prototype.decodeUtf8String = function(byteLength, headerOffset) {
                      var _a;
                      if (byteLength > this.maxStrLength) {
                        throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Max length exceeded: UTF-8 byte length (".concat(byteLength, ") > maxStrLength (").concat(this.maxStrLength, ")"));
                      }
                      if (this.bytes.byteLength < this.pos + headerOffset + byteLength) {
                        throw MORE_DATA;
                      }
                      var offset = this.pos + headerOffset;
                      var object;
                      if (this.stateIsMapKey() && ((_a = this.keyDecoder) === null || _a === void 0 ? void 0 : _a.canBeCached(byteLength))) {
                        object = this.keyDecoder.decode(this.bytes, offset, byteLength);
                      } else if (byteLength > _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_6__.TEXT_DECODER_THRESHOLD) {
                        object = (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_6__.utf8DecodeTD)(this.bytes, offset, byteLength);
                      } else {
                        object = (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_6__.utf8DecodeJs)(this.bytes, offset, byteLength);
                      }
                      this.pos += headerOffset + byteLength;
                      return object;
                    };
                    Decoder2.prototype.stateIsMapKey = function() {
                      if (this.stack.length > 0) {
                        var state = this.stack[this.stack.length - 1];
                        return state.type === 1;
                      }
                      return false;
                    };
                    Decoder2.prototype.decodeBinary = function(byteLength, headOffset) {
                      if (byteLength > this.maxBinLength) {
                        throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Max length exceeded: bin length (".concat(byteLength, ") > maxBinLength (").concat(this.maxBinLength, ")"));
                      }
                      if (!this.hasRemaining(byteLength + headOffset)) {
                        throw MORE_DATA;
                      }
                      var offset = this.pos + headOffset;
                      var object = this.bytes.subarray(offset, offset + byteLength);
                      this.pos += headOffset + byteLength;
                      return object;
                    };
                    Decoder2.prototype.decodeExtension = function(size, headOffset) {
                      if (size > this.maxExtLength) {
                        throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_5__.DecodeError("Max length exceeded: ext length (".concat(size, ") > maxExtLength (").concat(this.maxExtLength, ")"));
                      }
                      var extType = this.view.getInt8(this.pos + headOffset);
                      var data = this.decodeBinary(
                        size,
                        headOffset + 1
                        /* extType */
                      );
                      return this.extensionCodec.decode(data, extType, this.context);
                    };
                    Decoder2.prototype.lookU8 = function() {
                      return this.view.getUint8(this.pos);
                    };
                    Decoder2.prototype.lookU16 = function() {
                      return this.view.getUint16(this.pos);
                    };
                    Decoder2.prototype.lookU32 = function() {
                      return this.view.getUint32(this.pos);
                    };
                    Decoder2.prototype.readU8 = function() {
                      var value = this.view.getUint8(this.pos);
                      this.pos++;
                      return value;
                    };
                    Decoder2.prototype.readI8 = function() {
                      var value = this.view.getInt8(this.pos);
                      this.pos++;
                      return value;
                    };
                    Decoder2.prototype.readU16 = function() {
                      var value = this.view.getUint16(this.pos);
                      this.pos += 2;
                      return value;
                    };
                    Decoder2.prototype.readI16 = function() {
                      var value = this.view.getInt16(this.pos);
                      this.pos += 2;
                      return value;
                    };
                    Decoder2.prototype.readU32 = function() {
                      var value = this.view.getUint32(this.pos);
                      this.pos += 4;
                      return value;
                    };
                    Decoder2.prototype.readI32 = function() {
                      var value = this.view.getInt32(this.pos);
                      this.pos += 4;
                      return value;
                    };
                    Decoder2.prototype.readU64 = function() {
                      var value = (0, _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.getUint64)(this.view, this.pos);
                      this.pos += 8;
                      return value;
                    };
                    Decoder2.prototype.readI64 = function() {
                      var value = (0, _utils_int_mjs__WEBPACK_IMPORTED_MODULE_2__.getInt64)(this.view, this.pos);
                      this.pos += 8;
                      return value;
                    };
                    Decoder2.prototype.readF32 = function() {
                      var value = this.view.getFloat32(this.pos);
                      this.pos += 4;
                      return value;
                    };
                    Decoder2.prototype.readF64 = function() {
                      var value = this.view.getFloat64(this.pos);
                      this.pos += 8;
                      return value;
                    };
                    return Decoder2;
                  }()
                );
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/Encoder.mjs": (
              /*!****************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/Encoder.mjs ***!
                \****************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  DEFAULT_INITIAL_BUFFER_SIZE: () => (
                    /* binding */
                    DEFAULT_INITIAL_BUFFER_SIZE
                  ),
                  /* harmony export */
                  DEFAULT_MAX_DEPTH: () => (
                    /* binding */
                    DEFAULT_MAX_DEPTH
                  ),
                  /* harmony export */
                  Encoder: () => (
                    /* binding */
                    Encoder
                  )
                  /* harmony export */
                });
                var _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__2(
                  /*! ./utils/utf8.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/utf8.mjs"
                );
                var _ExtensionCodec_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./ExtensionCodec.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/ExtensionCodec.mjs"
                );
                var _utils_int_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__2(
                  /*! ./utils/int.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/int.mjs"
                );
                var _utils_typedArrays_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__2(
                  /*! ./utils/typedArrays.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/typedArrays.mjs"
                );
                var DEFAULT_MAX_DEPTH = 100;
                var DEFAULT_INITIAL_BUFFER_SIZE = 2048;
                var Encoder = (
                  /** @class */
                  function() {
                    function Encoder2(extensionCodec, context2, maxDepth, initialBufferSize, sortKeys, forceFloat32, ignoreUndefined, forceIntegerToFloat) {
                      if (extensionCodec === void 0) {
                        extensionCodec = _ExtensionCodec_mjs__WEBPACK_IMPORTED_MODULE_0__.ExtensionCodec.defaultCodec;
                      }
                      if (context2 === void 0) {
                        context2 = void 0;
                      }
                      if (maxDepth === void 0) {
                        maxDepth = DEFAULT_MAX_DEPTH;
                      }
                      if (initialBufferSize === void 0) {
                        initialBufferSize = DEFAULT_INITIAL_BUFFER_SIZE;
                      }
                      if (sortKeys === void 0) {
                        sortKeys = false;
                      }
                      if (forceFloat32 === void 0) {
                        forceFloat32 = false;
                      }
                      if (ignoreUndefined === void 0) {
                        ignoreUndefined = false;
                      }
                      if (forceIntegerToFloat === void 0) {
                        forceIntegerToFloat = false;
                      }
                      this.extensionCodec = extensionCodec;
                      this.context = context2;
                      this.maxDepth = maxDepth;
                      this.initialBufferSize = initialBufferSize;
                      this.sortKeys = sortKeys;
                      this.forceFloat32 = forceFloat32;
                      this.ignoreUndefined = ignoreUndefined;
                      this.forceIntegerToFloat = forceIntegerToFloat;
                      this.pos = 0;
                      this.view = new DataView(new ArrayBuffer(this.initialBufferSize));
                      this.bytes = new Uint8Array(this.view.buffer);
                    }
                    Encoder2.prototype.reinitializeState = function() {
                      this.pos = 0;
                    };
                    Encoder2.prototype.encodeSharedRef = function(object) {
                      this.reinitializeState();
                      this.doEncode(object, 1);
                      return this.bytes.subarray(0, this.pos);
                    };
                    Encoder2.prototype.encode = function(object) {
                      this.reinitializeState();
                      this.doEncode(object, 1);
                      return this.bytes.slice(0, this.pos);
                    };
                    Encoder2.prototype.doEncode = function(object, depth) {
                      if (depth > this.maxDepth) {
                        throw new Error("Too deep objects in depth ".concat(depth));
                      }
                      if (object == null) {
                        this.encodeNil();
                      } else if (typeof object === "boolean") {
                        this.encodeBoolean(object);
                      } else if (typeof object === "number") {
                        this.encodeNumber(object);
                      } else if (typeof object === "string") {
                        this.encodeString(object);
                      } else {
                        this.encodeObject(object, depth);
                      }
                    };
                    Encoder2.prototype.ensureBufferSizeToWrite = function(sizeToWrite) {
                      var requiredSize = this.pos + sizeToWrite;
                      if (this.view.byteLength < requiredSize) {
                        this.resizeBuffer(requiredSize * 2);
                      }
                    };
                    Encoder2.prototype.resizeBuffer = function(newSize) {
                      var newBuffer = new ArrayBuffer(newSize);
                      var newBytes = new Uint8Array(newBuffer);
                      var newView = new DataView(newBuffer);
                      newBytes.set(this.bytes);
                      this.view = newView;
                      this.bytes = newBytes;
                    };
                    Encoder2.prototype.encodeNil = function() {
                      this.writeU8(192);
                    };
                    Encoder2.prototype.encodeBoolean = function(object) {
                      if (object === false) {
                        this.writeU8(194);
                      } else {
                        this.writeU8(195);
                      }
                    };
                    Encoder2.prototype.encodeNumber = function(object) {
                      if (Number.isSafeInteger(object) && !this.forceIntegerToFloat) {
                        if (object >= 0) {
                          if (object < 128) {
                            this.writeU8(object);
                          } else if (object < 256) {
                            this.writeU8(204);
                            this.writeU8(object);
                          } else if (object < 65536) {
                            this.writeU8(205);
                            this.writeU16(object);
                          } else if (object < 4294967296) {
                            this.writeU8(206);
                            this.writeU32(object);
                          } else {
                            this.writeU8(207);
                            this.writeU64(object);
                          }
                        } else {
                          if (object >= -32) {
                            this.writeU8(224 | object + 32);
                          } else if (object >= -128) {
                            this.writeU8(208);
                            this.writeI8(object);
                          } else if (object >= -32768) {
                            this.writeU8(209);
                            this.writeI16(object);
                          } else if (object >= -2147483648) {
                            this.writeU8(210);
                            this.writeI32(object);
                          } else {
                            this.writeU8(211);
                            this.writeI64(object);
                          }
                        }
                      } else {
                        if (this.forceFloat32) {
                          this.writeU8(202);
                          this.writeF32(object);
                        } else {
                          this.writeU8(203);
                          this.writeF64(object);
                        }
                      }
                    };
                    Encoder2.prototype.writeStringHeader = function(byteLength) {
                      if (byteLength < 32) {
                        this.writeU8(160 + byteLength);
                      } else if (byteLength < 256) {
                        this.writeU8(217);
                        this.writeU8(byteLength);
                      } else if (byteLength < 65536) {
                        this.writeU8(218);
                        this.writeU16(byteLength);
                      } else if (byteLength < 4294967296) {
                        this.writeU8(219);
                        this.writeU32(byteLength);
                      } else {
                        throw new Error("Too long string: ".concat(byteLength, " bytes in UTF-8"));
                      }
                    };
                    Encoder2.prototype.encodeString = function(object) {
                      var maxHeaderSize = 1 + 4;
                      var strLength = object.length;
                      if (strLength > _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_1__.TEXT_ENCODER_THRESHOLD) {
                        var byteLength = (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_1__.utf8Count)(object);
                        this.ensureBufferSizeToWrite(maxHeaderSize + byteLength);
                        this.writeStringHeader(byteLength);
                        (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_1__.utf8EncodeTE)(object, this.bytes, this.pos);
                        this.pos += byteLength;
                      } else {
                        var byteLength = (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_1__.utf8Count)(object);
                        this.ensureBufferSizeToWrite(maxHeaderSize + byteLength);
                        this.writeStringHeader(byteLength);
                        (0, _utils_utf8_mjs__WEBPACK_IMPORTED_MODULE_1__.utf8EncodeJs)(object, this.bytes, this.pos);
                        this.pos += byteLength;
                      }
                    };
                    Encoder2.prototype.encodeObject = function(object, depth) {
                      var ext = this.extensionCodec.tryToEncode(object, this.context);
                      if (ext != null) {
                        this.encodeExtension(ext);
                      } else if (Array.isArray(object)) {
                        this.encodeArray(object, depth);
                      } else if (ArrayBuffer.isView(object)) {
                        this.encodeBinary(object);
                      } else if (typeof object === "object") {
                        this.encodeMap(object, depth);
                      } else {
                        throw new Error("Unrecognized object: ".concat(Object.prototype.toString.apply(object)));
                      }
                    };
                    Encoder2.prototype.encodeBinary = function(object) {
                      var size = object.byteLength;
                      if (size < 256) {
                        this.writeU8(196);
                        this.writeU8(size);
                      } else if (size < 65536) {
                        this.writeU8(197);
                        this.writeU16(size);
                      } else if (size < 4294967296) {
                        this.writeU8(198);
                        this.writeU32(size);
                      } else {
                        throw new Error("Too large binary: ".concat(size));
                      }
                      var bytes = (0, _utils_typedArrays_mjs__WEBPACK_IMPORTED_MODULE_2__.ensureUint8Array)(object);
                      this.writeU8a(bytes);
                    };
                    Encoder2.prototype.encodeArray = function(object, depth) {
                      var size = object.length;
                      if (size < 16) {
                        this.writeU8(144 + size);
                      } else if (size < 65536) {
                        this.writeU8(220);
                        this.writeU16(size);
                      } else if (size < 4294967296) {
                        this.writeU8(221);
                        this.writeU32(size);
                      } else {
                        throw new Error("Too large array: ".concat(size));
                      }
                      for (var _i = 0, object_1 = object; _i < object_1.length; _i++) {
                        var item = object_1[_i];
                        this.doEncode(item, depth + 1);
                      }
                    };
                    Encoder2.prototype.countWithoutUndefined = function(object, keys) {
                      var count = 0;
                      for (var _i = 0, keys_1 = keys; _i < keys_1.length; _i++) {
                        var key = keys_1[_i];
                        if (object[key] !== void 0) {
                          count++;
                        }
                      }
                      return count;
                    };
                    Encoder2.prototype.encodeMap = function(object, depth) {
                      var keys = Object.keys(object);
                      if (this.sortKeys) {
                        keys.sort();
                      }
                      var size = this.ignoreUndefined ? this.countWithoutUndefined(object, keys) : keys.length;
                      if (size < 16) {
                        this.writeU8(128 + size);
                      } else if (size < 65536) {
                        this.writeU8(222);
                        this.writeU16(size);
                      } else if (size < 4294967296) {
                        this.writeU8(223);
                        this.writeU32(size);
                      } else {
                        throw new Error("Too large map object: ".concat(size));
                      }
                      for (var _i = 0, keys_2 = keys; _i < keys_2.length; _i++) {
                        var key = keys_2[_i];
                        var value = object[key];
                        if (!(this.ignoreUndefined && value === void 0)) {
                          this.encodeString(key);
                          this.doEncode(value, depth + 1);
                        }
                      }
                    };
                    Encoder2.prototype.encodeExtension = function(ext) {
                      var size = ext.data.length;
                      if (size === 1) {
                        this.writeU8(212);
                      } else if (size === 2) {
                        this.writeU8(213);
                      } else if (size === 4) {
                        this.writeU8(214);
                      } else if (size === 8) {
                        this.writeU8(215);
                      } else if (size === 16) {
                        this.writeU8(216);
                      } else if (size < 256) {
                        this.writeU8(199);
                        this.writeU8(size);
                      } else if (size < 65536) {
                        this.writeU8(200);
                        this.writeU16(size);
                      } else if (size < 4294967296) {
                        this.writeU8(201);
                        this.writeU32(size);
                      } else {
                        throw new Error("Too large extension object: ".concat(size));
                      }
                      this.writeI8(ext.type);
                      this.writeU8a(ext.data);
                    };
                    Encoder2.prototype.writeU8 = function(value) {
                      this.ensureBufferSizeToWrite(1);
                      this.view.setUint8(this.pos, value);
                      this.pos++;
                    };
                    Encoder2.prototype.writeU8a = function(values) {
                      var size = values.length;
                      this.ensureBufferSizeToWrite(size);
                      this.bytes.set(values, this.pos);
                      this.pos += size;
                    };
                    Encoder2.prototype.writeI8 = function(value) {
                      this.ensureBufferSizeToWrite(1);
                      this.view.setInt8(this.pos, value);
                      this.pos++;
                    };
                    Encoder2.prototype.writeU16 = function(value) {
                      this.ensureBufferSizeToWrite(2);
                      this.view.setUint16(this.pos, value);
                      this.pos += 2;
                    };
                    Encoder2.prototype.writeI16 = function(value) {
                      this.ensureBufferSizeToWrite(2);
                      this.view.setInt16(this.pos, value);
                      this.pos += 2;
                    };
                    Encoder2.prototype.writeU32 = function(value) {
                      this.ensureBufferSizeToWrite(4);
                      this.view.setUint32(this.pos, value);
                      this.pos += 4;
                    };
                    Encoder2.prototype.writeI32 = function(value) {
                      this.ensureBufferSizeToWrite(4);
                      this.view.setInt32(this.pos, value);
                      this.pos += 4;
                    };
                    Encoder2.prototype.writeF32 = function(value) {
                      this.ensureBufferSizeToWrite(4);
                      this.view.setFloat32(this.pos, value);
                      this.pos += 4;
                    };
                    Encoder2.prototype.writeF64 = function(value) {
                      this.ensureBufferSizeToWrite(8);
                      this.view.setFloat64(this.pos, value);
                      this.pos += 8;
                    };
                    Encoder2.prototype.writeU64 = function(value) {
                      this.ensureBufferSizeToWrite(8);
                      (0, _utils_int_mjs__WEBPACK_IMPORTED_MODULE_3__.setUint64)(this.view, this.pos, value);
                      this.pos += 8;
                    };
                    Encoder2.prototype.writeI64 = function(value) {
                      this.ensureBufferSizeToWrite(8);
                      (0, _utils_int_mjs__WEBPACK_IMPORTED_MODULE_3__.setInt64)(this.view, this.pos, value);
                      this.pos += 8;
                    };
                    return Encoder2;
                  }()
                );
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/ExtData.mjs": (
              /*!****************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/ExtData.mjs ***!
                \****************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  ExtData: () => (
                    /* binding */
                    ExtData
                  )
                  /* harmony export */
                });
                var ExtData = (
                  /** @class */
                  /* @__PURE__ */ function() {
                    function ExtData2(type2, data) {
                      this.type = type2;
                      this.data = data;
                    }
                    return ExtData2;
                  }()
                );
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/ExtensionCodec.mjs": (
              /*!***********************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/ExtensionCodec.mjs ***!
                \***********************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  ExtensionCodec: () => (
                    /* binding */
                    ExtensionCodec
                  )
                  /* harmony export */
                });
                var _ExtData_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__2(
                  /*! ./ExtData.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/ExtData.mjs"
                );
                var _timestamp_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./timestamp.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/timestamp.mjs"
                );
                var ExtensionCodec = (
                  /** @class */
                  function() {
                    function ExtensionCodec2() {
                      this.builtInEncoders = [];
                      this.builtInDecoders = [];
                      this.encoders = [];
                      this.decoders = [];
                      this.register(_timestamp_mjs__WEBPACK_IMPORTED_MODULE_0__.timestampExtension);
                    }
                    ExtensionCodec2.prototype.register = function(_a) {
                      var type2 = _a.type, encode = _a.encode, decode = _a.decode;
                      if (type2 >= 0) {
                        this.encoders[type2] = encode;
                        this.decoders[type2] = decode;
                      } else {
                        var index = 1 + type2;
                        this.builtInEncoders[index] = encode;
                        this.builtInDecoders[index] = decode;
                      }
                    };
                    ExtensionCodec2.prototype.tryToEncode = function(object, context2) {
                      for (var i = 0; i < this.builtInEncoders.length; i++) {
                        var encodeExt = this.builtInEncoders[i];
                        if (encodeExt != null) {
                          var data = encodeExt(object, context2);
                          if (data != null) {
                            var type2 = -1 - i;
                            return new _ExtData_mjs__WEBPACK_IMPORTED_MODULE_1__.ExtData(type2, data);
                          }
                        }
                      }
                      for (var i = 0; i < this.encoders.length; i++) {
                        var encodeExt = this.encoders[i];
                        if (encodeExt != null) {
                          var data = encodeExt(object, context2);
                          if (data != null) {
                            var type2 = i;
                            return new _ExtData_mjs__WEBPACK_IMPORTED_MODULE_1__.ExtData(type2, data);
                          }
                        }
                      }
                      if (object instanceof _ExtData_mjs__WEBPACK_IMPORTED_MODULE_1__.ExtData) {
                        return object;
                      }
                      return null;
                    };
                    ExtensionCodec2.prototype.decode = function(data, type2, context2) {
                      var decodeExt = type2 < 0 ? this.builtInDecoders[-1 - type2] : this.decoders[type2];
                      if (decodeExt) {
                        return decodeExt(data, type2, context2);
                      } else {
                        return new _ExtData_mjs__WEBPACK_IMPORTED_MODULE_1__.ExtData(type2, data);
                      }
                    };
                    ExtensionCodec2.defaultCodec = new ExtensionCodec2();
                    return ExtensionCodec2;
                  }()
                );
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/decode.mjs": (
              /*!***************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/decode.mjs ***!
                \***************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  decode: () => (
                    /* binding */
                    decode
                  ),
                  /* harmony export */
                  decodeMulti: () => (
                    /* binding */
                    decodeMulti
                  ),
                  /* harmony export */
                  defaultDecodeOptions: () => (
                    /* binding */
                    defaultDecodeOptions
                  )
                  /* harmony export */
                });
                var _Decoder_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./Decoder.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/Decoder.mjs"
                );
                var defaultDecodeOptions = {};
                function decode(buffer, options) {
                  if (options === void 0) {
                    options = defaultDecodeOptions;
                  }
                  var decoder = new _Decoder_mjs__WEBPACK_IMPORTED_MODULE_0__.Decoder(options.extensionCodec, options.context, options.maxStrLength, options.maxBinLength, options.maxArrayLength, options.maxMapLength, options.maxExtLength);
                  return decoder.decode(buffer);
                }
                function decodeMulti(buffer, options) {
                  if (options === void 0) {
                    options = defaultDecodeOptions;
                  }
                  var decoder = new _Decoder_mjs__WEBPACK_IMPORTED_MODULE_0__.Decoder(options.extensionCodec, options.context, options.maxStrLength, options.maxBinLength, options.maxArrayLength, options.maxMapLength, options.maxExtLength);
                  return decoder.decodeMulti(buffer);
                }
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/encode.mjs": (
              /*!***************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/encode.mjs ***!
                \***************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  encode: () => (
                    /* binding */
                    encode
                  )
                  /* harmony export */
                });
                var _Encoder_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./Encoder.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/Encoder.mjs"
                );
                var defaultEncodeOptions = {};
                function encode(value, options) {
                  if (options === void 0) {
                    options = defaultEncodeOptions;
                  }
                  var encoder = new _Encoder_mjs__WEBPACK_IMPORTED_MODULE_0__.Encoder(options.extensionCodec, options.context, options.maxDepth, options.initialBufferSize, options.sortKeys, options.forceFloat32, options.ignoreUndefined, options.forceIntegerToFloat);
                  return encoder.encodeSharedRef(value);
                }
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/timestamp.mjs": (
              /*!******************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/timestamp.mjs ***!
                \******************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  EXT_TIMESTAMP: () => (
                    /* binding */
                    EXT_TIMESTAMP
                  ),
                  /* harmony export */
                  decodeTimestampExtension: () => (
                    /* binding */
                    decodeTimestampExtension
                  ),
                  /* harmony export */
                  decodeTimestampToTimeSpec: () => (
                    /* binding */
                    decodeTimestampToTimeSpec
                  ),
                  /* harmony export */
                  encodeDateToTimeSpec: () => (
                    /* binding */
                    encodeDateToTimeSpec
                  ),
                  /* harmony export */
                  encodeTimeSpecToTimestamp: () => (
                    /* binding */
                    encodeTimeSpecToTimestamp
                  ),
                  /* harmony export */
                  encodeTimestampExtension: () => (
                    /* binding */
                    encodeTimestampExtension
                  ),
                  /* harmony export */
                  timestampExtension: () => (
                    /* binding */
                    timestampExtension
                  )
                  /* harmony export */
                });
                var _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__2(
                  /*! ./DecodeError.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/DecodeError.mjs"
                );
                var _utils_int_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./utils/int.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/int.mjs"
                );
                var EXT_TIMESTAMP = -1;
                var TIMESTAMP32_MAX_SEC = 4294967296 - 1;
                var TIMESTAMP64_MAX_SEC = 17179869184 - 1;
                function encodeTimeSpecToTimestamp(_a) {
                  var sec = _a.sec, nsec = _a.nsec;
                  if (sec >= 0 && nsec >= 0 && sec <= TIMESTAMP64_MAX_SEC) {
                    if (nsec === 0 && sec <= TIMESTAMP32_MAX_SEC) {
                      var rv = new Uint8Array(4);
                      var view = new DataView(rv.buffer);
                      view.setUint32(0, sec);
                      return rv;
                    } else {
                      var secHigh = sec / 4294967296;
                      var secLow = sec & 4294967295;
                      var rv = new Uint8Array(8);
                      var view = new DataView(rv.buffer);
                      view.setUint32(0, nsec << 2 | secHigh & 3);
                      view.setUint32(4, secLow);
                      return rv;
                    }
                  } else {
                    var rv = new Uint8Array(12);
                    var view = new DataView(rv.buffer);
                    view.setUint32(0, nsec);
                    (0, _utils_int_mjs__WEBPACK_IMPORTED_MODULE_0__.setInt64)(view, 4, sec);
                    return rv;
                  }
                }
                function encodeDateToTimeSpec(date) {
                  var msec = date.getTime();
                  var sec = Math.floor(msec / 1e3);
                  var nsec = (msec - sec * 1e3) * 1e6;
                  var nsecInSec = Math.floor(nsec / 1e9);
                  return {
                    sec: sec + nsecInSec,
                    nsec: nsec - nsecInSec * 1e9
                  };
                }
                function encodeTimestampExtension(object) {
                  if (object instanceof Date) {
                    var timeSpec = encodeDateToTimeSpec(object);
                    return encodeTimeSpecToTimestamp(timeSpec);
                  } else {
                    return null;
                  }
                }
                function decodeTimestampToTimeSpec(data) {
                  var view = new DataView(data.buffer, data.byteOffset, data.byteLength);
                  switch (data.byteLength) {
                    case 4: {
                      var sec = view.getUint32(0);
                      var nsec = 0;
                      return { sec, nsec };
                    }
                    case 8: {
                      var nsec30AndSecHigh2 = view.getUint32(0);
                      var secLow32 = view.getUint32(4);
                      var sec = (nsec30AndSecHigh2 & 3) * 4294967296 + secLow32;
                      var nsec = nsec30AndSecHigh2 >>> 2;
                      return { sec, nsec };
                    }
                    case 12: {
                      var sec = (0, _utils_int_mjs__WEBPACK_IMPORTED_MODULE_0__.getInt64)(view, 4);
                      var nsec = view.getUint32(0);
                      return { sec, nsec };
                    }
                    default:
                      throw new _DecodeError_mjs__WEBPACK_IMPORTED_MODULE_1__.DecodeError("Unrecognized data size for timestamp (expected 4, 8, or 12): ".concat(data.length));
                  }
                }
                function decodeTimestampExtension(data) {
                  var timeSpec = decodeTimestampToTimeSpec(data);
                  return new Date(timeSpec.sec * 1e3 + timeSpec.nsec / 1e6);
                }
                var timestampExtension = {
                  type: EXT_TIMESTAMP,
                  encode: encodeTimestampExtension,
                  decode: decodeTimestampExtension
                };
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/int.mjs": (
              /*!******************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/utils/int.mjs ***!
                \******************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  UINT32_MAX: () => (
                    /* binding */
                    UINT32_MAX
                  ),
                  /* harmony export */
                  getInt64: () => (
                    /* binding */
                    getInt64
                  ),
                  /* harmony export */
                  getUint64: () => (
                    /* binding */
                    getUint64
                  ),
                  /* harmony export */
                  setInt64: () => (
                    /* binding */
                    setInt64
                  ),
                  /* harmony export */
                  setUint64: () => (
                    /* binding */
                    setUint64
                  )
                  /* harmony export */
                });
                var UINT32_MAX = 4294967295;
                function setUint64(view, offset, value) {
                  var high = value / 4294967296;
                  var low = value;
                  view.setUint32(offset, high);
                  view.setUint32(offset + 4, low);
                }
                function setInt64(view, offset, value) {
                  var high = Math.floor(value / 4294967296);
                  var low = value;
                  view.setUint32(offset, high);
                  view.setUint32(offset + 4, low);
                }
                function getInt64(view, offset) {
                  var high = view.getInt32(offset);
                  var low = view.getUint32(offset + 4);
                  return high * 4294967296 + low;
                }
                function getUint64(view, offset) {
                  var high = view.getUint32(offset);
                  var low = view.getUint32(offset + 4);
                  return high * 4294967296 + low;
                }
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/prettyByte.mjs": (
              /*!*************************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/utils/prettyByte.mjs ***!
                \*************************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  prettyByte: () => (
                    /* binding */
                    prettyByte
                  )
                  /* harmony export */
                });
                function prettyByte(byte) {
                  return "".concat(byte < 0 ? "-" : "", "0x").concat(Math.abs(byte).toString(16).padStart(2, "0"));
                }
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/typedArrays.mjs": (
              /*!**************************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/utils/typedArrays.mjs ***!
                \**************************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  createDataView: () => (
                    /* binding */
                    createDataView
                  ),
                  /* harmony export */
                  ensureUint8Array: () => (
                    /* binding */
                    ensureUint8Array
                  )
                  /* harmony export */
                });
                function ensureUint8Array(buffer) {
                  if (buffer instanceof Uint8Array) {
                    return buffer;
                  } else if (ArrayBuffer.isView(buffer)) {
                    return new Uint8Array(buffer.buffer, buffer.byteOffset, buffer.byteLength);
                  } else if (buffer instanceof ArrayBuffer) {
                    return new Uint8Array(buffer);
                  } else {
                    return Uint8Array.from(buffer);
                  }
                }
                function createDataView(buffer) {
                  if (buffer instanceof ArrayBuffer) {
                    return new DataView(buffer);
                  }
                  var bufferView = ensureUint8Array(buffer);
                  return new DataView(bufferView.buffer, bufferView.byteOffset, bufferView.byteLength);
                }
              }
            ),
            /***/
            "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/utf8.mjs": (
              /*!*******************************************************************!*\
                !*** ./node_modules/@msgpack/msgpack/dist.es5+esm/utils/utf8.mjs ***!
                \*******************************************************************/
              /***/
              (__unused_webpack___webpack_module__, __webpack_exports__2, __webpack_require__2) => {
                __webpack_require__2.r(__webpack_exports__2);
                __webpack_require__2.d(__webpack_exports__2, {
                  /* harmony export */
                  TEXT_DECODER_THRESHOLD: () => (
                    /* binding */
                    TEXT_DECODER_THRESHOLD
                  ),
                  /* harmony export */
                  TEXT_ENCODER_THRESHOLD: () => (
                    /* binding */
                    TEXT_ENCODER_THRESHOLD
                  ),
                  /* harmony export */
                  utf8Count: () => (
                    /* binding */
                    utf8Count
                  ),
                  /* harmony export */
                  utf8DecodeJs: () => (
                    /* binding */
                    utf8DecodeJs
                  ),
                  /* harmony export */
                  utf8DecodeTD: () => (
                    /* binding */
                    utf8DecodeTD
                  ),
                  /* harmony export */
                  utf8EncodeJs: () => (
                    /* binding */
                    utf8EncodeJs
                  ),
                  /* harmony export */
                  utf8EncodeTE: () => (
                    /* binding */
                    utf8EncodeTE
                  )
                  /* harmony export */
                });
                var _int_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__2(
                  /*! ./int.mjs */
                  "./node_modules/@msgpack/msgpack/dist.es5+esm/utils/int.mjs"
                );
                var _a, _b, _c;
                var TEXT_ENCODING_AVAILABLE = (typeof process === "undefined" || ((_a = process === null || process === void 0 ? void 0 : process.env) === null || _a === void 0 ? void 0 : _a["TEXT_ENCODING"]) !== "never") && typeof TextEncoder !== "undefined" && typeof TextDecoder !== "undefined";
                function utf8Count(str) {
                  var strLength = str.length;
                  var byteLength = 0;
                  var pos = 0;
                  while (pos < strLength) {
                    var value = str.charCodeAt(pos++);
                    if ((value & 4294967168) === 0) {
                      byteLength++;
                      continue;
                    } else if ((value & 4294965248) === 0) {
                      byteLength += 2;
                    } else {
                      if (value >= 55296 && value <= 56319) {
                        if (pos < strLength) {
                          var extra = str.charCodeAt(pos);
                          if ((extra & 64512) === 56320) {
                            ++pos;
                            value = ((value & 1023) << 10) + (extra & 1023) + 65536;
                          }
                        }
                      }
                      if ((value & 4294901760) === 0) {
                        byteLength += 3;
                      } else {
                        byteLength += 4;
                      }
                    }
                  }
                  return byteLength;
                }
                function utf8EncodeJs(str, output, outputOffset) {
                  var strLength = str.length;
                  var offset = outputOffset;
                  var pos = 0;
                  while (pos < strLength) {
                    var value = str.charCodeAt(pos++);
                    if ((value & 4294967168) === 0) {
                      output[offset++] = value;
                      continue;
                    } else if ((value & 4294965248) === 0) {
                      output[offset++] = value >> 6 & 31 | 192;
                    } else {
                      if (value >= 55296 && value <= 56319) {
                        if (pos < strLength) {
                          var extra = str.charCodeAt(pos);
                          if ((extra & 64512) === 56320) {
                            ++pos;
                            value = ((value & 1023) << 10) + (extra & 1023) + 65536;
                          }
                        }
                      }
                      if ((value & 4294901760) === 0) {
                        output[offset++] = value >> 12 & 15 | 224;
                        output[offset++] = value >> 6 & 63 | 128;
                      } else {
                        output[offset++] = value >> 18 & 7 | 240;
                        output[offset++] = value >> 12 & 63 | 128;
                        output[offset++] = value >> 6 & 63 | 128;
                      }
                    }
                    output[offset++] = value & 63 | 128;
                  }
                }
                var sharedTextEncoder = TEXT_ENCODING_AVAILABLE ? new TextEncoder() : void 0;
                var TEXT_ENCODER_THRESHOLD = !TEXT_ENCODING_AVAILABLE ? _int_mjs__WEBPACK_IMPORTED_MODULE_0__.UINT32_MAX : typeof process !== "undefined" && ((_b = process === null || process === void 0 ? void 0 : process.env) === null || _b === void 0 ? void 0 : _b["TEXT_ENCODING"]) !== "force" ? 200 : 0;
                function utf8EncodeTEencode(str, output, outputOffset) {
                  output.set(sharedTextEncoder.encode(str), outputOffset);
                }
                function utf8EncodeTEencodeInto(str, output, outputOffset) {
                  sharedTextEncoder.encodeInto(str, output.subarray(outputOffset));
                }
                var utf8EncodeTE = (sharedTextEncoder === null || sharedTextEncoder === void 0 ? void 0 : sharedTextEncoder.encodeInto) ? utf8EncodeTEencodeInto : utf8EncodeTEencode;
                var CHUNK_SIZE = 4096;
                function utf8DecodeJs(bytes, inputOffset, byteLength) {
                  var offset = inputOffset;
                  var end = offset + byteLength;
                  var units = [];
                  var result = "";
                  while (offset < end) {
                    var byte1 = bytes[offset++];
                    if ((byte1 & 128) === 0) {
                      units.push(byte1);
                    } else if ((byte1 & 224) === 192) {
                      var byte2 = bytes[offset++] & 63;
                      units.push((byte1 & 31) << 6 | byte2);
                    } else if ((byte1 & 240) === 224) {
                      var byte2 = bytes[offset++] & 63;
                      var byte3 = bytes[offset++] & 63;
                      units.push((byte1 & 31) << 12 | byte2 << 6 | byte3);
                    } else if ((byte1 & 248) === 240) {
                      var byte2 = bytes[offset++] & 63;
                      var byte3 = bytes[offset++] & 63;
                      var byte4 = bytes[offset++] & 63;
                      var unit = (byte1 & 7) << 18 | byte2 << 12 | byte3 << 6 | byte4;
                      if (unit > 65535) {
                        unit -= 65536;
                        units.push(unit >>> 10 & 1023 | 55296);
                        unit = 56320 | unit & 1023;
                      }
                      units.push(unit);
                    } else {
                      units.push(byte1);
                    }
                    if (units.length >= CHUNK_SIZE) {
                      result += String.fromCharCode.apply(String, units);
                      units.length = 0;
                    }
                  }
                  if (units.length > 0) {
                    result += String.fromCharCode.apply(String, units);
                  }
                  return result;
                }
                var sharedTextDecoder = TEXT_ENCODING_AVAILABLE ? new TextDecoder() : null;
                var TEXT_DECODER_THRESHOLD = !TEXT_ENCODING_AVAILABLE ? _int_mjs__WEBPACK_IMPORTED_MODULE_0__.UINT32_MAX : typeof process !== "undefined" && ((_c = process === null || process === void 0 ? void 0 : process.env) === null || _c === void 0 ? void 0 : _c["TEXT_DECODER"]) !== "force" ? 200 : 0;
                function utf8DecodeTD(bytes, inputOffset, byteLength) {
                  var stringBytes = bytes.subarray(inputOffset, inputOffset + byteLength);
                  return sharedTextDecoder.decode(stringBytes);
                }
              }
            )
            /******/
          };
          var __webpack_module_cache__ = {};
          function __webpack_require__(moduleId) {
            var cachedModule = __webpack_module_cache__[moduleId];
            if (cachedModule !== void 0) {
              return cachedModule.exports;
            }
            var module2 = __webpack_module_cache__[moduleId] = {
              /******/
              // no module.id needed
              /******/
              // no module.loaded needed
              /******/
              exports: {}
              /******/
            };
            __webpack_modules__[moduleId](module2, module2.exports, __webpack_require__);
            return module2.exports;
          }
          __webpack_require__.m = __webpack_modules__;
          (() => {
            __webpack_require__.d = (exports2, definition) => {
              for (var key in definition) {
                if (__webpack_require__.o(definition, key) && !__webpack_require__.o(exports2, key)) {
                  Object.defineProperty(exports2, key, { enumerable: true, get: definition[key] });
                }
              }
            };
          })();
          (() => {
            __webpack_require__.f = {};
            __webpack_require__.e = (chunkId) => {
              return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
                __webpack_require__.f[key](chunkId, promises);
                return promises;
              }, []));
            };
          })();
          (() => {
            __webpack_require__.u = (chunkId) => {
              return "" + chunkId + ".hypha-rpc-websocket.js";
            };
          })();
          (() => {
            __webpack_require__.g = function() {
              if (typeof globalThis === "object") return globalThis;
              try {
                return this || new Function("return this")();
              } catch (e) {
                if (typeof window === "object") return window;
              }
            }();
          })();
          (() => {
            __webpack_require__.o = (obj, prop) => Object.prototype.hasOwnProperty.call(obj, prop);
          })();
          (() => {
            var inProgress = {};
            var dataWebpackPrefix = "hyphaWebsocketClient:";
            __webpack_require__.l = (url, done, key, chunkId) => {
              if (inProgress[url]) {
                inProgress[url].push(done);
                return;
              }
              var script2, needAttach;
              if (key !== void 0) {
                var scripts = document.getElementsByTagName("script");
                for (var i = 0; i < scripts.length; i++) {
                  var s = scripts[i];
                  if (s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) {
                    script2 = s;
                    break;
                  }
                }
              }
              if (!script2) {
                needAttach = true;
                script2 = document.createElement("script");
                script2.charset = "utf-8";
                script2.timeout = 120;
                if (__webpack_require__.nc) {
                  script2.setAttribute("nonce", __webpack_require__.nc);
                }
                script2.setAttribute("data-webpack", dataWebpackPrefix + key);
                script2.src = url;
              }
              inProgress[url] = [done];
              var onScriptComplete = (prev, event2) => {
                script2.onerror = script2.onload = null;
                clearTimeout(timeout);
                var doneFns = inProgress[url];
                delete inProgress[url];
                script2.parentNode && script2.parentNode.removeChild(script2);
                doneFns && doneFns.forEach((fn) => fn(event2));
                if (prev) return prev(event2);
              };
              var timeout = setTimeout(onScriptComplete.bind(null, void 0, { type: "timeout", target: script2 }), 12e4);
              script2.onerror = onScriptComplete.bind(null, script2.onerror);
              script2.onload = onScriptComplete.bind(null, script2.onload);
              needAttach && document.head.appendChild(script2);
            };
          })();
          (() => {
            __webpack_require__.r = (exports2) => {
              if (typeof Symbol !== "undefined" && Symbol.toStringTag) {
                Object.defineProperty(exports2, Symbol.toStringTag, { value: "Module" });
              }
              Object.defineProperty(exports2, "__esModule", { value: true });
            };
          })();
          (() => {
            var scriptUrl;
            if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
            var document2 = __webpack_require__.g.document;
            if (!scriptUrl && document2) {
              if (document2.currentScript)
                scriptUrl = document2.currentScript.src;
              if (!scriptUrl) {
                var scripts = document2.getElementsByTagName("script");
                if (scripts.length) {
                  var i = scripts.length - 1;
                  while (i > -1 && (!scriptUrl || !/^http(s?):/.test(scriptUrl))) scriptUrl = scripts[i--].src;
                }
              }
            }
            if(!scriptUrl)scriptUrl="";
            scriptUrl = scriptUrl.replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
            __webpack_require__.p = scriptUrl;
          })();
          (() => {
            var installedChunks = {
              /******/
              "hyphaWebsocketClient": 0
              /******/
            };
            __webpack_require__.f.j = (chunkId, promises) => {
              var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : void 0;
              if (installedChunkData !== 0) {
                if (installedChunkData) {
                  promises.push(installedChunkData[2]);
                } else {
                  if (true) {
                    var promise = new Promise((resolve2, reject2) => installedChunkData = installedChunks[chunkId] = [resolve2, reject2]);
                    promises.push(installedChunkData[2] = promise);
                    var url = __webpack_require__.p + __webpack_require__.u(chunkId);
                    var error = new Error();
                    var loadingEnded = (event2) => {
                      if (__webpack_require__.o(installedChunks, chunkId)) {
                        installedChunkData = installedChunks[chunkId];
                        if (installedChunkData !== 0) installedChunks[chunkId] = void 0;
                        if (installedChunkData) {
                          var errorType = event2 && (event2.type === "load" ? "missing" : event2.type);
                          var realSrc = event2 && event2.target && event2.target.src;
                          error.message = "Loading chunk " + chunkId + " failed.\n(" + errorType + ": " + realSrc + ")";
                          error.name = "ChunkLoadError";
                          error.type = errorType;
                          error.request = realSrc;
                          installedChunkData[1](error);
                        }
                      }
                    };
                    __webpack_require__.l(url, loadingEnded, "chunk-" + chunkId, chunkId);
                  }
                }
              }
            };
            var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
              var [chunkIds, moreModules, runtime] = data;
              var moduleId, chunkId, i = 0;
              if (chunkIds.some((id) => installedChunks[id] !== 0)) {
                for (moduleId in moreModules) {
                  if (__webpack_require__.o(moreModules, moduleId)) {
                    __webpack_require__.m[moduleId] = moreModules[moduleId];
                  }
                }
                if (runtime) var result = runtime(__webpack_require__);
              }
              if (parentChunkLoadingFunction) parentChunkLoadingFunction(data);
              for (; i < chunkIds.length; i++) {
                chunkId = chunkIds[i];
                if (__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
                  installedChunks[chunkId][0]();
                }
                installedChunks[chunkId] = 0;
              }
            };
            var chunkLoadingGlobal = exports["webpackChunkhyphaWebsocketClient"] = exports["webpackChunkhyphaWebsocketClient"] || [];
            chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
            chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
          })();
          var __webpack_exports__ = {};
          __webpack_require__.r(__webpack_exports__);
          __webpack_require__.d(__webpack_exports__, {
            /* harmony export */
            API_VERSION: () => (
              /* reexport safe */
              _rpc_js__WEBPACK_IMPORTED_MODULE_0__.API_VERSION
            ),
            /* harmony export */
            HTTPStreamingRPCConnection: () => (
              /* reexport safe */
              _http_client_js__WEBPACK_IMPORTED_MODULE_4__.HTTPStreamingRPCConnection
            ),
            /* harmony export */
            LocalWebSocket: () => (
              /* binding */
              LocalWebSocket
            ),
            /* harmony export */
            RPC: () => (
              /* reexport safe */
              _rpc_js__WEBPACK_IMPORTED_MODULE_0__.RPC
            ),
            /* harmony export */
            connectToServer: () => (
              /* binding */
              connectToServer
            ),
            /* harmony export */
            connectToServerHTTP: () => (
              /* reexport safe */
              _http_client_js__WEBPACK_IMPORTED_MODULE_4__.connectToServerHTTP
            ),
            /* harmony export */
            getRTCService: () => (
              /* reexport safe */
              _webrtc_client_js__WEBPACK_IMPORTED_MODULE_3__.getRTCService
            ),
            /* harmony export */
            getRemoteService: () => (
              /* binding */
              getRemoteService
            ),
            /* harmony export */
            getRemoteServiceHTTP: () => (
              /* reexport safe */
              _http_client_js__WEBPACK_IMPORTED_MODULE_4__.getRemoteServiceHTTP
            ),
            /* harmony export */
            loadRequirements: () => (
              /* reexport safe */
              _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.loadRequirements
            ),
            /* harmony export */
            login: () => (
              /* binding */
              login
            ),
            /* harmony export */
            logout: () => (
              /* binding */
              logout
            ),
            /* harmony export */
            normalizeServerUrlHTTP: () => (
              /* reexport safe */
              _http_client_js__WEBPACK_IMPORTED_MODULE_4__.normalizeServerUrl
            ),
            /* harmony export */
            registerRTCService: () => (
              /* reexport safe */
              _webrtc_client_js__WEBPACK_IMPORTED_MODULE_3__.registerRTCService
            ),
            /* harmony export */
            schemaFunction: () => (
              /* reexport safe */
              _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction
            ),
            /* harmony export */
            setupLocalClient: () => (
              /* binding */
              setupLocalClient
            )
            /* harmony export */
          });
          var _rpc_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
            /*! ./rpc.js */
            "./src/rpc.js"
          );
          var _utils_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
            /*! ./utils/index.js */
            "./src/utils/index.js"
          );
          var _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
            /*! ./utils/schema.js */
            "./src/utils/schema.js"
          );
          var _webrtc_client_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
            /*! ./webrtc-client.js */
            "./src/webrtc-client.js"
          );
          var _http_client_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
            /*! ./http-client.js */
            "./src/http-client.js"
          );
          const MAX_RETRY = 1e6;
          class WebsocketRPCConnection {
            constructor(server_url2, client_id2, workspace2, token2, reconnection_token = null, timeout = 60, WebSocketClass = null, token_refresh_interval = 2 * 60 * 60, additional_headers = null) {
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(server_url2 && client_id2, "server_url and client_id are required");
              this._server_url = server_url2;
              this._client_id = client_id2;
              this._workspace = workspace2;
              this._token = token2;
              this._reconnection_token = reconnection_token;
              this._websocket = null;
              this._handle_message = null;
              this._handle_connected = null;
              this._handle_disconnected = null;
              this._timeout = timeout;
              this._WebSocketClass = WebSocketClass || WebSocket;
              this._closed = false;
              this._legacy_auth = null;
              this.connection_info = null;
              this._enable_reconnect = false;
              this._token_refresh_interval = token_refresh_interval;
              this.manager_id = null;
              this._refresh_token_task = null;
              this._reconnect_timeouts = /* @__PURE__ */ new Set();
              this._additional_headers = additional_headers;
            }
            /**
             * Centralized cleanup method to clear all timers and prevent resource leaks
             */
            _cleanup() {
              if (this._refresh_token_task) {
                clearInterval(this._refresh_token_task);
                this._refresh_token_task = null;
              }
              for (const timeoutId of this._reconnect_timeouts) {
                clearTimeout(timeoutId);
              }
              this._reconnect_timeouts.clear();
            }
            on_message(handler) {
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(handler, "handler is required");
              this._handle_message = handler;
            }
            on_connected(handler) {
              this._handle_connected = handler;
            }
            on_disconnected(handler) {
              this._handle_disconnected = handler;
            }
            async _attempt_connection(server_url2, attempt_fallback = true) {
              return new Promise((resolve2, reject2) => {
                this._legacy_auth = false;
                const websocket = new this._WebSocketClass(server_url2);
                websocket.binaryType = "arraybuffer";
                websocket.onopen = () => {
                  console.info("WebSocket connection established");
                  resolve2(websocket);
                };
                websocket.onerror = (event2) => {
                  console.error("WebSocket connection error:", event2);
                  reject2(new Error(`WebSocket connection error: ${event2}`));
                };
                websocket.onclose = (event2) => {
                  if (event2.code === 1003 && attempt_fallback) {
                    console.info(
                      "Received 1003 error, attempting connection with query parameters."
                    );
                    this._legacy_auth = true;
                    this._attempt_connection_with_query_params(server_url2).then(resolve2).catch(reject2);
                  } else if (this._handle_disconnected) {
                    this._handle_disconnected(event2.reason);
                  }
                };
              });
            }
            async _attempt_connection_with_query_params(server_url2) {
              const queryParamsParts = [];
              if (this._client_id)
                queryParamsParts.push(`client_id=${encodeURIComponent(this._client_id)}`);
              if (this._workspace)
                queryParamsParts.push(`workspace=${encodeURIComponent(this._workspace)}`);
              if (this._token)
                queryParamsParts.push(`token=${encodeURIComponent(this._token)}`);
              if (this._reconnection_token)
                queryParamsParts.push(
                  `reconnection_token=${encodeURIComponent(this._reconnection_token)}`
                );
              const queryString = queryParamsParts.length > 0 ? `?${queryParamsParts.join("&")}` : "";
              const full_url = server_url2 + queryString;
              return await this._attempt_connection(full_url, false);
            }
            _establish_connection() {
              return new Promise((resolve2, reject2) => {
                this._websocket.onmessage = (event2) => {
                  const data = event2.data;
                  const first_message = JSON.parse(data);
                  if (first_message.type == "connection_info") {
                    this.connection_info = first_message;
                    if (this._workspace) {
                      (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(
                        this.connection_info.workspace === this._workspace,
                        `Connected to the wrong workspace: ${this.connection_info.workspace}, expected: ${this._workspace}`
                      );
                    }
                    if (this.connection_info.reconnection_token) {
                      this._reconnection_token = this.connection_info.reconnection_token;
                    }
                    if (this.connection_info.reconnection_token_life_time) {
                      if (this._token_refresh_interval > this.connection_info.reconnection_token_life_time / 1.5) {
                        console.warn(
                          `Token refresh interval is too long (${this._token_refresh_interval}), setting it to 1.5 times of the token life time(${this.connection_info.reconnection_token_life_time}).`
                        );
                        this._token_refresh_interval = this.connection_info.reconnection_token_life_time / 1.5;
                      }
                    }
                    this.manager_id = this.connection_info.manager_id || null;
                    console.log(
                      `Successfully connected to the server, workspace: ${this.connection_info.workspace}, manager_id: ${this.manager_id}`
                    );
                    if (this.connection_info.announcement) {
                      console.log(`${this.connection_info.announcement}`);
                    }
                    resolve2(this.connection_info);
                  } else if (first_message.type == "error") {
                    const error = "ConnectionAbortedError: " + first_message.message;
                    console.error("Failed to connect, " + error);
                    reject2(new Error(error));
                    return;
                  } else {
                    console.error(
                      "ConnectionAbortedError: Unexpected message received from the server:",
                      data
                    );
                    reject2(
                      new Error(
                        "ConnectionAbortedError: Unexpected message received from the server"
                      )
                    );
                    return;
                  }
                };
              });
            }
            async open() {
              console.log(
                "Creating a new websocket connection to",
                this._server_url.split("?")[0]
              );
              try {
                this._websocket = await this._attempt_connection(this._server_url);
                if (this._legacy_auth) {
                  throw new Error(
                    "NotImplementedError: Legacy authentication is not supported"
                  );
                }
                const authInfo = JSON.stringify({
                  client_id: this._client_id,
                  workspace: this._workspace,
                  token: this._token,
                  reconnection_token: this._reconnection_token
                });
                this._websocket.send(authInfo);
                await (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.waitFor)(
                  this._establish_connection(),
                  this._timeout,
                  "Failed to receive the first message from the server"
                );
                if (this._token_refresh_interval > 0) {
                  setTimeout(() => {
                    this._send_refresh_token();
                    this._refresh_token_task = setInterval(() => {
                      this._send_refresh_token();
                    }, this._token_refresh_interval * 1e3);
                  }, 2e3);
                }
                this._enable_reconnect = true;
                this._closed = false;
                this._websocket.onmessage = (event2) => {
                  if (typeof event2.data === "string") {
                    const parsedData = JSON.parse(event2.data);
                    if (parsedData.type === "reconnection_token") {
                      this._reconnection_token = parsedData.reconnection_token;
                    } else {
                      console.log("Received message from the server:", parsedData);
                    }
                  } else {
                    this._handle_message(event2.data);
                  }
                };
                this._websocket.onerror = (event2) => {
                  console.error("WebSocket connection error:", event2);
                  this._cleanup();
                };
                this._websocket.onclose = this._handle_close.bind(this);
                if (this._handle_connected) {
                  this._handle_connected(this.connection_info);
                }
                return this.connection_info;
              } catch (error) {
                this._cleanup();
                console.error(
                  "Failed to connect to",
                  this._server_url.split("?")[0],
                  error
                );
                throw error;
              }
            }
            _send_refresh_token() {
              if (this._websocket && this._websocket.readyState === WebSocket.OPEN) {
                const refreshMessage = JSON.stringify({ type: "refresh_token" });
                this._websocket.send(refreshMessage);
              }
            }
            _handle_close(event2) {
              if (!this._closed && this._websocket && this._websocket.readyState === WebSocket.CLOSED) {
                this._cleanup();
                if (this._enable_reconnect) {
                  if ([1e3, 1001].includes(event2.code)) {
                    console.warn(
                      `Websocket connection closed gracefully by server (code: ${event2.code}): ${event2.reason} - attempting reconnect`
                    );
                  } else {
                    console.warn(
                      "Websocket connection closed unexpectedly (code: %s): %s",
                      event2.code,
                      event2.reason
                    );
                  }
                  let retry = 0;
                  const baseDelay = 1e3;
                  const maxDelay = 6e4;
                  const maxJitter = 0.1;
                  const reconnect = async () => {
                    if (this._closed) {
                      console.info("Connection was closed, stopping reconnection");
                      return;
                    }
                    try {
                      console.warn(
                        `Reconnecting to ${this._server_url.split("?")[0]} (attempt #${retry})`
                      );
                      await this.open();
                      await new Promise((resolve2) => setTimeout(resolve2, 500));
                      console.warn(
                        `Successfully reconnected to server ${this._server_url} (services re-registered)`
                      );
                    } catch (e) {
                      if (`${e}`.includes("ConnectionAbortedError:")) {
                        console.warn("Server refused to reconnect:", e);
                        this._closed = true;
                        if (this._handle_disconnected) {
                          this._handle_disconnected(`Server refused reconnection: ${e}`);
                        }
                        return;
                      } else if (`${e}`.includes("NotImplementedError:")) {
                        console.error(
                          `${e}
It appears that you are trying to connect to a hypha server that is older than 0.20.0, please upgrade the hypha server or use the websocket client in imjoy-rpc(https://www.npmjs.com/package/imjoy-rpc) instead`
                        );
                        this._closed = true;
                        if (this._handle_disconnected) {
                          this._handle_disconnected(`Server too old: ${e}`);
                        }
                        return;
                      }
                      if (e.name === "NetworkError" || e.message.includes("network")) {
                        console.error(`Network error during reconnection: ${e.message}`);
                      } else if (e.name === "TimeoutError" || e.message.includes("timeout")) {
                        console.error(
                          `Connection timeout during reconnection: ${e.message}`
                        );
                      } else {
                        console.error(
                          `Unexpected error during reconnection: ${e.message}`
                        );
                      }
                      const delay = Math.min(baseDelay * Math.pow(2, retry), maxDelay);
                      const jitter = (Math.random() * 2 - 1) * maxJitter * delay;
                      const finalDelay = Math.max(100, delay + jitter);
                      console.debug(
                        `Waiting ${(finalDelay / 1e3).toFixed(2)}s before next reconnection attempt`
                      );
                      const timeoutId = setTimeout(async () => {
                        this._reconnect_timeouts.delete(timeoutId);
                        if (this._websocket && this._websocket.readyState === WebSocket.OPEN) {
                          console.info("Connection restored externally");
                          return;
                        }
                        if (this._closed) {
                          console.info("Connection was closed, stopping reconnection");
                          return;
                        }
                        retry += 1;
                        if (retry < MAX_RETRY) {
                          await reconnect();
                        } else {
                          console.error(
                            `Failed to reconnect after ${MAX_RETRY} attempts, giving up.`
                          );
                          this._closed = true;
                          if (this._handle_disconnected) {
                            this._handle_disconnected(
                              "Max reconnection attempts exceeded"
                            );
                          }
                        }
                      }, finalDelay);
                      this._reconnect_timeouts.add(timeoutId);
                    }
                  };
                  reconnect();
                }
              } else {
                this._cleanup();
                if (this._handle_disconnected) {
                  this._handle_disconnected(event2.reason);
                }
              }
            }
            async emit_message(data) {
              if (this._closed) {
                throw new Error("Connection is closed");
              }
              if (!this._websocket || this._websocket.readyState !== WebSocket.OPEN) {
                await this.open();
              }
              try {
                this._websocket.send(data);
              } catch (exp) {
                console.error(`Failed to send data, error: ${exp}`);
                throw exp;
              }
            }
            disconnect(reason) {
              this._closed = true;
              if (this._websocket && this._websocket.readyState !== WebSocket.CLOSED && this._websocket.readyState !== WebSocket.CLOSING) {
                this._websocket.close(1e3, reason);
              }
              this._cleanup();
              console.info(`WebSocket connection disconnected (${reason})`);
            }
          }
          function normalizeServerUrl(server_url2) {
            if (!server_url2) throw new Error("server_url is required");
            if (server_url2.startsWith("http://")) {
              server_url2 = server_url2.replace("http://", "ws://").replace(/\/$/, "") + "/ws";
            } else if (server_url2.startsWith("https://")) {
              server_url2 = server_url2.replace("https://", "wss://").replace(/\/$/, "") + "/ws";
            }
            return server_url2;
          }
          async function login(config2) {
            const service_id = config2.login_service_id || "public/hypha-login";
            const workspace2 = config2.workspace;
            const expires_in = config2.expires_in;
            const timeout = config2.login_timeout || 60;
            const callback = config2.login_callback;
            const profile = config2.profile;
            const additional_headers = config2.additional_headers;
            const transport = config2.transport || "websocket";
            const server2 = await connectToServer({
              name: "initial login client",
              server_url: config2.server_url,
              additional_headers,
              transport
            });
            try {
              const svc = await server2.getService(service_id);
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(svc, `Failed to get the login service: ${service_id}`);
              let context2;
              if (workspace2) {
                context2 = await svc.start({ workspace: workspace2, expires_in, _rkwargs: true });
              } else {
                context2 = await svc.start();
              }
              if (callback) {
                await callback(context2);
              } else {
                console.log(`Please open your browser and login at ${context2.login_url}`);
              }
              return await svc.check(context2.key, { timeout, profile, _rkwargs: true });
            } catch (error) {
              throw error;
            } finally {
              await server2.disconnect();
            }
          }
          async function logout(config2) {
            const service_id = config2.login_service_id || "public/hypha-login";
            const callback = config2.logout_callback;
            const additional_headers = config2.additional_headers;
            const transport = config2.transport || "websocket";
            const server2 = await connectToServer({
              name: "initial logout client",
              server_url: config2.server_url,
              additional_headers,
              transport
            });
            try {
              const svc = await server2.getService(service_id);
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(svc, `Failed to get the login service: ${service_id}`);
              if (!svc.logout) {
                throw new Error(
                  "Logout is not supported by this server. Please upgrade the Hypha server to a version that supports logout."
                );
              }
              const context2 = await svc.logout({});
              if (callback) {
                await callback(context2);
              } else {
                console.log(
                  `Please open your browser to logout at ${context2.logout_url}`
                );
              }
              return context2;
            } catch (error) {
              throw error;
            } finally {
              await server2.disconnect();
            }
          }
          async function webrtcGetService(wm, query, config2) {
            config2 = config2 || {};
            const webrtc = config2.webrtc !== void 0 ? config2.webrtc : "auto";
            const webrtc_config = config2.webrtc_config;
            if (config2.webrtc !== void 0) delete config2.webrtc;
            if (config2.webrtc_config !== void 0) delete config2.webrtc_config;
            (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(
              [void 0, true, false, "auto"].includes(webrtc),
              "webrtc must be true, false or 'auto'"
            );
            const svc = await wm.getService(query, config2);
            if (webrtc === true || webrtc === "auto") {
              if (svc.id.includes(":") && svc.id.includes("/")) {
                try {
                  const wsAndClient = svc.id.split(":")[0];
                  const parts = wsAndClient.split("/");
                  const remoteClientId = parts[parts.length - 1];
                  const remoteWorkspace = parts.slice(0, -1).join("/");
                  const remoteRtcServiceId = `${remoteWorkspace}/${remoteClientId}-rtc`;
                  const peer = await (0, _webrtc_client_js__WEBPACK_IMPORTED_MODULE_3__.getRTCService)(wm, remoteRtcServiceId, webrtc_config);
                  const rtcSvc = await peer.getService(svc.id.split(":")[1], config2);
                  rtcSvc._webrtc = true;
                  rtcSvc._peer = peer;
                  rtcSvc._service = svc;
                  return rtcSvc;
                } catch (e) {
                  console.warn(
                    "Failed to get webrtc service, using websocket connection",
                    e
                  );
                }
              }
              if (webrtc === true) {
                throw new Error("Failed to get the service via webrtc");
              }
            }
            return svc;
          }
          async function connectToServer(config2) {
            const transport = config2.transport || "websocket";
            if (transport === "http") {
              return await (0, _http_client_js__WEBPACK_IMPORTED_MODULE_4__.connectToServerHTTP)(config2);
            }
            if (config2.server) {
              config2.server_url = config2.server_url || config2.server.url;
              config2.WebSocketClass = config2.WebSocketClass || config2.server.WebSocketClass;
            }
            let clientId = config2.client_id;
            if (!clientId) {
              clientId = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.randId)();
              config2.client_id = clientId;
            }
            if (Object.keys(config2).length === 0) {
              if (typeof process !== "undefined" && process.env) {
                config2.server_url = process.env.HYPHA_SERVER_URL;
                config2.token = process.env.HYPHA_TOKEN;
                config2.client_id = process.env.HYPHA_CLIENT_ID;
                config2.workspace = process.env.HYPHA_WORKSPACE;
              } else if (typeof self !== "undefined" && self.env) {
                config2.server_url = self.env.HYPHA_SERVER_URL;
                config2.token = self.env.HYPHA_TOKEN;
                config2.client_id = self.env.HYPHA_CLIENT_ID;
                config2.workspace = self.env.HYPHA_WORKSPACE;
              } else if (typeof globalThis !== "undefined" && globalThis.env) {
                config2.server_url = globalThis.env.HYPHA_SERVER_URL;
                config2.token = globalThis.env.HYPHA_TOKEN;
                config2.client_id = globalThis.env.HYPHA_CLIENT_ID;
                config2.workspace = globalThis.env.HYPHA_WORKSPACE;
              }
            }
            let server_url2 = normalizeServerUrl(config2.server_url);
            let connection = new WebsocketRPCConnection(
              server_url2,
              clientId,
              config2.workspace,
              config2.token,
              config2.reconnection_token,
              config2.method_timeout || 60,
              config2.WebSocketClass,
              config2.token_refresh_interval,
              config2.additional_headers
            );
            const connection_info = await connection.open();
            (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(
              connection_info,
              "Failed to connect to the server, no connection info obtained. This issue is most likely due to an outdated Hypha server version. Please use `imjoy-rpc` for compatibility, or upgrade the Hypha server to the latest version."
            );
            await new Promise((resolve2) => setTimeout(resolve2, 100));
            if (!connection.manager_id) {
              console.warn("Manager ID not set immediately, waiting...");
              const maxWaitTime = 5e3;
              const checkInterval = 100;
              const startTime = Date.now();
              while (!connection.manager_id && Date.now() - startTime < maxWaitTime) {
                await new Promise((resolve2) => setTimeout(resolve2, checkInterval));
              }
              if (!connection.manager_id) {
                console.error("Manager ID still not set after waiting");
                throw new Error("Failed to get manager ID from server");
              } else {
                console.info(`Manager ID set after waiting: ${connection.manager_id}`);
              }
            }
            if (config2.workspace && connection_info.workspace !== config2.workspace) {
              throw new Error(
                `Connected to the wrong workspace: ${connection_info.workspace}, expected: ${config2.workspace}`
              );
            }
            const workspace2 = connection_info.workspace;
            const rpc = new _rpc_js__WEBPACK_IMPORTED_MODULE_0__.RPC(connection, {
              client_id: clientId,
              workspace: workspace2,
              default_context: { connection_type: "websocket" },
              name: config2.name,
              method_timeout: config2.method_timeout,
              app_id: config2.app_id,
              server_base_url: connection_info.public_base_url,
              long_message_chunk_size: config2.long_message_chunk_size
            });
            await rpc.waitFor("services_registered", config2.method_timeout || 120);
            const wm = await rpc.get_manager_service({
              timeout: config2.method_timeout,
              case_conversion: "camel",
              kwargs_expansion: config2.kwargs_expansion || false
            });
            wm.rpc = rpc;
            async function _export(api) {
              api.id = "default";
              api.name = api.name || config2.name || api.id;
              api.description = api.description || config2.description;
              await rpc.register_service(api, { overwrite: true });
            }
            async function getApp(clientId2) {
              clientId2 = clientId2 || "*";
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(!clientId2.includes(":"), "clientId should not contain ':'");
              if (!clientId2.includes("/")) {
                clientId2 = connection_info.workspace + "/" + clientId2;
              }
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(
                clientId2.split("/").length === 2,
                "clientId should match pattern workspace/clientId"
              );
              return await wm.getService(`${clientId2}:default`);
            }
            async function listApps(ws) {
              ws = ws || workspace2;
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(!ws.includes(":"), "workspace should not contain ':'");
              (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.assert)(!ws.includes("/"), "workspace should not contain '/'");
              const query = { workspace: ws, service_id: "default" };
              return await wm.listServices(query);
            }
            if (connection_info) {
              wm.config = Object.assign(wm.config, connection_info);
            }
            wm.export = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(_export, {
              name: "export",
              description: "Export the api.",
              parameters: {
                properties: { api: { description: "The api to export", type: "object" } },
                required: ["api"],
                type: "object"
              }
            });
            wm.getApp = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(getApp, {
              name: "getApp",
              description: "Get the app.",
              parameters: {
                properties: {
                  clientId: { default: "*", description: "The clientId", type: "string" }
                },
                type: "object"
              }
            });
            wm.listApps = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(listApps, {
              name: "listApps",
              description: "List the apps.",
              parameters: {
                properties: {
                  workspace: {
                    default: workspace2,
                    description: "The workspace",
                    type: "string"
                  }
                },
                type: "object"
              }
            });
            wm.disconnect = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.disconnect.bind(rpc), {
              name: "disconnect",
              description: "Disconnect from the server.",
              parameters: { type: "object", properties: {}, required: [] }
            });
            wm.registerCodec = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.register_codec.bind(rpc), {
              name: "registerCodec",
              description: "Register a codec for the webrtc connection",
              parameters: {
                type: "object",
                properties: {
                  codec: {
                    type: "object",
                    description: "Codec to register",
                    properties: {
                      name: { type: "string" },
                      type: {},
                      encoder: { type: "function" },
                      decoder: { type: "function" }
                    }
                  }
                }
              }
            });
            wm.emit = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.emit.bind(rpc), {
              name: "emit",
              description: "Emit a message.",
              parameters: {
                properties: { data: { description: "The data to emit", type: "object" } },
                required: ["data"],
                type: "object"
              }
            });
            wm.on = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.on.bind(rpc), {
              name: "on",
              description: "Register a message handler.",
              parameters: {
                properties: {
                  event: { description: "The event to listen to", type: "string" },
                  handler: { description: "The handler function", type: "function" }
                },
                required: ["event", "handler"],
                type: "object"
              }
            });
            wm.off = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.off.bind(rpc), {
              name: "off",
              description: "Remove a message handler.",
              parameters: {
                properties: {
                  event: { description: "The event to remove", type: "string" },
                  handler: { description: "The handler function", type: "function" }
                },
                required: ["event", "handler"],
                type: "object"
              }
            });
            wm.once = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.once.bind(rpc), {
              name: "once",
              description: "Register a one-time message handler.",
              parameters: {
                properties: {
                  event: { description: "The event to listen to", type: "string" },
                  handler: { description: "The handler function", type: "function" }
                },
                required: ["event", "handler"],
                type: "object"
              }
            });
            wm.getServiceSchema = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.get_service_schema, {
              name: "getServiceSchema",
              description: "Get the service schema.",
              parameters: {
                properties: {
                  service: {
                    description: "The service to extract schema",
                    type: "object"
                  }
                },
                required: ["service"],
                type: "object"
              }
            });
            wm.registerService = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.register_service.bind(rpc), {
              name: "registerService",
              description: "Register a service.",
              parameters: {
                properties: {
                  service: { description: "The service to register", type: "object" },
                  force: {
                    default: false,
                    description: "Force to register the service",
                    type: "boolean"
                  }
                },
                required: ["service"],
                type: "object"
              }
            });
            wm.unregisterService = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(rpc.unregister_service.bind(rpc), {
              name: "unregisterService",
              description: "Unregister a service.",
              parameters: {
                properties: {
                  service: {
                    description: "The service id to unregister",
                    type: "string"
                  },
                  notify: {
                    default: true,
                    description: "Notify the workspace manager",
                    type: "boolean"
                  }
                },
                required: ["service"],
                type: "object"
              }
            });
            if (connection.manager_id) {
              rpc.on("force-exit", async (message) => {
                if (message.from === "*/" + connection.manager_id) {
                  console.log("Disconnecting from server, reason:", message.reason);
                  await rpc.disconnect();
                }
              });
            }
            if (config2.webrtc) {
              await (0, _webrtc_client_js__WEBPACK_IMPORTED_MODULE_3__.registerRTCService)(wm, `${clientId}-rtc`, config2.webrtc_config);
              const _wm = Object.assign({}, wm);
              const description = _wm.getService.__schema__.description;
              const parameters = _wm.getService.__schema__.parameters;
              wm.getService = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(
                webrtcGetService.bind(null, _wm),
                {
                  name: "getService",
                  description,
                  parameters
                }
              );
              wm.getRTCService = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(_webrtc_client_js__WEBPACK_IMPORTED_MODULE_3__.getRTCService.bind(null, wm), {
                name: "getRTCService",
                description: "Get the webrtc connection, returns a peer connection.",
                parameters: {
                  properties: {
                    config: {
                      description: "The config for the webrtc service",
                      type: "object"
                    }
                  },
                  required: ["config"],
                  type: "object"
                }
              });
            } else {
              const _getService = wm.getService;
              wm.getService = (query, config3) => {
                config3 = config3 || {};
                return _getService(query, config3);
              };
              wm.getService.__schema__ = _getService.__schema__;
            }
            async function registerProbes(probes) {
              probes.id = "probes";
              probes.name = "Probes";
              probes.config = { visibility: "public" };
              probes.type = "probes";
              probes.description = `Probes Service, visit ${server_url2}/${workspace2}services/probes for the available probes.`;
              return await wm.registerService(probes, { overwrite: true });
            }
            wm.registerProbes = (0, _utils_schema_js__WEBPACK_IMPORTED_MODULE_2__.schemaFunction)(registerProbes, {
              name: "registerProbes",
              description: "Register probes service",
              parameters: {
                properties: {
                  probes: {
                    description: "The probes to register, e.g. {'liveness': {'type': 'function', 'description': 'Check the liveness of the service'}}",
                    type: "object"
                  }
                },
                required: ["probes"],
                type: "object"
              }
            });
            return wm;
          }
          async function getRemoteService(serviceUri, config2 = {}) {
            const { serverUrl, workspace: workspace2, clientId, serviceId, appId } = (0, _utils_index_js__WEBPACK_IMPORTED_MODULE_1__.parseServiceUrl)(serviceUri);
            const fullServiceId = `${workspace2}/${clientId}:${serviceId}@${appId}`;
            if (config2.serverUrl) {
              if (config2.serverUrl !== serverUrl) {
                throw new Error(
                  "server_url in config does not match the server_url in the url"
                );
              }
            }
            config2.serverUrl = serverUrl;
            const server2 = await connectToServer(config2);
            return await server2.getService(fullServiceId);
          }
          class LocalWebSocket {
            constructor(url, client_id2, workspace2) {
              this.url = url;
              this.onopen = () => {
              };
              this.onmessage = () => {
              };
              this.onclose = () => {
              };
              this.onerror = () => {
              };
              this.client_id = client_id2;
              this.workspace = workspace2;
              const context2 = typeof window !== "undefined" ? window : self;
              const isWindow2 = typeof window !== "undefined";
              this.postMessage = (message) => {
                if (isWindow2) {
                  window.parent.postMessage(message, "*");
                } else {
                  self.postMessage(message);
                }
              };
              this.readyState = WebSocket.CONNECTING;
              context2.addEventListener(
                "message",
                (event2) => {
                  const { type: type2, data, to } = event2.data;
                  if (to !== this.client_id) {
                    return;
                  }
                  switch (type2) {
                    case "message":
                      if (this.readyState === WebSocket.OPEN && this.onmessage) {
                        this.onmessage({ data });
                      }
                      break;
                    case "connected":
                      this.readyState = WebSocket.OPEN;
                      this.onopen(event2);
                      break;
                    case "closed":
                      this.readyState = WebSocket.CLOSED;
                      this.onclose(event2);
                      break;
                    default:
                      break;
                  }
                },
                false
              );
              if (!this.client_id) throw new Error("client_id is required");
              if (!this.workspace) throw new Error("workspace is required");
              this.postMessage({
                type: "connect",
                url: this.url,
                from: this.client_id,
                workspace: this.workspace
              });
            }
            send(data) {
              if (this.readyState === WebSocket.OPEN) {
                this.postMessage({
                  type: "message",
                  data,
                  from: this.client_id,
                  workspace: this.workspace
                });
              }
            }
            close() {
              this.readyState = WebSocket.CLOSING;
              this.postMessage({
                type: "close",
                from: this.client_id,
                workspace: this.workspace
              });
              this.onclose();
            }
            addEventListener(type2, listener) {
              if (type2 === "message") {
                this.onmessage = listener;
              }
              if (type2 === "open") {
                this.onopen = listener;
              }
              if (type2 === "close") {
                this.onclose = listener;
              }
              if (type2 === "error") {
                this.onerror = listener;
              }
            }
          }
          function setupLocalClient({
            enable_execution = false,
            on_ready = null
          }) {
            return new Promise((resolve, reject) => {
              const context = typeof window !== "undefined" ? window : self;
              const isWindow = typeof window !== "undefined";
              context.addEventListener(
                "message",
                (event) => {
                  const {
                    type,
                    server_url,
                    workspace,
                    client_id,
                    token,
                    method_timeout,
                    name,
                    config
                  } = event.data;
                  if (type === "initializeHyphaClient") {
                    if (!server_url || !workspace || !client_id) {
                      console.error("server_url, workspace, and client_id are required.");
                      return;
                    }
                    if (!server_url.startsWith("https://local-hypha-server:")) {
                      console.error(
                        "server_url should start with https://local-hypha-server:"
                      );
                      return;
                    }
                    class FixedLocalWebSocket extends LocalWebSocket {
                      constructor(url) {
                        super(url, client_id, workspace);
                      }
                    }
                    connectToServer({
                      server_url,
                      workspace,
                      client_id,
                      token,
                      method_timeout,
                      name,
                      WebSocketClass: FixedLocalWebSocket
                    }).then(async (server) => {
                      globalThis.api = server;
                      try {
                        if (isWindow && enable_execution) {
                          let loadScript = function(script2) {
                            return new Promise((resolve2, reject2) => {
                              const scriptElement = document.createElement("script");
                              scriptElement.innerHTML = script2.content;
                              scriptElement.lang = script2.lang;
                              scriptElement.onload = () => resolve2();
                              scriptElement.onerror = (e) => reject2(e);
                              document.head.appendChild(scriptElement);
                            });
                          };
                          if (config.styles && config.styles.length > 0) {
                            for (const style of config.styles) {
                              const styleElement = document.createElement("style");
                              styleElement.innerHTML = style.content;
                              styleElement.lang = style.lang;
                              document.head.appendChild(styleElement);
                            }
                          }
                          if (config.links && config.links.length > 0) {
                            for (const link of config.links) {
                              const linkElement = document.createElement("a");
                              linkElement.href = link.url;
                              linkElement.innerText = link.text;
                              document.body.appendChild(linkElement);
                            }
                          }
                          if (config.windows && config.windows.length > 0) {
                            for (const w of config.windows) {
                              document.body.innerHTML = w.content;
                              break;
                            }
                          }
                          if (config.scripts && config.scripts.length > 0) {
                            for (const script2 of config.scripts) {
                              if (script2.lang !== "javascript")
                                throw new Error("Only javascript scripts are supported");
                              await loadScript(script2);
                            }
                          }
                        } else if (!isWindow && enable_execution && config.scripts && config.scripts.length > 0) {
                          for (const script of config.scripts) {
                            if (script.lang !== "javascript")
                              throw new Error("Only javascript scripts are supported");
                            eval(script.content);
                          }
                        }
                        if (on_ready) {
                          await on_ready(server, config);
                        }
                        resolve(server);
                      } catch (e) {
                        reject(e);
                      }
                    });
                  }
                },
                false
              );
              if (isWindow) {
                window.parent.postMessage({ type: "hyphaClientReady" }, "*");
              } else {
                self.postMessage({ type: "hyphaClientReady" });
              }
            });
          }
          return __webpack_exports__;
        })()
      );
    });
  }
});

// node_modules/hypha-rpc/index.js
var require_hypha_rpc = __commonJS({
  "node_modules/hypha-rpc/index.js"(exports2, module2) {
    module2.exports = { hyphaWebsocketClient: require_hypha_rpc_websocket() };
  }
});

// ../extension/src/offscreen.ts
var hyphaRpc = __toESM(require_hypha_rpc());

// src/relay/service-url.ts
function buildServiceUrl(serverUrl, serviceId) {
  const base = serverUrl.replace(/\/+$/, "");
  const slashIdx = serviceId.indexOf("/");
  if (slashIdx !== -1) {
    const workspace2 = serviceId.substring(0, slashIdx);
    const svcPart = serviceId.substring(slashIdx + 1);
    const colonIdx = svcPart.indexOf(":");
    const svcName = colonIdx !== -1 ? svcPart.substring(colonIdx + 1) : svcPart;
    return `${base}/${workspace2}/services/${svcName}`;
  }
  return `${base}/services/${serviceId}`;
}
function randomHex(bytes = 8) {
  const arr = new Uint8Array(bytes);
  crypto.getRandomValues(arr);
  return Array.from(arr, (b) => b.toString(16).padStart(2, "0")).join("");
}

// src/utils/wrap-fn.ts
function wrapFn(fn) {
  const schema = fn.__schema__;
  const paramNames = schema?.parameters?.properties ? Object.keys(schema.parameters.properties) : [];
  if (paramNames.length === 0) {
    return fn;
  }
  const wrapper = async function(...args) {
    if (args.length === 1 && args[0] != null && typeof args[0] === "object" && !Array.isArray(args[0]) && !(args[0] instanceof Date) && // Plain-object check that is realm-agnostic (kwargs may be created in a
    // different realm — e.g. hypha-rpc's HTTP handler, or relayed across a
    // postMessage/extension boundary). `constructor === Object` fails across
    // realms, so also accept the constructor name and a null prototype.
    isPlainObject(args[0])) {
      const kw = args[0];
      const keys = Object.keys(kw);
      if (keys.length === 0) {
        return fn();
      }
      if (paramNames.indexOf(keys[0]) !== -1) {
        return fn.apply(null, paramNames.map((n) => kw[n]));
      }
    }
    return fn.apply(null, args);
  };
  const fakeSource = `function (${paramNames.join(", ")}) {}`;
  try {
    Object.defineProperty(wrapper, "toString", {
      value: () => fakeSource,
      writable: true,
      configurable: true
    });
    Object.defineProperty(wrapper, "length", {
      value: paramNames.length,
      configurable: true
    });
  } catch {
    wrapper.toString = () => fakeSource;
  }
  if (schema) wrapper.__schema__ = schema;
  return wrapper;
}
function isPlainObject(x) {
  const proto = Object.getPrototypeOf(x);
  return proto === null || proto === Object.prototype || proto?.constructor?.name === "Object";
}

// src/relay/connector.ts
var RelayConnector = class {
  constructor(channel, cfg, opts = {}) {
    this.channel = channel;
    this.cfg = cfg;
    this.opts = opts;
  }
  server = null;
  pending = /* @__PURE__ */ new Map();
  unsub = null;
  start() {
    this.unsub = this.channel.onMessage((msg) => this.handle(msg));
    this.channel.post({ t: "connector-ready" });
  }
  stop() {
    this.unsub?.();
    this.unsub = null;
    for (const { timer, reject: reject2 } of this.pending.values()) {
      clearTimeout(timer);
      reject2(new Error("connector stopped"));
    }
    this.pending.clear();
  }
  handle(msg) {
    switch (msg.t) {
      case "hello":
        void this.onHello(msg);
        break;
      case "result":
        this.settle(msg.id, void 0, msg.result);
        break;
      case "error":
        this.settle(msg.id, msg.error);
        break;
    }
  }
  async onHello(msg) {
    try {
      this.opts.onStatus?.("connecting");
      const connectConfig = { server_url: this.cfg.server_url };
      if (this.cfg.workspace) connectConfig.workspace = this.cfg.workspace;
      if (this.cfg.token) connectConfig.token = this.cfg.token;
      try {
        this.server = await this.cfg.connect(connectConfig);
      } catch (e) {
        if (this.cfg.workspace) {
          this.server = await this.cfg.connect({
            server_url: this.cfg.server_url
          });
        } else {
          throw e;
        }
      }
      const requireToken = this.cfg.require_token ?? false;
      const visibility = this.cfg.visibility ?? (requireToken ? "protected" : "unlisted");
      const serviceId = this.cfg.service_id ?? `web-debugger-${randomHex(16)}`;
      const def = {
        id: serviceId,
        name: this.cfg.service_name ?? msg.meta?.name ?? "Web Debugger",
        type: msg.meta?.type ?? "debugger",
        description: msg.meta?.description ?? "Remote web page debugger.",
        config: { visibility }
      };
      for (const { name: name2, schema } of msg.services) {
        def[name2] = this.makeProxy(name2, schema);
      }
      const info = await this.server.registerService(def);
      const serviceUrl = buildServiceUrl(
        this.cfg.server_url,
        info.id ?? serviceId
      );
      const workspace2 = this.server.config?.workspace ?? "";
      const token2 = requireToken ? await this.server.generateToken({ expires_in: 86400 }) : "";
      this.channel.post({ t: "ready", service_url: serviceUrl, token: token2, workspace: workspace2 });
      this.opts.onStatus?.("connected", serviceUrl);
    } catch (err) {
      this.opts.onStatus?.("error", err?.message ?? String(err));
      this.channel.post({
        t: "status",
        status: "error",
        detail: err?.message ?? String(err)
      });
    }
  }
  /**
   * Build a proxy function for one service method. Wrapped with baseWrapFn so it
   * carries the schema + the toString() param-name trick — this is what keeps
   * HTTP kwargs ({code: "..."}) mapping to positional args correctly. baseWrapFn
   * converts kwargs→positional BEFORE we relay, so the Agent calls the raw
   * service fn with plain positional args.
   */
  makeProxy(name2, schema) {
    const inner = async (...args) => this.relayCall(name2, args);
    inner.__schema__ = schema;
    return wrapFn(inner);
  }
  relayCall(method, args) {
    const id = randomHex(8);
    const timeoutMs = this.opts.callTimeoutMs ?? 6e4;
    return new Promise((resolve2, reject2) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject2(new Error(`relay call "${method}" timed out`));
      }, timeoutMs);
      this.pending.set(id, { resolve: resolve2, reject: reject2, timer });
      this.channel.post({ t: "call", id, method, args });
    });
  }
  settle(id, error, result) {
    const p = this.pending.get(id);
    if (!p) return;
    clearTimeout(p.timer);
    this.pending.delete(id);
    if (error) p.reject(new Error(error));
    else p.resolve(result);
  }
};

// ../extension/src/runtime-channel.ts
var RELAY_ENVELOPE = "__hyphaRelayEnvelope";
var ConnectorRuntimeChannel = class {
  constructor(tabId) {
    this.tabId = tabId;
  }
  post(msg) {
    const env = {
      [RELAY_ENVELOPE]: true,
      dir: "toAgent",
      tabId: this.tabId,
      payload: msg
    };
    try {
      chrome.runtime.sendMessage(env).catch(() => {
      });
    } catch {
    }
  }
  onMessage(cb) {
    const handler = (m) => {
      if (m && m[RELAY_ENVELOPE] && m.dir === "toConnector" && m.tabId === this.tabId)
        cb(m.payload);
    };
    chrome.runtime.onMessage.addListener(handler);
    return () => chrome.runtime.onMessage.removeListener(handler);
  }
};

// ../extension/src/offscreen.ts
var connectors = /* @__PURE__ */ new Map();
function getConnect() {
  const override = globalThis.__HYPHA_CONNECT__;
  if (typeof override === "function") return override;
  const mod = hyphaRpc;
  if (mod.connectToServer) return mod.connectToServer;
  if (mod.hyphaWebsocketClient?.connectToServer)
    return mod.hyphaWebsocketClient.connectToServer;
  const w = self;
  if (w.hyphaWebsocketClient?.connectToServer)
    return w.hyphaWebsocketClient.connectToServer;
  throw new Error("hypha-rpc connectToServer not found");
}
function ui(tabId, data) {
  chrome.runtime.sendMessage({ __hyphaUi: true, tabId, ...data }).catch(() => {
  });
}
function createConnector(tabId, config2) {
  connectors.get(tabId)?.stop();
  const channel = new ConnectorRuntimeChannel(tabId);
  const conn = new RelayConnector(
    channel,
    {
      server_url: config2.server_url,
      workspace: config2.workspace || void 0,
      token: config2.token || void 0,
      service_id: config2.service_id || void 0,
      service_name: config2.service_name || void 0,
      require_token: !!config2.require_token,
      connect: getConnect()
    },
    {
      onStatus: (status, detail) => ui(tabId, { type: "status", status, detail })
    }
  );
  connectors.set(tabId, conn);
  ui(tabId, { type: "status", status: "connecting" });
  conn.start();
}
function destroyConnector(tabId) {
  connectors.get(tabId)?.stop();
  connectors.delete(tabId);
}
chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== "object") return;
  if (msg.__hyphaCtl === "createConnector") createConnector(msg.tabId, msg.config);
  else if (msg.__hyphaCtl === "destroyConnector") destroyConnector(msg.tabId);
  else if (msg.__hyphaUi && msg.__stamped && msg.type === "active" && msg.active) {
    for (const [tabId, config2] of Object.entries(msg.active)) {
      if (!connectors.has(Number(tabId))) createConnector(Number(tabId), config2);
    }
  }
});
chrome.runtime.sendMessage({ __hyphaCtl: "getActive" }).catch(() => {
});
