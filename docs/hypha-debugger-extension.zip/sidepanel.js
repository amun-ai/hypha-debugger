// src/relay/instruction.ts
function buildAgentInstruction(serviceUrl, opts = {}) {
  const where = opts.target ? ` ("${opts.target}")` : "";
  const auth = opts.token ? ` (auth header: Authorization: Bearer ${opts.token})` : "";
  return `A Hypha debugger is attached to this live web page${where} \u2014 call its HTTP API at ${serviceUrl} to inspect and control the page; GET ${serviceUrl}/get_skill_md for the full tool list and usage${auth}.`;
}

// ../extension/src/sidepanel.ts
var $ = (id) => document.getElementById(id);
var dot = $("dot");
var tabLabel = $("tab");
var serverInput = $("server");
var wsInput = $("workspace");
var tokenInput = $("token");
var requireToken = $("requireToken");
var connectBtn = $("connect");
var disconnectBtn = $("disconnect");
var urlBox = $("urlBox");
var urlCode = $("url");
var logsEl = $("logs");
var tabStates = /* @__PURE__ */ new Map();
var currentTabId = null;
var currentUrl = "";
function state(tabId) {
  let s = tabStates.get(tabId);
  if (!s) {
    s = { status: "disconnected", serviceUrl: "", logs: [] };
    tabStates.set(tabId, s);
  }
  return s;
}
function render() {
  if (currentTabId == null) return;
  const s = state(currentTabId);
  dot.className = "dot " + s.status;
  const connected = s.status === "connected";
  connectBtn.disabled = connected || s.status === "connecting";
  disconnectBtn.disabled = !connected && s.status !== "connecting";
  urlBox.className = "url" + (s.serviceUrl ? " show" : "");
  urlCode.textContent = s.serviceUrl;
  logsEl.innerHTML = "";
  for (const l of s.logs.slice(-300)) appendLogEl(l);
  logsEl.scrollTop = logsEl.scrollHeight;
}
function appendLogEl(l) {
  const div = document.createElement("div");
  div.className = "log " + l.kind;
  const t = new Date(l.ts).toLocaleTimeString();
  div.innerHTML = `<span class="t">${t}</span> <span class="k">${escapeHtml(l.msg)}</span>`;
  logsEl.appendChild(div);
}
function escapeHtml(s) {
  return s.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[c]);
}
function log(tabId, msg, kind) {
  const s = state(tabId);
  s.logs.push({ msg, kind, ts: Date.now() });
  if (s.logs.length > 500) s.logs.splice(0, s.logs.length - 500);
  if (tabId === currentTabId) {
    appendLogEl(s.logs[s.logs.length - 1]);
    logsEl.scrollTop = logsEl.scrollHeight;
  }
}
chrome.runtime.onMessage.addListener((m) => {
  if (!m || !m.__hyphaUi || !m.__stamped) return;
  if (m.type === "active") return;
  const tabId = m.tabId;
  if (tabId == null) return;
  const s = state(tabId);
  if (m.type === "log") {
    log(tabId, m.msg, m.kind);
  } else if (m.type === "status") {
    s.status = m.status === "agent-ready" ? s.status : m.status;
    log(tabId, `\xB7 ${m.status}${m.detail ? ": " + m.detail : ""}`, "status");
    if (m.status === "disconnected") s.serviceUrl = "";
    if (tabId === currentTabId) render();
  } else if (m.type === "ready") {
    s.status = "connected";
    s.serviceUrl = m.service_url;
    log(tabId, `connected \u2192 ${m.service_url}`, "result");
    if (tabId === currentTabId) render();
  }
});
async function refreshActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;
  currentTabId = tab.id;
  currentUrl = tab.url || "";
  tabLabel.textContent = hostOf(currentUrl);
  const active = (await chrome.storage.local.get("hyphaActiveConnections")).hyphaActiveConnections || {};
  if (active[String(currentTabId)] && state(currentTabId).status === "disconnected") {
    state(currentTabId).status = "connected";
  }
  render();
}
function hostOf(url) {
  try {
    return new URL(url).host || url;
  } catch {
    return url || "\u2014";
  }
}
chrome.tabs.onActivated.addListener(() => void refreshActiveTab());
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (tabId === currentTabId && info.url) void refreshActiveTab();
});
chrome.windows?.onFocusChanged?.addListener(() => void refreshActiveTab());
connectBtn.addEventListener("click", async () => {
  if (currentTabId == null) return;
  const config = {
    server_url: serverInput.value.trim() || "https://hypha.aicell.io",
    workspace: wsInput.value.trim(),
    token: tokenInput.value.trim(),
    require_token: requireToken.checked
  };
  await chrome.storage.local.set({ hyphaServerUrl: config.server_url });
  state(currentTabId).status = "connecting";
  state(currentTabId).serviceUrl = "";
  render();
  chrome.runtime.sendMessage({ __hyphaCtl: "connect", tabId: currentTabId, config });
});
disconnectBtn.addEventListener("click", () => {
  if (currentTabId == null) return;
  state(currentTabId).status = "disconnected";
  state(currentTabId).serviceUrl = "";
  chrome.runtime.sendMessage({ __hyphaCtl: "disconnect", tabId: currentTabId });
  render();
});
$("copyUrl").addEventListener("click", () => {
  if (currentTabId != null) navigator.clipboard.writeText(state(currentTabId).serviceUrl);
});
$("copySkill").addEventListener("click", () => {
  if (currentTabId == null) return;
  const url = state(currentTabId).serviceUrl;
  if (!url) return;
  navigator.clipboard.writeText(
    buildAgentInstruction(url, { target: hostOf(currentUrl) })
  );
});
$("clear").addEventListener("click", () => {
  if (currentTabId != null) state(currentTabId).logs = [];
  render();
});
(async () => {
  const stored = (await chrome.storage.local.get("hyphaServerUrl")).hyphaServerUrl;
  if (stored) serverInput.value = stored;
  await refreshActiveTab();
})();
