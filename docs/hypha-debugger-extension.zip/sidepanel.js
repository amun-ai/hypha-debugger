// src/relay/instruction.ts
function buildAgentInstruction(serviceUrl2, opts = {}) {
  const where = opts.target ? ` ("${opts.target}")` : "";
  const auth = opts.token ? ` (auth header: Authorization: Bearer ${opts.token})` : "";
  return `A Hypha debugger is attached to this live web page${where} \u2014 call its HTTP API at ${serviceUrl2} to inspect and control the page; GET ${serviceUrl2}/get_skill_md for the full tool list and usage${auth}.`;
}

// ../extension/src/sidepanel.ts
var $ = (id) => document.getElementById(id);
var dot = $("dot");
try {
  const v = "v" + chrome.runtime.getManifest().version;
  $("title").textContent = `Hypha Debugger ${v}`;
  document.title = `Hypha Debugger ${v}`;
} catch {
}
var serverInput = $("server");
var wsInput = $("workspace");
var tokenInput = $("token");
var requireToken = $("requireToken");
var connectBtn = $("connect");
var disconnectBtn = $("disconnect");
var urlBox = $("urlBox");
var urlCode = $("url");
var logsEl = $("logs");
var status = "disconnected";
var serviceUrl = "";
function render() {
  dot.className = "dot " + status;
  const connected = status === "connected";
  connectBtn.disabled = connected || status === "connecting";
  disconnectBtn.disabled = !connected && status !== "connecting";
  connectBtn.textContent = connected ? "Connected" : "Connect browser";
  urlBox.className = "url" + (serviceUrl ? " show" : "");
  urlCode.textContent = serviceUrl;
}
function appendLog(msg, kind) {
  const div = document.createElement("div");
  div.className = "log " + kind;
  div.innerHTML = `<span class="t">${(/* @__PURE__ */ new Date()).toLocaleTimeString()}</span> <span class="k">${escapeHtml(msg)}</span>`;
  logsEl.appendChild(div);
  while (logsEl.childElementCount > 400) logsEl.removeChild(logsEl.firstChild);
  logsEl.scrollTop = logsEl.scrollHeight;
}
function escapeHtml(s) {
  return s.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" })[c]);
}
function setTarget(tab) {
  const el = $("targetTab");
  const label = tab.title || tab.url || `tab ${tab.id}`;
  el.textContent = label;
  el.setAttribute("title", `${tab.title || ""}
${tab.url || ""}`);
}
chrome.runtime.onMessage.addListener((m) => {
  if (!m || !m.__ui) return;
  if (m.type === "log") {
    appendLog(m.msg, m.kind || "");
  } else if (m.type === "status") {
    status = m.status;
    if (m.status === "disconnected" || m.status === "error") serviceUrl = "";
    appendLog(`\xB7 ${m.status}${m.detail ? ": " + m.detail : ""}`, m.status === "error" ? "error" : "status");
    render();
  } else if (m.type === "ready") {
    status = "connected";
    serviceUrl = m.service_url;
    appendLog(`connected \u2192 ${m.service_url}`, "result");
    render();
  } else if (m.type === "target" && m.tab) {
    setTarget(m.tab);
  }
});
connectBtn.addEventListener("click", async () => {
  const config = {
    server_url: serverInput.value.trim() || "https://hypha.aicell.io",
    workspace: wsInput.value.trim(),
    token: tokenInput.value.trim(),
    require_token: requireToken.checked
  };
  await chrome.storage.local.set({ hyphaServerUrl: config.server_url });
  status = "connecting";
  serviceUrl = "";
  render();
  chrome.runtime.sendMessage({ __ctl: "connect", config });
});
disconnectBtn.addEventListener("click", () => {
  status = "disconnected";
  serviceUrl = "";
  render();
  chrome.runtime.sendMessage({ __ctl: "disconnect" });
});
$("copyUrl").addEventListener("click", () => {
  if (serviceUrl) navigator.clipboard.writeText(serviceUrl);
});
$("copySkill").addEventListener("click", () => {
  if (serviceUrl)
    navigator.clipboard.writeText(
      buildAgentInstruction(serviceUrl, { target: "this browser" }).replace(
        "this live web page",
        "this browser (open/close/navigate tabs + inspect & control pages)"
      )
    );
});
$("clear").addEventListener("click", () => {
  logsEl.innerHTML = "";
});
$("pinTab").addEventListener("click", () => {
  chrome.runtime.sendMessage({ __ctl: "pinActiveTab" });
});
var SKILLS_KEY = "hyphaSkills";
async function refreshSkillsInfo() {
  const all = (await chrome.storage.local.get(SKILLS_KEY))[SKILLS_KEY] || {};
  const sites = Object.keys(all).length;
  const entries = Object.values(all).reduce(
    (n, e) => n + Object.keys(e || {}).length,
    0
  );
  $("skillsInfo").textContent = `Skills: ${entries} across ${sites} site${sites === 1 ? "" : "s"}`;
}
$("exportSkills").addEventListener("click", async () => {
  const all = (await chrome.storage.local.get(SKILLS_KEY))[SKILLS_KEY] || {};
  const blob = new Blob([JSON.stringify(all, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "hypha-skills.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
  appendLog("exported skills", "status");
});
$("importSkills").addEventListener("click", () => {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = "application/json,.json";
  input.onchange = async () => {
    const file = input.files?.[0];
    if (!file) return;
    try {
      const imported = JSON.parse(await file.text());
      if (typeof imported !== "object" || Array.isArray(imported) || imported === null)
        throw new Error("not a skills object");
      const cur = (await chrome.storage.local.get(SKILLS_KEY))[SKILLS_KEY] || {};
      let merged = 0;
      for (const [site, entries] of Object.entries(imported)) {
        if (!entries || typeof entries !== "object") continue;
        cur[site] = { ...cur[site] || {}, ...entries };
        merged += Object.keys(entries).length;
      }
      await chrome.storage.local.set({ [SKILLS_KEY]: cur });
      await refreshSkillsInfo();
      appendLog(`imported ${merged} skill entr${merged === 1 ? "y" : "ies"}`, "result");
    } catch (e) {
      appendLog("import failed: " + (e?.message ?? e), "error");
    }
  };
  input.click();
});
chrome.storage.onChanged?.addListener?.((changes, area) => {
  if (area === "local" && changes[SKILLS_KEY]) void refreshSkillsInfo();
});
var saveTimer;
serverInput.addEventListener("input", () => {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    chrome.storage.local.set({ hyphaServerUrl: serverInput.value.trim() });
  }, 300);
});
(async () => {
  const r = await chrome.storage.local.get([
    "hyphaServerUrl",
    "hyphaStatus",
    "hyphaServiceUrl"
  ]);
  if (r.hyphaServerUrl) serverInput.value = r.hyphaServerUrl;
  if (r.hyphaStatus) status = r.hyphaStatus;
  if (r.hyphaServiceUrl) serviceUrl = r.hyphaServiceUrl;
  render();
  void refreshSkillsInfo();
  chrome.runtime.sendMessage({ __ctl: "getStatus" }).catch(() => {
  });
})();
